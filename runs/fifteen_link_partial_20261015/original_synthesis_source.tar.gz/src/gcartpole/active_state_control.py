"""Physically anchored active windows and checked minimum-change LP selection."""
import numpy as np
from scipy import sparse
from scipy.optimize import linprog
from .native_multiple_shooting_minimax_ipm import assemble_multiple_shooting_minimax

def active_state_control_problem(states, controls, A, B, C, angles, *, start, capture_start, protected_steps, **kwargs):
    """Freeze preceding increments exactly, including the measured start node."""
    h=len(controls)
    if not isinstance(start,(int,np.integer)) or isinstance(start,bool) or not 0<=start<h:
        raise ValueError('active start must be an integer inside the horizon')
    if not isinstance(capture_start,(int,np.integer)) or not 0<=capture_start<h:
        raise ValueError('capture start outside original horizon')
    if not 0<=protected_steps<=h-capture_start:raise ValueError('protected count outside original horizon')
    local_capture=max(0,capture_start-start)
    local_protected=max(0,min(h-start,capture_start+protected_steps-start)-local_capture)
    p=assemble_multiple_shooting_minimax(np.asarray(states)[start:],np.asarray(controls)[start:],np.asarray(A)[start:],np.asarray(B)[start:],C,np.asarray(angles)[start:],capture_start=local_capture,protected_steps=local_protected,**kwargs)
    p.update(active_start=int(start),full_horizon=h,local_capture_start=local_capture,local_protected_steps=local_protected)
    return p

def minimum_action_change(problem, primary, primary_diagnostics, *, solver_seconds=120., epigraph_slack=1e-9):
    """Retain the checked minimax bound, then minimize sum(abs(du / trust)).

    No integer-actuation, native feasibility or independent optimality certificate.
    """
    if not np.isfinite(solver_seconds) or solver_seconds<=0 or not np.isfinite(epigraph_slack) or epigraph_slack<0:
        raise ValueError('finite positive time and nonnegative epigraph slack required')
    p=problem;n=len(p['objective']);h=p['steps'];m=h*p['state_dimension'];y=np.asarray(primary['scaled_solution'],float)
    if y.shape!=(n,) or not np.isfinite(y).all() or max(float(np.max(abs(p['A_eq']@y-p['b_eq']))),float(np.max(p['A_ub']@y-p['b_ub'])),float(np.max(p['lower']-y)),float(np.max(y-p['upper'])))>1e-7:
        raise ValueError('checked feasible primary increments required')
    if abs(float(y[-1])-primary_diagnostics['epigraph'])>1e-12:raise ValueError('primary epigraph does not match solution')
    select=sparse.coo_matrix((np.ones(h),(np.arange(h),m+np.arange(h))),shape=(h,n)).tocsr()
    cap=sparse.coo_matrix(([1.],([0],[n-1])),shape=(1,n+h)).tocsr()
    E=sparse.hstack([p['A_eq'],sparse.csr_matrix((p['A_eq'].shape[0],h))],format='csr')
    F=sparse.vstack([sparse.hstack([p['A_ub'],sparse.csr_matrix((p['A_ub'].shape[0],h))]),sparse.hstack([select,-sparse.eye(h)]),sparse.hstack([-select,-sparse.eye(h)]),cap],format='csr')
    bound=np.r_[p['b_ub'],np.zeros(2*h),y[-1]+epigraph_slack];lower=np.r_[p['lower'],np.zeros(h)];upper=np.r_[p['upper'],np.full(h,np.inf)];objective=np.r_[np.zeros(n),np.ones(h)]
    solved=linprog(objective,A_eq=E,b_eq=p['b_eq'],A_ub=F,b_ub=bound,bounds=list(zip(lower,[None if np.isinf(q) else q for q in upper],strict=True)),method='highs-ipm',options=dict(time_limit=solver_seconds,maxiter=100000,small_matrix_value=1e-12,primal_feasibility_tolerance=1e-9,dual_feasibility_tolerance=1e-9))
    diag=dict(status=int(solved.status),message=solved.message,iterations=int(solved.nit),primary_epigraph=float(y[-1]),epigraph_slack=epigraph_slack,variables=n+h,nonzeros=E.nnz+F.nnz)
    if not solved.success or solved.x is None:return None,diag
    full=np.asarray(solved.x);eq=float(np.max(abs(E@full-p['b_eq'])));ineq=float(max(0.,np.max(F@full-bound)));box=float(max(0.,np.max(lower-full),np.max(full-upper)));diag.update(epigraph=float(full[n-1]),sum_absolute_scaled_action_changes=float(np.sum(abs(full[m:n-1]))),objective=float(objective@full),scaled_equality_residual=eq,scaled_inequality_violation=ineq,scaled_box_violation=box)
    if max(eq,ineq,box)>1e-7:diag['rejected_primal_residual']=True;return None,diag
    orig=full[:n];dx=np.vstack([np.zeros(p['state_dimension']),orig[:m].reshape(h,p['state_dimension'])*p['state_radii']]);du=orig[m:-1]*p['control_radii']
    return dict(scaled_solution=orig,state_step=dx,action_step=du,secondary_scaled_solution=full),diag
