"""Bounded native multi-step previews with MP factored perturbation costs.

Coordinate refinement keeps the delivered baseline sequence as a candidate.
It is a local finite-budget search, not a global optimizer or certificate.
"""
import mpmath
import numpy as np
from scipy.optimize import minimize_scalar
from .simulation import SimulationError


def shifted_preview_candidates(previous_actions,horizon,tail_actions):
    """Reuse the still-unexecuted discrete controls without retiming their knots."""
    previous=np.asarray(previous_actions,float);tails=np.asarray(tail_actions,float)
    if (previous.ndim!=1 or previous.size<2 or not isinstance(horizon,int)
            or not 1<=horizon<=previous.size or tails.ndim!=1 or not tails.size
            or not np.all(np.isfinite(previous)) or not np.all(np.isfinite(tails))
            or np.max(np.abs(previous))>1 or np.max(np.abs(tails))>1):
        raise ValueError('finite bounded discrete previous plan and at-most-one-step extension required')
    suffix=previous[1:].astype(np.float32).astype(float)
    if horizon<=len(suffix):return [suffix[:horizon].copy()]
    return [np.r_[suffix,u] for u in np.unique(tails.astype(np.float32).astype(float))]


def select_nonlinear_value_sequence(transition,state,terminal_factor,baseline_actions,*,
        reference_states,reference_actions,stage_factors,control_cost,rail_limit,
        decimal_digits=100,grid_points=17,max_iterations=40,sweeps=3,candidate_sequences=(),
        directions=None,preview_admissible=None):
    state=np.asarray(state,float);baseline=np.asarray(baseline_actions,float)
    references=np.asarray(reference_states,float);u_ref=np.asarray(reference_actions,float)
    terminal_factor=np.asarray(terminal_factor,float);horizon=len(baseline);nx=len(state)
    factors=[np.asarray(factor,float) for factor in stage_factors]
    candidates=np.asarray(candidate_sequences,float)
    if (state.ndim!=1 or baseline.ndim!=1 or horizon<1 or references.shape!=(horizon+1,nx)
            or u_ref.shape!=(horizon,) or terminal_factor.ndim!=2 or terminal_factor.shape[1]!=nx
            or len(factors)!=horizon or any(f.ndim!=2 or f.shape[1]!=nx for f in factors)
            or not isinstance(decimal_digits,int) or decimal_digits<40
            or grid_points<3 or max_iterations<1 or sweeps<1
            or not np.isfinite(control_cost) or control_cost<0 or not np.isfinite(rail_limit) or rail_limit<=0
            or any(not np.all(np.isfinite(x)) for x in [state,baseline,references,u_ref,terminal_factor,*factors,candidates])
            or (candidates.size and (candidates.ndim!=2 or candidates.shape[1]!=horizon))
            or (preview_admissible is not None and not callable(preview_admissible))):
        raise ValueError('finite aligned trajectory/costs and positive MP search budget required')
    ctx=mpmath.mp.clone();ctx.dps=decimal_digits
    if directions is not None:
        directions=np.asarray(directions,float)
        if (directions.shape!=(horizon,horizon) or not np.all(np.isfinite(directions))
                or np.linalg.matrix_rank(directions)!=horizon):
            raise ValueError('search directions must be finite independent action-space rows')
    roots=[ctx.matrix(f.tolist()) for f in factors]+[ctx.matrix(terminal_factor.tolist())]
    refs=[ctx.matrix(x.tolist()) for x in references];effort=ctx.mpf(control_cost)
    mp_actions=[ctx.mpf(float(x)) for x in u_ref];cache={};prefix_cache={};invalid=0;calls=0
    delivered=lambda sequence:tuple(np.clip(np.asarray(sequence,float),-1,1).astype(np.float32).astype(float))
    def objective(sequence):
        nonlocal invalid,calls
        key=delivered(sequence)
        if key in cache:return cache[key]
        current=state;value=ctx.mpf(0)
        try:
            for j,u in enumerate(key):
                residual=roots[j]*(ctx.matrix(current.tolist())-refs[j])
                value+=(residual.T*residual)[0]+effort*(ctx.mpf(u)-mp_actions[j])**2
                prefix=key[:j+1]
                if prefix not in prefix_cache:
                    calls+=1;predicted=np.asarray(transition(current,u),float)
                    if predicted.shape!=state.shape or not np.all(np.isfinite(predicted)) or abs(predicted[0])>rail_limit:
                        raise SimulationError('invalid or out-of-rail sequence preview')
                    if preview_admissible is not None and not preview_admissible(predicted.copy()):
                        raise SimulationError('sequence preview violates declared physical admissibility')
                    prefix_cache[prefix]=predicted
                current=prefix_cache[prefix]
            residual=roots[-1]*(ctx.matrix(current.tolist())-refs[-1]);value+=(residual.T*residual)[0]
            if not ctx.isfinite(value):raise SimulationError('nonfinite sequence value')
        except SimulationError:value=ctx.inf;invalid+=1
        cache[key]=value;return value
    baseline_key=delivered(baseline);baseline_value=objective(baseline_key)
    initial=[baseline_key,delivered(u_ref)]+([delivered(x) for x in candidates] if candidates.size else [])
    current=min(initial,key=objective)
    if not ctx.isfinite(objective(current)):raise SimulationError('no finite in-rail baseline/reference sequence')
    history=[float(objective(current))]
    for _ in range(sweeps):
        before=objective(current)
        for coordinate in range(horizon):
            if directions is not None:
                direction=directions[coordinate];origin=np.asarray(current)
                nonzero=direction!=0
                bounds=np.stack([(-1-origin[nonzero])/direction[nonzero],(1-origin[nonzero])/direction[nonzero]])
                lower=float(np.max(np.min(bounds,axis=0)));upper=float(np.min(np.max(bounds,axis=0)))
                def evaluate_line(alpha):return objective(origin+alpha*direction)
                options=np.unique(np.r_[np.linspace(lower,upper,grid_points),0.]).tolist()
                best_alpha=min(options,key=evaluate_line);anchor=evaluate_line(best_alpha)
                best=options.index(best_alpha);left=max(0,best-1);right=min(len(options)-1,best+1)
                if options[left]<options[right]:
                    def centered_line(alpha):
                        value=evaluate_line(alpha)
                        return float(value-anchor) if ctx.isfinite(value) else np.inf
                    result=minimize_scalar(centered_line,bounds=(options[left],options[right]),method='bounded',options=dict(maxiter=max_iterations,xatol=1e-12))
                    options.append(float(result.x))
                chosen=min(options,key=evaluate_line);current=delivered(origin+chosen*direction)
                continue
            trial=list(current)
            def evaluate(action):
                trial[coordinate]=float(np.float32(np.clip(action,-1,1)))
                return objective(trial)
            actions=np.unique(np.r_[np.linspace(-1,1,grid_points).astype(np.float32).astype(float),current[coordinate],float(np.float32(np.clip(u_ref[coordinate],-1,1)))])
            best=min(range(len(actions)),key=lambda i:evaluate(actions[i]));anchor=evaluate(actions[best])
            left=max(0,best-1);right=min(len(actions)-1,best+1)
            options=[float(x) for x in actions]
            if actions[left]<actions[right]:
                def centered(action):return float(evaluate(action)-anchor) if ctx.isfinite(evaluate(action)) else np.inf
                result=minimize_scalar(centered,bounds=(actions[left],actions[right]),method='bounded',options=dict(maxiter=max_iterations,xatol=1e-12))
                center=np.float32(np.clip(result.x,-1,1))
                options.extend([float(center),float(np.nextafter(center,np.float32(-np.inf))),float(np.nextafter(center,np.float32(np.inf)))])
            chosen=min(options,key=evaluate);trial[coordinate]=float(np.float32(np.clip(chosen,-1,1)));current=tuple(trial)
        history.append(float(objective(current)))
        if objective(current)>=before:break
    best=min(cache,key=cache.__getitem__)
    return np.asarray(best),dict(predicted_value=float(cache[best]),baseline_predicted_value=float(baseline_value),
        improves_baseline=bool(cache[best]<baseline_value),predictor_evaluations=calls,
        sequence_evaluations=len(cache),invalid_previews=invalid,sweep_values=history,
        horizon_steps=horizon,decimal_digits=decimal_digits,control_cost=control_cost,
        centered_refinement=True,baseline_sequence_is_candidate=True,
        search_directions=None if directions is None else directions.tolist())


def conditional_two_step_directions(a_next,b_first,b_next,stage_factor_next,terminal_factor,control_cost,ctx):
    """Orthogonalize local two-control curvature without forming a dense P."""
    f=ctx.matrix(np.asarray(terminal_factor,float).tolist());q=ctx.matrix(np.asarray(stage_factor_next,float).tolist())
    first=f*a_next*b_first;second=f*b_next
    h00=ctx.mpf(control_cost)+((q*b_first).T*(q*b_first))[0]+(first.T*first)[0]
    h11=ctx.mpf(control_cost)+(second.T*second)[0];cross=(first.T*second)[0]
    if h11<=0 or h00*h11-cross*cross<=0:raise ValueError('positive two-control curvature required')
    directions=np.array([[1.,float(-cross/h11)],[0.,1.]])
    if not np.all(np.isfinite(directions)):raise ValueError('nonfinite conditional directions')
    return directions


def conditional_sequence_directions(a_steps,b_steps,stage_factors,terminal_factor,control_cost,ctx):
    """Joint control directions for a finite-horizon factored local curvature.

    Each present-input direction includes the conditionally optimal changes to
    all later inputs. This guides native search; it does not certify its plant.
    """
    horizon=len(a_steps)
    if horizon<1 or len(b_steps)!=horizon or len(stage_factors)!=horizon or ctx.dps<40:
        raise ValueError('aligned nonempty MP dynamics and running factors required')
    a=[ctx.matrix(x) for x in a_steps];b=[ctx.matrix(x) for x in b_steps]
    nx=a[0].rows
    roots=[ctx.matrix(np.asarray(f,float).tolist()) for f in stage_factors]
    terminal=ctx.matrix(np.asarray(terminal_factor,float).tolist())
    effort=ctx.mpf(control_cost)
    if (not ctx.isfinite(effort) or effort<0 or nx<1
            or any(x.rows!=nx or x.cols!=nx for x in a)
            or any(x.rows!=nx or x.cols!=1 for x in b)
            or any(f.cols!=nx for f in [*roots,terminal])
            or any(not ctx.isfinite(z) for x in [*a,*b,*roots,terminal] for z in x)):
        raise ValueError('finite aligned single-input dynamics and nonnegative effort required')
    gram=effort*ctx.eye(horizon);response=ctx.zeros(nx,horizon)
    for step in range(horizon):
        weighted=roots[step]*response
        gram+=weighted.T*weighted
        response=a[step]*response
        for row in range(nx):response[row,step]+=b[step][row]
    weighted=terminal*response;gram+=weighted.T*weighted
    try:
        ctx.cholesky(gram)
    except ValueError as error:
        raise ValueError('positive finite-horizon control curvature required') from error
    directions=ctx.eye(horizon)
    for step in range(horizon-1):
        compensation=-ctx.cholesky_solve(gram[step+1:,step+1:],gram[step+1:,step])
        for offset in range(len(compensation)):directions[step,step+1+offset]=compensation[offset]
    result=np.asarray(directions.tolist(),float)
    if not np.all(np.isfinite(result)):raise ValueError('nonfinite conditional sequence directions')
    return result
