"""Bounded native feasibility search with explicit physical residuals.

Native quantized rollouts decide admissibility. SciPy termination alone never
supplies a feasible-sequence claim. This is a local fixed-budget search.
"""
import numpy as np
from scipy.optimize import least_squares
from .simulation import SimulationError


def extend_verified_native_sequence(transition,state,prefix_actions,expected_prefix_states,seeds,*,
        reference_actions,constraint_residual,admissible,derivative_epsilon=1e-5,max_evaluations=20,
        action_regularization=1e-5,constraint_jacobian=None):
    """Keep a checked input suffix fixed and search only its future extension.

    The endpoint is produced by independent native forecasting from the supplied
    actual state. Expected states are comparison data, never state replacements.
    The residual and Jacobian concern the extension alone; admissibility must
    hold for both the fixed prefix and every selected extension forecast.
    """
    state=np.asarray(state,float);prefix=np.asarray(prefix_actions,float)
    expected=np.asarray(expected_prefix_states,float)
    if (state.ndim!=1 or prefix.ndim!=1 or not len(prefix)
            or expected.shape!=(len(prefix),len(state))
            or any(not np.all(np.isfinite(x)) for x in (state,prefix,expected))
            or np.any(np.abs(prefix)>1)
            or not np.array_equal(prefix,prefix.astype(np.float32).astype(float))
            or not callable(admissible)):
        raise ValueError('finite aligned already-quantized fixed prefix and expected native states required')
    current=state.copy();predicted=[]
    for action in prefix:
        current=np.asarray(transition(current.copy(),float(action)),float)
        if current.shape!=state.shape or not np.all(np.isfinite(current)):
            raise SimulationError('invalid fixed-prefix native forecast')
        predicted.append(current.copy())
    predicted=np.asarray(predicted)
    if not np.array_equal(predicted,expected):
        raise ValueError('fixed prefix no longer exactly matches its expected native forecast')
    info=dict(fixed_prefix_steps=len(prefix),fixed_prefix_native_transition_calls=len(prefix),
        fixed_prefix_forecasts_bit_identical=True,extension_native_transition_calls=0,
        native_transition_calls=len(prefix),selected_states=None,feasible_sequence_found=False,
        minimum_observed_constraint_violation_cost=None,
        scope='Fixed native input suffix independently replayed; optimize only appended inputs from its forecast endpoint. No live state replacement or recursive viability certificate.')
    if not admissible(predicted.copy()):
        info['fixed_prefix_admissible']=False
        return None,info
    selected,extension=restore_native_sequence(transition,current.copy(),seeds,
        reference_actions=reference_actions,constraint_residual=constraint_residual,admissible=admissible,
        derivative_epsilon=derivative_epsilon,max_evaluations=max_evaluations,
        action_regularization=action_regularization,constraint_jacobian=constraint_jacobian)
    info.update(fixed_prefix_admissible=True,extension=extension,
        extension_native_transition_calls=extension['native_transition_calls'],
        native_transition_calls=len(prefix)+extension['native_transition_calls'],
        minimum_observed_constraint_violation_cost=extension['minimum_observed_constraint_violation_cost'],
        feasible_sequence_found=selected is not None)
    if selected is None:return None,info
    states=np.vstack([predicted,np.asarray(extension['selected_states'])])
    if not admissible(states.copy()):
        raise ValueError('combined native prefix and extension failed admissibility')
    info['selected_states']=states.tolist()
    return np.r_[prefix,selected],info


def restore_native_sequence(transition,state,seeds,*,reference_actions,
        constraint_residual,admissible,derivative_epsilon=1e-5,max_evaluations=20,
        action_regularization=1e-5,constraint_jacobian=None):
    """Search native forecasts; an optional callback supplies physical-loss derivatives.

    The callback receives independent copies of initial state, delivered F32
    inputs and their forecast states. Its own derivative sampling budget belongs
    to the caller; native_transition_calls counts the proposal rollouts here.
    """
    state=np.asarray(state,float);seeds=np.asarray(seeds,float);reference=np.asarray(reference_actions,float)
    if (state.ndim!=1 or seeds.ndim!=2 or not len(seeds) or reference.ndim!=1
            or not len(reference) or seeds.shape[1]!=len(reference)
            or any(not np.all(np.isfinite(x)) for x in (state,seeds,reference))
            or np.max(np.abs(seeds))>1 or np.max(np.abs(reference))>1
            or not callable(constraint_residual) or not callable(admissible)
            or (constraint_jacobian is not None and not callable(constraint_jacobian))
            or not np.isfinite(derivative_epsilon) or derivative_epsilon<=0
            or not isinstance(max_evaluations,int) or max_evaluations<1
            or not np.isfinite(action_regularization) or action_regularization<0):
        raise ValueError('finite bounded aligned native sequence seeds and positive search budget required')
    quantize=lambda u:np.clip(u,-1,1).astype(np.float32).astype(float)
    reference=quantize(reference);cache={};calls=0;records=[];residual_size=None
    def evaluate(u):
        nonlocal calls,residual_size
        delivered=quantize(np.asarray(u,float));key=tuple(delivered)
        if key not in cache:
            current=state.copy();states=[]
            for action in delivered:
                calls+=1;current=np.asarray(transition(current.copy(),float(action)),float)
                if current.shape!=state.shape or not np.all(np.isfinite(current)):
                    raise SimulationError('invalid native feasibility forecast')
                states.append(current.copy())
            states=np.asarray(states)
            residual=np.asarray(constraint_residual(states.copy()),float)
            if residual.ndim!=1 or not len(residual) or not np.all(np.isfinite(residual)):
                raise ValueError('physical constraint residual must be a finite nonempty vector')
            if residual_size is None:residual_size=len(residual)
            if len(residual)!=residual_size:raise ValueError('constraint residual size changed')
            total=np.r_[residual,action_regularization*(delivered-reference)]
            cache[key]=dict(residual=total,constraint_residual=residual,
                admissible=bool(admissible(states.copy())),states=states)
        return cache[key]['residual']
    def jacobian(u):
        center=quantize(np.asarray(u,float));columns=[]
        if constraint_jacobian is not None:
            evaluate(center)
            physical=np.asarray(constraint_jacobian(state.copy(),center.copy(),
                cache[tuple(center)]['states'].copy()),float)
            if physical.shape!=(residual_size,len(center)) or not np.all(np.isfinite(physical)):
                raise ValueError('native physical Jacobian must be finite and aligned with residual/actions')
            return np.vstack([physical,action_regularization*np.eye(len(center))])
        for index in range(len(center)):
            plus=center.copy();minus=center.copy()
            plus[index]=float(np.float32(min(1.,center[index]+derivative_epsilon)))
            minus[index]=float(np.float32(max(-1.,center[index]-derivative_epsilon)))
            denominator=plus[index]-minus[index]
            if denominator<=0:raise ValueError('native action secant vanished after quantization')
            columns.append((evaluate(plus)-evaluate(minus))/denominator)
        return np.column_stack(columns)
    for index,seed in enumerate(seeds):
        try:
            initial=evaluate(seed)
            result=least_squares(evaluate,seed,jac=jacobian,bounds=(-1.,1.),
                max_nfev=max_evaluations,ftol=1e-10,xtol=1e-10,gtol=1e-10,x_scale='jac')
            final=evaluate(result.x)
            records.append(dict(seed=index,solver_success=bool(result.success),solver_status=int(result.status),
                solver_message=str(result.message),reported_function_evaluations=int(result.nfev),
                reported_jacobian_evaluations=int(result.njev),initial_residual_cost=float(initial@initial),
                final_residual_cost=float(final@final),delivered_final_admissible=cache[tuple(quantize(result.x))]['admissible']))
        except SimulationError as error:
            records.append(dict(seed=index,solver_success=False,error=str(error)))
    feasible=[key for key,r in cache.items() if r['admissible']]
    selected=min(feasible,key=lambda k:float(cache[k]['residual']@cache[k]['residual'])) if feasible else None
    diagnostics=dict(feasible_sequence_found=selected is not None,native_transition_calls=calls,
        unique_quantized_sequences_evaluated=len(cache),feasible_sequences_observed=len(feasible),
        minimum_observed_constraint_violation_cost=min((float(r['constraint_residual']@r['constraint_residual']) for r in cache.values()),default=None),
        derivative_epsilon=derivative_epsilon,max_function_evaluations_per_seed=max_evaluations,
        action_regularization=action_regularization,seed_results=records,
        jacobian_method='whole_rollout_action_secants' if constraint_jacobian is None else 'provided_physical_constraint_jacobian',
        selected_states=None if selected is None else cache[selected]['states'].tolist(),
        scope=('Local bounded least-squares with whole-rollout action secants.' if constraint_jacobian is None else
            'Local bounded least-squares with a provided physical-loss Jacobian; callback sampling budget is external.')+
            ' Native float32 actions and every visited full forecast decide admissibility, independently of solver termination; no recursive viability or realtime certificate.')
    return None if selected is None else np.asarray(selected),diagnostics
