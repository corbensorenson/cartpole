"""Independent MP planar mechanics and smooth held-input RK4 sensitivities.

The native MuJoCo/F32 plant remains the execution authority. This model promotes
parsed binary64 parameters and differentiates the smooth physical force, not
the discontinuous delivered-action quantizer. Native arithmetic discrepancies
are retained; no nonlinear feasibility or robustness certificate is implied.
"""
import numpy as np
from .upright_mechanics import upright_rk4_matrices


class PlanarMechanics:
    def __init__(self, env, *, decimal_digits=100):
        # Reuse the existing strict tree/actuator/integrator/mechanics guards.
        _, _, checked = upright_rk4_matrices(env, decimal_digits=decimal_digits)
        import mpmath
        self.ctx = mpmath.mp.clone(); self.ctx.dps = decimal_digits
        c = self.ctx; self.n = env.n; self.d = env.n+1; d = self.d
        self.nx = 2*d; self.h = c.mpf(float(env.model.opt.timestep)); self.frames = env.frame_skip
        self.force_limit = c.mpf(float(env.force_limit))
        self.relative = c.eye(d)
        for i in range(2,d): self.relative[i,i-1] = -1
        self.absolute = self.relative**-1
        mass = c.matrix(checked['mass_matrix'])
        self.armature = self.relative.T*c.diag([c.mpf(float(v)) for v in env.model.dof_armature])*self.relative
        self.physical_mass = self.relative.T*mass*self.relative-self.armature
        self.damping = self.relative.T*c.diag([c.mpf(float(v)) for v in env.model.dof_damping])*self.relative
        gravity = self.relative.T*c.matrix(checked['gravity_hessian'])*self.relative
        self.gravity_weights = [-gravity[i+1,i+1] for i in range(self.n)]
        self.transform = c.zeros(self.nx,self.nx)
        for i in range(d):
            for j in range(d):
                self.transform[i,j] = self.absolute[i,j]
                self.transform[d+i,d+j] = self.absolute[i,j]
        self.inverse_transform = self.transform**-1
        self.native_upright_mass_difference = checked['maximum_mass_difference_from_native']

    def _promote(self, value):
        return value if isinstance(value, self.ctx.mpf) else self.ctx.mpf(float(value))

    def absolute_field(self, state, action, *, derivatives=False):
        c=self.ctx; d=self.d; n=self.n
        angles=[state[i+1] for i in range(n)]; omega=[state[d+i+1] for i in range(n)]
        sine=[c.sin(v) for v in angles]; cosine=[c.cos(v) for v in angles]
        sine_difference=[[c.sin(angles[i]-angles[j]) for j in range(n)] for i in range(n)]
        cosine_difference=[[c.cos(angles[i]-angles[j]) for j in range(n)] for i in range(n)]
        mass=self.armature.copy(); mass[0,0]+=self.physical_mass[0,0]
        coriolis=c.zeros(d,1); gravity=c.zeros(d,1)
        for i in range(n):
            coupling=self.physical_mass[0,i+1]
            mass[0,i+1]+=coupling*cosine[i]; mass[i+1,0]+=coupling*cosine[i]
            coriolis[0]-=coupling*sine[i]*omega[i]**2
            gravity[i+1]=self.gravity_weights[i]*sine[i]
            for j in range(n):
                coefficient=self.physical_mass[i+1,j+1]
                mass[i+1,j+1]+=coefficient*cosine_difference[i][j]
                coriolis[i+1]+=coefficient*sine_difference[i][j]*omega[j]**2
        inverse=c.inverse(mass); velocity=state[d:,:]
        force=c.zeros(d,1); force[0]=self.force_limit*action
        acceleration=inverse*(force+gravity-coriolis-self.damping*velocity)
        field=c.zeros(self.nx,1)
        for i in range(d):field[i]=velocity[i];field[d+i]=acceleration[i]
        if not derivatives:return field,mass
        rhs_q=c.zeros(d,d); rhs_v=-self.damping.copy()
        for k in range(n):
            dm=c.zeros(d,d);coupling=self.physical_mass[0,k+1]
            dm[0,k+1]=dm[k+1,0]=-coupling*sine[k]
            rhs_q[0,k+1]=coupling*cosine[k]*omega[k]**2
            rhs_v[0,k+1]+=2*coupling*sine[k]*omega[k]
            rhs_q[k+1,k+1]+=self.gravity_weights[k]*cosine[k]
            for i in range(n):
                coefficient=self.physical_mass[i+1,k+1]
                dm[i+1,k+1]=coefficient*sine_difference[i][k]
                dm[k+1,i+1]=-self.physical_mass[k+1,i+1]*sine_difference[k][i]
                rhs_q[i+1,k+1]+=coefficient*cosine_difference[i][k]*omega[k]**2
                rhs_q[k+1,k+1]-=self.physical_mass[k+1,i+1]*cosine_difference[k][i]*omega[i]**2
                rhs_v[i+1,k+1]-=2*coefficient*sine_difference[i][k]*omega[k]
            correction=dm*acceleration
            for i in range(d):rhs_q[i,k+1]-=correction[i]
        jac=c.zeros(self.nx,self.nx); jq=inverse*rhs_q; jv=inverse*rhs_v
        for i in range(d):
            jac[i,d+i]=1
            for j in range(d):jac[d+i,j]=jq[i,j];jac[d+i,d+j]=jv[i,j]
        bu=c.zeros(self.nx,1)
        for i in range(d):bu[d+i]=inverse[i,0]*self.force_limit
        return field,mass,jac,bu

    def relative_field(self, state, action, *, derivatives=False):
        c=self.ctx; x=c.matrix([self._promote(v) for v in state]); u=self._promote(action)
        result=self.absolute_field(self.transform*x,u,derivatives=derivatives)
        field,mass=result[:2]; relative_field=self.inverse_transform*field
        relative_mass=self.absolute.T*mass*self.absolute
        if not derivatives:return relative_field,relative_mass
        return relative_field,relative_mass,self.inverse_transform*result[2]*self.transform,self.inverse_transform*result[3]

    def transition(self, state, action, *, derivatives=False):
        c=self.ctx; x=self.transform*c.matrix([self._promote(v) for v in state]); u=self._promote(action); h=self.h
        sensitivity=c.zeros(self.nx,self.nx+1)
        for i in range(self.nx):sensitivity[i,i]=1
        def stage(z,s):
            r=self.absolute_field(z,u,derivatives=derivatives)
            if not derivatives:return r[0],s
            ds=r[2]*s
            for i in range(self.nx):ds[i,self.nx]+=r[3][i]
            return r[0],ds
        for _ in range(self.frames):
            k1,s1=stage(x,sensitivity);k2,s2=stage(x+h*k1/2,sensitivity+h*s1/2)
            k3,s3=stage(x+h*k2/2,sensitivity+h*s2/2);k4,s4=stage(x+h*k3,sensitivity+h*s3)
            x+=h*(k1+2*k2+2*k3+k4)/6
            if derivatives:sensitivity+=h*(s1+2*s2+2*s3+s4)/6
        result=self.inverse_transform*x
        if not derivatives:return result
        a=self.inverse_transform*sensitivity[:,:self.nx]*self.transform
        b=self.inverse_transform*sensitivity[:,self.nx:]
        return result,a,b
