"""Verify value-root provenance before native nonlinear route corrections."""
import json
from pathlib import Path
import numpy as np
from .evidence import data_sha256,file_metadata


def checked_metadata(metadata):
    path=Path(metadata['path'])
    if file_metadata(path)!=metadata:raise ValueError('recorded value input bytes changed')
    return path


def verified_route_value_inputs(source_path, values_path, config_path):
    source_meta=file_metadata(source_path);values_meta=file_metadata(values_path);config_meta=file_metadata(config_path)
    source=json.loads(Path(source_path).read_text());values=json.loads(Path(values_path).read_text());c=source['controller']
    states=np.asarray(source['search']['nominal_coordinate_states'],float);controls=np.asarray(c['controls'],float);gains=np.asarray(c['feedback_gains'],float);transform=np.asarray(c['coordinate_transform'],float);roots=np.asarray(values['value_factors'],float)
    nx=states.shape[1] if states.ndim==2 else 0
    if (values['config']!=config_meta or states.shape!=(len(controls)+1,nx) or gains.shape!=(len(controls),nx)
            or roots.shape!=(len(controls)+1,nx,nx) or transform.shape!=(nx,nx)
            or not np.array_equal(transform,values['coordinate_transform'])
            or data_sha256(states.tolist())!=values['nominal_states_sha256']
            or data_sha256(controls.tolist())!=values['controls_sha256']
            or any(not np.all(np.isfinite(v)) for v in [states,controls,gains,roots,transform])):
        raise ValueError('value roots/config do not match route nodes, controls or basis')
    design=c.get('tracking_feedback_design') or {}
    if values.get('known_defect_feedforward',False) or design.get('known_defect_feedforward',False):
        raise ValueError('this preview requires pure quadratic values without omitted affine forcing terms')
    base_meta=values['source_controller'];base_path=checked_metadata(base_meta)
    if base_meta==source_meta:
        provenance='direct_controller_identity'
    else:
        comparison=source.get('tracking_only_comparison') or {}
        base=json.loads(base_path.read_text())
        if (comparison.get('source')!=base_meta or not comparison.get('controls_identical')
                or not comparison.get('nominal_states_identical')
                or design.get('value_factor_export')!=values_meta
                or design.get('decimal_digits')!=values['decimal_digits']
                or design.get('regularization')!=values['regularization']
                or design.get('derivative_cache')!=values.get('derivative_cache')
                or not np.array_equal(base['controller']['controls'],controls)
                or not np.array_equal(base['search']['nominal_coordinate_states'],states)):
            raise ValueError('value design source is not the unchanged reference of this policy')
        provenance='verified_inherited_reference_and_export_identity'
    if values.get('derivative_cache') is not None:checked_metadata(values['derivative_cache'])
    return source,values,dict(source=source_meta,values=values_meta,config=config_meta,
        design_reference=base_meta,provenance=provenance,controls_identical=True,nodes_identical=True,
        pure_quadratic_value=True)
