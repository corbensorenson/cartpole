"""Physical-prefix initializer transformations, never solution certificates."""
import copy
import numpy as np


def _arrays(payload):
    c=payload['controller'];x=np.asarray(payload['search']['nominal_coordinate_states'],dtype=float);u=np.asarray(c['controls'],dtype=float);k=np.asarray(c['feedback_gains'],dtype=float)
    dimension=len(payload['selected_state']['qpos'])+len(payload['selected_state']['qvel'])
    if x.shape!=(len(u)+1,dimension) or k.shape!=(len(u),dimension) or not all(np.all(np.isfinite(v)) for v in (x,u,k)):
        raise ValueError('invalid initializer arrays')
    initial=np.asarray(payload['selected_state']['qpos']+payload['selected_state']['qvel'])
    if x[0].tobytes()!=initial.tobytes():raise ValueError('initial state mismatch')
    return x,u,k


def truncate_physical_initializer(payload,steps,*,dt=.02):
    """Trim a saved actual initializer; retain its exact samples, not a new rollout."""
    x,u,k=_arrays(payload)
    if isinstance(steps,bool) or not isinstance(steps,int) or not 1<=steps<=len(u) or dt<=0:raise ValueError('invalid prefix length')
    if not np.array_equal(u,u.astype(np.float32).astype(float)):raise ValueError('physical controls must be F32 representable')
    out=dict(selected_state=copy.deepcopy(payload['selected_state']),controller=copy.deepcopy(payload['controller']),search=dict(nominal_coordinate_states=x[:steps+1].tolist()),initialization_only=True,not_solution=True)
    out['controller'].update(controls=u[:steps].tolist(),feedback_gains=k[:steps].tolist(),horizon_steps=steps,horizon_seconds=steps*dt)
    return out


def extend_actual_prefix_initializer(payload,states,actions,gains,steps):
    """Replace a full initializer's prefix with actual data; keep its virtual tail."""
    x,u,k=_arrays(payload);actual_x=np.asarray(states,dtype=float);actual_u=np.asarray(actions,dtype=float);actual_k=np.asarray(gains,dtype=float)
    if not isinstance(steps,int) or not 1<=steps<len(u):raise ValueError('invalid prefix length')
    if actual_x.shape[1:]!=x.shape[1:] or actual_k.shape[1:]!=k.shape[1:] or len(actual_x)<steps+1 or len(actual_u)<steps or len(actual_k)<steps:raise ValueError('missing actual prefix samples')
    if not np.array_equal(actual_u[:steps],actual_u[:steps].astype(np.float32).astype(float)):raise ValueError('actual controls must be F32 representable')
    if actual_x[0].tobytes()!=x[0].tobytes() or not all(np.all(np.isfinite(v)) for v in (actual_x[:steps+1],actual_u[:steps],actual_k[:steps])):raise ValueError('invalid actual prefix')
    x=x.copy();u=u.copy();k=k.copy();x[:steps+1]=actual_x[:steps+1];u[:steps]=actual_u[:steps];k[:steps]=actual_k[:steps]
    out=dict(selected_state=copy.deepcopy(payload['selected_state']),controller=copy.deepcopy(payload['controller']),search=dict(nominal_coordinate_states=x.tolist()),initialization_only=True,not_solution=True,scope='Actual prefix followed by a virtual successor-plant capture tail; initializer only, not full-route evidence.')
    out['controller'].update(controls=u.tolist(),feedback_gains=k.tolist())
    return out
