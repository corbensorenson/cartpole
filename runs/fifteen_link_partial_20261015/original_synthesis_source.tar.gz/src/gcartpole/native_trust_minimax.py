"""A bounded affine minimax proposal; native rollouts decide acceptance."""
import numpy as np
from scipy.optimize import linprog


def affine_trust_proposal(values, jacobian, radii, *, action_values=None,
                          action_basis=None, solver_seconds=5.):
    """Minimize max|values+Jacobian*delta| in a scaled parameter trust box.

    Optional action rows constrain nominal feedforward, not measured feedback.
    Neither LP success nor its predicted bounds certify nonlinear feasibility.
    """
    values=np.asarray(values,float);jacobian=np.asarray(jacobian,float);radii=np.asarray(radii,float)
    if (values.ndim!=1 or not len(values) or jacobian.ndim!=2 or jacobian.shape!=(len(values),len(radii))
        or radii.ndim!=1 or not len(radii) or np.any(radii<=0)
        or not all(np.all(np.isfinite(v)) for v in (values,jacobian,radii))
        or not np.isfinite(solver_seconds) or solver_seconds<=0):
        raise ValueError('finite aligned feature model and positive trust radii required')
    mapped=jacobian*radii;dimension=len(radii)
    matrix=np.vstack([np.c_[mapped,-np.ones(len(values))],np.c_[-mapped,-np.ones(len(values))]])
    rhs=np.r_[-values,values]
    if (action_values is None)!=(action_basis is None):raise ValueError('action values and basis must be supplied together')
    if action_values is not None:
        action_values=np.asarray(action_values,float);action_basis=np.asarray(action_basis,float)
        if (action_values.ndim!=1 or action_basis.shape!=(len(action_values),dimension)
            or not np.all(np.isfinite(action_values)) or not np.all(np.isfinite(action_basis))
            or np.any(abs(action_values)>1+1e-12)):
            raise ValueError('finite bounded nominal actions and aligned action basis required')
        am=action_basis*radii;matrix=np.vstack([matrix,np.c_[am,np.zeros(len(am))],np.c_[-am,np.zeros(len(am))]])
        rhs=np.r_[rhs,1-action_values,1+action_values]
    result=linprog(np.r_[np.zeros(dimension),1.],A_ub=matrix,b_ub=rhs,
                   bounds=[(-1.,1.)]*dimension+[(0.,None)],method='highs-ds',
                   options=dict(time_limit=solver_seconds,maxiter=10000,
                                primal_feasibility_tolerance=1e-9,dual_feasibility_tolerance=1e-9))
    diagnostic=dict(solver_status=int(result.status),solver_message=str(result.message),
                    solver_iterations=int(result.nit or 0),baseline_maximum=float(np.max(abs(values))),
                    scope='Affine trust-box minimax proposal only; delivered F32 native physics determines acceptance.')
    if not result.success or result.x is None or not np.all(np.isfinite(result.x)):
        return None,diagnostic
    delta=radii*result.x[:-1];error=float(np.max(np.maximum(matrix@result.x-rhs,0)))
    diagnostic.update(predicted_maximum=float(np.max(abs(values+jacobian@delta))),
                      lp_epigraph=float(result.x[-1]),maximum_lp_inequality_error=error)
    if error>1e-7 or np.any(abs(delta)>radii*(1+1e-8)):
        diagnostic['rejected_numerical_residual']=True;return None,diagnostic
    return delta,diagnostic
