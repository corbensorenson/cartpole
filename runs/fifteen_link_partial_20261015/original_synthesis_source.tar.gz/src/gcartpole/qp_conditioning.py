"""Offline QP export and reversible coordinate conditioning.

The physical optimizer and forward validation remain authoritative.
"""
from pathlib import Path

import numpy as np
from scipy import sparse

from .config import dump_json
from .evidence import file_metadata


class FactoredStepWhitening:
    """Change physical step coordinates using MP roots of supplied cost factors.

    This does not whiten or discard dynamics, bounds, slacks or residuals.
    The exported binary64 mapping is used consistently in all constraints;
    dense cost-block products are accumulated in MP to retain cancellation.
    """
    def __init__(self, cost_factors, control_costs, objective_scale, *, decimal_digits=100):
        import mpmath
        factors = [np.asarray(root, dtype=float) for root in cost_factors]
        costs = np.asarray(control_costs, dtype=float)
        if (not factors or costs.shape != (len(factors),) or np.any(costs <= 0)
                or not np.all(np.isfinite(costs)) or not np.isfinite(objective_scale)
                or objective_scale < 1 or decimal_digits < 40):
            raise ValueError('positive costs, finite scale and MP precision required')
        self.steps, self.nx = len(factors), factors[0].shape[1]
        if any(root.ndim != 2 or root.shape[1] != self.nx or not np.all(np.isfinite(root)) for root in factors):
            raise ValueError('finite compatible cost factors required')
        self.factors, self.scale = factors, objective_scale
        self.ctx = mpmath.mp.clone(); self.ctx.dps = decimal_digits
        self.root_scale = np.sqrt(objective_scale)
        self.state_maps, self.cost_products = [], []
        cache = {}
        for factor in factors:
            key = (factor.shape, factor.tobytes())
            if key not in cache:
                root = self.ctx.matrix(factor.tolist())
                upper = self.ctx.cholesky(root.T*root).T
                # Promote the same existing binary64 sqrt scale, rather than
                # silently using a different high-precision scale.
                mp_map = self.ctx.inverse(upper)*self.ctx.mpf(float(self.root_scale))
                mapping = np.asarray(mp_map.tolist(), dtype=float)
                if not np.all(np.isfinite(mapping)):
                    raise ValueError('nonfinite exported step mapping')
                # This multiplies the actual rounded map and the actual
                # original scaled QP coefficients, not an ideal identity.
                # SciPy sparse division scales stored coefficients by the
                # rounded reciprocal. Direct NumPy division differs by a ULP.
                original_scaled_factor = factor*(1./self.root_scale)
                product = np.asarray((self.ctx.matrix(original_scaled_factor.tolist())*
                                      self.ctx.matrix(mapping.tolist())).tolist(), dtype=float)
                cache[key] = mapping, product
            mapping, product = cache[key]
            self.state_maps.append(mapping); self.cost_products.append(product)
        self.state_variables = self.steps*self.nx
        self.physical_variables = self.state_variables+self.steps
        self.control_map = self.root_scale/np.sqrt(costs)
        self.mapping = sparse.block_diag([*self.state_maps, sparse.diags(self.control_map)], format='csc')
        self.decimal_digits = decimal_digits
        self.unique_factor_blocks = len(cache)

    def transform(self, hessian, gradient, constraints, lower, upper, residual_rows):
        """Return an equivalent step QP and its full solution map.

        Native solver statuses and physical-coordinate validation are separate.
        """
        m, n, r = self.state_variables, self.physical_variables, residual_rows
        if (hessian.shape != (n+2*m+r, n+2*m+r) or constraints.shape[1] != hessian.shape[0]
                or np.asarray(gradient).shape != (hessian.shape[0],)):
            raise ValueError('requires the full factored shooting QP layout')
        full_map = sparse.block_diag([self.mapping, sparse.eye(2*m+r)], format='csc')
        new_hessian = (full_map.T@hessian@full_map).tocsc()
        new_gradient = np.asarray(full_map.T@gradient).ravel()
        new_constraints = (constraints@full_map).tocsc()
        # Row order: fixed initial cost/rail, each variable node's cost/rail,
        # then controls. Preserve soft-rail rows using their current derivative.
        initial_rows = r-self.steps-sum(factor.shape[0]+1 for factor in self.factors)
        if initial_rows < 1:
            raise ValueError('invalid cost-residual row layout')
        blocks = []; cursor = initial_rows
        for node, (factor, product, mapping) in enumerate(zip(self.factors,self.cost_products,self.state_maps)):
            columns = slice(node*self.nx, (node+1)*self.nx)
            original = constraints[m+cursor:m+cursor+factor.shape[0], columns].toarray()
            if not np.array_equal(original, factor*(1./self.root_scale)):
                raise ValueError('cost block differs from the supplied original QP factor')
            rail = constraints[m+cursor+factor.shape[0]:m+cursor+factor.shape[0]+1, columns]@mapping
            blocks.append(sparse.vstack([sparse.csc_matrix(product), sparse.csc_matrix(rail)]))
            cursor += factor.shape[0]+1
        state_objective = sparse.hstack([sparse.block_diag(blocks), sparse.csc_matrix((cursor-initial_rows,self.steps))])
        control_original = constraints[m+cursor:m+r, m:n]
        control_objective = sparse.hstack([sparse.csc_matrix((self.steps,m)),control_original@sparse.diags(self.control_map)])
        step_objective = sparse.vstack([sparse.csc_matrix((initial_rows,n)),state_objective,control_objective])
        objective_constraints = sparse.hstack([step_objective,sparse.csc_matrix((r,2*m)),-sparse.eye(r)])
        new_constraints = sparse.vstack([new_constraints[:m],objective_constraints,new_constraints[m+r:]],format='csc')
        return new_hessian, new_gradient, new_constraints, np.asarray(lower).copy(), np.asarray(upper).copy(), full_map

    def diagnostics(self):
        return dict(type='cost_block_right_whitening', decimal_digits=self.decimal_digits,
            physical_variables=self.physical_variables, unique_factor_blocks=self.unique_factor_blocks,
            maximum_mapping_coefficient=float(np.max(np.abs(self.mapping.data))),
            maximum_cost_product_coefficient=max(float(np.max(np.abs(p))) for p in self.cost_products),
            same_physical_objective_and_constraints=True, slacks_and_residual_coordinates_unchanged=True)


def export_first_qp_observer(directory):
    """Save the first problem once; observations cannot alter solver inputs."""
    out = Path(directory)
    if out.exists():
        raise FileExistsError(out)
    emitted = False
    def observe(record):
        nonlocal emitted
        if emitted:
            return
        out.mkdir(parents=True, exist_ok=False)
        sparse.save_npz(out/'hessian.npz', record['hessian'])
        sparse.save_npz(out/'constraints.npz', record['constraints'])
        np.savez_compressed(out/'vectors.npz', gradient=record['gradient'], lower=record['lower'],
            upper=record['upper'], control_costs=record['control_costs'])
        # Roots can be rectangular; archive each native supplied factor separately.
        np.savez_compressed(out/'cost_factors.npz', **{str(i):r for i,r in enumerate(record['cost_factors'])})
        metadata = {k:v for k,v in record.items() if k not in
                    ('hessian','gradient','constraints','lower','upper','cost_factors','control_costs')}
        metadata['files'] = [file_metadata(path) for path in sorted(out.glob('*.npz'))]
        dump_json(metadata, out/'metadata.json')
        emitted = True
    return observe
