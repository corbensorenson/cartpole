"""Sparse native state/control proposal; nonlinear replay remains authoritative."""
import numpy as np
from scipy import sparse
from scipy.optimize import linprog

def assemble_multiple_shooting_minimax(states,controls,A,B,angle_matrix,angle_values,*,capture_start,protected_steps,angle_limit,rail_limit,state_radii,control_radii,defects=None):
 X,U,A,B,C,phi=[np.asarray(q,dtype=float) for q in (states,controls,A,B,angle_matrix,angle_values)];h=len(U)
 if X.ndim!=2 or h<1 or X.shape[0]!=h+1:raise ValueError('aligned nonempty state/control horizon required')
 nx=X.shape[1];B=B.reshape(h,nx) if B.shape==(h,nx,1) else B
 if A.shape!=(h,nx,nx) or B.shape!=(h,nx) or C.ndim!=2 or C.shape[1]!=nx or C.shape[0]<1 or phi.shape!=(h+1,C.shape[0]):raise ValueError('aligned finite native matrices and angle anchors required')
 if not all(np.all(np.isfinite(q)) for q in (X,U,A,B,C,phi)) or np.any(abs(U)>1):raise ValueError('finite states/matrices and delivered bounded controls required')
 if not isinstance(capture_start,(int,np.integer)) or isinstance(capture_start,bool) or not 0<=capture_start<h:raise ValueError('capture_start outside horizon')
 if not isinstance(protected_steps,(int,np.integer)) or isinstance(protected_steps,bool) or not 0<=protected_steps<=h-capture_start:raise ValueError('protected_steps outside capture window')
 R=np.asarray(state_radii,float);V=np.broadcast_to(np.asarray(control_radii,float),(h,)).copy();g=np.zeros((h,nx)) if defects is None else np.asarray(defects,float)
 if R.shape!=(nx,) or g.shape!=(h,nx) or not all(np.all(np.isfinite(q)) for q in (R,V,g)) or min(np.min(R),np.min(V),angle_limit,rail_limit)<=0 or not np.isfinite([angle_limit,rail_limit]).all():raise ValueError('positive finite trust scales/limits and aligned defects required')
 m=h*nx;n=m+h+1;D=sparse.lil_matrix((m,n))
 for i in range(h):
  rows=slice(i*nx,(i+1)*nx);D[rows,i*nx:(i+1)*nx]=sparse.eye(nx)
  if i:D[rows,(i-1)*nx:i*nx]=-A[i]*R[None,:]/R[:,None]
  D[rows,m+i]=-B[i]*V[i]/R
 E=D.tocsr();rhs=(g/R).ravel();state_lo=np.full((h,nx),-1.);state_hi=np.full((h,nx),1.);state_lo[:,0]=np.maximum(-1.,(-rail_limit-X[1:,0])/R[0]);state_hi[:,0]=np.minimum(1.,(rail_limit-X[1:,0])/R[0]);ctrl_lo=np.maximum(-1.,(-1-U)/V);ctrl_hi=np.minimum(1.,(1-U)/V)
 cap=h-capture_start;nc=C.shape[0];block=(C*R[None,:])/angle_limit;G=sparse.hstack([sparse.csr_matrix((cap*nc,capture_start*nx)),sparse.kron(sparse.eye(cap),block,format='csr'),sparse.csr_matrix((cap*nc,h)),sparse.csr_matrix(-np.ones((cap*nc,1)))],format='csr');v=(phi[capture_start+1:]/angle_limit).ravel();positive=G;negative=G.copy();negative[:,:m]*=-1;ineq=[positive,negative];upper=[-v,v]
 if protected_steps:
  P=G[:protected_steps*nc].copy();P[:,-1]=0;N=P.copy();N[:,:m]*=-1;pv=v[:protected_steps*nc];ineq += [P,N];upper += [1-pv,1+pv]
 F=sparse.vstack(ineq,format='csr');bound=np.r_[upper];lo=np.r_[state_lo.ravel(),ctrl_lo,0.];hi=np.r_[state_hi.ravel(),ctrl_hi,np.inf];objective=np.zeros(n);objective[-1]=1.
 if np.any(lo>hi):raise ValueError('source cart/control bounds cannot intersect trust box')
 return dict(A_eq=E,b_eq=rhs,A_ub=F,b_ub=bound,lower=lo,upper=hi,objective=objective,state_radii=R,control_radii=V,steps=h,state_dimension=nx,capture_angles=nc,baseline_capture_peak=float(np.max(abs(v))))

def solve_multiple_shooting_minimax(problem,*,solver_seconds=20.):
 if not np.isfinite(solver_seconds) or solver_seconds<=0:raise ValueError('positive finite solver time required')
 p=problem;bounds=list(zip(p['lower'],[None if np.isinf(q) else q for q in p['upper']],strict=True));solved=linprog(p['objective'],A_ub=p['A_ub'],b_ub=p['b_ub'],A_eq=p['A_eq'],b_eq=p['b_eq'],bounds=bounds,method='highs-ds',options=dict(time_limit=solver_seconds,maxiter=100000,primal_feasibility_tolerance=1e-9,dual_feasibility_tolerance=1e-9));diag=dict(status=int(solved.status),message=solved.message,iterations=int(solved.nit),baseline_capture_peak=p['baseline_capture_peak'],variables=len(p['objective']),equality_rows=p['A_eq'].shape[0],inequality_rows=p['A_ub'].shape[0],nonzeros=p['A_eq'].nnz+p['A_ub'].nnz)
 if not solved.success or solved.x is None:return None,diag
 y=np.asarray(solved.x);eq=float(np.max(abs(p['A_eq']@y-p['b_eq'])));ineq=float(max(0.,np.max(p['A_ub']@y-p['b_ub'])));box=float(max(0.,np.max(p['lower']-y),np.max(y-p['upper'])));diag.update(epigraph=float(y[-1]),scaled_equality_residual=eq,scaled_inequality_violation=ineq,scaled_box_violation=box)
 if max(eq,ineq,box)>1e-7:diag['rejected_primal_residual']=True;return None,diag
 h,nx=p['steps'],p['state_dimension'];dx=np.vstack([np.zeros(nx),y[:h*nx].reshape(h,nx)*p['state_radii']]);du=y[h*nx:-1]*p['control_radii'];return dict(scaled_solution=y,state_step=dx,action_step=du),diag
