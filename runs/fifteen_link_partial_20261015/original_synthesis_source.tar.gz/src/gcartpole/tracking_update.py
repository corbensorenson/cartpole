"""Explicit provenance for defect bias and retained or redesigned runtime gains."""
import numpy as np


def native_defect_provider(transition, states, controls, start=0):
    """Measure the delivered native step once; do not add action rounding twice."""
    states = np.asarray(states, dtype=float)
    controls = np.asarray(controls, dtype=float)
    if states.ndim != 2 or controls.ndim != 1 or len(states) != len(controls)+1:
        raise ValueError('native defect reference arrays must align')
    if not isinstance(start, (int, np.integer)) or not 0 <= start < len(controls):
        raise ValueError('native defect start must lie inside the reference')
    def provider(step, context):
        index = step+start
        prediction = transition(states[index], float(controls[index]))
        difference = transition.difference(prediction, states[index+1])
        return context.matrix(np.asarray(difference, dtype=float).tolist())
    return provider


def compose_tracking_gains(saved, designed_tail, start=0, *, retain_saved=False):
    """Keep bias-design gains separate from the gains actually used by replay."""
    saved = np.asarray(saved, dtype=float)
    designed_tail = np.asarray(designed_tail, dtype=float)
    if (saved.ndim != 2 or not isinstance(start, (int, np.integer))
            or not 0 <= start < len(saved)
            or designed_tail.shape != saved[start:].shape
            or not np.all(np.isfinite(saved)) or not np.all(np.isfinite(designed_tail))):
        raise ValueError('saved and designed tracking gains must align and be finite')
    runtime = saved.copy()
    if not retain_saved:
        runtime[start:] = designed_tail
    return runtime


def tracking_regularization(explicit, source='explicit', history=None):
    """Use an explicitly requested final solver value, never an inherited guess."""
    if source not in ('explicit', 'solver'):
        raise ValueError('tracking regularization source must be explicit or solver')
    value = explicit
    if source == 'solver':
        if not history or 'regularization' not in history[-1]:
            raise ValueError('solver tracking regularization requires the final optimizer history row')
        value = history[-1]['regularization']
    value = float(value)
    if not np.isfinite(value) or value < 0:
        raise ValueError('tracking regularization must be finite and nonnegative')
    return value
