"""Precision-preserving modal input diagnostics, separate from native reachability."""
import mpmath


def backward_input_correlation(poles, *, decimal_digits=100):
    """Unit-diagonal infinite backward input Gramian for distinct real z > 1.

    For modal x[k+1]=diag(z)x[k]+beta*u[k], backward correction columns
    beta_i*z_i**(-k), k>=1, have Gramian beta_i*beta_j/(z_i*z_j-1).
    Row normalization and input sign removal give the expression below.
    It isolates modal time-response similarity; input magnitudes, physical
    eigenvector geometry, bounds and nonlinear dynamics are deliberately absent.
    """
    if decimal_digits<40:raise ValueError('at least40 decimal digits required')
    ctx=mpmath.mp.clone();ctx.dps=decimal_digits
    roots=[ctx.mpf(z) for z in poles]
    if not roots or any(not ctx.isfinite(z) or z<=1 for z in roots) or len(set(roots))!=len(roots):
        raise ValueError('distinct finite real unstable positive poles required')
    gram=ctx.matrix([[ctx.sqrt((a*a-1)*(b*b-1))/(a*b-1) for b in roots] for a in roots])
    values,vectors=ctx.eigsy(gram)
    if values[0]<=0:raise ValueError('insufficient precision for positive Gramian spectrum')
    residual=ctx.norm(gram*vectors-vectors*ctx.diag(values))/ctx.norm(gram)
    pairs=[abs(a-b)/(a*b-1) for i,a in enumerate(roots) for b in roots[i+1:]]
    logdet_pairs=2*ctx.fsum(ctx.log10(p) for p in pairs)
    logdet_spectrum=ctx.fsum(ctx.log10(v) for v in values)
    if abs(logdet_pairs-logdet_spectrum)>ctx.mpf(10)**(-decimal_digits//3):
        raise ValueError('Gramian eigenvalues disagree with independent Cauchy determinant identity')
    return ctx,gram,values,vectors,dict(decimal_digits=decimal_digits,
        normalized_backward_gram_eigenvalues=[str(v) for v in values],
        normalized_backward_gram_minimum=str(values[0]),normalized_backward_gram_condition=str(values[values.rows-1]/values[0]),
        normalized_backward_gram_eigen_residual=str(residual),
        log10_normalized_backward_gram_determinant=str(logdet_pairs),
        log_determinant_identity_error=str(abs(logdet_pairs-logdet_spectrum)),
        minimum_normalized_pair_separation=None if not pairs else str(min(pairs)),
        weakest_normalized_modal_combination=[str(vectors[i,0]) for i in range(len(roots))],
        scope='Unstable diagonal local input-response similarity in normalized modal coordinates. Not a physical capture radius, bounded-input feasibility result, nonlinear Gramian or proof of impossibility.')


def upright_spectrum(a,b,transform,*,dt,decimal_digits=100):
    """Eigenvalues and normalized left-mode input coupling in declared coordinates."""
    ctx=mpmath.mp.clone();ctx.dps=decimal_digits
    convert=lambda v:ctx.matrix(v.tolist() if hasattr(v,'tolist') else v)
    am,bm,w=map(convert,(a,b,transform));az=w*am*ctx.inverse(w);bz=w*bm
    roots,right=ctx.eig(az,left=False,right=True);left=ctx.inverse(right)
    tolerance=ctx.mpf(10)**(-decimal_digits//2)
    if any(abs(ctx.im(z))>tolerance for z in roots):raise ValueError('positive-real unstable spectral family required')
    indices=sorted((i for i,z in enumerate(roots) if ctx.re(z)>1+tolerance),key=lambda i:ctx.re(roots[i]))
    unstable=[ctx.re(roots[i]) for i in indices];rates=[ctx.log(z)/ctx.mpf(dt) for z in unstable]
    overlaps=[abs((left*bz)[i])/ (ctx.sqrt(ctx.fsum(abs(left[i,j])**2 for j in range(left.cols)))*ctx.norm(bz)) for i in indices]
    eigen_residual=ctx.norm(az*right-right*ctx.diag(roots))/max(ctx.norm(az)*ctx.norm(right),ctx.mpf(1))
    _,_,_,_,gram=backward_input_correlation([str(z) for z in unstable],decimal_digits=decimal_digits)
    return dict(**gram,unstable_poles=[str(z) for z in unstable],unstable_growth_rates_per_second=[str(v) for v in rates],
        minimum_adjacent_unstable_growth_gap_per_second=str(min(b-a for a,b in zip(rates[:-1],rates[1:]))),
        fastest_unstable_growth_per_second=str(max(rates)),fastest_doubling_time_seconds=str(ctx.log(2)/max(rates)),
        left_mode_normalized_input_overlaps=[str(v) for v in overlaps],minimum_left_mode_input_overlap=str(min(overlaps)),
        input_modal_coefficients=[str((left*bz)[i]) for i in indices],
        eigen_residual=str(eigen_residual),unstable_mode_count=len(indices),all_poles=[str(ctx.re(z)) for z in roots],
        stable_mode_count=sum(abs(z)<1-tolerance for z in roots),neutral_mode_count=sum(abs(z-1)<=tolerance for z in roots))
