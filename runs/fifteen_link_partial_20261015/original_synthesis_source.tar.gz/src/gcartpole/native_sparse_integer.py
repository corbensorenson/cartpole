"""Sparse delivered-input minimax MILP proposals with independent model checks."""
import numpy as np
from scipy.optimize import Bounds,LinearConstraint,milp


def sparse_integer_minimax(response,values,lower,upper,*,solver_seconds=1.,node_limit=20000):
    response=np.asarray(response,float);values=np.asarray(values,float)
    lower=np.asarray(lower);upper=np.asarray(upper)
    if (values.ndim!=1 or not len(values) or response.ndim!=2 or response.shape[0]!=len(values)
            or lower.shape!=(response.shape[1],) or upper.shape!=lower.shape
            or not all(np.all(np.isfinite(x)) for x in (response,values,lower,upper))
            or np.any(lower!=np.rint(lower)) or np.any(upper!=np.rint(upper))
            or np.any(lower>0) or np.any(upper<0) or np.any(lower>upper)
            or not np.isfinite(solver_seconds) or solver_seconds<=0
            or not isinstance(node_limit,(int,np.integer)) or node_limit<1):
        raise ValueError('finite physical rows,integer center-containing boxes and bounded MILP budgets required')
    k=response.shape[1];baseline=float(np.max(np.abs(values)))
    matrix=np.vstack([np.column_stack([response,-np.ones(len(values))]),
        np.column_stack([-response,-np.ones(len(values))])])
    rhs=np.r_[-values,values]
    result=milp(np.r_[np.zeros(k),1.],integrality=np.r_[np.ones(k),0],
        bounds=Bounds(np.r_[lower,0.],np.r_[upper,baseline]),
        constraints=LinearConstraint(matrix,np.full(len(rhs),-np.inf),rhs),
        options=dict(time_limit=solver_seconds,node_limit=node_limit,mip_rel_gap=1e-4,presolve=True))
    d=dict(status='no_checked_incumbent',solver_status=int(result.status),solver_success=bool(result.success),
        solver_message=result.message,baseline_predicted_normalized_peak=baseline,
        nonzero_coefficients_below1em9=int(np.count_nonzero((response!=0)&(np.abs(response)<1e-9))))
    for key in ('mip_gap','mip_dual_bound','mip_node_count'):
        value=getattr(result,key,None)
        d[key]=float(value) if value is not None and np.isfinite(value) else None
    if result.x is None or not np.all(np.isfinite(result.x)):return None,d
    offsets=np.rint(result.x[:k]);error=float(np.max(np.abs(offsets-result.x[:k])))
    peak=float(np.max(np.abs(values+response@offsets)))
    d.update(maximum_integer_rounding_error=error,checked_predicted_normalized_peak=peak,
        solver_epigraph=float(result.x[-1]),nonzero_offsets=int(np.count_nonzero(offsets)))
    if error>1e-5 or np.any(offsets<lower) or np.any(offsets>upper) or peak>baseline+1e-7:return None,d
    d['status']='checked_integer_model_incumbent'
    return offsets.astype(np.int64),d
