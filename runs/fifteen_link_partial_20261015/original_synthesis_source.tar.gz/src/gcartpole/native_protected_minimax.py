"""Affine trust-box proposals with explicit bounds on selected physical features.

Native delivered-action trajectories still determine acceptance. This module
leaves the historical unprotected proposal implementation unchanged.
"""
import numpy as np
from scipy.optimize import linprog
from gcartpole.native_trust_minimax import affine_trust_proposal


def protected_trust_proposal(values, jacobian, radii, *, protected_indices=(),
                             protected_limit=1., action_values=None,
                             action_basis=None, solver_seconds=5.):
    values=np.asarray(values,float);jacobian=np.asarray(jacobian,float);radii=np.asarray(radii,float)
    if values.ndim!=1 or radii.ndim!=1 or jacobian.ndim!=2:
        raise ValueError('one-dimensional features/radii and a matrix Jacobian required')
    indices=np.asarray(protected_indices)
    if indices.ndim!=1 or (indices.size and (not np.issubdtype(indices.dtype,np.integer)
        or np.any(indices<0) or np.any(indices>=len(values)) or len(np.unique(indices))!=len(indices))):
        raise ValueError('distinct aligned protected feature indices required')
    if not np.isfinite(protected_limit) or protected_limit<=0:
        raise ValueError('positive finite protected feature limit required')
    if not indices.size:
        return affine_trust_proposal(values,jacobian,radii,action_values=action_values,
                                     action_basis=action_basis,solver_seconds=solver_seconds)
    if (values.ndim!=1 or not len(values) or jacobian.shape!=(len(values),len(radii))
        or radii.ndim!=1 or not len(radii) or np.any(radii<=0)
        or not all(np.all(np.isfinite(v)) for v in (values,jacobian,radii))
        or not np.isfinite(solver_seconds) or solver_seconds<=0):
        raise ValueError('finite aligned feature model and positive trust radii required')
    indices=indices.astype(int);mapped=jacobian*radii;dimension=len(radii)
    matrix=np.vstack([np.c_[mapped,-np.ones(len(values))],np.c_[-mapped,-np.ones(len(values))],
                      np.c_[mapped[indices],np.zeros(len(indices))],
                      np.c_[-mapped[indices],np.zeros(len(indices))]])
    rhs=np.r_[-values,values,protected_limit-values[indices],protected_limit+values[indices]]
    if (action_values is None)!=(action_basis is None):
        raise ValueError('action values and basis must be supplied together')
    if action_values is not None:
        action_values=np.asarray(action_values,float);action_basis=np.asarray(action_basis,float)
        if (action_values.ndim!=1 or action_basis.shape!=(len(action_values),dimension)
            or not np.all(np.isfinite(action_values)) or not np.all(np.isfinite(action_basis))
            or np.any(abs(action_values)>1+1e-12)):
            raise ValueError('finite bounded nominal actions and aligned action basis required')
        am=action_basis*radii;matrix=np.vstack([matrix,np.c_[am,np.zeros(len(am))],np.c_[-am,np.zeros(len(am))]])
        rhs=np.r_[rhs,1-action_values,1+action_values]
    result=linprog(np.r_[np.zeros(dimension),1.],A_ub=matrix,b_ub=rhs,
                   bounds=[(-1.,1.)]*dimension+[(0.,None)],method='highs-ds',
                   options=dict(time_limit=solver_seconds,maxiter=10000,
                                primal_feasibility_tolerance=1e-9,dual_feasibility_tolerance=1e-9))
    diagnostic=dict(solver_status=int(result.status),solver_message=str(result.message),
                    solver_iterations=int(result.nit or 0),baseline_maximum=float(np.max(abs(values))),
                    protected_feature_count=len(indices),protected_limit=float(protected_limit),
                    baseline_protected_maximum=float(np.max(abs(values[indices]))),
                    scope='Affine trust-box minimax with selected feature bounds only; delivered F32 native physics determines acceptance.')
    if not result.success or result.x is None or not np.all(np.isfinite(result.x)):
        return None,diagnostic
    delta=radii*result.x[:-1];error=float(np.max(np.maximum(matrix@result.x-rhs,0)))
    prediction=values+jacobian@delta
    diagnostic.update(predicted_maximum=float(np.max(abs(prediction))),
                      predicted_protected_maximum=float(np.max(abs(prediction[indices]))),
                      lp_epigraph=float(result.x[-1]),maximum_lp_inequality_error=error)
    if error>1e-7 or np.any(abs(delta)>radii*(1+1e-8)):
        diagnostic['rejected_numerical_residual']=True;return None,diagnostic
    return delta,diagnostic
