"""Precision SISO pole placement; nonlinear native validation remains separate."""
import numpy as np
import mpmath
from .lqr_design import _precision_eigenvalues


def high_precision_siso_pole_gain(a,b,poles,*,decimal_digits=100):
    """Ackermann's identity with precision inputs and a rounded runtime gain.

    It solves the transpose controllability system instead of forming its
    inverse. Stable input-model poles do not certify native saturated behavior.
    """
    if not isinstance(decimal_digits,int) or decimal_digits<30:
        raise ValueError('pole design requires at least30 decimal digits')
    ctx=mpmath.mp.clone();ctx.dps=decimal_digits
    am=ctx.matrix(a.tolist() if hasattr(a,'tolist') else a)
    bm=ctx.matrix(b.tolist() if hasattr(b,'tolist') else b)
    n=am.rows;targets=[ctx.mpc(p) for p in poles]
    if (n<1 or am.cols!=n or bm.rows!=n or bm.cols!=1 or len(targets)!=n
            or not all(ctx.isfinite(x) and ctx.im(x)==0 for matrix in (am,bm) for x in matrix)
            or not all(ctx.isfinite(p) and abs(p)<1 for p in targets)):
        raise ValueError('finite real SISO matrices and aligned strictly stable target poles required')
    controllability=ctx.zeros(n,n);vector=bm.copy()
    for column in range(n):
        for row in range(n):controllability[row,column]=vector[row,0]
        vector=am*vector
    selector=ctx.zeros(n,1);selector[n-1,0]=1
    # mpmath's LU pivot search raises TypeError for an all-zero pivot column.
    # Check singularity explicitly so that unrelated TypeErrors still propagate.
    if ctx.det(controllability)==0:
        raise ValueError('input model is not controllable at requested precision')
    try:row=ctx.lu_solve(controllability.T,selector).T
    except ZeroDivisionError as error:raise ValueError('input model is not controllable at requested precision') from error
    coefficients=[ctx.mpc(1)]
    for pole in targets:
        following=[ctx.mpc(0)]*(len(coefficients)+1)
        for index,value in enumerate(coefficients):
            following[index]+=value;following[index+1]-=pole*value
        coefficients=following
    identity=ctx.eye(n)
    def polynomial(matrix):
        result=coefficients[0]*identity
        for value in coefficients[1:]:result=result*matrix+value*identity
        return result
    pa=polynomial(am);km=row*pa
    imaginary=max(abs(ctx.im(x)) for x in km)
    tolerance=ctx.mpf(10)**(-decimal_digits//2)
    if imaginary>tolerance*max(ctx.norm(km),ctx.mpf(1)):
        raise ValueError('target poles must define a real feedback gain')
    km=ctx.matrix([[ctx.re(x) for x in km]])
    gain=np.asarray(km.tolist(),float)
    if not np.all(np.isfinite(gain)):raise ValueError('pole gain is not representable in binary64')
    exact=am-bm*km;rounded=am-bm*ctx.matrix(gain.tolist())
    exact_values=_precision_eigenvalues(exact,ctx);rounded_values=_precision_eigenvalues(rounded,ctx)
    exact_radius=max(abs(x) for x in exact_values);rounded_radius=max(abs(x) for x in rounded_values)
    residual=ctx.norm(polynomial(exact))/max(ctx.norm(pa),ctx.mpf(1))
    if residual>ctx.sqrt(tolerance) or exact_radius>=1:
        raise ValueError('pole placement failed precision polynomial/stability validation')
    diagnostics=dict(method='precision_siso_ackermann_transpose_solve',decimal_digits=decimal_digits,
        target_poles=[str(p) for p in targets],high_precision_gain=[str(x) for x in km],
        high_precision_spectral_radius=str(exact_radius),rounded_gain_high_precision_spectral_radius=str(rounded_radius),
        rounded_gain_stabilizes_input_model=bool(rounded_radius<1),relative_characteristic_residual=str(residual),
        relative_controllability_solve_residual=str(ctx.norm(row*controllability-selector.T)),
        gain_norm=float(np.linalg.norm(gain)),nonlinear_certified=False,
        scope='Precision scalar/model information is retained;input-model errors,rounded gain,F32 actuation and native state arithmetic remain. Model pole placement is not a native capture certificate.')
    return gain,diagnostics
