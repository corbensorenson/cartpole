"""Select a recorded physical arrival without inventing missing trajectory data."""
import numpy as np
from .angles import wrap_angle


def select_physical_prefix(states, n_links, *, dt=.02):
    """Latest declared 0.2s-grid arrival from 6--8s, inside physical limits.

    This is a component selection rule, not a capture basin certificate. Every
    preceding state must be finite and in rail; only the endpoint is required
    to be near upright and slow. Later failed motion does not erase a feasible
    recorded prefix, and unavailable ticks are never extrapolated.
    """
    x=np.asarray(states,dtype=float)
    if x.ndim!=2 or x.shape[1]!=2*(n_links+1) or dt<=0:
        raise ValueError('invalid state layout or sampling period')
    for seconds in np.arange(8.,5.99,-.2):
        tick=round(seconds/dt)
        if tick>=len(x):continue
        prefix=x[:tick+1]
        if not np.all(np.isfinite(prefix)) or np.max(abs(prefix[:,0]))>2.85:continue
        state=x[tick]
        angle=float(np.max(abs(wrap_angle(np.cumsum(state[1:n_links+1])))))
        rate=float(np.sqrt(np.mean(np.cumsum(state[n_links+2:])**2)))
        if angle<=.15 and rate<=.75:
            return dict(steps=tick,seconds=tick*dt,max_abs_angle=angle,absolute_rate_rms=rate,
                        maximum_prefix_cart=float(np.max(abs(prefix[:,0]))))
    return None
