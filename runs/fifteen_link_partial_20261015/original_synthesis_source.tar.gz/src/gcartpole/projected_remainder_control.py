"""Bounded native action correction against one projected linear-model target.

This is a local policy experiment, not a stability theorem. The predictor must
remain independent of the live environment; all candidates are float32 actions.
"""
import mpmath
import numpy as np

from .angles import wrap_angle


class ProjectedRemainderController:
    def __init__(self, predictor, a, b, gain, *, n_links, decimal_digits=100,
                 secant_iterations=12, action_probe=1e-5, angle_limit=.15, rail_limit=3.):
        self.predictor = predictor
        self.n = int(n_links)
        self.ctx = mpmath.mp.clone(); self.ctx.dps = decimal_digits
        self.a = self.ctx.matrix(a.tolist() if hasattr(a, 'tolist') else a)
        self.b = self.ctx.matrix(b.tolist() if hasattr(b, 'tolist') else b)
        self.gain = np.asarray(gain, dtype=float).ravel()
        self.k = self.ctx.matrix([self.gain.tolist()])
        nx = 2*(self.n+1)
        if (self.a.rows != nx or self.a.cols != nx or self.b.rows != nx or self.b.cols != 1
                or self.gain.shape != (nx,) or not np.all(np.isfinite(self.gain))
                or not all(self.ctx.isfinite(v) for matrix in (self.a, self.b) for v in matrix)
                or decimal_digits < 40 or not 0 < action_probe <= .1
                or not 1 <= secant_iterations <= 24 or not 0 < angle_limit < np.pi
                or not 0 < rail_limit):
            raise ValueError('finite aligned mechanical model and positive bounded policy settings required')
        self.closed = self.a-self.b*self.k
        self.output = self.k*self.closed
        self.kb = (self.k*self.b)[0]
        self.iterations = secant_iterations
        self.probe = action_probe
        self.angle_limit = angle_limit
        self.rail_limit = rail_limit

    def physical(self, state):
        state = np.asarray(state, dtype=float).copy()
        if state.shape != self.gain.shape or not np.all(np.isfinite(state)):
            raise ValueError('finite aligned physical state required')
        state[1:self.n+1] = wrap_angle(state[1:self.n+1])
        return state

    def select(self, state):
        x = self.physical(state)
        raw = -float(self.gain@x)
        baseline = float(np.float32(np.clip(raw, -1., 1.)))
        target = -(self.output*self.ctx.matrix(x.tolist()))[0]
        if not self.ctx.isfinite(target):
            raise ValueError('nonfinite projected target')
        cache = {}

        def evaluate(action):
            delivered = float(np.float32(np.clip(action, -1., 1.)))
            if delivered in cache:
                return cache[delivered]
            predicted = np.asarray(self.predictor(np.asarray(state, dtype=float), delivered), dtype=float)
            if predicted.shape != x.shape or not np.all(np.isfinite(predicted)):
                raise ValueError('predictor returned invalid physical state')
            following = self.physical(predicted)
            projected = -(self.k*self.ctx.matrix(following.tolist()))[0]
            residual = projected-target
            angle = float(np.max(np.abs(wrap_angle(np.cumsum(predicted[1:self.n+1])))))
            violation = max(0., angle/self.angle_limit-1., abs(float(predicted[0]))/self.rail_limit-1.)
            item = dict(action=delivered, projected=projected, residual=residual,
                        predicted=predicted, angle=angle, violation=violation,
                        score=(violation, abs(residual), abs(delivered-baseline)))
            cache[delivered] = item
            return item

        initial = evaluate(baseline)
        left = evaluate(baseline-self.probe)
        right = evaluate(baseline+self.probe)
        # Choose a physical candidate by the declared one-step lexicographic
        # score. Secants only propose bounded delivered actions; no real-valued
        # root or tolerance can substitute for the checked float32 outcome.
        history = [left, right]
        for _ in range(self.iterations):
            best = min(cache.values(), key=lambda r:r['score'])
            pairs = [(history[-2], history[-1])]
            if self.kb:
                proposed = best['action']+float(best['residual']/self.kb)
            else:
                proposed = best['action']
            previous, current = pairs[0]
            difference = current['residual']-previous['residual']
            if difference and current['action'] != previous['action']:
                proposed = current['action']-float(current['residual']*
                    self.ctx.mpf(current['action']-previous['action'])/difference)
            trial = evaluate(proposed)
            history.append(trial)
            if trial['action'] == current['action']:
                break
        best = min(cache.values(), key=lambda r:r['score'])
        adjacent = np.float32(best['action'])
        for direction in (-np.inf, np.inf):
            evaluate(float(np.nextafter(adjacent, np.float32(direction), dtype=np.float32)))
        selected = min(cache.values(), key=lambda r:r['score'])
        assert len(cache) <= self.iterations+5
        assert selected['score'] <= initial['score']
        return selected['action'], selected['predicted'].copy(), dict(
            baseline_raw_action=raw, baseline_delivered_action=baseline,
            target_next_raw_action=str(target), baseline_next_projected_action=str(initial['projected']),
            selected_next_projected_action=str(selected['projected']),
            baseline_projected_error=str(initial['residual']),
            selected_projected_error=str(selected['residual']),
            baseline_angle=initial['angle'], selected_angle=selected['angle'],
            selected_one_step_violation=selected['violation'],
            improving=selected['score'] < initial['score'],
            changed_delivered_action=selected['action'] != baseline,
            predictor_evaluations=len(cache), mechanical_kb=str(self.kb),
            scope='Gain-projected next native-state remainder correction against MP mechanical linear feedback target. One-step improvement is not a capture or stability certificate.')
