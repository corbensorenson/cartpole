"""All-input affine minimax diagnostics; delivered native tapes decide acceptance."""
import mpmath
import numpy as np
from scipy.optimize import linprog
from .native_integer_continuation import normalized_bound_model


def checked_bound_model(model,center,states,prefix,n_links,angle_limit,rail_limit):
    for key,current in (('center',center),('states',states),('prefix_state',prefix)):
        if np.asarray(model[key],float).tobytes()!=np.asarray(current,float).tobytes():
            raise ValueError('frozen native affine context changed')
    values,response=normalized_bound_model(states,model['task_jacobian'],np.ones(len(center)),n_links,angle_limit,rail_limit)
    if values.tobytes()!=model['values'].tobytes() or response.tobytes()!=model['response'].tobytes():
        raise ValueError('frozen physical affine rows changed')
    return values,response


def checked_affine_prediction(response,values,delta):
    response=np.asarray(response,float);values=np.asarray(values,float);delta=np.asarray(delta,float)
    if (values.ndim!=1 or not len(values) or delta.ndim!=1 or not len(delta)
            or response.shape!=(len(values),len(delta))
            or not all(np.all(np.isfinite(x)) for x in (response,values,delta))):
        raise ValueError('finite aligned affine model required')
    ctx=mpmath.mp.clone();ctx.dps=100
    prediction=np.array([float(ctx.mpf(float(v))+ctx.fdot(
        [ctx.mpf(float(x)) for x in row],[ctx.mpf(float(x)) for x in delta]))
        for row,v in zip(response,values)])
    if not np.all(np.isfinite(prediction)):raise ValueError('nonfinite checked affine prediction')
    return prediction


def bounded_real_minimax(response,values,lower,upper,*,solver_seconds=10.):
    response=np.asarray(response,float);values=np.asarray(values,float)
    lower=np.asarray(lower,float);upper=np.asarray(upper,float)
    if (values.ndim!=1 or not len(values) or response.ndim!=2 or not response.shape[1]
            or response.shape[0]!=len(values) or lower.shape!=(response.shape[1],)
            or upper.shape!=lower.shape or not all(np.all(np.isfinite(x)) for x in (response,values,lower,upper))
            or np.any(lower>0) or np.any(upper<0) or np.any(lower>=upper)
            or not np.isfinite(solver_seconds) or solver_seconds<=0):
        raise ValueError('finite all-input model and center-containing physical boxes required')
    scale=np.maximum(-lower,upper);mapped=response*scale[None,:]
    baseline=float(np.max(np.abs(values)));k=len(lower)
    matrix=np.vstack([np.column_stack([mapped,-np.ones(len(values))]),
                      np.column_stack([-mapped,-np.ones(len(values))])]);rhs=np.r_[-values,values]
    result=linprog(np.r_[np.zeros(k),1.],A_ub=matrix,b_ub=rhs,
        bounds=list(zip(lower/scale,upper/scale))+[(0,baseline)],method='highs-ds',
        options=dict(time_limit=solver_seconds,maxiter=10000,
            primal_feasibility_tolerance=1e-9,dual_feasibility_tolerance=1e-9))
    d=dict(status='solver_rejected',solver_status=int(result.status),solver_success=bool(result.success),
        solver_message=result.message,solver_iterations=int(result.nit or 0),
        baseline_normalized_peak=baseline,maximum_scaled_response=float(np.max(np.abs(mapped))),
        nonzero_scaled_coefficients_below1em9=int(np.count_nonzero((mapped!=0)&(np.abs(mapped)<1e-9))))
    if not result.success or result.x is None or not np.all(np.isfinite(result.x)):return None,d
    delta=scale*result.x[:-1]
    normalized_box_error=float(np.max(np.maximum(np.r_[lower/scale-result.x[:-1],result.x[:-1]-upper/scale],0)))
    if normalized_box_error>1e-7:d['status']='box_rejected';return None,d
    delta=np.clip(delta,lower,upper)
    prediction=checked_affine_prediction(response,values,delta)
    peak=float(np.max(np.abs(prediction)));epigraph=float(result.x[-1])
    error=max(peak-epigraph,0.)
    d.update(checked_normalized_peak=peak,solver_epigraph=epigraph,
        maximum_checked_epigraph_error=error,maximum_normalized_box_error=normalized_box_error,
        binary64_prediction_maximum_error=float(np.max(np.abs(prediction-(values+response@delta)))))
    if error>1e-7 or peak>baseline+1e-7:d['status']='checked_model_rejected';return None,d
    d['status']='checked_optimal_real_model_proposal'
    return delta,d


def quantized_box_trial(center,delta,lower,upper,fraction):
    center=np.asarray(center,float);delta=np.asarray(delta,float)
    lower=np.asarray(lower,float);upper=np.asarray(upper,float)
    if (center.ndim!=1 or not len(center) or any(v.shape!=center.shape for v in (delta,lower,upper))
            or not all(np.all(np.isfinite(v)) for v in (center,delta,lower,upper))
            or np.any(np.abs(center)>1) or center.tobytes()!=center.astype(np.float32).astype(float).tobytes()
            or np.any(lower>0) or np.any(upper<0) or np.any(lower>upper)
            or np.any(center+lower < -1) or np.any(center+upper > 1)
            or not np.isfinite(fraction) or not 0<fraction<=1):
        raise ValueError('bounded delivered center,physical box and contraction required')
    lo=center+lower;hi=center+upper
    proposal=np.clip(center+delta*fraction,lo,hi).astype(np.float32)
    outside=(proposal.astype(float)<lo)|(proposal.astype(float)>hi)
    proposal[outside]=np.nextafter(proposal[outside],center[outside].astype(np.float32))
    actions=proposal.astype(float)
    if np.any(actions<lo) or np.any(actions>hi) or np.any(np.abs(actions)>1):
        raise ValueError('no bounded delivered trial after inward rounding')
    return actions
