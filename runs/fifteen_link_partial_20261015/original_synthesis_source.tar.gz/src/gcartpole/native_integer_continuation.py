"""Seed and support selection for representable native horizon extension."""
import numpy as np
from .angles import wrap_angle


def selected_source_score(source,selected):
    """A failed longer center's score must never stand in for the valid tape."""
    if 'selected_plan_score' in source:return source['selected_plan_score']
    selected=np.asarray(selected,float)
    if ('last_finite_score' in source and 'last_finite_center' in source
            and np.asarray(source['last_finite_center'],float).tobytes()==selected.tobytes()):
        return source['last_finite_score']
    for stage in reversed(source.get('stages',[])):
        if stage['feasible_sequence_found'] and stage['horizon_steps']==len(selected):return stage['score']
    raise ValueError('original selected-plan score is unavailable')


def source_known_tape(source,parent=None):
    """Recover the shorter checked plan from growth or failed diagnostic exports."""
    if source.get('selected_sequence') is not None:
        actions=np.asarray(source['selected_sequence'],float);states=np.asarray(source['selected_states'],float)
        score=selected_source_score(source,actions)
    else:
        actions=np.asarray(source['known_plan'],float);states=np.asarray(source['known_plan_states'],float)
        if 'known_plan_score' in source:score=source['known_plan_score']
        else:
            if parent is None or np.asarray(parent.get('selected_sequence'),float).tobytes()!=actions.tobytes():
                raise ValueError('bound parent with identical known plan required')
            score=selected_source_score(parent,actions)
    if (actions.ndim!=1 or not len(actions) or states.ndim!=2 or states.shape[0]!=len(actions)
            or states.shape[1]<4 or states.shape[1]%2
            or not np.all(np.isfinite(states)) or not np.all(np.isfinite(actions)) or np.any(abs(actions)>1)
            or actions.tobytes()!=actions.astype(np.float32).astype(float).tobytes()):
        raise ValueError('finite delivered shorter plan and physical states required')
    return actions,states,score


def append_seed_controls(reference,teacher,start,horizon):
    """Teacher controls are optional proposals, never a physical horizon bound."""
    reference=np.asarray(reference,float);teacher=np.asarray(teacher,float)
    if (reference.ndim!=1 or teacher.ndim!=1 or not isinstance(start,int) or start<0
            or not isinstance(horizon,int) or horizon<1 or start+horizon>len(reference)
            or not all(np.all(np.isfinite(v)) and np.all(np.abs(v)<=1) for v in (reference,teacher))
            or any(v.tobytes()!=v.astype(np.float32).astype(float).tobytes() for v in (reference,teacher))):
        raise ValueError('delivered unpadded reference and optional actual teacher controls required')
    index=start+horizon-1;choices=[('reference',float(reference[index])),('zero',0.)]
    if index<len(teacher):choices.append(('actual_teacher',float(teacher[index])))
    seen=set();seeds=[]
    for label,value in choices:
        if value not in seen:seen.add(value);seeds.append(dict(label=label,action=value))
    return seeds


def structured_integer_supports(horizon,spans,preferred=(),max_supports=80):
    """Retain prior moves, then distribute five inputs across time and scales."""
    if (not isinstance(horizon,int) or horizon<5 or not isinstance(max_supports,int) or max_supports<1
            or not spans or any(not isinstance(s,int) or not 4<=s<horizon for s in spans)
            or list(spans)!=sorted(set(spans))):raise ValueError('bounded horizon and ordered five-input spans required')
    supports=[];seen=set()
    def add(indices):
        support=tuple(sorted(set(map(int,indices))))
        if len(support)==5 and min(support)>=0 and max(support)<horizon and support not in seen:
            seen.add(support);supports.append(support)
    for indices in preferred:
        if len(indices)==5:add(indices)
        elif len(indices)==4:
            for extra in np.rint(np.linspace(0,horizon-1,8)).astype(int):add([*indices,int(extra)])
    groups=[]
    for span in spans:
        offsets=np.rint(np.linspace(0,span,5)).astype(int)
        groups.append([tuple(start+offsets) for start in np.rint(np.linspace(0,horizon-span-1,8)).astype(int)])
    for index in range(8):
        for group in groups:add(group[index])
    return supports[:max_supports]


def normalized_bound_model(states,jacobian,spacing,n_links,angle_limit,rail_limit):
    states=np.asarray(states,float);jac=np.asarray(jacobian,float);spacing=np.asarray(spacing,float)
    if (not isinstance(n_links,int) or n_links<1 or states.ndim!=2 or not len(states)
            or states.shape[1]!=2*(n_links+1) or spacing.shape!=(len(states),)
            or jac.shape!=(2*n_links*len(states)+2*len(states)+2*n_links,len(states))
            or not all(np.all(np.isfinite(x)) for x in (states,jac,spacing)) or np.any(spacing<=0)
            or not .1<angle_limit<.15 or not np.isfinite(rail_limit) or rail_limit<=0):
        raise ValueError('aligned physical unbanded task Jacobian and native bounds required')
    n=n_links;h=len(states);scaled=jac*spacing[None,:]
    phi=wrap_angle(np.cumsum(states[:,1:n+1],axis=1))
    values=np.r_[phi.ravel()/angle_limit,states[:,0]/rail_limit]
    response=np.vstack([scaled[:n*h]*(.15*np.sqrt(n*h)/angle_limit),
        scaled[2*n*h:2*n*h+h]*(1.5*np.sqrt(h)/.1/rail_limit)])
    return values,response
