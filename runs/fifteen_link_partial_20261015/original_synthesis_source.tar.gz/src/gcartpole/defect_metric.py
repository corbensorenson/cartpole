"""Explicit collocation defect factors in a frozen feedback-sensitive basis."""
import json
from pathlib import Path
import numpy as np

def load_defect_factor(path,default):
 base=np.asarray(default,dtype=float)
 if path is None:return base.copy()
 factor=np.asarray(json.loads(Path(path).read_text())['factor'],dtype=float)
 if factor.shape!=base.shape or not np.all(np.isfinite(factor)):raise ValueError('defect factor must be finite and match the state dimension')
 return factor

def feedback_direction_factors(base,next_gains,weights):
 """Separate L1 basis rotation from added feedback-direction weighting.

F_beta.T F_beta = D.T D + beta**2 * mean(K.T K), but the optimizer
uses L1 residuals; include the beta-zero rotated control in comparisons.
No Gram matrix or artificial singular-value floor is used.
"""
 D=np.asarray(base,dtype=float);K=np.asarray(next_gains,dtype=float);weights=np.asarray(weights,dtype=float)
 if D.ndim!=2 or D.shape[0]!=D.shape[1] or K.ndim!=2 or K.shape[1]!=len(D) or len(K)<len(D):raise ValueError('invalid defect factor/gain dimensions')
 if not all(np.all(np.isfinite(v)) for v in [D,K,weights]) or np.any(weights<0):raise ValueError('finite nonnegative metric weights required')
 scaled=K@np.linalg.inv(D)/np.sqrt(len(K));_,singular,Q=np.linalg.svd(scaled,full_matrices=False);rotation=Q@D
 factors=[np.sqrt(1+(beta*singular)**2)[:,None]*rotation for beta in weights]
 return factors,dict(rotation=Q.tolist(),base=D.tolist(),singular_values=singular.tolist(),gain_rows=len(K),weights=weights.tolist(),gram_matrix_formed=False,singular_value_floor_applied=False)
