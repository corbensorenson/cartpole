"""Delivered-F32 pair proposals; only native forecasts can validate them."""
import numpy as np
from itertools import combinations,product
from .native_action_lattice import affine_action_lattice
from .angles import wrap_angle


def balanced_action_pairs(center,jacobian,residual,reference,*,amplitudes=(1,2,4,8,16),
                          max_offset=4096,action_regularization=.01,minimum_column_response=1e-12):
    """Propose two-input integer moves that approximately cancel a leading row mode.

    Uses a binary64 SVD of the task Jacobian scaled by each action's F32 grid.
    Predictions rank candidates only; no model feasibility or native acceptance
    is inferred. Direct +/-1 pairs supplement leading-mode cancellation pairs.
    """
    center=np.asarray(center,float);jac=np.asarray(jacobian,float)
    residual=np.asarray(residual,float);reference=np.asarray(reference,float)
    spacing,lower,upper=affine_action_lattice(center,max_offset)
    if (reference.shape!=center.shape or residual.ndim!=1 or not len(residual)
            or jac.shape!=(len(residual),len(center))
            or not all(np.all(np.isfinite(x)) for x in (jac,residual,reference))
            or not len(amplitudes) or any(not isinstance(v,(int,np.integer)) or not 1<=v<=max_offset for v in amplitudes)
            or not np.isfinite(action_regularization) or action_regularization<0
            or not np.isfinite(minimum_column_response) or minimum_column_response<0):
        raise ValueError('finite aligned task inputs and bounded integer amplitudes required')
    scaled=jac*spacing[None,:]
    _,singular,right=np.linalg.svd(scaled,full_matrices=False)
    coefficients=singular[0]*right[0]
    active=np.flatnonzero(np.linalg.norm(scaled,axis=0)>minimum_column_response)
    offsets=set()
    def add(i,j,oi,oj):
        if i>j:i,j,oi,oj=j,i,oj,oi
        if oi!=0 and oj!=0 and lower[i]<=oi<=upper[i] and lower[j]<=oj<=upper[j]:offsets.add((int(i),int(j),int(oi),int(oj)))
    for position,i in enumerate(active):
        for j in active[position+1:]:
            for oi in (-1,1):
                for oj in (-1,1):add(i,j,oi,oj)
            for first,second in ((i,j),(j,i)):
                if coefficients[second]==0:continue
                for amplitude in amplitudes:
                    for sign in (-1,1):
                        oi=sign*amplitude;target=-oi*coefficients[first]/coefficients[second]
                        if not np.isfinite(target) or abs(target)>max_offset+1:continue
                        for oj in {int(np.floor(target)),int(np.ceil(target))}:add(first,second,oi,oj)
    regularizer=action_regularization**2;difference=center-reference
    baseline_action_cost=regularizer*float(difference@difference);proposals=[]
    for i,j,oi,oj in sorted(offsets):
        di,dj=spacing[i]*oi,spacing[j]*oj
        change=scaled[:,i]*oi+scaled[:,j]*oj;predicted=residual+change
        cost=float(predicted@predicted+baseline_action_cost+regularizer*(2*(difference[i]*di+difference[j]*dj)+di*di+dj*dj))
        if np.isfinite(cost):proposals.append(dict(indices=[i,j],offsets_ulps=[oi,oj],
            predicted_total_cost=cost,leading_mode_change=float(coefficients[i]*oi+coefficients[j]*oj)))
    proposals.sort(key=lambda p:(p['predicted_total_cost'],p['indices'],p['offsets_ulps']))
    return proposals,dict(spacing=spacing.tolist(),lower_offsets=lower.tolist(),upper_offsets=upper.tolist(),
        active_action_columns=active.tolist(),leading_scaled_singular_value=float(singular[0]),
        leading_scaled_coefficients=coefficients.tolist(),proposal_count=len(proposals),
        minimum_column_response=minimum_column_response,
        scope='Binary64 leading scaled task singular-mode cancellation proposes integer two-input F32 changes;native nonlinear feasibility remains unproven.')


def rank_pairs_by_physical_bounds(proposals,spacing,unbanded_task_jacobian,states,*,n_links,angle_limit,rail_limit):
    """Rank sparse moves using linearized angle/cart violations and task cost ties.

    Requires the unbanded physical_task_residual Jacobian row convention.
    Native proposals must still be evaluated; these are local predictions.
    """
    states=np.asarray(states,float);jac=np.asarray(unbanded_task_jacobian,float);spacing=np.asarray(spacing,float)
    h=len(states);n=n_links
    if (n<1 or h<1 or states.shape!=(h,2*(n+1)) or spacing.shape!=(h,)
            or jac.shape!=(2*n*h+2*h+2*n,h) or not all(np.all(np.isfinite(x)) for x in (states,jac,spacing))
            or not np.isfinite(angle_limit) or angle_limit<=0 or not np.isfinite(rail_limit) or rail_limit<=0):
        raise ValueError('finite aligned unbanded physical task rows and positive bounds required')
    phi=wrap_angle(np.cumsum(states[:,1:n+1],axis=1))
    angle_jac=jac[:n*h].reshape(h,n,h)*(.15*np.sqrt(n*h))
    cart_jac=jac[2*n*h:2*n*h+h]*(1.5*np.sqrt(h)/.1)
    ranked=[]
    for proposal in proposals:
        indices=proposal['indices'];delta=spacing[indices]*proposal['offsets_ulps']
        predicted_phi=phi+np.sum(angle_jac[:,:,indices]*delta[None,None,:],axis=2)
        predicted_cart=states[:,0]+cart_jac[:,indices]@delta
        av=np.maximum(np.abs(predicted_phi)-angle_limit,0)/angle_limit
        cv=np.maximum(np.abs(predicted_cart)-rail_limit,0)/rail_limit
        violation=float(np.sum(av*av)+np.sum(cv*cv))
        row=dict(proposal,predicted_bound_violation_squared_sum=violation,
            predicted_maximum_angle=float(np.max(np.abs(predicted_phi))),predicted_maximum_cart=float(np.max(np.abs(predicted_cart))))
        ranked.append(row)
    ranked.sort(key=lambda p:(p['predicted_bound_violation_squared_sum'],p['predicted_total_cost'],p['indices'],p['offsets_ulps']))
    return ranked


def balanced_action_triples(center,jacobian,residual,reference,*,amplitudes=(1,2,4,8,16),
                            max_offset=4096,action_regularization=.01,minimum_column_response=1e-12,
                            max_support_span=12,relative_rank_tolerance=1e-12):
    """Three-input integer proposals from two leading scaled task responses.

    A cross product gives a real null direction on each three-column support.
    Scale its smallest nonzero component to each amplitude; bounded floor/ceil
    rounding supplies delivered-F32 candidates. This is a restricted proposal
    family, not an exact integer nullspace or a native feasibility certificate.
    """
    center=np.asarray(center,float);jac=np.asarray(jacobian,float)
    residual=np.asarray(residual,float);reference=np.asarray(reference,float)
    spacing,lower,upper=affine_action_lattice(center,max_offset)
    if (reference.shape!=center.shape or residual.ndim!=1 or not len(residual)
            or jac.shape!=(len(residual),len(center))
            or not all(np.all(np.isfinite(x)) for x in (jac,residual,reference))
            or not len(amplitudes) or any(not isinstance(v,(int,np.integer)) or not 1<=v<=max_offset for v in amplitudes)
            or not np.isfinite(action_regularization) or action_regularization<0
            or not np.isfinite(minimum_column_response) or minimum_column_response<0
            or not isinstance(max_support_span,(int,np.integer)) or max_support_span<2
            or not np.isfinite(relative_rank_tolerance) or not 0<relative_rank_tolerance<1):
        raise ValueError('finite aligned task inputs and bounded triple settings required')
    scaled=jac*spacing[None,:];_,singular,right=np.linalg.svd(scaled,full_matrices=False)
    active=np.flatnonzero(np.linalg.norm(scaled,axis=0)>minimum_column_response)
    model=dict(spacing=spacing.tolist(),lower_offsets=lower.tolist(),upper_offsets=upper.tolist(),
        active_action_columns=active.tolist(),scaled_singular_values=singular.tolist(),max_support_span=int(max_support_span),
        relative_rank_tolerance=relative_rank_tolerance,minimum_column_response=minimum_column_response,
        scope='Binary64 two leading scaled task singular responses propose bounded integer triples on restricted temporal supports. Rounding/model errors remain;native physics must decide acceptance.')
    if len(singular)<2 or singular[0]==0 or singular[1]<=singular[0]*relative_rank_tolerance:
        model.update(proposal_count=0,status='fewer_than_two_resolved_model_responses');return [],model
    rows=right[:2].copy()
    for row in rows:row/=np.max(np.abs(row))
    offsets=set();tested_supports=0
    for indices in combinations(active,3):
        if indices[-1]-indices[0]>max_support_span:continue
        tested_supports+=1;columns=rows[:,indices]
        vector=np.cross(columns[0],columns[1]);smallest=float(np.min(np.abs(vector)))
        if smallest==0 or not np.all(np.isfinite(vector)):continue
        direction=vector/smallest
        for amplitude in amplitudes:
            target=direction*amplitude
            if np.max(np.abs(target))>max_offset+1:continue
            choices=[sorted({int(np.floor(v)),int(np.ceil(v))}) for v in target]
            for integer in product(*choices):
                for sign in (-1,1):
                    values=tuple(sign*v for v in integer)
                    if all(v!=0 and lower[i]<=v<=upper[i] for i,v in zip(indices,values)):
                        offsets.add((*map(int,indices),*values))
    difference=center-reference;regularizer=action_regularization**2
    baseline_action_cost=regularizer*float(difference@difference);proposals=[]
    coefficients=singular[:2,None]*right[:2]
    for values in sorted(offsets):
        indices=list(values[:3]);integer=np.asarray(values[3:]);delta=spacing[indices]*integer
        predicted=residual+scaled[:,indices]@integer
        cost=float(predicted@predicted+baseline_action_cost+regularizer*(2*difference[indices]@delta+delta@delta))
        if np.isfinite(cost):proposals.append(dict(indices=indices,offsets_ulps=integer.tolist(),
            predicted_total_cost=cost,leading_mode_changes=(coefficients[:,indices]@integer).tolist()))
    proposals.sort(key=lambda p:(p['predicted_total_cost'],p['indices'],p['offsets_ulps']))
    model.update(proposal_count=len(proposals),tested_supports=tested_supports,
        leading_scaled_coefficients=coefficients.tolist(),status='bounded_triples_generated')
    return proposals,model


def balanced_action_quadruples(center,jacobian,residual,reference,*,amplitudes=(1,2,4,8,16),
                              max_offset=4096,action_regularization=.01,minimum_column_response=1e-12,
                              max_support_span=12,relative_rank_tolerance=1e-12):
    """Four-input grid proposals approximately cancel three resolved responses.

    Signed 3x3 minors give a real null direction for each four-column support.
    Rounding does not preserve an exact nullspace; native physics must validate.
    """
    center=np.asarray(center,float);jac=np.asarray(jacobian,float)
    residual=np.asarray(residual,float);reference=np.asarray(reference,float)
    spacing,lower,upper=affine_action_lattice(center,max_offset)
    if (reference.shape!=center.shape or residual.ndim!=1 or not len(residual)
            or jac.shape!=(len(residual),len(center))
            or not all(np.all(np.isfinite(x)) for x in (jac,residual,reference))
            or not len(amplitudes) or any(not isinstance(v,(int,np.integer)) or not 1<=v<=max_offset for v in amplitudes)
            or not np.isfinite(action_regularization) or action_regularization<0
            or not np.isfinite(minimum_column_response) or minimum_column_response<0
            or not isinstance(max_support_span,(int,np.integer)) or max_support_span<3
            or not np.isfinite(relative_rank_tolerance) or not 0<relative_rank_tolerance<1):
        raise ValueError('finite aligned task inputs and bounded quadruple settings required')
    scaled=jac*spacing[None,:];_,singular,right=np.linalg.svd(scaled,full_matrices=False)
    active=np.flatnonzero(np.linalg.norm(scaled,axis=0)>minimum_column_response)
    model=dict(spacing=spacing.tolist(),lower_offsets=lower.tolist(),upper_offsets=upper.tolist(),
        active_action_columns=active.tolist(),scaled_singular_values=singular.tolist(),
        max_support_span=int(max_support_span),relative_rank_tolerance=relative_rank_tolerance,
        minimum_column_response=minimum_column_response,
        scope='Three leading scaled task singular responses propose rounded integer quadruples on restricted temporal supports; no native feasibility or exact integer-nullspace claim.')
    if len(singular)<3 or singular[0]==0 or singular[2]<=singular[0]*relative_rank_tolerance:
        model.update(proposal_count=0,status='fewer_than_three_resolved_model_responses');return [],model
    rows=right[:3].copy()
    for row in rows:row/=np.max(np.abs(row))
    offsets=set();tested_supports=0
    for indices in combinations(active,4):
        if indices[-1]-indices[0]>max_support_span:continue
        tested_supports+=1;columns=rows[:,indices]
        vector=np.asarray([(-1.)**j*np.linalg.det(np.delete(columns,j,axis=1)) for j in range(4)])
        smallest=float(np.min(np.abs(vector)))
        if smallest==0 or not np.all(np.isfinite(vector)):continue
        direction=vector/smallest
        for amplitude in amplitudes:
            target=direction*amplitude
            if np.max(np.abs(target))>max_offset+1:continue
            choices=[sorted({int(np.floor(v)),int(np.ceil(v))}) for v in target]
            for integer in product(*choices):
                for sign in (-1,1):
                    values=tuple(sign*v for v in integer)
                    if all(v!=0 and lower[i]<=v<=upper[i] for i,v in zip(indices,values)):
                        offsets.add((*map(int,indices),*values))
    difference=center-reference;regularizer=action_regularization**2
    baseline_action_cost=regularizer*float(difference@difference);proposals=[]
    coefficients=singular[:3,None]*right[:3]
    for values in sorted(offsets):
        indices=list(values[:4]);integer=np.asarray(values[4:]);delta=spacing[indices]*integer
        predicted=residual+scaled[:,indices]@integer
        cost=float(predicted@predicted+baseline_action_cost+regularizer*(2*difference[indices]@delta+delta@delta))
        if np.isfinite(cost):proposals.append(dict(indices=indices,offsets_ulps=integer.tolist(),
            predicted_total_cost=cost,leading_mode_changes=(coefficients[:,indices]@integer).tolist()))
    proposals.sort(key=lambda p:(p['predicted_total_cost'],p['indices'],p['offsets_ulps']))
    model.update(proposal_count=len(proposals),tested_supports=tested_supports,
        leading_scaled_coefficients=coefficients.tolist(),status='bounded_quadruples_generated')
    return proposals,model
