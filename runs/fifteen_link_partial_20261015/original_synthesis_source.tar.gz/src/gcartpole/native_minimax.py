"""Scalar bounded affine minimax proposal; native replay supplies validity."""
import numpy as np

def bounded_affine_minimax(minus,plus):
    """Minimize max(abs(z(u))) for affine z matching z(-1)/z(+1).

    Enumerate envelope intersections and endpoints. This is a proposal for the
    real nonlinear plant, not a bound on its response or a viability certificate.
    """
    minus,plus=np.asarray(minus,float),np.asarray(plus,float)
    if (minus.ndim!=1 or not len(minus) or plus.shape!=minus.shape
            or not np.all(np.isfinite(minus)) or not np.all(np.isfinite(plus))):
        raise ValueError('Aligned nonempty finite feature vectors required')
    intercept=(minus+plus)/2;slope=(plus-minus)/2
    intercept=np.r_[intercept,-intercept];slope=np.r_[slope,-slope]
    i,j=np.triu_indices(len(intercept),1);denom=slope[i]-slope[j]
    with np.errstate(over='ignore',divide='ignore',invalid='ignore'):
        crossing=(intercept[j]-intercept[i])/denom
    keep=(denom!=0)&np.isfinite(crossing)&(crossing>=-1)&(crossing<=1)
    candidates=np.unique(np.r_[-1.,0.,1.,crossing[keep]])
    values=np.max(intercept[:,None]+slope[:,None]*candidates[None,:],axis=0)
    best=min(range(len(candidates)),key=lambda k:(values[k],abs(candidates[k]),candidates[k]))
    return float(candidates[best])
