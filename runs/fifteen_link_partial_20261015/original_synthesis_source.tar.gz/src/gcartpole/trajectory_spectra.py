"""Descriptive spectra of uniformly sampled actual trajectory signals.

These utilities do not infer resonance, causality, or modal energy during a
nonlinear swing. Frequencies are in Hz, not the growth rates of upright poles.
"""
from __future__ import annotations

import numpy as np
from scipy import signal


def welch_summary(samples, sample_rate, *, window_seconds=2.0):
    x = np.asarray(samples, dtype=np.float64)
    if x.ndim != 1 or not np.all(np.isfinite(x)) or len(x) < 4:
        raise ValueError("need at least four finite, uniformly sampled values")
    if sample_rate <= 0 or window_seconds <= 0:
        raise ValueError("rate and window duration must be positive")
    size = min(len(x), max(4, int(round(sample_rate * window_seconds))))
    overlap = size // 2
    frequencies, psd = signal.welch(x, fs=sample_rate, window="hann", nperseg=size,
                                  noverlap=overlap, nfft=size, detrend="constant",
                                  scaling="density")
    spacing = sample_rate / size
    total = float(np.sum(psd) * spacing)
    positive = psd[1:]
    dominant = int(np.argmax(positive)) + 1 if total > 0 else None
    normalized = positive / np.sum(positive) if np.sum(positive) > 0 else positive
    entropy = float(-np.sum(normalized[normalized > 0] * np.log(normalized[normalized > 0])))
    if len(positive) > 1:
        entropy /= np.log(len(positive))
    segments = 1 + (len(x) - size) // (size - overlap)
    covered = size + (segments-1)*(size-overlap)
    return dict(frequencies_hz=frequencies, psd=psd, segment_samples=size,
                segments=segments, covered_samples=covered, unused_tail_samples=len(x)-covered,
                bin_spacing_hz=spacing, nyquist_hz=sample_rate / 2,
                mean_square_psd=total, peak_frequency_hz=None if dominant is None else float(frequencies[dominant]),
                peak_bin_fraction=None if total == 0 else float(psd[dominant] * spacing / total),
                normalized_positive_frequency_entropy=entropy,
                sample_rms=float(np.sqrt(np.mean(x*x))))


def force_motion_coherence(force, motion, sample_rate, *, window_seconds=2.0):
    """Reject the misleading identically-one single-periodogram coherence."""
    x, y = np.asarray(force), np.asarray(motion)
    if x.shape != y.shape or x.ndim != 1:
        raise ValueError("paired signals must have the same one-dimensional shape")
    summary = welch_summary(x, sample_rate, window_seconds=window_seconds)
    if summary['segments'] < 3 or np.std(x) == 0 or np.std(y) == 0:
        return dict(estimated=False, segments=summary['segments'],
                    reason="fewer than three segments or a constant signal")
    size = summary['segment_samples']
    f, coherence = signal.coherence(x, y, fs=sample_rate, window='hann', nperseg=size,
                                   noverlap=size//2, nfft=size, detrend='constant')
    _, cross = signal.csd(x, y, fs=sample_rate, window='hann', nperseg=size,
                         noverlap=size//2, nfft=size, detrend='constant')
    return dict(estimated=True, segments=summary['segments'], frequencies_hz=f,
                coherence=coherence, cross_phase_radians=np.angle(cross))


def projected_modal_rates(states, n_links, projector):
    """Use stored rates so angle wrap/unwrap branch choices cannot create peaks."""
    states = np.asarray(states)
    if states.ndim != 2 or states.shape[1] != 2*(n_links+1):
        raise ValueError("state layout must be qpos followed by qvel")
    return states[:, n_links+2:] @ np.asarray(projector).T


def first_sustained_upright_tick(states, n_links, sample_rate, *, threshold=.15, seconds=5.):
    absolute = np.cumsum(np.asarray(states)[1:, 1:n_links+1], axis=1)
    angles = (absolute+np.pi) % (2*np.pi) - np.pi
    good = np.max(np.abs(angles), axis=1) < threshold
    required = int(np.ceil(seconds*sample_rate))
    streak = 0
    for tick, value in enumerate(good):
        streak = streak+1 if value else 0
        if streak >= required:
            return tick-required+1
    return None
