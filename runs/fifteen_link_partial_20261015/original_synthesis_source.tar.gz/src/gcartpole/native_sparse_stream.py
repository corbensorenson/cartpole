"""Bounded-memory proposals for coordinated delivered-F32 input changes.

Model predictions select a finite batch; only native rollouts prove feasibility.
Supports are visited by increasing temporal span, across all time positions.
"""
import heapq
import time
from collections import deque
from itertools import combinations,product
import numpy as np
from .angles import wrap_angle
from .native_action_lattice import affine_action_lattice
from .native_bound_objective import bound_task_gradient,proposal_bound_key
from .native_null_minimax import coupled_null_minimax,rounded_nonzero_offsets


class _WorstFirst:
    def __init__(self,key,row):self.key=key;self.row=row
    def __lt__(self,other):return self.key>other.key


def temporal_supports(active,arity,max_span):
    active=tuple(map(int,active))
    for span in range(arity-1,max_span+1):
        available=set(active)
        for first in active:
            last=first+span
            if last not in available:continue
            middle=[i for i in active if first<i<last]
            for inner in combinations(middle,arity-2):yield (first,*inner,last)


def fixed_span_supports(active,arity,span):
    """Visit each starting time before advancing its inner combinations."""
    active=tuple(map(int,active));available=set(active);pending=deque()
    for first in active:
        last=first+span
        if last not in available:continue
        middle=[i for i in active if first<i<last]
        if len(middle)>=arity-2:
            pending.append((first,last,combinations(middle,arity-2)))
    while pending:
        first,last,inner=pending.popleft()
        try:selection=next(inner)
        except StopIteration:continue
        yield (first,*selection,last)
        pending.append((first,last,inner))


def _free_null_directions(columns,bound_gradient,task_gradient,relative_rank_tolerance):
    """A finite family in a full-row-rank support's larger real null space."""
    _,singular,right=np.linalg.svd(columns,full_matrices=True)
    modes=columns.shape[0]
    if len(singular)<modes or singular[0]==0 or singular[-1]<=singular[0]*relative_rank_tolerance:
        return []
    basis=right[modes:].T
    directions=[(f'null_basis_{i}',basis[:,i]) for i in range(basis.shape[1])]
    for name,gradient in [('bound_gradient',bound_gradient),('task_gradient',task_gradient)]:
        vector=-basis@(basis.T@gradient)
        if np.linalg.norm(vector)>relative_rank_tolerance*np.linalg.norm(gradient):
            directions.append((name,vector/np.linalg.norm(vector)))
    return directions


def stream_balanced_actions(center,jacobian,residual,reference,*,arity,
        states,n_links,angle_limit,rail_limit,amplitudes=(1,2,4,8,16),
        max_offset=4096,max_support_span=12,max_supports=12000,
        max_model_proposals=500000,keep_proposals=5000,batch_size=128,
        action_regularization=.01,minimum_column_response=1e-12,relative_rank_tolerance=1e-12,
        exact_support_span=None,cancelled_rank=None,bound_objective='sum',
        coupled_null_supports=0,coupled_null_solver_seconds=.2):
    center=np.asarray(center,float);jac=np.asarray(jacobian,float)
    residual=np.asarray(residual,float);reference=np.asarray(reference,float)
    states=np.asarray(states,float);h=len(center);n=n_links
    spacing,lower,upper=affine_action_lattice(center,max_offset)
    integers=(arity,max_support_span,max_supports,max_model_proposals,keep_proposals,batch_size)
    if (any(not isinstance(v,(int,np.integer)) for v in integers) or not 3<=arity<=8
            or max_support_span<arity-1 or min(max_supports,max_model_proposals,keep_proposals,batch_size)<1
            or not isinstance(n,(int,np.integer)) or n<1
            or states.shape!=(h,2*(n+1)) or reference.shape!=center.shape
            or residual.shape!=(2*n*h+2*h+2*n,) or jac.shape!=(len(residual),h)
            or not all(np.all(np.isfinite(x)) for x in (jac,residual,reference,states))
            or not len(amplitudes) or any(not isinstance(v,(int,np.integer)) or not 1<=v<=max_offset for v in amplitudes)
            or not np.isfinite(angle_limit) or not 0<angle_limit<.15
            or not np.isfinite(rail_limit) or rail_limit<=0
            or not np.isfinite(action_regularization) or action_regularization<0
            or not np.isfinite(minimum_column_response) or minimum_column_response<0
            or not np.isfinite(relative_rank_tolerance) or not 0<relative_rank_tolerance<1):
        raise ValueError('aligned unbanded physical task and bounded streaming settings required')
    if exact_support_span is not None and (not isinstance(exact_support_span,(int,np.integer))
            or not arity-1<=exact_support_span<=max_support_span):
        raise ValueError('exact support span must lie within the declared support range')
    modes=arity-1 if cancelled_rank is None else cancelled_rank
    if not isinstance(modes,(int,np.integer)) or not 1<=modes<arity:
        raise ValueError('cancelled response rank must be a positive integer below arity')
    if bound_objective not in ('sum','maximum'):raise ValueError('declared bound objective required')
    if (not isinstance(coupled_null_supports,(int,np.integer)) or coupled_null_supports<0
            or not np.isfinite(coupled_null_solver_seconds) or coupled_null_solver_seconds<=0
            or coupled_null_supports and (bound_objective!='maximum' or modes>=arity-1)):
        raise ValueError('coupled proposals require a positive bounded LP budget,maximum objective and extra null freedom')
    scaled=jac*spacing[None,:];_,singular,right=np.linalg.svd(scaled,full_matrices=False)
    active=np.flatnonzero(np.linalg.norm(scaled,axis=0)>minimum_column_response)
    model=dict(spacing=spacing.tolist(),lower_offsets=lower.tolist(),upper_offsets=upper.tolist(),
        active_action_columns=active.tolist(),scaled_singular_values=singular.tolist(),arity=int(arity),
        max_support_span=int(max_support_span),max_supports=int(max_supports),
        max_model_proposals=int(max_model_proposals),keep_proposals=int(keep_proposals),batch_size=int(batch_size),
        tested_supports=0,scored_model_proposals=0,peak_pending_proposals=0,peak_retained_proposals=0,
        proposal_count=0,relative_rank_tolerance=relative_rank_tolerance,
        bound_objective=bound_objective,
        cancelled_response_rank=int(modes),real_null_dimension=int(arity-modes),
        maximum_directions_per_support=(1 if modes==arity-1 else int(arity-modes+2))+int(coupled_null_supports>0),
        local_rank_rejected_supports=0,directions_considered=0,direction_families_generated={},
        direction_offset_ratio_rejections=0,zero_component_directions=0,
        coupled_null_support_budget=int(coupled_null_supports),coupled_null_attempted_supports=0,
        coupled_null_solver_seconds=float(coupled_null_solver_seconds),coupled_null_status_counts={},
        coupled_null_solver_status_counts={},coupled_null_solver_wall_seconds=0.,
        coupled_null_model_proposals=0,coupled_null_maximum_lp_inequality_error=0.,
        coupled_null_maximum_leading_response_residual=0.,
        exact_support_span=None if exact_support_span is None else int(exact_support_span),
        support_visit_order='short_span_first' if exact_support_span is None else 'fixed_span_round_robin',
        visited_support_span_histogram={},support_anchor_visits={},
        scope='Bounded rounded real null-direction proposals for a declared cancelled response rank. One-dimensional supports retain signed-minor proposals;larger null spaces use basis/projected descent and optionally bounded coupled worst-constraint LP proposals. Declared traversal visits short spans first or cycles starting times at one exact span. Real LP status,model rank,rounding and finite budgets do not certify native feasibility,global infeasibility or arbitrary-arity scalability.')
    if len(singular)<modes or singular[0]==0 or singular[modes-1]<=singular[0]*relative_rank_tolerance:
        model['status']='insufficient_resolved_model_responses';return [],model
    rows=right[:modes].copy()
    for row in rows:row/=np.max(np.abs(row))
    coefficients=singular[:modes,None]*right[:modes]
    phi=wrap_angle(np.cumsum(states[:,1:n+1],axis=1))
    difference=center-reference;regularizer=action_regularization**2
    baseline=regularizer*float(difference@difference);heap=[];pending=[]
    task_gradient=scaled.T@residual+regularizer*difference*spacing
    bound_residual_gradient=bound_task_gradient(states,n,angle_limit,rail_limit,bound_objective)
    bound_gradient=scaled.T@bound_residual_gradient
    if coupled_null_supports:
        normalized_values=np.r_[phi.ravel()/angle_limit,states[:,0]/rail_limit]
        normalized_response=np.vstack([scaled[:n*h]*(.15*np.sqrt(n*h)/angle_limit),
            scaled[2*n*h:2*n*h+h]*(1.5*np.sqrt(h)/.1/rail_limit)])
        model['coupled_null_backtracking_fractions']=[1.,.5,.25,.125,.0625]
    def flush():
        if not pending:return
        index=np.asarray([p[0] for p in pending],int)
        offsets=np.asarray([p[1] for p in pending],float)
        change=np.zeros((len(pending),len(residual)))
        for col in range(arity):change+=scaled[:,index[:,col]].T*offsets[:,col,None]
        prediction=change+residual[None,:]
        delta=spacing[index]*offsets
        cost=np.sum(prediction*prediction,axis=1)+baseline+regularizer*(2*np.sum(difference[index]*delta,axis=1)+np.sum(delta*delta,axis=1))
        predicted_phi=phi[None,:,:]+change[:,:n*h].reshape(-1,h,n)*(.15*np.sqrt(n*h))
        predicted_cart=states[None,:,0]+change[:,2*n*h:2*n*h+h]*(1.5*np.sqrt(h)/.1)
        violation=np.sum((np.maximum(np.abs(predicted_phi)-angle_limit,0)/angle_limit)**2,axis=(1,2))
        violation+=np.sum((np.maximum(np.abs(predicted_cart)-rail_limit,0)/rail_limit)**2,axis=1)
        maximum=np.maximum(np.max((np.maximum(np.abs(predicted_phi)-angle_limit,0)/angle_limit)**2,axis=(1,2)),
            np.max((np.maximum(np.abs(predicted_cart)-rail_limit,0)/rail_limit)**2,axis=1))
        for k,(indices,integer,family) in enumerate(pending):
            if not np.isfinite(cost[k]) or not np.isfinite(violation[k]):continue
            # Use tuples internally to preserve deterministic legacy tie order.
            key=(float(violation[k]),float(cost[k]),indices,integer) if bound_objective=='sum' else (
                float(maximum[k]),float(violation[k]),float(cost[k]),indices,integer)
            if len(heap)>=keep_proposals and key>=heap[0].key:continue
            row=dict(indices=list(indices),offsets_ulps=list(integer),predicted_total_cost=float(cost[k]),
                predicted_bound_violation_squared_sum=float(violation[k]),
                predicted_bound_violation_squared_maximum=float(maximum[k]),
                predicted_maximum_angle=float(np.max(np.abs(predicted_phi[k]))),
                predicted_maximum_cart=float(np.max(np.abs(predicted_cart[k]))),
                null_direction_family=family,
                leading_mode_changes=(coefficients[:,indices]@np.asarray(integer)).tolist())
            entry=_WorstFirst(key,row)
            if len(heap)<keep_proposals:heapq.heappush(heap,entry)
            else:heapq.heapreplace(heap,entry)
        model['peak_retained_proposals']=max(model['peak_retained_proposals'],len(heap));pending.clear()
    status='all_bounded_supports_visited';stop=False
    supports=(temporal_supports(active,arity,max_support_span) if exact_support_span is None
              else fixed_span_supports(active,arity,exact_support_span))
    for indices in supports:
        if model['tested_supports']>=max_supports:status='support_budget';break
        model['tested_supports']+=1;columns=rows[:,indices]
        span=str(indices[-1]-indices[0]);anchor=str(indices[0])
        model['visited_support_span_histogram'][span]=model['visited_support_span_histogram'].get(span,0)+1
        model['support_anchor_visits'][anchor]=model['support_anchor_visits'].get(anchor,0)+1
        if modes==arity-1:
            directions=[('signed_minors',np.asarray([(-1.)**j*np.linalg.det(np.delete(columns,j,axis=1)) for j in range(arity)]))]
        else:
            directions=_free_null_directions(columns,bound_gradient[list(indices)],task_gradient[list(indices)],relative_rank_tolerance)
            if not directions:model['local_rank_rejected_supports']+=1
        seen=set()
        if model['coupled_null_attempted_supports']<coupled_null_supports:
            model['coupled_null_attempted_supports']+=1
            solver_started=time.monotonic()
            offsets,diagnostic=coupled_null_minimax(columns,normalized_response[:,indices],normalized_values,
                lower[list(indices)],upper[list(indices)],relative_rank_tolerance=relative_rank_tolerance,
                solver_seconds=coupled_null_solver_seconds)
            model['coupled_null_solver_wall_seconds']+=time.monotonic()-solver_started
            label=diagnostic['status'];counts=model['coupled_null_status_counts'];counts[label]=counts.get(label,0)+1
            label=str(diagnostic['solver_status']);counts=model['coupled_null_solver_status_counts'];counts[label]=counts.get(label,0)+1
            for name in ('maximum_lp_inequality_error','maximum_leading_response_residual'):
                key='coupled_null_'+name
                model[key]=max(model[key],diagnostic.get(name,0.))
            if offsets is not None and np.max(np.abs(offsets))>1e-6:
                family='coupled_minimax'
                model['directions_considered']+=1
                model['direction_families_generated'][family]=model['direction_families_generated'].get(family,0)+1
                for fraction in model['coupled_null_backtracking_fractions']:
                    for values in rounded_nonzero_offsets(offsets*fraction,lower[list(indices)],upper[list(indices)]):
                        if values in seen:continue
                        seen.add(values)
                        if model['scored_model_proposals']>=max_model_proposals:status='model_proposal_budget';stop=True;break
                        pending.append((indices,values,family));model['scored_model_proposals']+=1
                        model['coupled_null_model_proposals']+=1
                        model['peak_pending_proposals']=max(model['peak_pending_proposals'],len(pending))
                        if len(pending)>=batch_size:flush()
                    if stop:break
        if stop:break
        for family,vector in directions:
            model['directions_considered']+=1
            model['direction_families_generated'][family]=model['direction_families_generated'].get(family,0)+1
            smallest=float(np.min(np.abs(vector)))
            if smallest==0 or not np.all(np.isfinite(vector)):
                model['zero_component_directions']+=1;continue
            direction=vector/smallest
            for amplitude in amplitudes:
                target=direction*amplitude
                if np.max(np.abs(target))>max_offset+1:
                    model['direction_offset_ratio_rejections']+=1;continue
                choices=[sorted({int(np.floor(v)),int(np.ceil(v))}) for v in target]
                for integer in product(*choices):
                    for sign in (-1,1):
                        values=tuple(sign*v for v in integer)
                        if values in seen or not all(v!=0 and lower[i]<=v<=upper[i] for i,v in zip(indices,values)):continue
                        seen.add(values)
                        if model['scored_model_proposals']>=max_model_proposals:status='model_proposal_budget';stop=True;break
                        pending.append((indices,values,family));model['scored_model_proposals']+=1
                        model['peak_pending_proposals']=max(model['peak_pending_proposals'],len(pending))
                        if len(pending)>=batch_size:flush()
                    if stop:break
                if stop:break
            if stop:break
        if stop:break
    flush();ordered=sorted(heap,key=lambda p:p.key)
    model.update(status=status,proposal_count=len(ordered),leading_scaled_coefficients=coefficients.tolist())
    return [p.row for p in ordered],model


def stratified_balanced_actions(center,jacobian,residual,reference,*,arity,support_spans,
        max_supports=12000,max_model_proposals=500000,keep_proposals=5000,batch_size=128,
        coupled_null_supports=0,**settings):
    """Reserve separate model, support and retention quotas for each span.

    Unused quotas are reported rather than transferred. Each fixed-span stream
    cycles starting times. Native testing remains the caller's responsibility.
    """
    spans=tuple(support_spans);groups=len(spans)
    if (not groups or any(not isinstance(s,(int,np.integer)) or s<arity-1 for s in spans)
            or tuple(sorted(set(spans)))!=spans
            or any(not isinstance(v,(int,np.integer)) or v<groups
                   for v in (max_supports,max_model_proposals,keep_proposals))
            or not isinstance(coupled_null_supports,(int,np.integer)) or not 0<=coupled_null_supports<=max_supports
            or 'exact_support_span' in settings or 'max_support_span' in settings):
        raise ValueError('ordered unique spans and positive per-span quotas required')
    def quota(total,index):return total//groups+int(index<total%groups)
    proposals=[];strata=[]
    for index,span in enumerate(spans):
        rows,model=stream_balanced_actions(center,jacobian,residual,reference,arity=arity,
            max_support_span=max(spans),exact_support_span=span,
            max_supports=quota(max_supports,index),max_model_proposals=quota(max_model_proposals,index),
            keep_proposals=quota(keep_proposals,index),batch_size=batch_size,
            coupled_null_supports=quota(coupled_null_supports,index),**settings)
        for row in rows:row['support_span_ticks']=int(span)
        proposals.extend(rows);strata.append(dict(span_ticks=int(span),model=model))
    proposals.sort(key=lambda p:proposal_bound_key(p,settings.get('bound_objective','sum')))
    model=dict(strata[0]['model'])
    model.update(support_spans=list(map(int,spans)),strata=strata,
        exact_support_span=None,support_visit_order='reserved_fixed_span_round_robin',
        max_supports=max_supports,max_model_proposals=max_model_proposals,keep_proposals=keep_proposals,
        coupled_null_support_budget=int(coupled_null_supports),
        coupled_null_attempted_supports=sum(s['model']['coupled_null_attempted_supports'] for s in strata),
        coupled_null_model_proposals=sum(s['model']['coupled_null_model_proposals'] for s in strata),
        tested_supports=sum(s['model']['tested_supports'] for s in strata),
        scored_model_proposals=sum(s['model']['scored_model_proposals'] for s in strata),
        peak_pending_proposals=max(s['model']['peak_pending_proposals'] for s in strata),
        peak_retained_proposals=len(proposals),proposal_count=len(proposals),status='stratified_stream_finished',
        scope='Independent finite model/support/retention quotas per exact temporal span,with round-robin starting times. Unused quotas are not borrowed. Different arities still sample different supports;model predictions and finite coverage do not certify native feasibility,causal arity ordering or global infeasibility.')
    for key in ('visited_support_span_histogram','support_anchor_visits'):
        total={}
        for s in strata:
            for label,count in s['model'][key].items():total[label]=total.get(label,0)+count
        model[key]=total
    for key in ('local_rank_rejected_supports','directions_considered',
                'direction_offset_ratio_rejections','zero_component_directions'):
        model[key]=sum(s['model'][key] for s in strata)
    families={}
    for s in strata:
        for name,count in s['model']['direction_families_generated'].items():families[name]=families.get(name,0)+count
    model['direction_families_generated']=families
    for key in ('coupled_null_status_counts','coupled_null_solver_status_counts'):
        statuses={}
        for s in strata:
            for name,count in s['model'][key].items():statuses[name]=statuses.get(name,0)+count
        model[key]=statuses
    model['coupled_null_solver_wall_seconds']=sum(s['model']['coupled_null_solver_wall_seconds'] for s in strata)
    for key in ('coupled_null_maximum_lp_inequality_error','coupled_null_maximum_leading_response_residual'):
        model[key]=max(s['model'][key] for s in strata)
    return proposals,model
