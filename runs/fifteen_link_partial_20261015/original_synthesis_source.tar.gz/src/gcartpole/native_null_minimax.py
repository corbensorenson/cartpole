"""Bounded real-null-plane minimax proposals; native replay remains decisive."""
import numpy as np
from scipy.optimize import linprog


def coupled_null_minimax(columns, response, values, lower, upper, *,
        relative_rank_tolerance=1e-12, solver_seconds=.2):
    """Minimize all predicted normalized absolute bounds in a support null space.

    Response maps integer action offsets to angle/limit and cart/rail rows.
    A real LP solution is only a proposal; rounding breaks exact cancellation.
    """
    columns=np.asarray(columns,float);response=np.asarray(response,float)
    values=np.asarray(values,float);lower=np.asarray(lower,float);upper=np.asarray(upper,float)
    if (columns.ndim!=2 or not 1<=columns.shape[0]<columns.shape[1]
            or response.shape!=(len(values),columns.shape[1]) or values.ndim!=1 or not len(values)
            or lower.shape!=(columns.shape[1],) or upper.shape!=lower.shape
            or not all(np.all(np.isfinite(v)) for v in (columns,response,values,lower,upper))
            or np.any(lower>0) or np.any(upper<0) or np.any(lower>=upper)
            or not np.isfinite(relative_rank_tolerance) or not 0<relative_rank_tolerance<1
            or not np.isfinite(solver_seconds) or solver_seconds<=0):
        raise ValueError('finite aligned null-plane model and center-containing bounds required')
    _,singular,right=np.linalg.svd(columns,full_matrices=True);rank=columns.shape[0]
    diagnostic=dict(status='rank_rejected',solver_status=None,
        baseline_maximum_normalized_bound=float(np.max(np.abs(values))))
    if singular[0]==0 or singular[-1]<=singular[0]*relative_rank_tolerance:return None,diagnostic
    basis=right[rank:].T;radius=float(max(np.max(-lower),np.max(upper)))
    mapped=response@basis*radius;dimension=basis.shape[1]
    matrix=np.vstack([np.column_stack([mapped,-np.ones(len(values))]),
        np.column_stack([-mapped,-np.ones(len(values))]),
        np.column_stack([basis,np.zeros(len(lower))]),
        np.column_stack([-basis,np.zeros(len(lower))])])
    rhs=np.r_[-values,values,upper/radius,-lower/radius]
    result=linprog(np.r_[np.zeros(dimension),1.],A_ub=matrix,b_ub=rhs,
        bounds=[(None,None)]*dimension+[(0,None)],method='highs-ds',
        options=dict(time_limit=solver_seconds,maxiter=2000,
            primal_feasibility_tolerance=1e-9,dual_feasibility_tolerance=1e-9))
    diagnostic.update(status='solver_rejected',solver_status=int(result.status),
        solver_iterations=int(result.nit or 0),real_null_dimension=dimension)
    if not result.success or result.x is None or not np.all(np.isfinite(result.x)):return None,diagnostic
    offsets=radius*(basis@result.x[:-1]);peak=float(np.max(np.abs(values+response@offsets)))
    error=float(np.max(np.maximum(matrix@result.x-rhs,0)))
    cancellation=float(np.max(np.abs(columns@offsets)))
    diagnostic.update(predicted_maximum_normalized_bound=peak,
        maximum_lp_inequality_error=error,maximum_leading_response_residual=cancellation)
    if (error>1e-7 or np.any(offsets<lower-1e-5) or np.any(offsets>upper+1e-5)
            or cancellation>1e-8*max(1.,np.linalg.norm(columns)*np.linalg.norm(offsets))
            or peak>diagnostic['baseline_maximum_normalized_bound']+1e-7):return None,diagnostic
    diagnostic['status']='optimal_real_model_proposal'
    return np.clip(offsets,lower,upper),diagnostic


def rounded_nonzero_offsets(target,lower,upper):
    """Nearest floor/ceil nonzero choices, including both neighbors of exact zero."""
    from itertools import product
    target=np.asarray(target,float);lower=np.asarray(lower);upper=np.asarray(upper)
    if target.ndim!=1 or lower.shape!=target.shape or upper.shape!=target.shape or not np.all(np.isfinite(target)):
        raise ValueError('finite aligned offset target required')
    choices=[]
    for value,lo,hi in zip(target,lower,upper):
        options={int(np.floor(value)),int(np.ceil(value))}-{0}
        if not options:options={-1,1}
        choices.append(sorted(v for v in options if lo<=v<=hi))
    return product(*choices)
