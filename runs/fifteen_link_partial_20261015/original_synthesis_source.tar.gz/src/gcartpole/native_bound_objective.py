"""Physical bound diagnostics and explicit native feasibility-search priorities."""
import numpy as np
from .angles import wrap_angle


def bound_diagnostics(states,n_links,angle_limit,rail_limit):
    states=np.asarray(states,float);n=n_links
    if (not isinstance(n,(int,np.integer)) or n<1
            or states.ndim!=2 or not len(states) or states.shape[1]!=2*(n+1)
            or not np.all(np.isfinite(states)) or not 0<angle_limit<.15
            or not np.isfinite(rail_limit) or rail_limit<=0):
        raise ValueError('finite aligned physical states and positive bounds required')
    phi=np.abs(wrap_angle(np.cumsum(states[:,1:n+1],axis=1)));cart=np.abs(states[:,0])
    angle=(np.maximum(phi-angle_limit,0)/angle_limit)**2
    rail=(np.maximum(cart-rail_limit,0)/rail_limit)**2
    return dict(feasible=bool(np.all(phi<angle_limit) and np.all(cart<=rail_limit)),
        squared_sum=float(np.sum(angle)+np.sum(rail)),
        squared_maximum=float(max(np.max(angle),np.max(rail))),
        maximum_angle=float(np.max(phi)),maximum_cart=float(np.max(cart)))


def native_bound_score(diagnostics,cost,objective='sum'):
    if objective not in ('sum','maximum') or not np.isfinite(cost):raise ValueError('finite cost and declared bound objective required')
    flag=0 if diagnostics['feasible'] else 1
    if objective=='sum':return (flag,diagnostics['squared_sum'],float(cost))
    return (flag,diagnostics['squared_maximum'],diagnostics['squared_sum'],float(cost))


def bound_task_gradient(states,n_links,angle_limit,rail_limit,objective='sum'):
    """Derivative in the unbanded physical-task row layout; average max ties."""
    diagnostics=bound_diagnostics(states,n_links,angle_limit,rail_limit)
    if objective not in ('sum','maximum'):raise ValueError('declared bound objective required')
    states=np.asarray(states,float);h=len(states);n=n_links
    phi=wrap_angle(np.cumsum(states[:,1:n+1],axis=1));cart=states[:,0]
    angular=2*np.sign(phi)*np.maximum(np.abs(phi)-angle_limit,0)/angle_limit**2*(.15*np.sqrt(n*h))
    rail=2*np.sign(cart)*np.maximum(np.abs(cart)-rail_limit,0)/rail_limit**2*(1.5*np.sqrt(h)/.1)
    if objective=='maximum':
        peak=diagnostics['squared_maximum']
        if peak==0:angular[:]=0;rail[:]=0
        else:
            a=((np.maximum(np.abs(phi)-angle_limit,0)/angle_limit)**2)==peak
            c=((np.maximum(np.abs(cart)-rail_limit,0)/rail_limit)**2)==peak
            count=int(np.sum(a)+np.sum(c));angular*=a/count;rail*=c/count
    gradient=np.zeros(2*n*h+2*h+2*n)
    gradient[:n*h]=angular.reshape(-1);gradient[2*n*h:2*n*h+h]=rail
    return gradient


def proposal_bound_key(proposal,objective='sum'):
    tail=(proposal['predicted_total_cost'],proposal['indices'],proposal['offsets_ulps'])
    total=proposal['predicted_bound_violation_squared_sum']
    if objective=='sum':return (total,*tail)
    if objective=='maximum':return (proposal['predicted_bound_violation_squared_maximum'],total,*tail)
    raise ValueError('declared bound objective required')
