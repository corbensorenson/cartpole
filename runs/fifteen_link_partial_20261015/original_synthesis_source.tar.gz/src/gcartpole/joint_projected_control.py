"""Joint native preview correction of several future feedback projections.

Finite action searches and stable mechanical references do not certify capture.
Every objective/derivative evaluation uses delivered float32 native controls.
"""
import mpmath
import numpy as np
from .angles import wrap_angle
from .native_real_minimax import bounded_real_minimax, quantized_box_trial


def checked_constraint_step(ctx, response, values, lower, upper):
    """Propose a boxed minimax step, then check the original MP derivative rows."""
    matrix = np.array(response.tolist(), dtype=float)
    baseline = np.array(list(values), dtype=float)
    delta, diag = bounded_real_minimax(matrix, baseline, lower, upper, solver_seconds=1.)
    if delta is None:
        return None, diag
    prediction = values + response*ctx.matrix(delta.tolist())
    peak = max(abs(v) for v in prediction)
    original_peak = max(abs(v) for v in values)
    error = max(ctx.mpf(0), peak-ctx.mpf(diag['solver_epigraph']))
    diag.update(original_mp_checked_peak=str(peak), original_mp_epigraph_error=str(error),
                original_mp_baseline_peak=str(original_peak))
    if error > ctx.mpf('1e-7') or peak > original_peak+ctx.mpf('1e-7'):
        diag['status'] = 'original_mp_model_rejected'
        return None, diag
    diag['status'] = 'original_mp_model_checked_proposal'
    return delta, diag


def native_agreement(ctx, values, response, delivered_delta, actual):
    """Compare the MP affine model of delivered controls with native rows."""
    predicted=values+response*ctx.matrix(delivered_delta.tolist())
    baseline=max(abs(v) for v in values); peak=max(abs(v) for v in predicted)
    measured=max(abs(v) for v in actual)
    error=max(abs(x-y) for x,y in zip(predicted,actual))
    reduction=baseline-peak
    ratio=(baseline-measured)/reduction if reduction>0 else None
    scale=max(ctx.mpf(1),peak)
    poor=(error>ctx.mpf('.25')*scale or (peak<=1 and measured>1)
          or (ratio is not None and ratio<ctx.mpf('.25')))
    good=(not poor and ratio is not None and ratio>ctx.mpf('.75')
          and error<=ctx.mpf('.1')*scale)
    return dict(predicted_peak=str(peak),native_peak=str(measured),maximum_row_error=str(error),
                reduction_ratio=None if ratio is None else str(ratio),poor=bool(poor),good=bool(good))


class JointProjectedController:
    def __init__(self, predictor, a, b, gain, *, n_links, horizon=2,
                 projection_delays=(0, 1), rounds=3, derivative_epsilon=1e-5,
                 trust_halfwidth=.01, decimal_digits=100,
                 reference_mode='linear', projection_scaling='response', future_force_limit=None,
                 correction_mode='projected',adaptive_trust=False,warm_start=False):
        self.ctx = mpmath.mp.clone(); self.ctx.dps = decimal_digits
        self.a = self.ctx.matrix(a.tolist() if hasattr(a, 'tolist') else a)
        self.b = self.ctx.matrix(b.tolist() if hasattr(b, 'tolist') else b)
        self.gain = np.asarray(gain, dtype=float).ravel()
        self.k = self.ctx.matrix([self.gain.tolist()])
        self.n = n_links; self.h = horizon; self.delays = tuple(projection_delays)
        nx = 2*(n_links+1)
        if (not isinstance(n_links, int) or n_links<1 or self.a.rows!=nx or self.a.cols!=nx
                or self.b.rows!=nx or self.b.cols!=1 or self.gain.shape!=(nx,)
                or not np.all(np.isfinite(self.gain)) or not all(self.ctx.isfinite(v) for m in (self.a,self.b) for v in m)
                or not isinstance(horizon,int) or not 2<=horizon<=16
                or len(self.delays)<horizon or len(set(self.delays))!=len(self.delays)
                or any(not isinstance(t,int) or not 0<=t<=100 for t in self.delays)
                or not 1<=rounds<=8 or not 0<derivative_epsilon<=.01
                or not 0<trust_halfwidth<=1 or decimal_digits<40
                or reference_mode not in ('linear','zero') or projection_scaling not in ('response','force')
                or (future_force_limit is not None and not 0<future_force_limit<=1)
                or correction_mode not in ('projected','restore_violations','minimize_peak')
                or (correction_mode!='projected' and future_force_limit is None)
                or not isinstance(adaptive_trust,bool) or not isinstance(warm_start,bool)
                or (adaptive_trust and trust_halfwidth<8*derivative_epsilon)):
            raise ValueError('aligned finite model and bounded joint preview settings required')
        self.predictor=predictor; self.rounds=rounds; self.epsilon=derivative_epsilon; self.trust=trust_halfwidth
        self.reference_mode=reference_mode;self.projection_scaling=projection_scaling
        self.future_force_limit=future_force_limit
        self.correction_mode=correction_mode
        self.adaptive_trust=adaptive_trust;self.warm_start=warm_start
        self.active_trust=self.trust;self.previous_plan=None
        self.minimum_trust=8*self.epsilon
        self.closed=self.a-self.b*self.k
        powers={0:self.ctx.eye(nx)}
        for step in range(1,max([horizon,*self.delays])+1):
            powers[step]=self.closed*powers[step-1]
        self.end_model=powers[horizon]
        projection=self.ctx.matrix([list(self.k*powers[t]) for t in self.delays])
        response=self.ctx.zeros(nx,horizon)
        for index in range(horizon):
            column=self.a**(horizon-index-1)*self.b
            for row in range(nx):response[row,index]=column[row]
        projected_response=projection*response
        self.scales=[max(self.ctx.mpf(1),max(abs(projected_response[row,i]) for i in range(horizon)))
                     for row in range(projection.rows)]
        if projection_scaling=='force':self.scales=[self.ctx.mpf(1)]*projection.rows
        self.raw_projection=projection
        self.projection=self.ctx.matrix([[projection[row,col]/self.scales[row] for col in range(nx)]
                                       for row in range(projection.rows)])
        self.native_transition_ceiling_per_plan=(3*horizon+rounds*(4*horizon*horizon+4*horizon)
                                                +2*horizon*horizon+(horizon if warm_start else 0))

    def physical(self,x):
        value=np.asarray(x,dtype=float).copy()
        if value.shape!=self.gain.shape or not np.all(np.isfinite(value)):
            raise ValueError('finite aligned physical state required')
        value[1:self.n+1]=wrap_angle(value[1:self.n+1])
        return value

    def select(self,state):
        state=np.asarray(state,float); physical=self.physical(state)
        reference=(self.end_model*self.ctx.matrix(physical.tolist()) if self.reference_mode=='linear'
                   else self.ctx.zeros(len(physical),1))
        cache={}; calls=0
        def quantize(actions):return tuple(np.clip(actions,-1,1).astype(np.float32).astype(float))
        def store(actions,states):
            states=np.asarray(states)
            angles=wrap_angle(np.cumsum(states[:,1:self.n+1],axis=1))
            rates=np.cumsum(states[:,self.n+2:],axis=1)
            violations=np.r_[np.maximum(np.abs(angles)/.149-1,0).ravel(),
                np.maximum(np.abs(rates)/.75-1,0).ravel(), np.maximum(np.abs(states[:,0])/3-1,0)]
            terminal=self.ctx.matrix(self.physical(states[-1]).tolist())
            requests=list(self.raw_projection*terminal)
            requests.extend((self.k*self.ctx.matrix(self.physical(x).tolist()))[0] for x in states)
            maximum_request=max(abs(v) for v in requests)
            if self.future_force_limit is not None:
                violations=np.r_[violations,[float(max(self.ctx.mpf(0),abs(v)/self.future_force_limit-1)) for v in requests]]
            signed_bounds=[self.ctx.mpf(float(v))/.149 for v in angles.ravel()]
            signed_bounds.extend(self.ctx.mpf(float(v))/.75 for v in rates.ravel())
            signed_bounds.extend(self.ctx.mpf(float(v))/3 for v in states[:,0])
            if self.future_force_limit is not None:
                signed_bounds.extend(v/self.future_force_limit for v in requests)
            bound_values=self.ctx.matrix(signed_bounds)
            constraint_peak=max(abs(v) for v in bound_values)
            residual=self.projection*(terminal-reference)
            error=self.ctx.fsum(v*v for v in residual)
            motion=float(np.sum((angles/.149)**2)+np.sum((rates/.75)**2))
            score=(float(np.max(violations)),float(np.sum(violations*violations)),error,motion)
            if self.correction_mode=='minimize_peak':
                score=(constraint_peak,score[1],error,motion)
            cache[actions]=dict(actions=actions,states=states,residual=residual,score=score,
                bound_values=bound_values, constraint_peak=constraint_peak,
                maximum_violation=float(np.max(violations)),maximum_model_feedback_request=maximum_request)
            return cache[actions]
        def evaluate(actions):
            nonlocal calls
            actions=quantize(np.asarray(actions,float))
            if actions in cache:return cache[actions]
            current=state.copy(); states=[]
            for action in actions:
                current=np.asarray(self.predictor(current,action),float); calls+=1
                self.physical(current); states.append(current.copy())
            return store(actions,states)

        # Both candidates are exactly delivered to a private native predictor.
        # The mechanical seed changes no live state, even when its ideal
        # reference is unreachable with the available bounded action sequence.
        ideal=self.ctx.matrix(physical.tolist()); linear=[]
        for _ in range(self.h):
            linear.append(float(np.float32(np.clip(float(-(self.k*ideal)[0]),-1,1))))
            ideal=self.closed*ideal
        current=state.copy(); feedback=[];feedback_states=[]
        for _ in range(self.h):
            action=float(np.float32(np.clip(-float(self.gain@self.physical(current)),-1,1)))
            feedback.append(action)
            current=np.asarray(self.predictor(current,action),float); calls+=1
            self.physical(current);feedback_states.append(current.copy())
        baseline=store(tuple(feedback),feedback_states)
        evaluate(linear)
        evaluate(np.zeros(self.h))
        warm=None;warm_actions=None;warm_reason='disabled'
        if self.warm_start:
            previous=self.previous_plan
            warm_reason='no_previous_feasible_plan'
            if previous is not None:
                warm_reason='measured_state_changed'
                if state.tobytes()==previous['states'][0].tobytes():
                    terminal=previous['states'][-1]
                    append=float(np.float32(np.clip(-float(self.gain@self.physical(terminal)),-1,1)))
                    warm_actions=[*previous['actions'][1:],append]
                    warm=evaluate(warm_actions)
                    assert warm['states'][:-1].tobytes()==previous['states'][1:].tobytes()
                    warm_reason='fresh_shifted_previous_feasible_plan'
        trust_radius=self.active_trust if self.adaptive_trust else self.trust
        initial_trust=trust_radius
        history=[]
        for round_index in range(self.rounds):
            center=min(cache.values(),key=lambda r:r['score'])
            controls=np.asarray(center['actions']);jac=self.ctx.zeros(len(self.delays),self.h)
            restore=(self.correction_mode=='minimize_peak' or
                     (self.correction_mode=='restore_violations' and center['maximum_violation']>0))
            identify_bounds=restore or self.adaptive_trust
            constraint_jac=self.ctx.zeros(len(center['bound_values']),self.h) if identify_bounds else None
            node_records=[]
            for column in range(self.h):
                offsets=[];samples=[center];nodes=[self.ctx.mpf(0)]
                for multiplier in (1,-1,2,-2,3,-3,4,-4):
                    trial=controls.copy();trial[column]=float(np.float32(np.clip(controls[column]+multiplier*self.epsilon,-1,1)))
                    offset=self.ctx.mpf(float(trial[column]))-self.ctx.mpf(float(controls[column]))
                    if not offset or offset in offsets:continue
                    offsets.append(offset);nodes.append(offset/self.ctx.mpf(self.epsilon));samples.append(evaluate(trial))
                    if len(offsets)==4:break
                if len(offsets)!=4:raise ValueError('unable to identify four bounded delivered derivative nodes')
                vandermonde=self.ctx.matrix([[node**power for node in nodes] for power in range(5)])
                target=self.ctx.matrix([0,1,0,0,0]);weights=self.ctx.lu_solve(vandermonde,target)/self.ctx.mpf(self.epsilon)
                for row in range(len(self.delays)):
                    jac[row,column]=self.ctx.fsum(weights[i]*samples[i]['residual'][row] for i in range(5))
                if identify_bounds:
                    for row in range(constraint_jac.rows):
                        constraint_jac[row,column]=self.ctx.fsum(weights[i]*samples[i]['bound_values'][row] for i in range(5))
                node_records.append([str(v*self.ctx.mpf(self.epsilon)) for v in nodes])
            constraint_diag=None;delta=None
            lower=np.maximum(-trust_radius,-1-controls);upper=np.minimum(trust_radius,1-controls)
            if restore:
                delta,constraint_diag=checked_constraint_step(self.ctx,constraint_jac,center['bound_values'],lower,upper)
            if delta is None:
                try:
                    change,_=self.ctx.qr_solve(jac,-center['residual'])
                except (ValueError,ZeroDivisionError) as error:
                    history.append(dict(round=round_index,status='projected_jacobian_rank_failure',error=str(error),
                                        constraint_subproblem=constraint_diag))
                    break
            else:
                change=self.ctx.matrix(delta.tolist())
            delta=np.array([float(v) for v in change])
            if not np.all(np.isfinite(delta)):raise ValueError('nonfinite projected correction')
            peak=float(np.max(np.abs(delta)))
            if peak>trust_radius:delta*=trust_radius/peak
            trials=[]
            for fraction in (1.,.5,.25,.125):
                trial=(quantized_box_trial(controls,delta,lower,upper,fraction) if self.adaptive_trust or
                       (restore and constraint_diag['status']=='original_mp_model_checked_proposal') else controls+fraction*delta)
                checked=evaluate(trial)
                agreement=(native_agreement(self.ctx,center['bound_values'],constraint_jac,
                    np.asarray(checked['actions'])-controls,checked['bound_values']) if self.adaptive_trust else None)
                trials.append((checked,agreement,fraction))
            following=min(cache.values(),key=lambda r:r['score'])
            trust_before=trust_radius;trust_action='fixed';best_agreement=None
            if self.adaptive_trust:
                candidate,best_agreement,_=min(trials,key=lambda item:item[0]['score'])
                if best_agreement['poor']:
                    trust_radius=max(self.minimum_trust,.25*trust_radius);trust_action='shrink'
                elif best_agreement['good'] and max(abs(np.asarray(candidate['actions'])-controls))>=.8*trust_radius:
                    trust_radius=min(self.trust,2*trust_radius);trust_action='expand'
                else:
                    trust_action='retain'
            history.append(dict(round=round_index,status='native_checked',derivative_nodes=node_records,
                predicted_control_change=[str(v) for v in change],clipped_control_change=delta.tolist(),
                initial_projected_cost=str(center['score'][2]),final_projected_cost=str(following['score'][2]),
                initial_constraint_peak=str(center['constraint_peak']),final_constraint_peak=str(following['constraint_peak']),
                constraint_subproblem=constraint_diag,
                trust_before=trust_before,trust_after=trust_radius,trust_action=trust_action,
                best_trial_agreement=best_agreement,
                trial_agreements=[dict(fraction=f,agreement=g) for _,g,f in trials] if self.adaptive_trust else [],
                improved=following['score']<center['score']))
            if following['score']>=center['score'] and not (self.adaptive_trust and trust_radius<trust_before):break
        best=min(cache.values(),key=lambda r:r['score'])
        controls=np.asarray(best['actions'])
        for column in range(self.h):
            for direction in (-np.inf,np.inf):
                trial=controls.copy();trial[column]=float(np.nextafter(np.float32(controls[column]),np.float32(direction),dtype=np.float32))
                evaluate(trial)
        selected=min(cache.values(),key=lambda r:r['score'])
        ceiling=self.native_transition_ceiling_per_plan
        assert calls<=ceiling,(calls,ceiling)
        assert selected['score']<=baseline['score']
        if self.adaptive_trust:self.active_trust=trust_radius
        if self.warm_start:
            self.previous_plan=(dict(actions=selected['actions'],states=selected['states'].copy())
                                if selected['maximum_violation']==0 else None)
        return np.asarray(selected['actions']),selected['states'].copy(),dict(
            horizon=self.h,projection_delays=list(self.delays),projection_scales=[str(v) for v in self.scales],
            native_transition_calls=calls,native_transition_ceiling=ceiling,
            baseline_actions=list(baseline['actions']),baseline_projected_cost=str(baseline['score'][2]),
            selected_projected_cost=str(selected['score'][2]),
            reference_mode=self.reference_mode,projection_scaling=self.projection_scaling,
            correction_mode=self.correction_mode,
            adaptive_trust=self.adaptive_trust,initial_trust_radius=initial_trust,final_trust_radius=trust_radius,
            warm_start=self.warm_start,warm_candidate_used=warm is not None,warm_candidate_reason=warm_reason,
            warm_candidate_actions=warm_actions,warm_prefix_matches_previous_forecast=True if warm is not None else None,
            warm_candidate_preview_feasible=None if warm is None else warm['maximum_violation']==0,
            warm_candidate_constraint_peak=None if warm is None else str(warm['constraint_peak']),
            future_force_limit=self.future_force_limit,
            baseline_maximum_model_feedback_request=str(baseline['maximum_model_feedback_request']),
            selected_maximum_model_feedback_request=str(selected['maximum_model_feedback_request']),
            baseline_maximum_violation=baseline['maximum_violation'],selected_maximum_violation=selected['maximum_violation'],
            baseline_constraint_peak=str(baseline['constraint_peak']),selected_constraint_peak=str(selected['constraint_peak']),
            selected_preview_feasible=selected['maximum_violation']==0,
            baseline_is_candidate=True,selected_no_worse_than_baseline=True,rounds=history,
            selected_projection_residual=[str(v) for v in selected['residual']],
            scope='Native F32 joint previews with MP100 projected residuals and whole-preview angle/rate/rail/model-force rows. Optional constraint minimax differentiates the same delivered native forecasts and checks proposals in original MP rows before native contractions. Projected remains the default. Finite preview improvement and modeled baseline force reserve are not recursive feasibility, physical impossibility or nonlinear stability certificates.')
