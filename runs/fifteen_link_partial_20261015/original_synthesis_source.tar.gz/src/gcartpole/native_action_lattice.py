"""Bounded nearby F32 action search with native proposal acceptance.

An integer L1 model proposes coordinated changes. Only measured native squared
loss selects a plan; neither the affine model nor a MILP status certifies it.
"""
import numpy as np
from scipy.optimize import Bounds,LinearConstraint,milp
from scipy.sparse import csr_matrix,eye,hstack,vstack
from .simulation import SimulationError


def affine_action_lattice(center,radius):
    center=np.asarray(center,float)
    if (center.ndim!=1 or not len(center) or not np.all(np.isfinite(center))
            or np.any(np.abs(center)>1) or not np.array_equal(center,center.astype(np.float32).astype(float))
            or not isinstance(radius,(int,np.integer)) or not 1<=radius<=4096):
        raise ValueError('bounded delivered F32 center and integer radius1..4096 required')
    spacing=[];lower=[];upper=[]
    for value in center:
        single=np.float32(value)
        step=min(float(np.nextafter(single,np.float32(np.inf)))-value,
                 value-float(np.nextafter(single,np.float32(-np.inf))))
        offsets=np.arange(-radius,radius+1);affine=value+step*offsets
        valid=(np.abs(affine)<=1.)&(affine==affine.astype(np.float32).astype(float))
        left=right=radius
        while left>0 and valid[left-1]:left-=1
        while right<2*radius and valid[right+1]:right+=1
        spacing.append(step);lower.append(left-radius);upper.append(right-radius)
    return np.asarray(spacing),np.asarray(lower),np.asarray(upper)


def polish_native_action_lattice(transition,state,center,*,reference_actions,
        constraint_residual,constraint_jacobian,admissible,radii=(8,64,512),
        solver_seconds=1.,action_regularization=.01):
    state=np.asarray(state,float);center=np.asarray(center,float);reference=np.asarray(reference_actions,float)
    if (state.ndim!=1 or not np.all(np.isfinite(state)) or reference.shape!=center.shape
            or not np.all(np.isfinite(reference)) or np.any(np.abs(reference)>1)
            or not len(radii) or any(not isinstance(r,(int,np.integer)) or not 1<=r<=4096 for r in radii)
            or not np.isfinite(solver_seconds) or solver_seconds<=0
            or not np.isfinite(action_regularization) or action_regularization<0
            or not all(callable(x) for x in (transition,constraint_residual,constraint_jacobian,admissible))):
        raise ValueError('aligned finite inputs, physical callbacks and bounded search budgets required')
    affine_action_lattice(center,int(radii[0]))
    reference=reference.astype(np.float32).astype(float);horizon=len(center);cache={};calls=0
    def evaluate(actions):
        nonlocal calls
        actions=np.asarray(actions,float)
        if (actions.shape!=center.shape or not np.array_equal(actions,actions.astype(np.float32).astype(float))
                or np.any(np.abs(actions)>1)):
            raise ValueError('Every lattice proposal must be exactly representable bounded F32 inputs')
        key=tuple(actions)
        if key not in cache:
            current=state.copy();states=[]
            try:
                for action in actions:
                    calls+=1;current=np.asarray(transition(current.copy(),float(action)),float)
                    if current.shape!=state.shape or not np.all(np.isfinite(current)):
                        raise SimulationError('invalid native lattice forecast')
                    states.append(current.copy())
                states=np.asarray(states);residual=np.asarray(constraint_residual(states.copy()),float)
                if residual.ndim!=1 or not len(residual) or not np.all(np.isfinite(residual)):
                    raise ValueError('physical lattice residual must be finite and nonempty')
                cache[key]=dict(states=states,residual=residual,admissible=bool(admissible(states.copy())),
                    physical_cost=float(residual@residual),
                    total_cost=float(residual@residual+action_regularization**2*np.sum((actions-reference)**2)))
            except SimulationError as error:
                cache[key]=dict(admissible=False,error=str(error))
        return cache[key]
    baseline=evaluate(center)
    if 'error' in baseline:raise SimulationError('lattice center must have a finite native forecast')
    jac=np.asarray(constraint_jacobian(state.copy(),center.copy(),baseline['states'].copy()),float)
    residual=baseline['residual'];physical_rows=len(residual)
    if jac.shape!=(physical_rows,horizon) or not np.all(np.isfinite(jac)):
        raise ValueError('finite lattice physical Jacobian aligned with residual/actions required')
    total_residual=np.r_[residual,action_regularization*(center-reference)]
    total_jac=np.vstack([jac,action_regularization*np.eye(horizon)]);searches=[];scale=2.**20
    for radius in radii:
        spacing,lower,upper=affine_action_lattice(center,int(radius));d=scale*total_jac*spacing[None,:]
        r=scale*total_residual;m=len(r)
        matrix=vstack([hstack([csr_matrix(d),-eye(m)]),hstack([-csr_matrix(d),-eye(m)])],format='csc')
        solution=milp(np.r_[np.zeros(horizon),np.ones(m)],integrality=np.r_[np.ones(horizon),np.zeros(m)],
            bounds=Bounds(np.r_[lower,np.zeros(m)],np.r_[upper,np.full(m,np.inf)]),
            constraints=LinearConstraint(matrix,np.full(2*m,-np.inf),np.r_[-r,r]),
            options=dict(time_limit=solver_seconds,mip_rel_gap=1e-3,presolve=True))
        search=dict(radius_ulps=int(radius),solver_status=int(solution.status),solver_success=bool(solution.success),
            solver_message=solution.message,solver_mip_gap=getattr(solution,'mip_gap',None),
            nonzero_scaled_coefficients_below1em9=int(np.count_nonzero((d!=0)&(np.abs(d)<1e-9))),trials=[])
        searches.append(search)
        if solution.x is not None and np.all(np.isfinite(solution.x)):
            integers=np.rint(solution.x[:horizon]);error=float(np.max(np.abs(integers-solution.x[:horizon])))
            search['maximum_integer_rounding_error']=error
            if error<=1e-5 and np.all((integers>=lower)&(integers<=upper)):
                for exponent in range(10):
                    offsets=np.rint(integers*2.**(-exponent));candidate=center+spacing*offsets
                    measured=evaluate(candidate)
                    trial=dict(fraction=2.**(-exponent),sequence=candidate.tolist(),admissible=measured['admissible'])
                    for key in ('error','physical_cost','total_cost'):
                        if key in measured:trial[key]=measured[key]
                    trial['linear_predicted_physical_cost']=float(np.sum((residual+jac@(candidate-center))**2))
                    search['trials'].append(trial)
    feasible=[key for key,value in cache.items() if value['admissible']]
    best=min(feasible,key=lambda key:cache[key]['total_cost']) if feasible else None
    info=dict(native_transition_calls=calls,unique_quantized_sequences_evaluated=len(cache),
        baseline_physical_cost=baseline['physical_cost'],baseline_total_cost=baseline['total_cost'],
        selected_physical_cost=None if best is None else cache[best]['physical_cost'],
        selected_total_cost=None if best is None else cache[best]['total_cost'],
        selected_states=None if best is None else cache[best]['states'].tolist(),
        changed_sequence=best is not None and best!=tuple(center),searches=searches,
        radii_ulps=list(radii),solver_seconds_per_box=solver_seconds,common_residual_scale=scale,
        action_regularization=action_regularization,
        scope='Nearby affine F32 grids and mixed-integer L1 proposals; measured native squared loss plus action regularization selects only rail/constraint-admissible forecasts. Callback derivative sampling budget is external. No episode pass, optimality or recursive viability certificate.')
    return None if best is None else np.asarray(best),info
