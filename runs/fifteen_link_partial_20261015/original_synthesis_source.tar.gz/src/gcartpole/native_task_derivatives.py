"""Physical task loss and one-step native derivative composition.

The Jacobian approximates the smooth held-action map; final float32 proposals
must still be checked by native rollouts. MP composition preserves arithmetic
accuracy, but cannot restore information missing from local finite differences.
"""
import mpmath
import numpy as np
from .angles import wrap_angle


def physical_task_residual(states,n_links,rate_weight,angle_band=0.):
    states=np.asarray(states,float);horizon=len(states);n=n_links
    if (states.shape!=(horizon,2*(n+1)) or horizon<1 or n<1
            or not np.all(np.isfinite(states)) or not np.isfinite(rate_weight) or rate_weight<=0
            or not np.isfinite(angle_band) or not 0<=angle_band<.15):
        raise ValueError('finite physical states and positive task scales required')
    angles=wrap_angle(np.cumsum(states[:,1:n+1],axis=1))
    if angle_band>0:angles=np.sign(angles)*np.maximum(np.abs(angles)-angle_band,0.)
    rates=np.cumsum(states[:,n+2:],axis=1);scale=np.sqrt(n*horizon)
    return np.r_[(angles/.15/scale).ravel(),(rate_weight*rates/.75/scale).ravel(),
        .1*states[:,0]/1.5/np.sqrt(horizon),.1*states[:,n+1]/.5/np.sqrt(horizon),
        np.sqrt(5)*angles[-1]/.15/np.sqrt(n),np.sqrt(5)*rate_weight*rates[-1]/.75/np.sqrt(n)]


def chained_physical_task_jacobian(local_transition,state,actions,predictions,*,
        n_links,rate_weight,state_epsilon,action_epsilon,angle_band=0.):
    state=np.asarray(state,float);actions=np.asarray(actions,float);predictions=np.asarray(predictions,float)
    physical_task_residual(predictions,n_links,rate_weight,angle_band)
    n=n_links;nx=2*(n+1);horizon=len(actions)
    if (state.shape!=(nx,) or predictions.shape!=(horizon,nx)
            or not np.all(np.isfinite(state)) or not np.all(np.isfinite(actions))
            or np.any(np.abs(actions)>1)):
        raise ValueError('aligned finite native state/action forecast required')
    ctx=mpmath.mp.clone();ctx.dps=100;s=None;sensitivities=[]
    for k in range(horizon):
        a,b=local_transition.linearize(state if k==0 else predictions[k-1],float(actions[k]),
            state_epsilon=state_epsilon,action_epsilon=action_epsilon)
        if a.shape!=(nx,nx) or b.shape!=(nx,1) or not np.all(np.isfinite(a)) or not np.all(np.isfinite(b)):
            raise ValueError('finite aligned native transition Jacobians required')
        # Future action columns are identically zero. Propagate only columns
        # already introduced, using the same MP100 dot products and order.
        propagated=None if s is None else ctx.matrix(a.tolist())*s
        s=ctx.zeros(nx,k+1);padded=ctx.zeros(nx,horizon)
        for j in range(nx):
            for c in range(k):s[j,c]=padded[j,c]=propagated[j,c]
            s[j,k]=padded[j,k]=ctx.mpf(float(b[j,0]))
        sensitivities.append(padded)
    # Same row ordering as physical_task_residual, including terminal terms.
    angle_rows=[];rate_rows=[];mapped=[]
    for s in sensitivities:
        angles=[];rates=[];angle=[0]*horizon;rate=[0]*horizon
        for j in range(n):
            # Reuse each cumulative sum; preserve its left-to-right addition
            # order instead of summing every shorter prefix again.
            angle=[angle[c]+s[j+1,c] for c in range(horizon)]
            rate=[rate[c]+s[n+j+2,c] for c in range(horizon)]
            angles.append(angle);rates.append(rate)
        angle_rows.append(angles);rate_rows.append(rates)
    for blocks,scale in [(angle_rows,1/.15/np.sqrt(n*horizon)),(rate_rows,rate_weight/.75/np.sqrt(n*horizon))]:
        for block in blocks:
            for row in block:mapped.append([v*ctx.mpf(float(scale)) for v in row])
    for index,scale in [(0,.1/1.5/np.sqrt(horizon)),(n+1,.1/.5/np.sqrt(horizon))]:
        for s in sensitivities:mapped.append([s[index,c]*ctx.mpf(float(scale)) for c in range(horizon)])
    for block,scale in [(angle_rows[-1],np.sqrt(5)/.15/np.sqrt(n)),
            (rate_rows[-1],np.sqrt(5)*rate_weight/.75/np.sqrt(n))]:
        for row in block:mapped.append([v*ctx.mpf(float(scale)) for v in row])
    jac=np.asarray(ctx.matrix(mapped).tolist(),float)
    if angle_band>0:
        active=np.abs(wrap_angle(np.cumsum(predictions[:,1:n+1],axis=1)))>angle_band
        jac[:n*horizon]*=active.ravel()[:,None]
        terminal_begin=2*n*horizon+2*horizon
        jac[terminal_begin:terminal_begin+n]*=active[-1,:,None]
    if not np.all(np.isfinite(jac)):raise ValueError('nonfinite composed native task Jacobian')
    return jac
