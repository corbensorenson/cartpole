"""Factored empirical modal arrival geometry; not a nonlinear basin certificate."""
import mpmath
import numpy as np


def physical_factor(ctx, n_links, time_scale):
    n = n_links
    w = ctx.zeros(2*(n+1))
    tau = ctx.mpf(time_scale)
    w[0, 0] = ctx.mpf(1)/3
    w[n+1, n+1] = tau/3
    for i in range(n):
        for j in range(i+1):
            w[i+1, j+1] = ctx.mpf(1)/ctx.mpf('.15')
            w[n+2+i, n+2+j] = tau/ctx.mpf('.15')
    return w


def empirical_modal_factor(directions, *, n_links, time_scale,
                           modal_scale=1e-4, physical_floor=1e-13):
    """Use an MP100 SVD and explicit floor, preserving left directional factors.

    The floor limits numerical amplification. It is a declared search parameter,
    not a demonstrated disturbance radius or a certified terminal ellipsoid.
    """
    if (n_links < 1 or not np.isfinite(modal_scale) or modal_scale <= 0 or
            not np.isfinite(physical_floor) or physical_floor <= 0):
        raise ValueError('positive finite geometry scales required')
    ctx = mpmath.mp.clone(); ctx.dps = 100
    nx = 2*(n_links+1)
    d = ctx.matrix(np.asarray(directions, dtype=float).T.tolist())
    if d.rows != nx or d.cols != nx:
        raise ValueError('complete aligned real mode basis required')
    w = physical_factor(ctx, n_links, time_scale)
    u, singular, _ = ctx.svd_r(w*d)
    factor = ctx.zeros(nx)
    denominators = []
    for i in range(nx):
        denominator = max(ctx.mpf(float(modal_scale))*singular[i], ctx.mpf(float(physical_floor)))
        denominators.append(denominator)
        for j in range(nx):
            factor[i, j] = ctx.fsum(u[k, i]*w[k, j] for k in range(nx))/denominator
    return ctx, factor, w, dict(
        decimal_digits=100, modal_scale=modal_scale, physical_floor=physical_floor,
        weighted_singular_values=[str(v) for v in singular],
        effective_denominators=[str(v) for v in denominators],
        effective_condition=str(max(denominators)/min(denominators)),
        floored_directions=sum(ctx.mpf(float(modal_scale))*v < ctx.mpf(float(physical_floor)) for v in singular),
        scope='Factored search geometry from saved rounded modes. Floor is an experimental numerical choice; sampled maintenance does not certify this ellipsoid.')


def regularized_qr_step(ctx, jacobian, residual, regularization):
    """Solve augmented least squares by MP100 QR, without normal equations."""
    if not np.isfinite(regularization) or regularization <= 0:
        raise ValueError('positive finite regularization required')
    jac = ctx.matrix(jacobian); res = ctx.matrix(residual)
    if res.rows != jac.rows or res.cols != 1:
        raise ValueError('aligned residual and Jacobian required')
    augmented = ctx.zeros(jac.rows+jac.cols, jac.cols)
    rhs = ctx.zeros(augmented.rows, 1)
    for i in range(jac.rows):
        rhs[i] = -res[i]
        for j in range(jac.cols):
            augmented[i, j] = jac[i, j]
    for j in range(jac.cols):
        augmented[jac.rows+j, j] = ctx.sqrt(ctx.mpf(float(regularization)))
    step, error = ctx.qr_solve(augmented, rhs)
    return np.asarray(list(step), dtype=float), str(error)
