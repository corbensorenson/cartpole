"""Keep scored action sequences aligned with the latent CEM samples.

Exact source and warm-start sequences need not lie in the interpolation basis.
They can win action selection, but must not contribute unrelated latent samples
to the distribution update. Final delivered actions use float32 rounding.
"""
from dataclasses import dataclass
import numpy as np


@dataclass(frozen=True)
class CEMPopulation:
    knots: np.ndarray
    actions: np.ndarray
    update_eligible: np.ndarray
    kinds: tuple[str, ...]


def draw_cem_population(mean, std, basis, rng, *, candidate_count, warm,
                        reference=None, base_actions=None):
    mean, std, basis = (np.asarray(x, dtype=float) for x in (mean, std, basis))
    if (mean.ndim != 1 or std.shape != mean.shape or basis.ndim != 2
            or basis.shape[1] != len(mean) or candidate_count < 8
            or not all(np.all(np.isfinite(x)) for x in (mean, std, basis))
            or np.any(std <= 0)):
        raise ValueError('Finite aligned latent distribution and at least eight candidates required')
    knots = rng.normal(mean, std, size=(candidate_count, len(mean)))
    knots[0], knots[1], knots[2], knots[3] = mean, 0., -1., 1.
    base = np.zeros(basis.shape[0]) if base_actions is None else np.asarray(base_actions, float)
    if base.shape != (basis.shape[0],) or not np.all(np.isfinite(base)):
        raise ValueError('Finite aligned residual-action anchor required')
    actions = np.clip(base + knots @ basis.T, -1., 1.).astype(np.float32).astype(float)
    eligible = np.ones(candidate_count, dtype=bool)
    kinds = ['sampled'] * candidate_count
    kinds[:4] = ['mean', 'zero', 'minimum', 'maximum']
    for index, value, kind in ((4, warm, 'warm'), (5, reference, 'reference')):
        if value is None:
            if kind == 'warm':
                raise ValueError('Exact warm-start sequence required')
            continue
        value = np.asarray(value, dtype=float)
        if value.shape != (basis.shape[0],) or not np.all(np.isfinite(value)):
            raise ValueError('Finite full-horizon fixed sequence required')
        actions[index] = np.clip(value, -1., 1.).astype(np.float32).astype(float)
        eligible[index] = False
        kinds[index] = kind
    return CEMPopulation(knots, actions, eligible, tuple(kinds))


def update_cem_distribution(population, scores, *, elite_count, minimum_std):
    eligible = np.flatnonzero(population.update_eligible)
    scores = [tuple(float(v) for v in score) for score in scores]
    if (len(scores) != len(population.actions) or not scores
            or len({len(score) for score in scores}) != 1
            or not all(np.all(np.isfinite(score)) for score in scores)
            or elite_count < 1 or elite_count > len(eligible)
            or not np.isfinite(minimum_std) or minimum_std <= 0):
        raise ValueError('Finite scores and enough eligible samples for the declared elites required')
    chosen = np.asarray(sorted(eligible, key=lambda i: scores[i])[:elite_count], dtype=int)
    # Preserve the declared bounded-latent update convention. These are the
    # latent rows that actually generated the corresponding scored commands.
    elite = np.clip(population.knots[chosen], -1., 1.)
    return np.mean(elite, axis=0), np.maximum(np.std(elite, axis=0), minimum_std), chosen
