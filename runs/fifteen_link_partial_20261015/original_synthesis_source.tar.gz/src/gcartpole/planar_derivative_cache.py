"""Byte-verified smooth planar sensitivities for an unchanged native route."""
import json
from pathlib import Path
import numpy as np
from .evidence import data_sha256,file_metadata,text_sha256


class PlanarDerivativeCache:
    def __init__(self, directory, *, states, controls, config_path, env, decimal_digits):
        self.directory=Path(directory);path=self.directory/'derivative_cache.json'
        manifest=json.loads(path.read_text())
        if (manifest['status']!='finished' or manifest['decimal_digits']<decimal_digits
                or manifest['config']!=file_metadata(config_path)
                or manifest['physics_xml_sha256']!=text_sha256(env.xml)
                or manifest['frame_skip']!=env.frame_skip
                or manifest['states_sha256']!=data_sha256(np.asarray(states,dtype=float).tolist())
                or manifest['controls_sha256']!=data_sha256(np.asarray(controls,dtype=float).tolist())
                or len(manifest['steps'])!=len(controls)):
            raise ValueError('completed derivative cache does not match route, precision or native physics')
        self.steps={row['step']:row for row in manifest['steps']}
        if set(self.steps)!=set(range(len(controls))):raise ValueError('derivative cache has missing/duplicate horizon steps')
        for row in self.steps.values():
            p=self.directory/f"step{row['step']:04d}.json"
            if file_metadata(p)!=row['artifact']:raise ValueError('derivative cache step bytes changed')
        self.metadata=file_metadata(path)
        self.manifest=manifest
        self.states=np.asarray(states,dtype=float).copy()

    def __call__(self, step, state, action, ctx):
        row=self.steps[step];p=self.directory/f'step{step:04d}.json'
        if file_metadata(p)!=row['artifact']:raise ValueError('derivative cache step bytes changed during design')
        data=json.loads(p.read_text())
        if (data['step']!=step or not np.array_equal(data['state'],state)
                or data['delivered_nominal_action']!=float(np.float32(np.clip(action,-1.,1.)))):
            raise ValueError('derivative cache step state/action differs')
        return ctx.matrix(data['A']),ctx.matrix(data['B'])

    def nominal_defect(self, step, ctx):
        row=self.steps[step];p=self.directory/f'step{step:04d}.json'
        if file_metadata(p)!=row['artifact']:raise ValueError('derivative cache step bytes changed during defect design')
        data=json.loads(p.read_text())
        # Promote each saved binary64 coordinate before subtracting, retaining
        # the exact native/reference scalar difference in the MP recurrence.
        return ctx.matrix(data['native_next_state'])-ctx.matrix(self.states[step+1].tolist())
