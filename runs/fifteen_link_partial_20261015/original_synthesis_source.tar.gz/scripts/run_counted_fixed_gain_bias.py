"""Run a shared full-route repair with inclusive native physics accounting.

The immutable outer runner snapshots this script and inputs. The mj_step hook
only counts and limits calls; all controller and optimizer arithmetic stays in
search_fddp_capture. This is auxiliary development, never release promotion.
"""
import argparse
import json
import runpy
import sys
import time
from pathlib import Path

import mujoco
import numpy as np
from gcartpole.config import load_config, dump_json
from gcartpole.evidence import file_metadata, utc_timestamp


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config', required=True)
    p.add_argument('--initializer', required=True)
    p.add_argument('--directory', required=True)
    p.add_argument('--iterations', type=int, default=8)
    p.add_argument('--native-transition-ceiling', type=int, default=1000000)
    p.add_argument('--native-bias',action='store_true')
    p.add_argument('--replay-only', action='store_true')
    p.add_argument('--optimize-suffix-start-seconds',type=float,default=0.)
    args = p.parse_args()
    out = Path(args.directory)
    out.mkdir(parents=True, exist_ok=False)
    cfg = load_config(args.config)
    frame = cfg['env']['frame_skip']
    source = json.loads(Path(args.initializer).read_text())
    n = cfg['env']['n_links']
    assert n == 14 and args.replay_only and args.iterations > 0 and args.native_transition_ceiling > 0
    if not np.isfinite(args.optimize_suffix_start_seconds) or not 0<=args.optimize_suffix_start_seconds<14:
        raise ValueError('suffix start must lie inside the fourteen-second reference')
    assert source['selected_state']['qpos'][1] == -np.pi
    assert all(x == 0. for x in source['selected_state']['qvel'])
    command = ['scripts/search_fddp_capture.py', '--config', args.config,
        '--state-json', args.initializer, '--state-index', 'selected', '--seed', '0',
        '--initial-controller', args.initializer, '--iterations', str(args.iterations),
        '--optimizer', 'sqrt-ilqr' if args.replay_only else 'sparse-scvx',
        '--derivative-order', '4', '--state-epsilon', '.0002', '--action-epsilon', '.0005',
        '--tracking-gain-scale', '1', '--lqr-scale', '1', '--lqr-control-cost', '1000',
        '--lqr-decimal-digits', '100', '--terminal-weight', '0', '--terminal-state-weight', '1000',
        '--terminal-angle-factor', '20', '--terminal-hinge-velocity-factor', '4',
        '--initial-regularization', '10', '--defect-penalty', '100000',
        '--stage-weight', '.01', '--control-cost', '.01', '--rail-soft-limit', '2.85',
        '--rail-weight', '5000000', '--handoff-lyapunov', '10', '--handoff-cart-abs', '1.5',
        '--handoff-angle-abs', '.15', '--handoff-cart-velocity-abs', '.5',
        '--handoff-hinge-velocity-rms', '.75', '--solver-verbose', '--continuous-angles',
        '--physical-shooting', '--defer-handoff-until-horizon', '--out', str(out/'candidate.json')]
    command += ['--capture-start-seconds','9','--capture-stage-weight','1000']
    if args.native_bias:
        command += ['--recompute-tracking-feedback','--tracking-feedback-decimal-digits','100','--tracking-feedback-regularization','800000','--tracking-feedback-defect-feedforward','--tracking-feedback-defect-source','native','--tracking-feedback-retain-solver-gains','--tracking-feedback-start-seconds','8']
    if args.optimize_suffix_start_seconds:
        command += ['--optimize-suffix-start-seconds',str(args.optimize_suffix_start_seconds)]
    if args.replay_only:
        command.append('--replay-only')
    else:
        command += ['--capture-start-seconds', '9', '--capture-stage-weight', '1000',
            '--enforce-rail-during-search', '--sparse-capture-angle-limit', '.14',
            '--sparse-state-trust', '.05', '--sparse-control-trust', '.1',
            '--sparse-qp-solver', 'clarabel', '--sparse-qp-max-iterations', '200',
            '--sparse-qp-initial-tolerance', '1e-5', '--sparse-qp-tolerance', '1e-8',
            '--sparse-qp-inexact-dual-tolerance', '.001', '--sparse-trust-policy', 'agreement']
    payload = dict(generated_at=utc_timestamp(), config=file_metadata(args.config),
        initializer=file_metadata(args.initializer),native_bias=args.native_bias, script=file_metadata(__file__), command=command,
        status='running', not_solution=True, canonical_release_evidence=False,
        reserved_seeds_used=False, noisy_development_seeds_used=False, seed=0,
        entire_horizon_free=not args.replay_only and args.optimize_suffix_start_seconds==0.,
        optimize_suffix_start_seconds=args.optimize_suffix_start_seconds,native_transition_ceiling=args.native_transition_ceiling,
        total_native_transition_calls=0, native_physics_substeps=0,
        actual_hanging_start_episode_steps=0, independent_tape_replay_transition_calls=0,
        scope='Exact unparked hanging-start14 component. Same shared residual-form recipe, eight Clarabel/agreement full-horizon iterations on small armature changes; canonical replay control. Inclusive mj_step accounting includes LQR/metric design, warm-start diagnostics, derivatives, rejected trials, actual controller evaluation and byte proof. No15/noisy/reserved seeds or count promotion.')
    original_step = mujoco.mj_step
    counter = [0]
    from gcartpole.env import NLinkCartPoleEnv
    original_environment_step = NLinkCartPoleEnv.step
    actual_counter = [0]

    def counted_environment_step(env, action):
        actual_counter[0] += 1
        return original_environment_step(env, action)

    def counted_step(model, data, *positional, **keywords):
        count = int(keywords.get('nstep', positional[0] if positional else 1))
        if counter[0] + count > args.native_transition_ceiling * frame:
            raise RuntimeError('inclusive native transition ceiling reached')
        counter[0] += count
        return original_step(model, data, *positional, **keywords)

    mujoco.mj_step = counted_step
    NLinkCartPoleEnv.step = counted_environment_step
    started = time.monotonic()
    old_argv = sys.argv
    try:
        sys.argv = command
        runpy.run_path(command[0], run_name='__main__')
        candidate = json.loads((out/'candidate.json').read_text())
        result = candidate['result']
        trajectory = result['trajectory']
        states = np.vstack([candidate['selected_state']['qpos'] + candidate['selected_state']['qvel'],
                            [row['qpos'] + row['qvel'] for row in trajectory]])
        actions = np.asarray([row['action'] for row in trajectory], np.float32).astype(float)
        from gcartpole.env import NLinkCartPoleEnv
        from gcartpole.ilqr import MujocoTransition
        from scripts.search_capture_sequence import fixed_state_cfg
        env = NLinkCartPoleEnv(fixed_state_cfg(cfg, candidate['selected_state'], 30.), progress=1., seed=0)
        env.reset(seed=0)
        native = MujocoTransition(env, np.eye(2*(n+1)), continuous_angles=True)
        try:
            for i, u in enumerate(actions):
                assert native(states[i], float(u)).tobytes() == states[i+1].tobytes()
            proof = native.evaluations
        finally:
            env.close()
        assert proof == len(actions) == result['length']
        assert actual_counter[0] == len(actions)
        tape = out/'actual_tape.npz'
        np.savez_compressed(tape, states=states, actions=actions)
        passed = bool(result['success'] and result['length'] == round(30/(.005*frame))
            and result['termination_reason'] == 'time_limit'
            and result['max_upright_streak_seconds'] >= 5
            and result['max_cart_excursion'] <= 3 and result['trajectory_integrity'])
        payload.update(status='finished', candidate=file_metadata(out/'candidate.json'),
            actual_hanging_start_episode_steps=len(actions), independent_tape_replay_transition_calls=proof,
            independent_whole_actual_tape_bytes_exact=True, tape=file_metadata(tape),
            full_nominal_component_gate_passed=passed,
            result={key:value for key,value in result.items() if not isinstance(value,(dict,list))},
            optimizer_iterations=candidate['search']['iterations'],
            optimizer_transitions=candidate['evidence']['compute'] if 'compute' in candidate['evidence'] else None)
    except BaseException as error:
        payload.update(status='failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        mujoco.mj_step = original_step
        NLinkCartPoleEnv.step = original_environment_step
        sys.argv = old_argv
        payload.update(native_physics_substeps=counter[0],
            actual_hanging_start_episode_steps=actual_counter[0],
            total_native_transition_calls=counter[0]/frame,
            partial_transition_substeps=counter[0]%frame,
            finished_at=utc_timestamp(), wall_seconds=time.monotonic()-started)
        dump_json(payload, out/'result.json')
        print(json.dumps({key:value for key,value in payload.items() if key in
            ('status','total_native_transition_calls','actual_hanging_start_episode_steps',
             'full_nominal_component_gate_passed','error','result')}), flush=True)


if __name__ == '__main__':
    main()
