"""Read-only fixed-physical-prefix and saved-feedback capture audit."""
import argparse,json
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from scripts.audit_armature_route_increment import tape,journal,checked,read


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',required=True);args=p.parse_args();root=Path(args.directory);rows=[]
    previous=read(root/'verified_step_iterations.json');assert previous['passed']
    folder=root/'armature0.98_actual8s_prefix_capture8';ej=journal(folder);d=read(folder/'diagnostic/result.json')
    for key in ('config','initializer','candidate'):checked(d[key])
    assert d['status']=='finished' and d['optimize_suffix_start_seconds']==8 and not d['entire_horizon_free']
    candidate=read(d['candidate']['path']);initial=read(d['initializer']['path']);c=candidate['controller']
    assert c['frozen_prefix_steps']==400 and candidate['search']['optimized_horizon_steps']==300
    source=read(initial['source']['path']);origin=np.load(initial['actual_prefix_tape']['path'])
    assert np.array_equal(np.array(initial['search']['nominal_coordinate_states'])[:401],origin['states'][:401])
    assert np.array_equal(np.array(initial['controller']['controls'])[:400],origin['actions'][:400])
    for key in ('controls','feedback_gains'):assert np.array(c[key])[:400].tobytes()==np.array(initial['controller'][key])[:400].tobytes()
    assert np.array(candidate['search']['nominal_coordinate_states'])[:401].tobytes()==origin['states'][:401].tobytes()
    x,u,gate=tape(d);assert x[:401].tobytes()==origin['states'][:401].tobytes() and u[:400].tobytes()==origin['actions'][:400].tobytes()
    assert d['partial_transition_substeps']==0 and d['native_physics_substeps']==4*d['total_native_transition_calls']
    rows.append(dict(directory=str(folder),execution=ej,result=file_metadata(folder/'diagnostic/result.json'),candidate=d['candidate'],config=d['config'],initializer=d['initializer'],tape=d['tape'],total_native_transition_calls=d['total_native_transition_calls'],actual_hanging_start_episode_steps=len(u),full_nominal_component_gate_passed=gate,maximum_model_defect=c['final_trajectory_diagnostics']['maximum_dynamics_defect']))
    ff=root/'armature0.98_actual8s_prefix_native_defect_feedback';j=journal(ff);f=read(ff/'diagnostic/result.json')
    assert f['status']=='finished' and f['preserve_actual_prefix_steps']==400 and f['source']==d['candidate'] and f['config']==d['config']
    assert f['native_reference_design_calls']==38500 and f['upright_gain_design_calls']==62
    checked(f['reference']);ref=np.load(f['reference']['path'])
    assert np.array_equal(ref['states'],np.array(candidate['search']['nominal_coordinate_states']))
    assert ref['native_predictions'][:400].tobytes()==ref['states'][1:401].tobytes()
    assert np.array_equal(ref['feedforward_offsets'][:400],np.zeros(400))
    assert np.array_equal(ref['feedback_gains'][:400],np.array(c['feedback_gains'])[:400])
    for r in f['records']:
        xx,uu,_=tape(r);assert xx[:401].tobytes()==origin['states'][:401].tobytes() and uu[:400].tobytes()==origin['actions'][:400].tobytes()
    rows.append(dict(directory=str(ff),execution=j,result=file_metadata(ff/'diagnostic/result.json'),config=f['config'],source=f['source'],reference=f['reference'],records=f['records'],total_native_transition_calls=f['total_native_transition_calls'],actual_hanging_start_episode_steps=f['actual_hanging_start_episode_steps']))
    passes=[]
    for label,screen_name,prefix_tape in [('solver','armature0.98_actual8s_solver_handoff_screen',d['tape']),('MP','armature0.98_actual8s_MP_handoff_screen',next(r['tape'] for r in f['records'] if r['affine']))]:
        sf=root/screen_name;sj=journal(sf);s=read(sf/'diagnostic/result.json');expected=[8.,9.,10.,11.,12.,13.] if label=='solver' else [8.]
        assert [r['handoff_seconds'] for r in s['records']]==expected
        pp=np.load(prefix_tape['path'])
        for r in s['records']:
            xx,uu,gg=tape(r);steps=round(r['handoff_seconds']/.02)
            assert xx[:steps+1].tobytes()==pp['states'][:steps+1].tobytes() and uu[:steps].tobytes()==pp['actions'][:steps].tobytes()
            if gg:passes.append((label,r))
        assert s['total_native_transition_calls']==sum(r['total_native_transition_calls'] for r in s['records'])
        rows.append(dict(directory=str(sf),execution=sj,result=file_metadata(sf/'diagnostic/result.json'),config=s['config'],records=s['records'],feedback_family=label,total_native_transition_calls=s['total_native_transition_calls'],actual_hanging_start_episode_steps=s['actual_hanging_start_episode_steps']))
    total=sum(r['total_native_transition_calls'] for r in rows);actual=sum(r['actual_hanging_start_episode_steps'] for r in rows)
    assert total<=718000
    payload=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),helper=file_metadata('scripts/audit_armature_route_increment.py'),passed=True,studies=rows,previous_batch=file_metadata(root/'verified_step_iterations.json'),total_new_native_transition_calls=int(total),actual_hanging_start_episode_steps=actual,combined_turn_native_transition_calls=previous['combined_turn_native_transition_calls']+int(total),combined_turn_actual_hanging_start_episode_steps=previous['combined_turn_actual_hanging_start_episode_steps']+actual,native_transition_calls_for_this_audit=0,canonical_release_evidence=False,not_solution=True,reserved_seeds_used=False,noisy_development_seeds_used=False,full_passing_handoffs=[dict(feedback=label,handoff_seconds=r['handoff_seconds']) for label,r in passes],prefix_actual_states_actions_gains_byte_preserved=True)
    if passes:
        label,r=min(passes,key=lambda v:v[1]['handoff_seconds']);assert label=='solver'
        tt=np.load(r['tape']['path']);h=round(r['handoff_seconds']/.02)
        gains=np.vstack([np.array(c['feedback_gains'])[:h],np.tile(-np.array(f['gain']),(700-h,1))])
        path=root/'armature0.98_passing_physical_initializer.json'
        dump_json(dict(selected_state=candidate['selected_state'],controller=dict(controls=tt['actions'][:700].tolist(),feedback_gains=gains.tolist(),coordinate_transform=np.eye(30).tolist(),continuous_angles=True,physical_shooting=True,capture_start_seconds=9.),search=dict(nominal_coordinate_states=tt['states'][:701].tolist()),source=d['candidate'],passing_tape=r['tape'],config=d['config'],seed=0,not_solution=True,initialization_only=True,selected_handoff_seconds=r['handoff_seconds'],feedback_family='saved_optimizer_feedback_then_MP100maintenance',scope='Actual700tick states/F32controls from a complete30spassing0.98altered14episode,withactualsuccessfulfeedbackbeforehandoff andnegativemaintenancegainafter. Only a physical initializer for the next continuation,notcanonical15or nextplant feasibility.'),path)
        payload['passing_physical_initializer']=file_metadata(path)
    dump_json(payload,root/'verified_fixed_prefix.json');print(json.dumps(dict(passed=True,total_calls=int(total),turn_calls=payload['combined_turn_native_transition_calls'],actual_steps=actual,passing=payload['full_passing_handoffs'])))

if __name__=='__main__':main()
