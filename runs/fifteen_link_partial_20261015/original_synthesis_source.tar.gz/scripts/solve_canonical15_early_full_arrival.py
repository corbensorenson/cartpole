"""Native earlier full-arrival repair with explicit bounded maintenance forecasts."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import dump_json,load_config
from gcartpole.evidence import file_metadata,utc_timestamp,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition,QuadraticTrajectoryCost
from gcartpole.sqrt_ilqr import square_root_tracking_gains
from gcartpole.modal_arrival import empirical_modal_factor,regularized_qr_step
from gcartpole.simulation import SimulationError
from scripts.refine_native_feedback_arrival import represented_state,raw_feedback
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix,scale_step_to_trust_region
from scripts.search_capture_sequence import fixed_state_cfg
read=lambda p:json.loads(Path(p).read_text())

def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--directory',required=True);a=p.parse_args();m=read(a.manifest);out=Path(a.directory);out.mkdir(exist_ok=False);(out/'tapes').mkdir();began=time.monotonic()
 for key in ('source','config','aligned','geometry','tracking_design','tracking_array','tracking_audit','source_audit','gain_source'):assert m[key]==file_metadata(m[key]['path'])
 assert read(m['tracking_audit']['path'])['passed'] and read(m['source_audit']['path'])['passed']
 s=read(m['source']['path']);base=read(s['source']['path']);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);start,end=m['start_step'],m['arrival_step'];h=end-start;tail=m['maintenance_steps'];assert (start,end,h,tail)==(291,375,84,50)
 U=np.asarray([q['action'] for q in s['result']['trajectory']],np.float32).astype(float);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in s['result']['trajectory']]])
 with np.load(m['tracking_array']['path']) as z:A=z['A'][:h];B=z['B'][:h];sf=z['stage_factor'];tf=z['terminal_factor'];same_reference=z['states'][:h+1]
 assert same_reference.tobytes()==X[start:end+1].tobytes();cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);assert cfg['env']['n_links']==15 and cfg['env']['frame_skip']==4 and cfg['env']['timestep']==.005 and base['seed']==m['nominal_seed']==20265100
 cost=QuadraticTrajectoryCost(stage_state=sf.T@sf,stage_factor=sf,terminal_state=tf.T@tf,terminal_factor=tf,control=base['controller']['control_cost'],rail_soft_limit=base['controller']['rail_soft_limit'],rail_limit=3.,rail_weight=base['controller']['rail_weight'],wrap_angles=False)
 env=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);env.reset(seed=20265100);native=MujocoTransition(env,np.eye(32),continuous_angles=True)
 K=square_root_tracking_gains(native,X[start:end+1],U[start:end],cost,regularization=m['tracking_regularization'],decimal_digits=100,mp_linearization=lambda i,x,u,ctx:(ctx.matrix(A[i].tolist()),ctx.matrix(B[i].tolist())))
 K80=square_root_tracking_gains(native,X[start:end+1],U[start:end],cost,regularization=m['tracking_regularization'],decimal_digits=80,mp_linearization=lambda i,x,u,ctx:(ctx.matrix(A[i].tolist()),ctx.matrix(B[i].tolist())))
 design=out/'earlier_tracking.npz';np.savez_compressed(design,A=A,B=B,stage_factor=sf,terminal_factor=tf,states=X[start:end+1],controls=U[start:end],gain100=K,gain80=K80)
 assert np.all(np.isfinite(K));tracking_equal=K.tobytes()==K80.tobytes()
 aligned=read(m['aligned']['path']);geometry=read(m['geometry']['path']);gain_label='moderately_separated_decay';gain=np.asarray(read(m['gain_source']['path'])['gain']);assert gain.tobytes()==np.asarray(aligned['gains'][gain_label]).tobytes()
 dd=next(q for q in aligned['designs'] if q['gain_label']==gain_label);targetrow=next(q for q in geometry['records'] if q['gain_label']==gain_label and q['kind']=='modal_mixture' and q['amplitude']==1e-4 and q['direction']==0 and q['sign']==1);assert targetrow['result']['local_gate_pass'] and targetrow['result']['all_samples_upright'];assert targetrow['result']['tape']==file_metadata(targetrow['result']['tape']['path']);target=np.asarray(targetrow['result']['initial_state']);ctx,modal,w,metric=empirical_modal_factor([q['rounded_direction'] for q in dd['directions']],n_links=15,time_scale=dd['normalization']['time_scale_seconds']);targetmp=ctx.matrix(target.tolist());basis=interpolation_matrix(m['knots'],h)
 payload=dict(status='running',generated_at=utc_timestamp(),runtime=runtime_metadata(),script=file_metadata(__file__),manifest=file_metadata(a.manifest),tracking=file_metadata(design),tracking_mp80_export_byte_equal=tracking_equal,tracking_maximum_export_difference=float(np.max(abs(K-K80))),gain=gain.tolist(),target=target.tolist(),target_tape=targetrow['result']['tape'],metric=metric,private_forecasts=[],records=[],actual_hanging_start_episode_steps=0,total_native_transition_calls=0,not_solution=True,canonical_release_evidence=False,noisy_development_seeds_used=False,reserved_seeds_used=False)
 actual_ticks=0
 def score(states,residual,completed):
  arrival=states[1:1+min(h,completed)];ang=np.abs(wrap_angle(np.cumsum(arrival[:,1:16],axis=1)));viol=float(np.sum((np.maximum(ang-.149,0)/.149)**2)+np.sum((np.maximum(abs(arrival[:,0])-3,0)/3)**2));safe=bool(len(arrival)==h and np.all(ang<.149) and np.all(abs(arrival[:,0])<=3));tails=states[1+h:1+completed];angles=np.abs(wrap_angle(np.cumsum(tails[:,1:16],axis=1))) if len(tails) else np.empty((0,15));ok=(np.max(angles,axis=1)<.149)&(np.abs(tails[:,0])<=3) if len(tails) else np.zeros(0,bool);bad=np.flatnonzero(~ok);prefix=int(bad[0]) if len(bad) else len(tails)
  return (0 if completed==h+tail and safe else 1,viol,-prefix,float(ctx.norm(residual)**2) if residual is not None else 1e100)
 def forecast(ff,label,factor,kind):
  states=[X[start].copy()];actions=[];raws=[];err=None
  try:
   for i in range(h+tail):
    state=states[-1];raw=float(ff[i])+float(K[i]@(state-X[start+i])) if i<h else raw_feedback(gain,state,15);u=float(np.float32(np.clip(raw,-1,1)));raws.append(raw);actions.append(u);states.append(native(state,u))
  except SimulationError as error:err=f'SimulationError: {error}'
  completed=len(states)-1;res=None
  if completed==h+tail:
   values=list(factor*(ctx.matrix(represented_state(states[h],15).tolist())-targetmp));values.append(ctx.mpf(float(m['endpoint_raw_weight']))*ctx.asinh(ctx.mpf(float(raw_feedback(gain,states[h],15)))))
   for offset in m['tail_sample_offsets']:
    values.extend(ctx.mpf(float(m['tail_physical_weight']))*v for v in w*ctx.matrix(represented_state(states[h+1+offset],15).tolist()));values.append(ctx.mpf(float(m['endpoint_raw_weight']))*ctx.asinh(ctx.mpf(float(raws[h+offset]))))
   res=ctx.matrix(values)
  ss=score(np.asarray(states),res,completed);path=out/'tapes'/f'private_{len(payload["private_forecasts"])+1:05d}.npz';np.savez_compressed(path,states=np.asarray(states),actions=np.asarray(actions),raws=np.asarray(raws),feedforward=np.asarray(ff));row=dict(index=len(payload['private_forecasts'])+1,label=label,kind=kind,tape=file_metadata(path),error=err,completed_steps=completed,attempted_steps=len(actions),score=list(ss),residual=None if res is None else [str(v) for v in res]);payload['private_forecasts'].append(row);return dict(states=np.asarray(states),actions=np.asarray(actions),feedforward=np.asarray(ff).copy(),raws=np.asarray(raws),score=ss,residual=res,record=row)
 def actual_episode(label,ff,selected):
  nonlocal actual_ticks
  actual=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);actual.reset(seed=20265100);xs=[initial.copy()];us=[];streak=longest=0;maxcart=0.;reason=None;info=None
  try:
   for tick in range(actual.max_steps):
    state=np.r_[actual.data.qpos,actual.data.qvel];raw=float(U[tick]) if tick<start else float(ff[tick-start])+float(K[tick-start]@(state-X[tick])) if tick<end else raw_feedback(gain,state,15);u=float(np.float32(np.clip(raw,-1,1)));_,_,terminated,truncated,info=actual.step([u]);actual_ticks+=1;x=np.r_[actual.data.qpos,actual.data.qvel];xs.append(x.copy());us.append(u)
    if tick<start:assert x.tobytes()==X[tick+1].tobytes()
    elif tick<end:assert x.tobytes()==selected['states'][tick-start+1].tobytes()
    angle=np.max(np.abs(wrap_angle(np.cumsum(x[1:16]))));streak=streak+1 if angle<.15 else 0;longest=max(longest,streak);maxcart=max(maxcart,abs(float(x[0])))
    if terminated or truncated:reason=info['termination_reason'];break
  finally:actual.close()
  for tick,u in enumerate(us):assert native(xs[tick],float(u)).tobytes()==xs[tick+1].tobytes()
  path=out/'tapes'/(label+'_actual.npz');np.savez_compressed(path,states=np.asarray(xs),actions=np.asarray(us));passed=len(us)==1500 and longest*.02>=5 and maxcart<=3 and reason=='time_limit' and not info['simulation_error'];row=dict(label=label,selected_forecast=selected['record']['tape'],selected_feedforward=ff.tolist(),tape=file_metadata(path),hold_seconds=longest*.02,maximum_cart=maxcart,actual_hanging_start_episode_steps=len(us),termination_reason=reason,full_nominal_gate_passed=passed,whole_actual_tape_byte_exact=True,selected_arrival_byte_exact=True);payload['records'].append(row);print(json.dumps(row),flush=True)
 def progress():
  payload.update(total_native_transition_calls=native.evaluations+actual_ticks,actual_hanging_start_episode_steps=actual_ticks);dump_json(payload,out/'result.progress.json')
 try:
  for i in range(end):assert native(X[i],float(U[i])).tobytes()==X[i+1].tobytes()
  baseline=forecast(U[start:end],'baseline',w,'baseline');assert baseline['states'][:h+1].tobytes()==X[start:end+1].tobytes();payload['baseline_forecast']=baseline['record'];actual_episode('baseline',U[start:end],baseline);progress()
  for label in m['arms']:
   factor=w if label=='physical' else modal;center=forecast(U[start:end],label,factor,'initial');rounds=[];status='iteration_limit'
   for iteration in range(m['iterations']):
    if center['residual'] is None:status='incomplete_center_forecast';break
    if native.evaluations+actual_ticks+(2*m['knots']+m['contraction_powers'])*(h+tail)+10000>m['execution_native_transition_ceiling']:status='inclusive_native_budget';break
    res=center['residual'];jac=ctx.zeros(res.rows,m['knots']);probes=[];invalid=False
    for column in range(m['knots']):
     pair=[]
     for sign in (1,-1):
      ff=np.clip(center['feedforward']+sign*m['epsilon']*basis[:,column],-1,1);q=forecast(ff,label,factor,f'derivative_{iteration}_{column}_{sign}');probes.append(q['record']['index']);pair.append(q)
     if any(q['residual'] is None for q in pair):invalid=True;break
     for rr in range(res.rows):jac[rr,column]=(pair[0]['residual'][rr]-pair[1]['residual'][rr])/(2*ctx.mpf(float(m['epsilon'])))
    if invalid:rounds.append(dict(iteration=iteration,derivative_failed=True,probes=probes));status='native_derivative_failed';break
    step,qrerror=regularized_qr_step(ctx,jac,res,m['regularization']);step=scale_step_to_trust_region(step,m['trust']);history=dict(iteration=iteration,center_index=center['record']['index'],probes=probes,jacobian=[[str(jac[i,j]) for j in range(jac.cols)] for i in range(jac.rows)],residual=[str(v) for v in res],step=step.tolist(),qr_error=qrerror,proposals=[],nominal_no_op_powers=[]);best=None
    for power in range(m['contraction_powers']):
     ff=np.clip(center['feedforward']+basis@(step/(2**power)),-1,1)
     if ff.tobytes()==center['feedforward'].tobytes():history['nominal_no_op_powers'].append(power);continue
     q=forecast(ff,label,factor,f'proposal_{iteration}_{power}');history['proposals'].append(dict(power=power,index=q['record']['index'],score=list(q['score'])))
     if q['score']<center['score'] and (best is None or q['score']<best['score']):best=q
    history.update(improved=best is not None,selected_index=None if best is None else best['record']['index']);rounds.append(history)
    if best is not None:center=best
    print(json.dumps(dict(label=label,iteration=iteration,improved=best is not None,score=list(center['score']),calls=native.evaluations+actual_ticks)),flush=True);payload['running_arm']=label;payload['running_rounds']=rounds;progress()
    if best is None:status='no_improving_tested_contraction';break
   proof=forecast(center['feedforward'],label,factor,'selected_proof');assert proof['states'].tobytes()==center['states'].tobytes() and proof['actions'].tobytes()==center['actions'].tobytes();assert proof['score']==center['score'];actual_episode(label,center['feedforward'],center);payload['records'][-1].update(status=status,rounds=rounds,selected_score=list(center['score']));progress()
  assert native.evaluations+actual_ticks<=m['execution_native_transition_ceiling'];payload.pop('running_arm',None);payload.pop('running_rounds',None);payload.update(status='finished',wall_seconds=time.monotonic()-began);progress();dump_json(payload,out/'result.json')
 except BaseException as error:payload.update(status='failed',error=f'{type(error).__name__}: {error}');progress();dump_json(payload,out/'result.failed.json');raise
 finally:env.close()
if __name__=='__main__':main()
