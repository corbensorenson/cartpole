"""Independently reconstruct R35 populations and legacy latent/command mismatch."""
import argparse,json
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix

def main():
 p=argparse.ArgumentParser();p.add_argument('--source-root',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(a.source_root);out=Path(a.out);out.mkdir(exist_ok=False);r=json.loads((root/'execution_corrected/diagnostic/result.json').read_text());m=json.loads((root/'manifest.json').read_text());source=json.loads(Path(m['source']['path']).read_text());U=np.asarray([q['action'] for q in source['result']['trajectory']]);rows=[];savedknots=[];savedelites=[]
 for arm in m['arms']:
  label,horizon=arm['label'],arm['horizon'];rng=np.random.default_rng(m['search_random_seed']);basis=interpolation_matrix(m['knots'],horizon);row=next(q for q in r['records'] if q['label']==label);decisions=json.loads(Path(row['decisions']['path']).read_text())['decisions'];warm=None
  for decision in decisions:
   tick=decision['tick']
   if warm is None:warm=U[tick:tick+horizon].copy() if tick+horizon<=len(U) else np.zeros(horizon)
   mean=np.interp(np.linspace(0,horizon-1,m['knots']),np.arange(horizon),warm);std=np.full(m['knots'],m['initial_std']);projection_error=float(np.max(abs(mean@basis.T-warm)));group=sorted([q for q in r['private_batches'] if q['label']==label and q['tick']==tick],key=lambda q:q['iteration']);assert len(group)==m['cem_iterations']
   for q in group:
    knots=rng.normal(mean,std,size=(m['candidates'],m['knots']));knots[0]=mean;knots[1]=0;knots[2]=-1;knots[3]=1;latent_commands=np.clip(knots@basis.T,-1,1).astype(np.float32).astype(float);commands=latent_commands.copy();commands[4]=warm;fixed=[4]
    if tick+horizon<=len(U):commands[5]=U[tick:tick+horizon];fixed.append(5)
    commands=np.clip(commands,-1,1).astype(np.float32).astype(float)
    assert q['tape']==file_metadata(q['tape']['path'])
    with np.load(q['tape']['path']) as z:
     assert commands.tobytes()==z['actions'].tobytes();scores=z['scores'].copy()
    order=sorted(range(len(scores)),key=lambda i:tuple(scores[i]));chosen=order[:m['elite_count']];wrong=[i for i in chosen if i in fixed and latent_commands[i].tobytes()!=commands[i].tobytes()]
    rows.append(dict(label=label,tick=tick,iteration=q['iteration'],batch=q['tape'],fixed_entries=fixed,selected_fixed_elites=wrong,maximum_fixed_latent_command_mismatch=float(max((np.max(abs(latent_commands[i]-commands[i])) for i in fixed),default=0)),initial_warm_interpolation_projection_error=projection_error,initial_projection_error_over_search_std=projection_error/m['initial_std']))
    savedknots.append(knots.copy());savedelites.append(chosen);elite=np.clip(knots[chosen],-1,1);mean=np.mean(elite,axis=0);std=np.maximum(np.std(elite,axis=0),m['minimum_std'])
   warm=np.r_[np.asarray(decision['selected_sequence'])[1:],decision['selected_sequence'][-1]]
 array=out/'reconstructed_populations.npz';np.savez_compressed(array,knots=np.asarray(savedknots),old_elite_indices=np.asarray(savedelites));summary=[]
 for arm in m['arms']:
  group=[q for q in rows if q['label']==arm['label']];summary.append(dict(label=arm['label'],batches=len(group),candidate_sequences=sum(q['label']==arm['label'] for q in r['private_batches'])*m['candidates'],batches_with_wrong_fixed_elites=sum(bool(q['selected_fixed_elites']) for q in group),total_wrong_fixed_elite_entries=sum(len(q['selected_fixed_elites']) for q in group),maximum_warm_interpolation_projection_error=max(q['initial_warm_interpolation_projection_error'] for q in group),maximum_projection_error_over_initial_std=max(q['initial_projection_error_over_search_std'] for q in group)))
 payload=dict(generated_at=utc_timestamp(),status='finished',passed=True,script=file_metadata(__file__),source_result=file_metadata(root/'execution_corrected/diagnostic/result.json'),source_manifest=file_metadata(root/'manifest.json'),frozen_legacy_actor=file_metadata(root/'execution_corrected/snapshot/scripts/solve_canonical15_fine_gain_demand_preview_corrected.py'),reconstructed_arrays=file_metadata(array),records=rows,summaries=summary,independent_reconstructed_batches=len(rows),independent_reconstructed_f32_candidate_sequences=len(rows)*m['candidates'],total_native_transition_calls=0,actual_hanging_start_episode_steps=0,canonical_release_evidence=False,not_solution=True,scope='AllhistoricalR35Gaussian populations/actions/oldeliteupdates independentlyreconstructed exactly, zero newphysics. Fixedseedactions werepairedwithdifferentlatentrows fordistributionupdates; sourceprojection displacement can dominatefine Gaussian std. These constrain interpretation of recentR33--R35searchfamilies, notanoverall15impossibility orsingle-cause certificate. Original tapes/results unchanged.');dump_json(payload,out/'result.json');print(summary,flush=True)
if __name__=='__main__':main()
