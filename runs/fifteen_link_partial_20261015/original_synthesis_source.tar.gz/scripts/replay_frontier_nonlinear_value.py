#!/usr/bin/env python
"""Physically test native next-step value corrections along a saved route.

Forecast states stay in a separate predictor. An exported static initializer
requires its own replay and every canonical gate before any release claim.
"""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json,load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,data_sha256,utc_timestamp,runtime_metadata
from gcartpole.ilqr import MujocoTransition,QuadraticTrajectoryCost
from gcartpole.nonlinear_value_control import select_nonlinear_value_action
from gcartpole.nonlinear_sequence_control import select_nonlinear_value_sequence,conditional_two_step_directions,conditional_sequence_directions,shifted_preview_candidates
from gcartpole.native_sequence_feasibility import restore_native_sequence
from gcartpole.route_value_inputs import verified_route_value_inputs
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.search_ilqr_capture import execute_controller
from scripts.search_fddp_capture import warm_start_diagnostics
from scripts.search_fddp_capture import capture_interval_cost
from gcartpole.sqrt_ilqr import _state_residual
from scripts.solve_frontier_capture_increment import validate_development_seeds


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',required=True);p.add_argument('--source',required=True)
    p.add_argument('--value-factors',required=True);p.add_argument('--capture-cache',required=True)
    p.add_argument('--directory',required=True);p.add_argument('--handoff-seconds',type=float,default=9.)
    p.add_argument('--start-seconds',type=float,default=3.)
    p.add_argument('--decimal-digits',type=int,default=80)
    p.add_argument('--grid-points',type=int,default=17);p.add_argument('--max-iterations',type=int,default=40)
    p.add_argument('--exact-reference-subtraction',action='store_true',
        help='Promote predicted/reference coordinates before MP subtraction.')
    p.add_argument('--center-refinement-objective',action='store_true',
        help='Subtract a fixed MP cost before scalar refinement converts to binary64.')
    p.add_argument('--preview-horizon-steps',type=int,default=1)
    p.add_argument('--truncate-preview-at-handoff',action='store_true',
        help='Shorten joint tracking previews at the actual maintenance switch; preserve legacy forecasts by default.')
    p.add_argument('--maximum-absolute-preview-angle',type=float,default=None,
        help='Optional hard absolute-link angle bound on joint native forecast states during correction.')
    p.add_argument('--include-zero-preview-sequence',action='store_true',
        help='Include an all-zero input sequence as an additional joint native feasibility seed.')
    p.add_argument('--shift-previous-preview-sequence',action='store_true',
        help='Include previous selected plan suffixes with zero/reference/last-input extensions as native candidates.')
    p.add_argument('--maximum-absolute-preview-rate',type=float,default=None,
        help='Optional hard maximum absolute-link angular velocity in joint forecasts (rad/s).')
    p.add_argument('--restore-preview-feasibility',action='store_true',
        help='When all value-search seeds fail, repair the full bounded native input sequence using physical violations.')
    p.add_argument('--coordinate-sweeps',type=int,default=3)
    p.add_argument('--condition-two-step-directions',action='store_true',
        help='Use verified nominal MP derivatives to jointly move coupled future controls.')
    p.add_argument('--condition-sequence-directions',action='store_true',
        help='Condition any multi-step control sequence using verified nominal cache or matching native finite derivatives.')
    args=p.parse_args();out=Path(args.directory)
    if args.maximum_absolute_preview_angle is not None and (
            not np.isfinite(args.maximum_absolute_preview_angle)
            or not 0<args.maximum_absolute_preview_angle<np.pi
            or args.preview_horizon_steps<2):
        raise ValueError('finite positive joint forecast angle bound below pi required')
    if args.include_zero_preview_sequence and args.preview_horizon_steps<2:
        raise ValueError('zero sequence seed requires a joint preview policy')
    if args.shift_previous_preview_sequence and args.preview_horizon_steps<2:
        raise ValueError('previous sequence warm start requires a joint preview policy')
    if args.maximum_absolute_preview_rate is not None and (
            not np.isfinite(args.maximum_absolute_preview_rate)
            or args.maximum_absolute_preview_rate<=0 or args.preview_horizon_steps<2):
        raise ValueError('finite positive joint forecast angular rate bound required')
    if args.restore_preview_feasibility and (args.maximum_absolute_preview_angle is None
            or args.maximum_absolute_preview_rate is None or args.preview_horizon_steps<2):
        raise ValueError('feasibility restoration requires joint angle and rate forecast bounds')
    if (out/'result.json').exists() or (out/'static_initializer.json').exists():raise FileExistsError(out)
    source,values,value_provenance=verified_route_value_inputs(args.source,args.value_factors,args.config);c=source['controller']
    cache=json.loads(Path(args.capture_cache).read_text())
    cfg=load_config(args.config);dt=cfg['env']['timestep']*cfg['env']['frame_skip'];steps=round(args.handoff_seconds/dt);start=round(args.start_seconds/dt)
    validate_development_seeds(cfg['env']['n_links'],source['seed'])
    maximum_preview_end=steps if args.truncate_preview_at_handoff else steps+args.preview_horizon_steps-1
    if (not c['continuous_angles'] or c['phase_adaptive'] or not 0<=start<steps<=len(c['controls'])
            or (steps==len(c['controls']) and not args.truncate_preview_at_handoff)
            or not np.isclose(start*dt,args.start_seconds) or not np.isclose(steps*dt,args.handoff_seconds)
            or args.preview_horizon_steps<1 or args.coordinate_sweeps<1
            or (args.condition_two_step_directions and args.preview_horizon_steps!=2)
            or (args.condition_sequence_directions and args.preview_horizon_steps<2)
            or (args.condition_sequence_directions and args.condition_two_step_directions)
            or maximum_preview_end>len(c['controls'])):
        raise ValueError('Fixed-time continuous route and aligned interior correction/handoff times required')
    source_meta=file_metadata(args.source);config_meta=file_metadata(args.config)
    if (cache['source']!=source_meta or cache['config']!=config_meta):
        raise ValueError('Value/capture inputs do not match source and config')
    controls=np.asarray(c['controls']);nodes=np.asarray(source['search']['nominal_coordinate_states']);gains=np.asarray(c['feedback_gains']);transform=np.asarray(c['coordinate_transform']);factors=np.asarray(values['value_factors'])
    physical_forecast_bounds=args.maximum_absolute_preview_angle is not None or args.maximum_absolute_preview_rate is not None
    if physical_forecast_bounds and not np.array_equal(transform,np.eye(nodes.shape[1])):
        raise ValueError('absolute angle forecast bounds require physical coordinate state inputs')
    def preview_admissible(predicted):
        from gcartpole.angles import wrap_angle
        n=cfg['env']['n_links']
        angle_ok=args.maximum_absolute_preview_angle is None or np.max(np.abs(wrap_angle(np.cumsum(predicted[1:n+1]))))<=args.maximum_absolute_preview_angle
        rate_ok=args.maximum_absolute_preview_rate is None or np.max(np.abs(np.cumsum(predicted[n+2:])))<=args.maximum_absolute_preview_rate
        return bool(angle_ok and rate_ok)
    def restoration_residual(predictions):
        from gcartpole.angles import wrap_angle
        n=cfg['env']['n_links'];angle_margin=args.maximum_absolute_preview_angle*(13/14)
        rate_margin=args.maximum_absolute_preview_rate*.8;cart_margin=cfg['env']['rail_limit']*.95
        angles=np.abs(wrap_angle(np.cumsum(predictions[:,1:n+1],axis=1)))
        rates=np.abs(np.cumsum(predictions[:,n+2:],axis=1))
        return np.r_[(np.maximum(angles-angle_margin,0.)/angle_margin).ravel(),
            (np.maximum(rates-rate_margin,0.)/rate_margin).ravel(),
            np.maximum(np.abs(predictions[:,0])-cart_margin,0.)/cart_margin]
    if (data_sha256(controls.tolist())!=values['controls_sha256'] or data_sha256(nodes.tolist())!=values['nominal_states_sha256']
            or not np.array_equal(transform,values['coordinate_transform']) or factors.shape!=(len(controls)+1,nodes.shape[1],nodes.shape[1])
            or not np.all(np.isfinite(factors))):raise ValueError('Value roots do not match route nodes/controls/basis')
    gain=np.asarray(cache['gain']);factor=np.asarray(source['lyapunov']['factor'])
    if data_sha256(gain.tolist())!=cache['gain_sha256'] or data_sha256(factor.tolist())!=source['lyapunov']['factor_sha256']:
        raise ValueError('Capture gain or value factor hash mismatch')
    cfg=fixed_state_cfg(cfg,source['selected_state'],30.)
    env=NLinkCartPoleEnv(cfg,progress=1.,seed=source['seed']);env.reset(seed=source['seed'])
    predictor=MujocoTransition(env,transform,continuous_angles=True);evaluations=0;fallbacks=0;improvements=0
    assert predictor.data is not env.data
    stage_factors=None
    direction_cache=direction_ctx=direction_predictor=None
    direction_linearizations={}
    if args.preview_horizon_steps>1:
        if not args.exact_reference_subtraction or not args.center_refinement_objective or args.decimal_digits<40:
            raise ValueError('sequence previews require exact MP subtraction and centered refinement')
        if c['split_angle_stage_weight'] or c['split_rate_stage_weight']:
            raise ValueError('sequence running-cost reconstruction does not support split penalties')
        mapping=np.asarray(c['normalized_cost_mapping']);nx=nodes.shape[1];half=nx//2
        base=QuadraticTrajectoryCost(stage_state=mapping.T@(c['stage_weight']*np.eye(nx))@mapping,
            terminal_state=np.eye(nx),control=c['control_cost'],rail_soft_limit=c['rail_soft_limit']*transform[0,0],
            rail_limit=env.rail_limit,rail_weight=c['rail_weight'],wrap_angles=False)
        identity=np.eye(nx);identity[1:half,1:half]*=c['terminal_angle_factor']
        identity[half,half]*=c['terminal_cart_velocity_factor'];identity[half+1:,half+1:]*=c['terminal_hinge_velocity_factor']
        capture=capture_interval_cost(base,identity,mapping,c['capture_stage_weight'],factor,c['capture_value_weight'],c['handoff_lyapunov'])
        if data_sha256(capture.stage_factor.tolist())!=c['capture_stage_factor_sha256']:
            raise ValueError('reconstructed capture running factor differs from source')
        capture_step=round(c['capture_start_seconds']/dt)
        stage_factors=[_state_residual(nodes[j],capture if j>=capture_step else base,env.n,terminal=False)[0]
                       for j in range(maximum_preview_end)]
        if args.condition_two_step_directions or args.condition_sequence_directions:
            import mpmath
            from gcartpole.planar_derivative_cache import PlanarDerivativeCache
            direction_ctx=mpmath.mp.clone();direction_ctx.dps=args.decimal_digits
            if values.get('derivative_cache') is not None:
                direction_cache=PlanarDerivativeCache(Path(values['derivative_cache']['path']).parent,
                    states=nodes,controls=controls,config_path=args.config,env=env,decimal_digits=args.decimal_digits)
            elif args.condition_two_step_directions:
                raise ValueError('legacy two-step directions require the verified MP derivative cache')
            else:
                from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
                if values['derivative_order'] not in (2,4):raise ValueError('unsupported native direction derivative order')
                direction_predictor=(FourthOrderMujocoTransition if values['derivative_order']==4 else MujocoTransition)(
                    env,transform,continuous_angles=True)
                assert direction_predictor.data is not env.data and direction_predictor.data is not predictor.data
    begun=time.monotonic();previous_plan=None;previous_plan_step=None
    restoration_calls=restoration_attempts=restoration_successes=0
    def direction_derivatives(index):
        if direction_cache is not None:
            return direction_cache(index,nodes[index],controls[index],direction_ctx)
        if index not in direction_linearizations:
            a,b=direction_predictor.linearize(nodes[index],float(controls[index]),
                state_epsilon=values['state_epsilon'],action_epsilon=values['action_epsilon'])
            direction_linearizations[index]=(direction_ctx.matrix(a.tolist()),direction_ctx.matrix(b.tolist()))
        return direction_linearizations[index]
    def selector(step,state,baseline):
        nonlocal evaluations,fallbacks,improvements,previous_plan,previous_plan_step
        nonlocal restoration_calls,restoration_attempts,restoration_successes
        if step<start:return baseline,None
        try:
            horizon=min(args.preview_horizon_steps,steps-step) if args.truncate_preview_at_handoff else args.preview_horizon_steps
            if horizon>1 or physical_forecast_bounds:
                baseline_plan=[float(np.float32(baseline))];current=state
                before=predictor.evaluations
                for offset in range(1,horizon):
                    current=predictor(current,baseline_plan[-1]);index=step+offset
                    baseline_plan.append(float(np.float32(np.clip(controls[index]+gains[index]@(current-nodes[index]),-1,1))))
                baseline_calls=predictor.evaluations-before
                directions=None
                if args.condition_two_step_directions and horizon==2:
                    _,b0=direction_derivatives(step)
                    a1,b1=direction_derivatives(step+1)
                    directions=conditional_two_step_directions(a1,b0,b1,stage_factors[step+1],factors[step+2],
                        values['control_cost']+values['regularization'],direction_ctx)
                elif args.condition_sequence_directions or args.condition_two_step_directions:
                    ab=[direction_derivatives(step+j) for j in range(horizon)]
                    directions=conditional_sequence_directions([a for a,b in ab],[b for a,b in ab],
                        stage_factors[step:step+horizon],factors[step+horizon],
                        values['control_cost']+values['regularization'],direction_ctx)
                candidates=[np.zeros(horizon)] if args.include_zero_preview_sequence else []
                shifted=[]
                if args.shift_previous_preview_sequence and previous_plan_step==step-1 and len(previous_plan)>1:
                    shifted=shifted_preview_candidates(previous_plan,int(horizon),
                        [0.,controls[step+horizon-1],previous_plan[-1]])
                    candidates.extend(shifted)
                def search(candidate_seeds):
                    return select_nonlinear_value_sequence(predictor,state,factors[step+horizon],baseline_plan,
                        reference_states=nodes[step:step+horizon+1],reference_actions=controls[step:step+horizon],
                        stage_factors=stage_factors[step:step+horizon],control_cost=values['control_cost']+values['regularization'],
                        rail_limit=env.rail_limit,decimal_digits=args.decimal_digits,grid_points=args.grid_points,
                        max_iterations=args.max_iterations,sweeps=args.coordinate_sweeps,directions=directions,
                        candidate_sequences=candidate_seeds,
                        preview_admissible=preview_admissible if physical_forecast_bounds else None)
                restored_info=None
                try:sequence,diag=search(candidates)
                except SimulationError:
                    if not args.restore_preview_feasibility:raise
                    restoration_attempts+=1;before_restore=predictor.evaluations
                    try:
                        restored,restored_info=restore_native_sequence(predictor,state,
                            [controls[step:step+horizon],shifted[0] if shifted else np.asarray(baseline_plan)],
                            reference_actions=controls[step:step+horizon],constraint_residual=restoration_residual,
                            admissible=lambda predictions:all(preview_admissible(z) and abs(z[0])<=env.rail_limit for z in predictions),
                            derivative_epsilon=1e-5,max_evaluations=20,action_regularization=1e-5)
                    finally:restoration_calls+=predictor.evaluations-before_restore
                    if restored is None:raise SimulationError('native sequence feasibility restoration found no admissible forecast')
                    restoration_successes+=1;sequence,diag=search([*candidates,restored])
                if restored_info is not None:diag['feasibility_restoration']={k:v for k,v in restored_info.items() if k!='selected_states'}
                diag['shifted_previous_plan_candidates']=len(shifted)
                previous_plan=sequence.copy();previous_plan_step=step
                action=float(sequence[0]);diag['selected_sequence']=sequence.tolist();diag['baseline_sequence']=baseline_plan
                diag['baseline_plan_predictor_evaluations']=baseline_calls
                diag['predictor_evaluations']+=baseline_calls
            else:
                action,diag=select_nonlinear_value_action(predictor,state,factors[step+1],baseline,
                    error_function=None if args.exact_reference_subtraction else lambda predicted:predicted-nodes[step+1],
                    reference_state=nodes[step+1] if args.exact_reference_subtraction else None,rail_limit=env.rail_limit,
                    grid_points=args.grid_points,max_iterations=args.max_iterations,
                    control_cost=values['control_cost']+values['regularization'],reference_action=float(controls[step]),
                    decimal_digits=args.decimal_digits,candidate_actions=[controls[step]],
                    center_refinement_objective=args.center_refinement_objective)
            evaluations+=diag['predictor_evaluations'];diag['baseline_action']=baseline
            diag['effective_preview_horizon_steps']=horizon
            improvements+=int(diag['improves_baseline'])
        except SimulationError as error:
            # Keep an executed failure record; the live environment enforces
            # rail/simulation termination. Never substitute a forecast state.
            action=float(np.float32(np.clip(baseline,-1,1)));fallbacks+=1
            diag=dict(fallback=True,error=str(error))
        if step%25==0:print(json.dumps(dict(step=step,time_seconds=step*dt,action=action,diagnostic=diag)),flush=True)
        return action,diag
    try:
        result=execute_controller(cfg,progress=1.,seed=source['seed'],controls=controls[:steps],nominal_states=nodes[:steps+1],feedback_gains=gains[:steps],
            gain=gain,lqr_scale=c['lqr_scale'],transform=transform,lyapunov=factor.T@factor,lyapunov_factor=factor,
            handoff_lyapunov=c['handoff_lyapunov'],handoff_cart_abs=c['handoff_cart_abs'],handoff_angle_abs=c['handoff_angle_abs'],
            handoff_cart_velocity_abs=c['handoff_cart_velocity_abs'],handoff_hinge_velocity_rms=c['handoff_hinge_velocity_rms'],
            tracking_mode='native_value_sequence_tracking' if args.preview_horizon_steps>1 else 'native_next_step_value_tracking',defer_handoff_until_horizon=True,continuous_angles=True,
            tracking_action_selector=selector)
        length=min(steps,result['length']);rows=result['trajectory'][:length]
        initial=np.r_[source['selected_state']['qpos'],source['selected_state']['qvel']]
        actual=np.vstack([initial,[r['qpos']+r['qvel'] for r in rows]])@transform.T
        delivered=np.asarray([r['action'] for r in rows],dtype=np.float32).astype(float)
        diagnostics=warm_start_diagnostics(predictor,actual[0],delivered,actual)
        if not diagnostics['is_exactly_feasible']:raise ValueError('Recorded physical prefix does not independently reproduce exactly')
        full_pass=bool(result['success'] and result['trajectory_integrity'] and result['termination_reason']=='time_limit' and result['length']==1500 and result['max_upright_streak_seconds']>=5 and result['max_cart_excursion']<=3)
        dump_json(dict(not_solution=True,benchmark_evidence=False,generated_at=utc_timestamp(),runtime=runtime_metadata(),parameters=vars(args),
            source=source_meta,config=config_meta,value_factors=file_metadata(args.value_factors),capture_cache=file_metadata(args.capture_cache),
            value_provenance=value_provenance,
            result=result,full_development_episode_passed=full_pass,physical_prefix_diagnostics=diagnostics,
            predictor_evaluations=evaluations,total_predictor_transition_calls=predictor.evaluations,fallbacks=fallbacks,
            total_preview_transition_calls=predictor.evaluations-length,
            failed_preview_transition_calls=predictor.evaluations-length-evaluations-restoration_calls,
            feasibility_restoration_transition_calls=restoration_calls,
            feasibility_restoration_attempts=restoration_attempts,feasibility_restoration_successes=restoration_successes,
            direction_design_transition_calls=0 if direction_predictor is None else direction_predictor.evaluations,
            total_native_transition_calls=predictor.evaluations+(0 if direction_predictor is None else direction_predictor.evaluations),
            improving_corrections=improvements,prefix_validation_transition_calls=length,wall_time_seconds=time.monotonic()-begun,
            executed_policy=dict(type='native_factored_value_sequence_tracking_then_lqr' if args.preview_horizon_steps>1 else 'native_next_step_factored_value_tracking_then_lqr',frequency_hz=1/dt,action_precision='float32',
                preview_horizon_steps=args.preview_horizon_steps,coordinate_sweeps=args.coordinate_sweeps,
                preview_truncated_at_handoff=args.truncate_preview_at_handoff,
                terminal_value_scope='Tracking value heuristic; no future maintenance certificate.',
                maximum_absolute_preview_angle=args.maximum_absolute_preview_angle,
                zero_preview_sequence_is_candidate=args.include_zero_preview_sequence,
                previous_preview_sequence_shifted=args.shift_previous_preview_sequence,
                maximum_absolute_preview_rate=args.maximum_absolute_preview_rate,
                native_feasibility_restoration=args.restore_preview_feasibility,
                restoration_recipe=None if not args.restore_preview_feasibility else dict(
                    angle_margin_fraction=13/14,rate_margin_fraction=.8,cart_margin_fraction=.95,
                    native_action_secant=1e-5,max_function_evaluations_per_seed=20,action_regularization=1e-5),
                angle_constraint_scope='All native forecast states during corrections, including the shortened final boundary preview; not a live state constraint guarantee.' if args.maximum_absolute_preview_angle is not None else None,
                conditional_nominal_directions=args.condition_two_step_directions or args.condition_sequence_directions,
                direction_derivative_cache=None if direction_cache is None else direction_cache.metadata,
                direction_native_derivative_recipe=None if direction_predictor is None else dict(
                    derivative_order=values['derivative_order'],state_epsilon=values['state_epsilon'],
                    action_epsilon=values['action_epsilon'],nominal_steps_cached=len(direction_linearizations)),
                cost_arithmetic_decimal_digits=args.decimal_digits,live_state_projection=False,static_initializer_is_not_executed_policy=True,
                predictor_data_is_separate=True,baseline_and_reference_are_candidates=True,
                reference_subtraction='MP promoted coordinates' if args.exact_reference_subtraction else 'legacy binary64 difference'),
            note='One exact-start development episode only. The emitted physical tape with inherited feedback is an offline initializer, not the policy that produced this episode. It requires independent static replay, exact rebuild and all noisy/reserved release gates.'),out/'result.json')
        initializer=dict(c);initializer.update(type='physical_nonlinear_preview_tape_static_feedback_initializer',controls=delivered.tolist(),feedback_gains=gains[:length].tolist(),horizon_steps=length,horizon_seconds=length*dt,final_trajectory_diagnostics=diagnostics,initialization_only=True,feedback_gains_are_distillation_initializer=True)
        initializer.pop('solver_feedback_gains',None)
        dump_json(dict(not_solution=True,initialization_only=True,seed=source['seed'],selected_state=source['selected_state'],controller=initializer,
            search=dict(nominal_coordinate_states=actual.tolist()),source=file_metadata(out/'result.json'),
            note='Exact physical prefix tape; inherited feedback must be independently tested about these new nodes.'),out/'static_initializer.json')
        print(json.dumps(dict(full_episode_passed=full_pass,length=result['length'],hold=result['max_upright_streak_seconds'],termination=result['termination_reason'],fallbacks=fallbacks)),flush=True)
    finally:env.close()
if __name__=='__main__':main()
