"""Traceable finite capture-prefix comparison; scientific PNG/PDF, zero new physics."""
import argparse,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp

def read(p):return json.loads(Path(p).read_text())
def main():
 p=argparse.ArgumentParser();p.add_argument('--directory',required=True);a=p.parse_args();root=Path(a.directory);audit=read(root/'verified.json');assert audit['passed'];out=root/'figures';out.mkdir(exist_ok=True);refs=[];holds={};defects={}
 for sec in [6,7,8]:
  holds[sec]=[];defects[sec]=[]
  for it in [8,16]:
   path=root/f'prefix{sec}/diagnostic/capture_suffix{it}/diagnostic/result.json';r=read(path);c=read(r['candidate']['path']);refs.append(file_metadata(path));holds[sec].append(r['result']['max_upright_streak_seconds']);defects[sec].append(c['controller']['final_trajectory_diagnostics']['maximum_dynamics_defect'])
 plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42});fig,ax=plt.subplots(1,2,figsize=(10.5,4.8));colors=['#205493','#bd713f','#477f64']
 for sec,col in zip([6,7,8],colors):
  ax[0].plot([8,16],holds[sec],'o-',label=f'{sec}s frozen prefix',color=col);ax[1].plot([8,16],defects[sec],'o-',color=col)
 ax[0].axhline(5,color='#a14848',ls='--',lw=1,label='Required hold (plus complete 30s)');ax[0].set(ylabel='Longest actual upright hold (s)',xlabel='Cumulative capture-repair iterations',xticks=[8,16],ylim=(0,5.5));ax[1].set(ylabel='Maximum stored model defect',xlabel='Cumulative capture-repair iterations',xticks=[8,16],yscale='log');ax[0].grid(axis='y',alpha=.15);ax[1].grid(axis='y',alpha=.15);ax[0].legend(frameon=False,fontsize=8,loc='upper left');fig.suptitle('Earlier intervention did not rescue capture at armature factor 0.95',fontsize=14);fig.text(.5,.02,'Same altered 14-link plant and source, seed 0, 50Hz/F32; actual prefixes preserved byte-for-byte. All available integer handoffs fail.\nSmall modeled defect does not certify native closed-loop capture. Mixed-state defect norm; finite optimizer budget.',ha='center',fontsize=8);fig.tight_layout(rect=(0,.12,1,.93));artifacts=[]
 for ext in ['png','pdf']:
  path=out/f'earlier_capture.{ext}';fig.savefig(path,dpi=180);artifacts.append(file_metadata(path))
 plt.close(fig);dump_json(dict(generated_at=utc_timestamp(),script=file_metadata(__file__),audit=file_metadata(root/'verified.json'),source_results=refs,artifacts=artifacts,native_transition_calls=0,scope='Actual hold and modeldefect after8/16; allfailed actualgates,notimpossibility/causalprecision.'),out/'figures.json');print(out/'earlier_capture.png')
if __name__=='__main__':main()
