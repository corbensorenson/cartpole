"""Matched local gain redesign on selected geometry-map plants and fifteen.

Isolates the upright maintenance component; no swing-route resynthesis claim.
"""
import argparse,copy,json,time
from pathlib import Path
import mpmath
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata,utc_timestamp
from gcartpole.ilqr import MujocoTransition
from gcartpole.lqr_design import high_precision_discrete_lqr
from gcartpole.upright_mechanics import upright_rk4_matrices
from scripts.make_lqr_checkpoint import absolute_angle_cost
from scripts.map_solved_chain_parameters import physical_metrics
from scripts.search_capture_sequence import fixed_state_cfg

WEIGHTS=dict(cart_position=.1,absolute_angle=10.,cart_velocity=.1,
             absolute_angular_velocity=5.,relative_angle=1.,relative_angular_velocity=.01)
CHOICES=((1.,0.),(.95,0.),(1.05,0.),(1.,.05),(1.,.15),(1.05,.15))


def local_episode(cfg,gain,direction,amplitude,path):
    n=cfg['env']['n_links'];start=amplitude*direction
    q=np.r_[0.,start[:n]];v=np.r_[0.,start[n:]]
    ecfg=fixed_state_cfg(cfg,dict(qpos=q.tolist(),qvel=v.tolist()),30.)
    env=NLinkCartPoleEnv(ecfg,progress=1.,seed=0);env.reset(seed=0)
    states=[np.r_[env.data.qpos.copy(),env.data.qvel.copy()]];actions=[];raw_max=0.;info={}
    ctx=mpmath.mp.clone();ctx.dps=100;kg=ctx.matrix([gain.tolist()])
    try:
        for i in range(env.max_steps):
            physical=states[-1].copy();physical[1:n+1]=wrap_angle(physical[1:n+1])
            raw=-float((kg*ctx.matrix(physical.tolist()))[0]);raw_max=max(raw_max,abs(raw))
            u=float(np.float32(np.clip(raw,-1,1)));actions.append(u)
            _,_,terminated,truncated,info=env.step([u])
            states.append(np.r_[env.data.qpos.copy(),env.data.qvel.copy()])
            if terminated or truncated:break
        passed=bool(info.get('success') and len(actions)==1500 and info['termination_reason']=='time_limit'
                    and env.max_cart_excursion<=3 and not info.get('simulation_error'))
        summary=dict(steps=len(actions),local_full_episode_gate_passed=passed,
            hold_seconds=float(info.get('max_upright_streak_seconds',0.)),
            maximum_cart=float(env.max_cart_excursion),termination_reason=info.get('termination_reason'),
            simulation_error=info.get('simulation_error'),raw_action_maximum=raw_max,
            delivered_saturation_ticks=int(np.sum(np.abs(actions)>=1)))
    finally:env.close()
    states=np.asarray(states);actions=np.asarray(actions)
    proofenv=NLinkCartPoleEnv(ecfg,progress=1.,seed=0);proofenv.reset(seed=0)
    native=MujocoTransition(proofenv,np.eye(2*(n+1)),continuous_angles=True)
    try:
        for i,u in enumerate(actions):assert native(states[i],float(u)).tobytes()==states[i+1].tobytes()
    finally:proofenv.close()
    np.savez_compressed(path,states=states,actions=actions)
    summary.update(independent_tape_replay_bytes_exact=True,tape=file_metadata(path),
                   actual_local_episode_steps=len(actions),independent_tape_replay_transition_calls=native.evaluations,
                   total_native_transition_calls=len(actions)+native.evaluations)
    return summary


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--map',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();out=Path(args.directory);out.mkdir(parents=True,exist_ok=False);(out/'tapes').mkdir();(out/'configs').mkdir()
    study=json.loads(Path(args.map).read_text());data=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),
        map=file_metadata(args.map),runtime=runtime_metadata(),records=[],counts=[7,10,14,15],choices=list(CHOICES),
        paired_direction_seed_rule='20261040+n; two uniform relative-angle/rate directions, same across geometry per count',
        amplitudes=[1e-5,1e-9,1e-13],weights=WEIGHTS,control_cost=1000.,
        actual_local_episode_steps=0,independent_tape_replay_transition_calls=0,total_native_transition_calls=0,
        native_transition_ceiling=432000,reserved_seeds_used=False,fifteen_noisy_development_seeds_used=False,
        actual_hanging_start_episode_steps=0,canonical_release_evidence=False,not_solution=True,
        scope='Selected7/10/14/15 plants: exact native local upright components with newly designed analytic MP100 Riccati gains at a shared cost. Rounded gain, MP100 dot product, native binary64 RK4 and delivered F32. Two paired physical directions and three amplitudes, full30s/inrail/5s gate plus byte tape replay. No swing-route resynthesis, basin certificate or count promotion. Fixed0.1kg added hub mass for positive diameter,1kg rods; nohub comparison is mass-confounded.')
    began=time.monotonic()
    for n in data['counts']:
        directions=np.random.default_rng(20261040+n).uniform(-1,1,(2,2*n))
        for s,d in CHOICES:
            if n!=15:
                source=next(r for r in study['records'] if (r['n_links'],r['length_scale'],r['hub_diameter_m'])==(n,s,d))
                assert source['config']==file_metadata(source['config']['path']);cfg=load_config(source['config']['path'])
            else:
                cfg=load_config('configs/swingup15_uniform.yaml');cfg['env']['total_length']=3*s
                if d:cfg['env'].update(joint_hub_radius=d/2,joint_hub_mass=.1/n,joint_hub_half_width=.0125)
            tag=f'n{n}_l{s:.2f}_d{d:.2f}';cpath=out/'configs'/f'{tag}.json';dump_json(cfg,cpath)
            row=dict(n_links=n,length_scale=s,hub_diameter_m=d,config=file_metadata(cpath),mechanics=physical_metrics(cfg),
                     paired_directions=directions.tolist(),episodes=[]);data['records'].append(row)
            env=NLinkCartPoleEnv(cfg,progress=1.,seed=0);env.reset(seed=0)
            try:
                a,b,_=upright_rk4_matrices(env,decimal_digits=100);t=time.monotonic()
                k,_,diag=high_precision_discrete_lqr(a.tolist(),b.tolist(),absolute_angle_cost(n,WEIGHTS),[[1000.]],
                    decimal_digits=100,preserve_input_precision=True)
                row.update(gain=k.ravel().tolist(),design_diagnostics=diag,design_wall_seconds=time.monotonic()-t)
            finally:env.close()
            for amplitude in data['amplitudes']:
                for i,direction in enumerate(directions):
                    e=local_episode(cfg,k.ravel(),direction,amplitude,out/'tapes'/f'{tag}_a{amplitude:.0e}_v{i}.npz')
                    e.update(amplitude=amplitude,direction_index=i);row['episodes'].append(e)
                    for key in ('actual_local_episode_steps','independent_tape_replay_transition_calls','total_native_transition_calls'):data[key]+=e[key]
                    assert data['total_native_transition_calls']<=data['native_transition_ceiling']
            dump_json(data,out/'result.progress.json')
            print(json.dumps(dict(n=n,length_scale=s,diameter=d,gain_norm=diag['gain_norm'],
                passes=[e['local_full_episode_gate_passed'] for e in row['episodes']],
                holds=[e['hold_seconds'] for e in row['episodes']],calls=data['total_native_transition_calls'])),flush=True)
    data['wall_seconds']=time.monotonic()-began;dump_json(data,out/'result.json')


if __name__=='__main__':main()
