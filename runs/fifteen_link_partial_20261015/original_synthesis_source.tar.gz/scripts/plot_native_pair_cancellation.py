#!/usr/bin/env python
"""Export matched native pair/individual forecast responses for paper evidence."""
import argparse,json,time
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();out=Path(args.directory);out.mkdir(parents=True,exist_ok=True)
    if (out/'result.json').exists():raise FileExistsError(out)
    source=json.loads(Path(args.source).read_text());began=time.monotonic();times=np.asarray(source['nominal_times_seconds'])
    expected=['center','first_only','second_only','paired']
    if [r['variant'] for r in source['records']]!=expected or not source['paired_forecast_byte_identical']:raise ValueError('matched verified four-case audit required')
    labels=['Unchanged failed plan','First correction alone','Second correction alone','Both corrections']
    colors=['#657687','#bf4a50','#c98a30','#187b62']
    fig,ax=plt.subplots(figsize=(9.3,5.0));fig.subplots_adjust(left=.105,right=.97,bottom=.22,top=.83)
    for record,label,color in zip(source['records'],labels,colors):
        states=np.asarray(record['states']);n=states.shape[1]//2-1
        measured=np.max(np.abs(wrap_angle(np.cumsum(states[:,1:n+1],axis=1))),axis=1)
        if measured.tobytes()!=np.asarray(record['maximum_angle_series']).tobytes():raise ValueError('plot data differs from measured native states')
        ax.plot(times,measured,label=label,color=color,lw=2.2 if record['variant']=='paired' else 1.7)
    ax.axhline(.14,color='#202831',ls='--',lw=1,label='Planner bound 0.14 rad')
    ax.axhline(.15,color='#929ba4',ls=':',lw=1.3,label='Canonical angle gate 0.15 rad')
    ax.set(xlabel='Nominal time from hanging start (s)',ylabel='Maximum absolute link angle (rad)',
        xlim=(times[0],times[-1]+.07),ylim=(0,.60))
    ax.grid(alpha=.18);ax.spines[['top','right']].set_visible(False);ax.legend(loc='upper left',ncol=2,fontsize=9,frameon=False)
    fig.suptitle('Coordinated float32 input corrections',x=.105,y=.95,ha='left',fontsize=17,fontweight='bold')
    fig.text(.105,.875,'15-link native physics · same cold-source state and 56-tick horizon',fontsize=10,color='#4a5967')
    changes=source['delivered_action_changes'];offsets=source['selected_offsets_ulps'];indices=source['selected_indices']
    fig.text(.105,.10,f'Input {indices[0]}: {offsets[0]:+d} grid steps ({changes[0]:+.3e})   |   Input {indices[1]}: {offsets[1]:+d} grid steps ({changes[1]:+.3e})',fontsize=9)
    fig.text(.105,.055,'Forecast diagnostic; paired states independently replay byte for byte. No episode or record claimed.',fontsize=9,color='#4a5967')
    paths=[]
    for suffix in ('png','pdf','svg'):
        path=out/f'comparison.{suffix}';fig.savefig(path,dpi=220,facecolor='white');paths.append(path)
    plt.close(fig)
    dump_json(dict(not_solution=True,canonical_release_evidence=False,source=file_metadata(args.source),
        figure_files=[file_metadata(path) for path in paths],native_transition_calls=0,actual_episode_steps=0,
        wall_seconds=time.monotonic()-began,scope='Scientific figure of matched independently measured native forecast responses;no new simulation or behavior validation.'),out/'result.json')


if __name__=='__main__':main()
