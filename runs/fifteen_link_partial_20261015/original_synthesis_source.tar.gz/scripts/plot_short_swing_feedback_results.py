"""Scientific comparison of finite failed repair/gain alternatives; zero new physics."""
import argparse,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.config import dump_json

def read(p):return json.loads(Path(p).read_text())
def main():
 p=argparse.ArgumentParser();p.add_argument('--directory',required=True);a=p.parse_args();root=Path(a.directory);audit=read(root/'verified.json');gain_audit=read('runs/preserved_gain_followup_20261004/verified.json');assert audit['passed'] and gain_audit['passed'];out=root/'figures';out.mkdir(exist_ok=True)
 values=[];defects=[];refs=[]
 for h in (14,6,8):
  folder=Path('runs/armature_closer_source_20261004/target0.95/diagnostic') if h==14 else root/f'target0.95_{h}s_corrected2/diagnostic'
  source=folder/'full_repair16/diagnostic/result.json';feedback=folder/'native_feedback16/diagnostic/result.json';r=read(source);f=read(feedback);c=read(r['candidate']['path']);refs.extend([file_metadata(source),file_metadata(feedback)])
  vals=[r['result']['length']*.02,*[x['result']['length']*.02 for x in f['records']],*[x['result']['length']*.02 for x in gain_audit['records'] if x['tag']==f'horizon{h}']];assert len(vals)==6;values.append(vals);defects.append(c['controller']['final_trajectory_diagnostics']['maximum_dynamics_defect'])
 labels=['Saved solver','MP pure','MP affine','Source gain 1','Source gain 0.25','No tracking'];colors=['#205493','#b56b3a','#7d567e','#287b61','#7c9c4c','#87919c'];plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42});fig,axes=plt.subplots(1,2,figsize=(11.4,5.6),gridspec_kw={'width_ratios':[1.7,1]});x=np.arange(3);width=.13
 for i,(label,color) in enumerate(zip(labels,colors)):axes[0].bar(x+(i-2.5)*width,np.array(values)[:,i],width,label=label,color=color)
 axes[0].set(xticks=x,xticklabels=['14s reference','6s reference','8s reference'],ylabel='Actual time before failure (s)',ylim=(0,float(np.max(values))*1.12),title='Longer survival does not give capture');axes[0].grid(axis='y',alpha=.15)
 axes[1].bar(x,defects,color='#205493',width=.55);axes[1].set(xticks=x,xticklabels=['14s','6s','8s'],yscale='log',ylabel='Maximum stored model defect',title='After 8+8 restarted repairs');axes[1].grid(axis='y',alpha=.15)
 for i,v in enumerate(defects):axes[1].text(i,v*1.2,f'{v:.2e}',ha='center',fontsize=9)
 axes[1].set_ylim(min(defects)*.4,max(defects)*3);handles,ls=axes[0].get_legend_handles_labels();fig.legend(handles,ls,loc='lower center',bbox_to_anchor=(.5,.08),ncol=3,frameon=False,fontsize=9)
 fig.suptitle('Shorter references and reused feedback did not recover the native swing',fontsize=14,y=.99)
 fig.text(.5,.013,'Same 0.95 altered14 plant, 0.97 source, seed0, 50Hz/F32. Every shown target episode has zero upright hold.\nShort references use capture from5.82s; 14s uses9s. Model defects mix state components. These are finite task/controller comparisons.',ha='center',fontsize=8.6);fig.tight_layout(rect=(0,.22,1,.92));paths=[out/'short_swing_and_feedback.png',out/'short_swing_and_feedback.pdf']
 for path in paths:fig.savefig(path,dpi=180)
 plt.close(fig);dump_json(dict(generated_at=utc_timestamp(),script=file_metadata(__file__),audits=[file_metadata(root/'verified.json'),file_metadata('runs/preserved_gain_followup_20261004/verified.json')],source_results=refs,artifacts=[file_metadata(p) for p in paths],native_transition_calls=0,scope='Durations are actualfailure times, notsuccess proxies. Alltargethold0; horizon/capture timing confounded; no impossibilityorprecisioncausality.'),out/'figures.json');print(paths[0])
if __name__=='__main__':main()
