"""Frozen-tape Welch window sensitivity, with independent FFT checks; zero physics."""
import argparse,csv,json
from pathlib import Path
import numpy as np
import mujoco
from scipy.signal import get_window
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.trajectory_spectra import welch_summary,force_motion_coherence,projected_modal_rates


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--memo',required=True);p.add_argument('--directory',required=True);a=p.parse_args()
    source=json.loads(Path(a.source).read_text());out=Path(a.directory);out.mkdir(exist_ok=False,parents=True);(out/'spectra').mkdir()
    def checked(r):assert file_metadata(r['path'])==r,r['path']
    def forbidden(*args,**kwargs):raise AssertionError('native integration prohibited in stored-tape analysis')
    original=mujoco.mj_step;mujoco.mj_step=forbidden
    result=dict(generated_at=utc_timestamp(),status='running',script=file_metadata(__file__),source=file_metadata(a.source),memo=file_metadata(a.memo),records=[],traces=[],total_native_transition_calls=0,actual_hanging_start_episode_steps=0,native_transition_ceiling=0,canonical_release_evidence=False,not_solution=True,reserved_seeds_used=False,noisy_development_seeds_used=False,scope='Same22stored50Hzactualtapes/modebases/phases, fixed2/4/8sWelch windows; no shortened windows for unavailable phases. Descriptive sampling/window sensitivity only, no causal resonance or new solve.')
    try:
        modes={m['tag']:m for m in source['mode_catalog']};max_error=0.;compared=0
        for trace in source['traces']:
            checked(trace['tape']);checked(trace['spectra']);raw=np.load(trace['tape']['path']);old=np.load(trace['spectra']['path']);n=trace['n_links'];m=modes[trace['basis_tag']]['modes'];V=np.array(m['relative_shapes']);M=np.array(m['joint_mass_matrix'])
            force=raw['actions']*80.;modal=projected_modal_rates(raw['states'][:-1],n,V.T@M)
            assert np.array_equal(force,old['force_N']) and np.array_equal(modal,old['modal_rates'])
            phases=[dict(label='whole',start_tick=0,end_tick=len(force)),*trace['phases']];arrays={};indices=[]
            for phase in phases:
                lo,hi=phase['start_tick'],phase['end_tick'];signals=np.column_stack([force[lo:hi],modal[lo:hi]])
                for seconds in (2.,4.,8.):
                    size=round(seconds*50);row=dict(tag=trace['tag'],n_links=n,phase=phase['label'],start_tick=lo,end_tick=hi,phase_samples=hi-lo,window_seconds=seconds,requested_segment_samples=size,estimated=hi-lo>=size)
                    indices.append(len(result['records']));result['records'].append(row)
                    if hi-lo<size:row['reason']='phase shorter than requested window; not shortened or extrapolated';continue
                    prefix=f"{phase['label']}_w{int(seconds)}";specs=[welch_summary(signals[:,i],50.,window_seconds=seconds) for i in range(n+1)]
                    frequencies=specs[0]['frequencies_hz'];psds=np.column_stack([s['psd'] for s in specs]);arrays[prefix+'_frequency_hz']=frequencies;arrays[prefix+'_psd']=psds
                    window=get_window('hann',size,fftbins=True);blocks=np.stack([signals[start:start+size] for start in range(0,len(signals)-size+1,size//2)])
                    blocks=(blocks-blocks.mean(axis=1,keepdims=True))*window[None,:,None];manual=np.abs(np.fft.rfft(blocks,axis=1))**2/(50*np.sum(window**2));manual[:,1:-1]*=2;manual=manual.mean(axis=0)
                    scale=np.max(abs(psds),axis=0);residual=np.max(abs(manual-psds),axis=0);error=np.divide(residual,scale,out=np.zeros_like(residual),where=scale>0);assert np.max(error)<2e-12;max_error=max(max_error,float(np.max(error)));compared+=n+1
                    row.update(force={k:v for k,v in specs[0].items() if k not in ('frequencies_hz','psd')},modes=[])
                    for i in range(n):
                        coherence=force_motion_coherence(signals[:,0],signals[:,i+1],50.,window_seconds=seconds)
                        record=dict(index=i,spectrum={k:v for k,v in specs[i+1].items() if k not in ('frequencies_hz','psd')},coherence_estimated=coherence['estimated'],coherence_segments=coherence['segments'])
                        if coherence['estimated']:
                            arrays[prefix+f'_m{i}_coherence']=coherence['coherence'];arrays[prefix+f'_m{i}_cross_phase']=coherence['cross_phase_radians']
                        else:record['coherence_reason']=coherence['reason']
                        row['modes'].append(record)
            path=out/'spectra'/f"{trace['tag']}.npz";np.savez_compressed(path,**arrays);result['traces'].append(dict(tag=trace['tag'],tape=trace['tape'],original_signals=trace['spectra'],spectra=file_metadata(path),record_indices=indices))
        csv_path=out/'phase_windows.csv'
        with csv_path.open('w') as f:
            fields=['tag','n_links','phase','window_seconds','phase_samples','estimated','segments','covered_samples','unused_tail_samples','bin_spacing_hz','peak_frequency_hz','peak_bin_fraction'];writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
            for r in result['records']:writer.writerow({k:r.get(k,r.get('force',{}).get(k)) for k in fields})
        full=[r for r in result['records'] if r['phase']=='whole' and r['tag'].startswith('canonical')];peak_grid={}
        for tag in sorted({r['tag'] for r in full},key=lambda v:int(v.removeprefix('canonical'))):peak_grid[tag]={str(int(r['window_seconds'])):r['force']['peak_frequency_hz'] for r in full if r['tag']==tag}
        result.update(status='finished',trace_count=len(result['traces']),record_count=len(result['records']),estimated_window_records=sum(r['estimated'] for r in result['records']),unavailable_window_records=sum(not r['estimated'] for r in result['records']),independent_fft_spectra_checked=compared,maximum_fft_relative_peak_scaled_residual=max_error,canonical_whole_force_peak_hz_by_window=peak_grid,metrics=file_metadata(csv_path),all_stored_input_signals_byte_reproduced=True,interpretation='Window length changes frequency bins and averaging/coverage. Nonstationary dominant-bin shifts do not establish a physical fundamental or harmonic law. Longer windows are unavailable in short phases and can lack enough independent segments for coherence. Native substep alias tests remain pending.')
    except BaseException as e:result.update(status='failed',error=f'{type(e).__name__}: {e}');raise
    finally:mujoco.mj_step=original;dump_json(result,out/'result.json')
    print(json.dumps({k:result[k] for k in ('status','trace_count','record_count','estimated_window_records','unavailable_window_records','independent_fft_spectra_checked','maximum_fft_relative_peak_scaled_residual','canonical_whole_force_peak_hz_by_window')}))

if __name__=='__main__':main()
