"""Independent replay of every R31 private tape, including exact failed calls."""
import argparse,json,re
from pathlib import Path
import numpy as np,mujoco
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.simulation import SimulationError
from gcartpole.evidence import file_metadata,utc_timestamp
from scripts.search_capture_sequence import fixed_state_cfg

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(a.root);out=Path(a.out);out.mkdir(exist_ok=False)
 r=json.loads((root/'execution/diagnostic/result.json').read_text());account=json.loads((root/'execution/inclusive_accounting.json').read_text());source=json.loads(Path(r['source']['path']).read_text());base=json.loads(Path(source['source']['path']).read_text())
 gain=np.asarray(r['gain']);K=np.asarray(r['tracking_gains']);design=json.loads(Path(r['tracking_design']['path']).read_text());ref=np.load(design['array']['path'])['states'];start,end=r['parameters']['start_step'],r['parameters']['arrival_step'];U=np.asarray([x['action'] for x in source['result']['trajectory'][:end]],float);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[x['qpos']+x['qvel'] for x in source['result']['trajectory'][:end]]])
 count=[0];original=mujoco.mj_step;env=None;failures=[];outcomes=[];completed=0;attempts=0
 payload=dict(generated_at=utc_timestamp(),status='running',script=file_metadata(__file__),source_result=file_metadata(root/'execution/diagnostic/result.json'),source_accounting=file_metadata(root/'execution/inclusive_accounting.json'),actual_hanging_start_episode_steps=0,canonical_release_evidence=False,not_solution=True,native_transition_ceiling=190000)
 def counted(model,data,*args,**kw):
  n=int(kw.get('nstep',args[0] if args else 1));assert count[0]+n<=760000;count[0]+=n;return original(model,data,*args,**kw)
 mujoco.mj_step=counted
 def check_tape(q,kind):
  nonlocal completed,attempts
  meta=q['tape'];assert meta==file_metadata(meta['path'])
  with np.load(meta['path']) as z:
   states,actions=z['states'],z['actions'];assert states.shape==(len(actions)+1,32) and len(actions)==q['completed_steps'];assert np.all(np.isfinite(states));assert actions.tobytes()==actions.astype(np.float32).astype(float).tobytes();assert np.max(abs(actions),initial=0)<=1
   if kind=='forecast':
    ff=z['nominal_feedforward'];is_arr=q['arrival_feedback'];assert states[0].tobytes()==X[start if is_arr else 0].tobytes()
    get=lambda i:float(np.float32(np.clip(float(ff[i])+(float(K[i]@(states[i]-ref[i])) if is_arr else 0),-1,1)))
   else:
    def get(i):
     x=states[i].copy();x[1:16]=wrap_angle(x[1:16]);return float(np.float32(np.clip(-float(gain@x),-1,1)))
    raws=np.asarray([-float(gain@np.r_[s[0],wrap_angle(s[1:16]),s[16:]]) for s in states[:-1]])
    assert raws.tobytes()==z['raws'].tobytes()
   for i,u in enumerate(actions):
    assert get(i)==u;attempts+=1;assert native(states[i],float(u)).tobytes()==states[i+1].tobytes();completed+=1
   if q['error']:
    failed_input=get(len(actions));before=count[0];attempts+=1
    try:native(states[-1],failed_input)
    except SimulationError as e:assert f'SimulationError: {e}'==q['error']
    else:raise AssertionError('Archived private failure did not reproduce')
    substeps=count[0]-before;assert substeps==int(re.search(r'physics step (\d+)',q['error']).group(1));failures.append(dict(kind=kind,index=q['index'],error=q['error'],failed_input_reconstructed_from_frozen_controller=failed_input,executed_substeps=substeps,tape=meta))
 try:
  cfg=fixed_state_cfg(load_config(r['config']['path']),base['selected_state'],30.);env=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);env.reset(seed=20265100);native=MujocoTransition(env,np.eye(32),continuous_angles=True)
  for q in r['private_forecasts']:check_tape(q,'forecast')
  for q in r['private_tails']:check_tape(q,'tail')
  private_substeps=count[0];private_attempts=attempts
  for row in r['records']:
   assert row['tape']==file_metadata(row['tape']['path'])
   with np.load(row['tape']['path']) as z:
    x,u=z['states'],z['actions'];assert x[0].tobytes()==initial.tobytes() and x[:start+1].tobytes()==X[:start+1].tobytes();assert x[start+1:end+1].tobytes()==np.asarray(row['selected_states']).tobytes();ff=np.asarray(row['selected_feedforward_controls']);assert u[start:end].tobytes()==np.asarray(row['selected_actual_arrival_actions']).tobytes()
    streak=longest=0
    for i,v in enumerate(u):
     if i<start:command=U[i]
     elif i<end:command=float(np.float32(np.clip(ff[i-start]+K[i-start]@(x[i]-ref[i-start]),-1,1)))
     else:
      s=x[i].copy();s[1:16]=wrap_angle(s[1:16]);command=float(np.float32(np.clip(-float(gain@s),-1,1)))
     assert command==v;assert native(x[i],float(v)).tobytes()==x[i+1].tobytes();attempts+=1;completed+=1
     phi=float(np.max(np.abs(wrap_angle(np.cumsum(x[i+1,1:16])))));streak=streak+1 if phi<.15 else 0;longest=max(longest,streak)
    assert longest*.02==row['actual_hold_seconds'];assert len(u)==row['actual_hanging_start_episode_steps'];assert float(np.max(abs(x[1:,0])))==row['actual_maximum_cart'];assert len(u)<1500 and not row['full_nominal_gate_passed'];assert abs(x[-1,0])>3
    outcomes.append(dict(label=row['label'],ticks=len(u),hold_seconds=longest*.02,termination='rail_violation',full_gate_passed=False,arrival_maximum_angle=row['endpoint_maximum_angle'],arrival_absolute_rate_rms=row['endpoint_absolute_rate_rms'],arrival_raw_feedback_action=row['endpoint_raw_feedback_action'],next_tick_maximum_angle=float(np.max(abs(wrap_angle(np.cumsum(x[end+1,1:16]))))),selected_score=row['final_score'],source_score=row['initial_score'],tape=row['tape']))
  actual=r['actual_hanging_start_episode_steps'];assert attempts+actual==r['total_native_transition_calls'];assert private_substeps+8*actual==account['native_physics_substeps'];assert account['total_native_transition_calls']==account['native_physics_substeps']/4
  assert len(failures)==6 and sum(q['executed_substeps'] for q in failures)==13
  payload.update(status='finished',passed=True,independent_native_private_tapes=len(r['private_forecasts'])+len(r['private_tails']),private_completed_transitions=private_attempts-6,private_attempted_transitions=private_attempts,private_executed_substeps=private_substeps,reproduced_private_failures=failures,outcomes=outcomes,original_attempted_transition_calls=r['total_native_transition_calls'],original_executed_substeps=account['native_physics_substeps'],original_transition_equivalents=account['total_native_transition_calls'],scope='Every private completed state/action and six failed native transitions independently reproduce, including controller-reconstructed failed inputs absent from original tapes. Both complete recorded actual episodes/actions/gates independently checked. Lowlevel executed substeps and attempted transitions kept distinct. No robustness/release claim.')
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}');raise
 finally:
  if env:env.close()
  mujoco.mj_step=original;payload.update(total_native_transition_calls=count[0]/4,native_physics_substeps=count[0],attempted_transition_calls=attempts,finished_at=utc_timestamp());dump_json(payload,out/'result.json');print(json.dumps({k:v for k,v in payload.items() if k not in ('reproduced_private_failures','outcomes')}),flush=True)
if __name__=='__main__':main()
