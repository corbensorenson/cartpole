#!/usr/bin/env python
"""Matched Clarabel numerical settings on one unchanged archived physical QP."""
import argparse,json,time
from pathlib import Path
import clarabel,numpy as np
from scipy import sparse
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.qp_conditioning import FactoredStepWhitening

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--qp-directory',required=True);p.add_argument('--directory',required=True);args=p.parse_args()
 source=Path(args.qp_directory);out=Path(args.directory)
 if (out/'result.json').exists():raise FileExistsError(out)
 out.mkdir(parents=True,exist_ok=True)
 meta=json.loads((source/'metadata.json').read_text())
 for item in meta['files']:
  if file_metadata(item['path'])!=item:raise ValueError('archived QP bytes changed')
 h=sparse.load_npz(source/'hessian.npz');c=sparse.load_npz(source/'constraints.npz');v=np.load(source/'vectors.npz');f=np.load(source/'cost_factors.npz')
 q,lo,hi=v['gradient'],v['lower'],v['upper'];m,n,r=meta['state_values'],meta['physical_step_variables'],meta['residual_rows']
 conditioner=FactoredStepWhitening([f[str(i)] for i in range(meta['steps'])],v['control_costs'],meta['objective_scale'])
 start=time.monotonic();hp,qp,cp,lower,upper,mapping=conditioner.transform(h,q,c,lo,hi,r);setup=time.monotonic()-start
 equal=np.isfinite(lower)&np.isfinite(upper)&(lower==upper);high=~equal&np.isfinite(upper);low=~equal&np.isfinite(lower)
 matrix=sparse.vstack([cp[equal],cp[high],-cp[low]],format='csc');rhs=np.r_[upper[equal],upper[high],-lower[low]]
 cones=[clarabel.ZeroConeT(int(equal.sum())),clarabel.NonnegativeConeT(int(high.sum()+low.sum()))]
 tight=dict(iterative_refinement_reltol=1e-15,iterative_refinement_abstol=1e-15,iterative_refinement_max_iter=30)
 cases=[('native_defaults',{}),('tight_refinement',tight),('static1e12_tight_refinement',dict(tight,static_regularization_constant=1e-12)),('no_static_tight_refinement',dict(tight,static_regularization_enable=False))]
 records=[]
 for label,updates in cases:
  settings=clarabel.DefaultSettings();settings.verbose=False;settings.max_threads=1;settings.max_iter=meta['max_iterations']
  settings.tol_gap_abs=settings.tol_gap_rel=settings.tol_feas=meta['tolerance'];settings.reduced_tol_gap_abs=settings.reduced_tol_gap_rel=settings.reduced_tol_feas=meta['tolerance']
  for key,value in updates.items():setattr(settings,key,value)
  began=time.monotonic();solver=clarabel.DefaultSolver(sparse.triu(hp).tocsc(),qp,matrix,rhs,cones,settings);s=solver.solve();seconds=time.monotonic()-began
  physical=np.asarray(mapping@np.asarray(s.x)).ravel()
  def violation(mat,vec,a,b):
   y=mat[a:b]@vec;return float(max(0.,np.max(lo[a:b]-y),np.max(y-hi[a:b])))
  groups={'dynamics':(0,m),'cost_residual':(m,m+r),'physical_step_box':(m+r,m+r+n),'capture_node':(m+r+n,c.shape[0]-2*m),'slack_nonnegative':(c.shape[0]-2*m,c.shape[0])}
  filename=out/(label+'_solution.npz');np.savez_compressed(filename,solver_coordinates=np.asarray(s.x),physical_coordinates=physical)
  record=dict(label=label,settings_overrides=updates,all_settings=str(settings),native_status=str(s.status),native_usable=str(s.status) in('Solved','AlmostSolved'),native_iterations=s.iterations,native_primal_residual=s.r_prim,native_dual_residual=s.r_dual,solve_seconds=seconds,original_coordinate_bound_violation={name:violation(c,physical,*bounds) for name,bounds in groups.items()},original_qp_objective=float(.5*physical@(h@physical)+q@physical),maximum_physical_state_step=float(np.max(np.abs(physical[:m]))),maximum_physical_control_step=float(np.max(np.abs(physical[m:n]))),solution=file_metadata(filename))
  records.append(record);dump_json(dict(not_solution=True,records=records),out/'progress.json');print(json.dumps({k:v for k,v in record.items() if k not in('all_settings','solution')}),flush=True)
 dump_json(dict(not_solution=True,benchmark_evidence=False,physical_replay_performed=False,runtime=runtime_metadata(),qp_metadata=file_metadata(source/'metadata.json'),parameters=vars(args),conditioning_setup_seconds=setup,conditioning=conditioner.diagnostics(),records=records,scope='Identical frozen QP, cost-block MP100 coordinates, objective, bounds and convergence tolerance. Native solver settings only. No status override, native transition or physical feasibility certificate.'),out/'result.json')
if __name__=='__main__':main()
