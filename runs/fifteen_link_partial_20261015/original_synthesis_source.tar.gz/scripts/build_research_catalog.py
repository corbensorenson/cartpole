"""Inventory saved research without replaying physics or upgrading claims.

All non-snapshot run artifacts are inventoried. Journal counts are not unique
experiment counts: wrappers can contain nested stage journals. Explicit memo
links are checked against exact bytes; historical scientific coverage is not
silently inferred from file presence or a reported journal status.
"""
import csv
import json
import os
from collections import Counter
from pathlib import Path
from gcartpole.evidence import file_metadata, utc_timestamp

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED = {'snapshot', '.git', 'node_modules', '__pycache__', '.pytest_cache'}


def verify_references(value, root=ROOT):
    seen = set()
    errors = []
    relocated = []
    # Supplemental registries preserve the literal bytes of older registries
    # already bound by historical memos.
    bindings = {}
    for registry_path in sorted((root/'research/sources').glob('code_reference_relocations*.json')):
        for b in json.loads(registry_path.read_text())['bindings']:
            key = (b['original']['path'], b['original']['bytes'], b['original']['sha256'])
            assert key not in bindings or bindings[key] == b['preserved'], 'Conflicting archive bindings'
            bindings[key] = b['preserved']
    def preserved_code(v, label):
        # Relocation is deliberately limited to Python code, never outcome data.
        if not str(v['path']).endswith('.py'):
            return False
        saved = bindings.get((v['path'], v['bytes'], v['sha256']))
        if saved is None:
            return False
        p = root/saved['path']
        if (not p.is_file() or (saved['bytes'], saved['sha256']) != (v['bytes'], v['sha256'])
                or file_metadata(p)['sha256'] != saved['sha256'] or p.stat().st_size != saved['bytes']):
            return False
        relocated.append(dict(original=v, preserved=saved, label=label,
            scope='Exact historical code bytes verified at explicit immutable snapshot; not current livecode.'))
        return True
    def preserved_checkpoint(v, label):
        # A plan may freeze the mutable progress checkpoint as background.
        # This exception never redirects scientific outcomes or configurations.
        if v['path'] != 'tmp/fifteen_native_followup_current_state.json':
            return False
        registry_path = root/'research/sources/checkpoint_reference_relocations.json'
        if not registry_path.is_file():
            return False
        for b in json.loads(registry_path.read_text())['bindings']:
            if b['original'] != v:
                continue
            saved = b['preserved']; journal = b['execution']
            jp = root/journal['path']; sp = root/saved['path']
            expected = str(Path(journal['path']).parent/'snapshot'/v['path'])
            if (saved['path'] != expected or not jp.is_file() or not sp.is_file()
                    or (file_metadata(jp)['bytes'], file_metadata(jp)['sha256']) != (journal['bytes'], journal['sha256'])
                    or (file_metadata(sp)['bytes'], file_metadata(sp)['sha256']) != (saved['bytes'], saved['sha256'])
                    or (saved['bytes'], saved['sha256']) != (v['bytes'], v['sha256'])):
                return False
            if {'path': v['path'], 'sha256': v['sha256']} not in read(jp)['frozen_inputs']:
                return False
            relocated.append(dict(original=v, preserved=saved, label=label,
                scope='Exact mutable bookkeeping checkpoint frozen as an explicit input; current progress state is not claimed.'))
            return True
        return False
    def visit(v, label):
        if isinstance(v, dict):
            if all(k in v for k in ('path', 'bytes', 'sha256')):
                identity = (v['path'], v['sha256'])
                if identity in seen:
                    return
                seen.add(identity)
                path = root / v['path']
                if not path.is_file() and not (preserved_code(v, label) or preserved_checkpoint(v, label)):
                    errors.append(dict(label=label, path=v['path'], reason='missing'))
                elif path.is_file():
                    actual = file_metadata(path)
                    if ((actual['bytes'], actual['sha256']) != (v['bytes'], v['sha256'])
                            and not (preserved_code(v, label) or preserved_checkpoint(v, label))):
                        errors.append(dict(label=label, path=v['path'], reason='changed_bytes'))
            else:
                for key, item in v.items():
                    visit(item, label+'.'+key)
        elif isinstance(v, list):
            for i, item in enumerate(v):
                visit(item, label+f'[{i}]')
    visit(value, 'research')
    return dict(references_checked=len(seen), passed=not errors, errors=errors,
                historical_code_bindings_verified=relocated)


def read(path):
    return json.loads(path.read_text())


def normalize_recorded_memo(memo, root=ROOT):
    """Index flat recorded notes without changing their already frozen bytes.

    Planning fields must exist in the original record. Result notes can inherit
    them only from a hash-verified plan. Claim scope comes from a verified
    manifest/audit or the record itself; this does not invent preregistration.
    """
    result = dict(memo)
    if memo.get('hypotheses') and memo.get('claim_scope'):
        return result
    def referenced(ref):
        assert verify_references([ref],root=root)['passed']
        return read(root/ref['path'])
    if memo.get('prospective_plan'):
        plan = normalize_recorded_memo(referenced(memo['prospective_plan']),root)
        result['hypotheses'] = plan['hypotheses']
        if not memo.get('claim_scope'):
            assert memo.get('verification')
            result['claim_scope'] = referenced(memo['verification'])['scope']
    elif memo.get('record_kind') == 'prospective_correction_after_prephysics_failure':
        assert memo.get('question') and memo.get('correction') and memo.get('claim_scope')
        result['hypotheses'] = [dict(question=memo['question'], method=memo['correction'],
            evidence=memo.get('evidence',[]), scope=memo['claim_scope'])]
    else:
        assert memo.get('record_kind') == 'prospective'
        for key in ('question','prediction','held_parameters','changed_parameters','seed_policy','budget','recording'):
            assert memo.get(key),key
        result['hypotheses'] = [{key:memo[key] for key in
            ('question','prediction','held_parameters','changed_parameters','seed_policy','budget','recording')}]
        if not memo.get('claim_scope'):
            assert memo.get('evidence')
            result['claim_scope'] = referenced(memo['evidence'][0])['scope']
    assert result['hypotheses'] and result['claim_scope']
    result['inventory_schema_normalization'] = 'Read-only flat-note adapter; original file bytes and chronology preserved. No new scientific validation.'
    return result


def registered_memo_adapter(path, memo, root=ROOT):
    """Use an explicit exact-byte inventory adapter; chronology stays original."""
    key=str(path.relative_to(root))
    matches=[]
    for registry in sorted((root/'research/sources').glob('memo_inventory_adapters*.json')):
        for entry in read(registry)['entries']:
            if entry['original']['path'] == key:
                actual=file_metadata(path);actual['path']=key
                assert entry['original'] == actual, 'Memo adapter source hash mismatch'
                normalized=entry['normalized']
                assert all(normalized.get(k)==v for k,v in memo.items() if k != 'record_kind'), 'Adapter altered original memo fields'
                assert normalized['original_record_kind']==memo['record_kind']
                assert normalized.get('hypotheses') and normalized.get('claim_scope')
                matches.append(normalized)
    assert len(matches)<=1, 'Conflicting memo inventory adapters'
    return matches[0] if matches else None


def main():
    out = ROOT/'runs/research_catalog'
    out.mkdir(parents=True, exist_ok=True)
    ledger_path = ROOT/'runs/frontier_campaign_20261001/inverse_increment_experiments.json'
    ledger = read(ledger_path)
    registered = {str(Path(r['directory'])) for r in ledger['experiments']}
    pipelines = {str(Path(r['directory'])) for r in ledger.get('pipeline_executions', [])}
    memos = []
    for path in sorted((ROOT/'research/memos').glob('*.json')):
        memo = read(path)
        # Preserve the already frozen correction memo's explicit chronology.
        # It describes a prospective correction after a zero-physics failure.
        adapted = registered_memo_adapter(path, memo)
        indexed = adapted if adapted is not None else memo
        assert indexed['record_kind'] in ('retrospective', 'prospective', 'amendment',
                                       'prospective_correction_after_prephysics_failure')
        normalized = adapted if adapted is not None else normalize_recorded_memo(memo)
        memos.append(dict(file=file_metadata(path.relative_to(ROOT)), content=normalized))
    coverage_path = ROOT/'research/coverage.json'
    coverage = read(coverage_path)
    explicit = dict(memos=memos, coverage=coverage)
    checked = verify_references(explicit)
    archive_path = ROOT/'research/sources/archive_manifest.json'
    archive = read(archive_path)
    archives = verify_references([r['archive'] for r in archive['files']])
    for pair in archive['files']:
        assert pair['original']['sha256'] == pair['archive']['sha256']
    checked['archive_references_checked'] = archives['references_checked']
    checked['errors'] += archives['errors']
    checked['passed'] = not checked['errors']
    journals = []
    artifacts = []
    for folder, directories, names in os.walk(ROOT/'runs'):
        directories[:] = sorted(d for d in directories if d not in EXCLUDED
            and Path(folder)/d != out)
        directory = Path(folder)
        for name in sorted(names):
            path = directory/name
            if not path.is_file():
                continue
            relative = path.relative_to(ROOT)
            stat = path.stat()
            artifacts.append((str(relative), stat.st_size, path.suffix,
                'file_inventory_only; content not validated'))
            if name != 'execution.json':
                continue
            metadata = file_metadata(relative)
            entry = dict(execution=metadata, directory=str(directory.relative_to(ROOT)),
                scientific_validation='not_established_by_inventory', live_process_status='not_checked')
            try:
                record = read(path)
                entry.update(reported_status=record.get('status', 'missing'),
                    returncode=record.get('returncode'), started_at=record.get('started_at'),
                    finished_at=record.get('finished_at'), command=record.get('command'),
                    wall_time_seconds=record.get('wall_time_seconds'),
                    frozen_inputs_count=len(record.get('frozen_inputs', [])),
                    ledger_exact_directory_match=entry['directory'] in registered)
            except (ValueError, TypeError) as error:
                entry.update(reported_status='unreadable_journal', error=f'{type(error).__name__}: {error}')
            journals.append(entry)
    journal_dirs = {r['directory'] for r in journals}
    for row in journals:
        parents = [str(p) for p in Path(row['directory']).parents]
        row['ancestor_journal_directories'] = [p for p in parents if p in journal_dirs]
        row['nested_stage_or_wrapper'] = bool(row['ancestor_journal_directories'])
        row['ancestor_current_ledger_directories'] = [p for p in parents if p in registered]
        row['current_ledger_relation'] = ('exact' if row['ledger_exact_directory_match'] else
            'registered_pipeline_not_additive' if row['directory'] in pipelines else
            'registered_parent' if row['ancestor_current_ledger_directories'] else 'no_directory_relation')
    gaps = dict(
        reported_running_or_missing_terminal_status=[r['execution'] for r in journals
            if r['reported_status'] in ('running', 'missing', 'unreadable_journal')],
        journals_without_frozen_input_list=[r['execution'] for r in journals if not r.get('frozen_inputs_count')],
        journals_without_exact_current_ledger_directory=[r['execution'] for r in journals
            if not r.get('ledger_exact_directory_match')],
        journals_without_exact_or_parent_current_ledger_directory=[r['execution'] for r in journals
            if r['current_ledger_relation'] == 'no_directory_relation'],
        explanation='Recording gaps are inspection targets, not automatically missing experiments or live processes. '
            'Nested wrappers, historical runs and independent analysis can lack exact current-ledger matches. '
            'Explicit pipeline parents are registered separately and are not additive primitive experiments. '
            'This inventory cannot recover experiments that were never saved.')
    csv_path = out/'artifact_inventory.csv'
    with csv_path.open('w', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['path', 'bytes', 'extension', 'validation_scope'])
        writer.writerows(artifacts)
    catalog = dict(schema_version=1, generated_at=utc_timestamp(), script=file_metadata(__file__),
        scope='Inventory and explicit memo-source integrity; no physics, no historical claim promotion, '
            'no cumulative compute total across nested or overlapping records.',
        ledger=file_metadata(ledger_path.relative_to(ROOT)), current_ledger_rows=len(ledger['experiments']),
        separately_registered_pipeline_parents=len(pipelines),
        execution_journal_records=len(journals), saved_run_artifact_files=len(artifacts),
        journal_status_counts=dict(Counter(r['reported_status'] for r in journals)),
        artifact_inventory=file_metadata(csv_path.relative_to(ROOT)), journals=journals,
        memos=memos, coverage=coverage, archive_manifest=file_metadata(archive_path.relative_to(ROOT)),
        recording_gaps=gaps, native_transition_calls=0)
    catalog_path = out/'catalog.json'
    catalog_path.write_text(json.dumps(catalog, indent=2)+'\n')
    verification = dict(generated_at=utc_timestamp(), **checked, catalog=file_metadata(catalog_path.relative_to(ROOT)),
        execution_journal_records=len(journals), saved_run_artifact_files=len(artifacts),
        native_transition_calls=0, scope='Explicit memo and archive byte/hash checks plus inventory generation. '
            'Journal status does not establish process liveness or scientific correctness.')
    (out/'verification.json').write_text(json.dumps(verification, indent=2)+'\n')
    print(json.dumps(verification))
    raise SystemExit(not verification['passed'])


if __name__ == '__main__':
    main()
