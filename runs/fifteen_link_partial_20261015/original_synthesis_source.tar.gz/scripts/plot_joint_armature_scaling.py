#!/usr/bin/env python
"""Plot source-bound local inertia/cadence diagnostics without new physics."""
import argparse,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--armature',required=True);p.add_argument('--cadence',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    arm=json.loads(Path(args.armature).read_text());cad=json.loads(Path(args.cadence).read_text())
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    fig,axes=plt.subplots(2,2,figsize=(10.5,7.4),layout='constrained')
    for n,color in [(15,'#243a50'),(20,'#43816a')]:
        rows=[next(r for r in arm['records'] if r['n_links']==n and r['armature_factor']==factor) for factor in [1.,.1,0.]]
        axes[0,0].semilogy(range(3),[r['design_diagnostics']['gain_norm'] for r in rows],'-o',color=color,label=f'{n} links')
        axes[0,1].plot(range(3),[r['fastest_hanging_frequency_hz'] for r in rows],'-o',color=color)
        axes[1,0].plot(range(3),[sum(c['successes'] for c in r['local_capture'].values()) for r in rows],'-o',color=color)
    for ax in [axes[0,0],axes[0,1],axes[1,0]]:ax.set(xticks=[0,1,2],xticklabels=['100%','10%','0%'],xlabel='Added joint inertia (% of original)')
    rows=[next(r for r in arm['records'] if r['n_links']==20 and r['armature_factor']==0.),*cad['records']]
    axes[1,1].semilogy([50.,*[r['control_hz'] for r in cad['records']]],
        [r['design_diagnostics']['gain_norm'] for r in rows],'-o',color='#b75735')
    axes[0,0].set(ylabel='Upright LQR gain norm',title='Lower inertia reduces this LQR gain');axes[0,0].legend()
    axes[0,1].set(ylabel='Fastest hanging mode (Hz)',title='The plant also becomes faster')
    axes[1,0].set(ylabel='Full native local passes / 12',ylim=(-.5,12.5),yticks=[0,4,8,12],title='Passes occur only at 1e−13 perturbations')
    axes[1,1].set(xlabel='Control rate (Hz)',ylabel='20-link, zero-inertia gain norm',xticks=[50,100,200],title='Higher rate increases this gain; 0/12 pass at each')
    for ax in axes.flat:ax.grid(axis='y',alpha=.18)
    fig.suptitle('Added joint inertia and correction rate affect different limits',fontsize=14)
    fig.supxlabel('1 kg / 3 m rods; same force, rail, damping and 0.005 s native timestep. MP100 design.\n'
        'Paired local perturbations 1e−5, 1e−9, 1e−13; invalid episodes count as failures.\n'
        'Auxiliary components only: no hanging-start solve or canonical count promotion.',fontsize=9)
    out.mkdir(parents=True,exist_ok=True);outputs=[]
    for suffix in ['png','pdf','svg']:
        path=out/f'comparison.{suffix}';fig.savefig(path,dpi=180);outputs.append(file_metadata(path))
    plt.close(fig);dump_json(dict(not_solution=True,canonical_release_evidence=False,
        sources=[file_metadata(args.armature),file_metadata(args.cadence)],outputs=outputs,native_transition_calls=0,
        scope='Source-bound static scientific plots; no new model or episode evaluation.'),out/'result.json')


if __name__=='__main__':main()
