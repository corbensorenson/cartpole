#!/usr/bin/env python
"""Audit early native errors and MP projections about a fixed periodic orbit."""
import argparse,json
from pathlib import Path
from time import monotonic
import mpmath
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',required=True);p.add_argument('--source',required=True)
    p.add_argument('--out',required=True);p.add_argument('--steps',type=int,default=20)
    p.add_argument('--episode-index',type=int,default=1)
    args=p.parse_args();out=Path(args.out)
    if out.exists():raise FileExistsError(out)
    src=json.loads(Path(args.source).read_text());cfg=load_config(args.config)
    if src['config']!=file_metadata(args.config) or args.steps<1 or not 0<=args.episode_index<len(src['episode_results']):
        raise ValueError('fixed input/config, existing episode and positive steps required')
    nodes=np.asarray(src['search']['nominal_coordinate_states']);u=np.asarray(src['controller']['controls'])
    k=np.asarray(src['controller']['feedback_gains']);nx=nodes.shape[1];n=cfg['env']['n_links']
    if not np.array_equal(src['controller']['coordinate_transform'],np.eye(nx)):
        raise ValueError('physical coordinates required')
    episode=src['episode_results'][args.episode_index]
    initial=np.r_[episode['selected_state']['qpos'],episode['selected_state']['qvel']]
    env=NLinkCartPoleEnv(cfg,progress=1.,seed=0);env.reset(seed=0)
    transition=FourthOrderMujocoTransition(env,np.eye(nx),continuous_angles=True)
    ctx=mpmath.mp.clone();ctx.dps=100
    matrix=lambda a:ctx.matrix(np.asarray(a,dtype=float).tolist())
    peak=lambda a:float(max(abs(v) for v in a))
    rows=[];max_gap=0.;begun=monotonic()
    try:
        for step,row in enumerate(episode['trajectory'][:args.steps]):
            phase=step%len(u);following=(phase+1)%len(u)
            actual=initial if step==0 else np.array(episode['trajectory'][step-1]['qpos']+episode['trajectory'][step-1]['qvel'])
            after=np.array(row['qpos']+row['qvel'])
            delivered=float(row['action']);predicted=transition(actual,delivered)
            native_gap=float(np.max(np.abs(predicted-after)));max_gap=max(max_gap,native_gap)
            if native_gap!=0:raise ValueError('native saved step is not exact')
            a,b=transition.linearize(nodes[phase],float(u[phase]),state_epsilon=.0002,action_epsilon=.0005)
            nominal_next=transition(nodes[phase],float(u[phase]))
            error=matrix(actual)-matrix(nodes[phase]);next_error=matrix(after)-matrix(nodes[phase+1])
            defect=matrix(nominal_next)-matrix(nodes[phase+1]);gain=matrix(k[phase][None]);next_gain=matrix(k[following][None])
            linear=matrix(a)*error+matrix(b)*(ctx.mpf(delivered)-ctx.mpf(float(u[phase])))
            remainder=next_error-defect-linear
            rows.append(dict(step=step,time_seconds=row['time'],native_recorded_step_gap=native_gap,
                initial_error_peak=peak(error),next_error_peak=peak(next_error),nominal_defect_peak=peak(defect),
                linear_response_peak=peak(linear),native_remainder_peak=peak(remainder),
                normalized_reference_action=float(u[phase]),delivered_action=delivered,
                raw_feedback_action=float(ctx.mpf(float(u[phase]))+(gain*error)[0]),
                next_feedback_from_nominal_defect=float((next_gain*defect)[0]),
                next_feedback_from_local_remainder=float((next_gain*remainder)[0]),
                next_feedback_from_linear_response=float((next_gain*linear)[0]),
                next_feedback_total_error=float((next_gain*next_error)[0]),
                maximum_absolute_angle=float(row['max_absolute_angle']),cart=float(row['qpos'][0])))
    finally:env.close()
    dump_json(dict(not_solution=True,benchmark_evidence=False,source=file_metadata(args.source),config=file_metadata(args.config),
        runtime=runtime_metadata(),parameters=vars(args),maximum_native_recorded_step_gap=max_gap,
        rows=rows,transition_calls=transition.evaluations,wall_time_seconds=monotonic()-begun,
        scope='Early recorded native steps, exact saved-state replay. The local remainder includes nonlinear and derivative/numerical discrepancies; projected terms describe correlated saved data, not independent counterfactuals. MP100 subtraction/projection does not change the binary64 native map or derivative inputs. No late-horizon causality or robustness certificate.'),out)
    print(json.dumps(dict(native_replay_gap=max_gap,rows=len(rows),largest_projected_remainder=max(abs(row['next_feedback_from_local_remainder']) for row in rows))))
if __name__=='__main__':main()
