"""Native MP100 finite-horizon feedback about the physically executed arrival."""
import argparse
from pathlib import Path
import mujoco,numpy as np
from gcartpole.config import dump_json,load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.ilqr import QuadraticTrajectoryCost
from gcartpole.sqrt_ilqr import square_root_tracking_gains
from scripts.audit_armature_route_increment import read,checked
from scripts.search_capture_sequence import fixed_state_cfg

def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--directory',required=True);a=p.parse_args()
 m=read(a.manifest)
 for k in ('source','controller_source','config','oracle_audit'):checked(m[k])
 assert read(m['oracle_audit']['path'])['passed']
 saved=read(m['source']['path']);base=read(m['controller_source']['path']);c=base['controller'];start,end=m['start_step'],m['arrival_step']
 initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in saved['result']['trajectory'][:end]]])
 U=np.asarray([q['action'] for q in saved['result']['trajectory'][:end]],np.float32).astype(float)
 D=np.asarray(c['normalized_cost_mapping']);weights=np.ones(32);weights[1:16]*=c['terminal_angle_factor'];weights[16]*=c['terminal_cart_velocity_factor'];weights[17:]*=c['terminal_hinge_velocity_factor']
 tf=np.diag(np.sqrt(c['terminal_state_weight']*weights))@D;sf=np.sqrt(c['stage_weight'])*D
 assert c['terminal_weight']==c['terminal_cart_weight']==c['terminal_cart_velocity_weight']==0 and c['split_link'] is None
 cost=QuadraticTrajectoryCost(stage_state=sf.T@sf,stage_factor=sf,terminal_state=tf.T@tf,terminal_factor=tf,control=c['control_cost'],
  rail_soft_limit=c['rail_soft_limit'],rail_limit=3.,rail_weight=c['rail_weight'],wrap_angles=False)
 out=Path(a.directory);out.mkdir(exist_ok=False);count=[0];original=mujoco.mj_step;env=None
 payload=dict(generated_at=utc_timestamp(),status='running',script=file_metadata(__file__),manifest=file_metadata(a.manifest),
  config=m['config'],source=m['source'],native_transition_ceiling=m['design_native_transition_ceiling'],actual_hanging_start_episode_steps=0,not_solution=True,canonical_release_evidence=False,
  source_capture_value_weight_omitted=c['capture_value_weight'],feedback_cost_scope='Declared physical stage/terminal tracking Hessians; historical source capture-value term omitted. Comparison to inherited feedback is a joint design change.')
 def counted(model,data,*args,**kw):
  n=int(kw.get('nstep',args[0] if args else 1))
  if count[0]+n>4*m['design_native_transition_ceiling']:raise RuntimeError('native design ceiling')
  count[0]+=n;return original(model,data,*args,**kw)
 mujoco.mj_step=counted
 try:
  cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.)
  env=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);env.reset(seed=20265100)
  native=FourthOrderMujocoTransition(env,np.eye(32),continuous_angles=True)
  for i,u in enumerate(U):assert native(X[i],float(u)).tobytes()==X[i+1].tobytes()
  A=np.empty((end-start,32,32));B=np.empty((end-start,32,1))
  for i in range(start,end):
   A[i-start],B[i-start]=native.linearize(X[i],float(U[i]),state_epsilon=c['state_epsilon'],action_epsilon=c['action_epsilon'])
  np.savez_compressed(out/'native_derivatives.npz',states=X[start:end+1],controls=U[start:end],A=A,B=B,stage_factor=sf,terminal_factor=tf)
  gains=[]
  for v in m['gain_variants']:
   K=square_root_tracking_gains(native,X[start:end+1],U[start:end],cost,regularization=v['regularization'],decimal_digits=m['decimal_digits'],
    mp_linearization=lambda i,x,u,ctx:(ctx.matrix(A[i].tolist()),ctx.matrix(B[i].tolist())))
   assert K.shape==(148,32) and np.all(np.isfinite(K));gains.append(K)
   print(dict(tag=v['tag'],maximum_gain_norm=float(np.max(np.linalg.norm(K,axis=1)))),flush=True)
  path=out/'gain_design.npz';np.savez_compressed(path,states=X[start:end+1],controls=U[start:end],gains=np.asarray(gains),A=A,B=B,stage_factor=sf,terminal_factor=tf)
  payload.update(status='finished',array=file_metadata(path),cold439_source_byte_exact=True,
   state_epsilon=c['state_epsilon'],action_epsilon=c['action_epsilon'],regularizations=[v['regularization'] for v in m['gain_variants']],
   gain_scope='MP100 finite-horizon perturbation Hessian,148actualarrivalnodes; nominalobjectivegradient excluded from tracking gains. Nativebinary64 fourthorder derivatives, binary64 runtimegain export. No stability/nonlinearcertificate.')
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}');raise
 finally:
  if env is not None:env.close()
  mujoco.mj_step=original;payload.update(total_native_transition_calls=count[0]/4,native_physics_substeps=count[0],partial_transition_substeps=count[0]%4,finished_at=utc_timestamp());dump_json(payload,out/'result.json');print(payload,flush=True)

if __name__=='__main__':main()
