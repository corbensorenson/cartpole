"""Record project-test validation separately from frontier solve accounting."""
import argparse
from pathlib import Path
import mujoco
import pytest
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp

def main():
 p=argparse.ArgumentParser();p.add_argument('--accounting-file',required=True);p.add_argument('--substep-ceiling',type=int,required=True);a=p.parse_args();original=mujoco.mj_step;count=[0];payload=dict(generated_at=utc_timestamp(),status='running',script=file_metadata(__file__),native_substep_ceiling=a.substep_ceiling,actual_hanging_start_episode_steps=0,not_solution=True,canonical_release_evidence=False,scope='Separate repository-test validation. Counts in-process mj_step calls reaching this wrapper; mocked steps, independent native rollout APIs or subprocess physics are outside this counter. Four-substep equivalents are cost units, not test episode ticks. No frontier actual episode or record claim.')
 def counted(model,data,*args,**kw):
  n=int(kw.get('nstep',args[0] if args else 1))
  if count[0]+n>a.substep_ceiling:raise RuntimeError('declared project-validation physics ceiling')
  count[0]+=n;return original(model,data,*args,**kw)
 mujoco.mj_step=counted
 try:
  code=int(pytest.main(['-q']));payload.update(status='finished' if code==0 else 'failed',pytest_returncode=code)
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}');raise
 finally:
  mujoco.mj_step=original;payload.update(native_physics_substeps=count[0],total_native_transition_calls=count[0]/4,finished_at=utc_timestamp());dump_json(payload,Path(a.accounting_file))
 raise SystemExit(code)
if __name__=='__main__':main()
