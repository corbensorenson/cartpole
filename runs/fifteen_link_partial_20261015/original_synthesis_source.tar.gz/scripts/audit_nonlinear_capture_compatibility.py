"""Check a received review and screen saved maintenance at local diagnostic resets.

These resets measure capture compatibility only. They cannot establish a
hanging-start solve, a disturbance certificate, or a new canonical record.
"""
from pathlib import Path
import argparse
import json
import time

import numpy as np

from gcartpole.angles import wrap_angle
from gcartpole.config import load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, runtime_metadata, utc_timestamp
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.transfer_physical_capture_route import transfer_physical_nodes


def verify_references(value, verified):
    if isinstance(value, dict):
        if all(key in value for key in ('path', 'bytes', 'sha256')):
            assert file_metadata(value['path']) == value, value['path']
            verified.add(value['path'])
        else:
            for item in value.values():
                verify_references(item, verified)
    elif isinstance(value, list):
        for item in value:
            verify_references(item, verified)


def screen(cfg, initial, gain, seconds, expected=None):
    n = cfg['env']['n_links']
    initial = np.asarray(initial, dtype=float)
    local = fixed_state_cfg(cfg, dict(qpos=initial[:n+1].tolist(),
                                    qvel=initial[n+1:].tolist()), seconds)
    for key in ('init_qpos_scale_start', 'init_qpos_scale_end'):
        local['env'].pop(key, None)
    env = NLinkCartPoleEnv(local, progress=1., seed=0)
    env.reset(seed=0)
    assert np.r_[env.data.qpos, env.data.qvel].tobytes() == initial.tobytes()
    streak = longest = saturated = steps = 0
    max_angle = max_rate = max_action = 0.
    first_angle_failure = None
    try:
        for step in range(env.max_steps):
            state = np.r_[env.data.qpos, env.data.qvel]
            state[1:n+1] = wrap_angle(state[1:n+1])
            raw = -float(gain @ state)
            delivered = float(np.float32(np.clip(raw, -1., 1.)))
            max_action = max(max_action, abs(raw))
            saturated += abs(raw) > 1
            _, _, terminated, truncated, info = env.step([delivered])
            steps += 1
            if expected is not None:
                row = expected[step]
                assert np.r_[env.data.qpos, env.data.qvel].tobytes() == np.asarray(
                    row['qpos'] + row['qvel'], dtype=float).tobytes(), step
            angle = float(np.max(np.abs(wrap_angle(np.cumsum(env.data.qpos[1:n+1])))))
            max_angle = max(max_angle, angle)
            max_rate = max(max_rate, float(np.max(np.abs(np.cumsum(env.data.qvel[1:])))))
            streak = streak+1 if angle < .15 else 0
            longest = max(longest, streak)
            if angle >= .15 and first_angle_failure is None:
                first_angle_failure = steps * env.dt
            if terminated or truncated:
                break
        return dict(steps=steps, native_transition_calls=steps,
                    duration_seconds=steps*env.dt, physical_hold_seconds=longest*env.dt,
                    all_samples_upright=first_angle_failure is None,
                    first_angle_failure_seconds=first_angle_failure,
                    full_local_episode_completed=steps == env.max_steps and
                        info['termination_reason'] == 'time_limit' and not info['simulation_error'],
                    local_gate_pass=steps == env.max_steps and longest*env.dt >= 5 and
                        info['termination_reason'] == 'time_limit' and not info['simulation_error'],
                    maximum_angle=max_angle, maximum_absolute_rate=max_rate,
                    maximum_cart=info['max_cart_excursion'], maximum_raw_action=max_action,
                    saturated_ticks=saturated, termination_reason=info['termination_reason'],
                    simulation_error=info['simulation_error'],
                    expected_native_states_byte_identical=expected is not None)
    finally:
        env.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--review', default='tmp/deep_review_fifteen_20261003/analysis.json')
    parser.add_argument('--directory', required=True)
    args = parser.parse_args()
    directory = Path(args.directory)
    directory.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    review = json.loads(Path(args.review).read_text())
    verified = set()
    verify_references(review, verified)
    root = Path('runs/frontier_campaign_20261001')
    controller_path = Path('runs/swingup14_uniform/fourteen_link_controller.json')
    policy_path = Path('runs/swingup14_uniform/fourteen_link_policy.json')
    cache_path = root/'n15_adjacent_best_refined2p2_nonlinear_value_inputs/capture_cache.json'
    h64_path = root/'n15_native_h64_fresh_physical_suffix_round2/result.json'
    controller = json.loads(controller_path.read_text())
    policy = json.loads(policy_path.read_text())
    cache = json.loads(cache_path.read_text())
    assert file_metadata(cache['source']['path']) == cache['source']
    h64 = json.loads(h64_path.read_text())
    assert h64['feasible_sequence_found'] and h64['independent_final_plan_replay_byte_identical']
    count = len(controller['controller']['controls'])
    row = controller['result']['trajectory'][count-1]
    initial14 = np.asarray(row['qpos']+row['qvel'], dtype=float)
    gain14 = np.asarray(policy['capture_gain']).ravel()*controller['controller']['lqr_scale']
    gain15 = np.asarray(cache['gain']).ravel()
    records = []
    cfg14 = load_config('configs/swingup14_uniform.yaml')
    cfg15 = load_config('configs/swingup15_uniform.yaml')
    records.append(dict(center='accepted14_handoff', n_links=14, amplitude=0.,
                        result=screen(cfg14, initial14, gain14, 8.,
                                      controller['result']['trajectory'][count:count+400])))
    directions14 = np.random.default_rng(20261017).normal(size=(4, 28))
    directions14 /= np.linalg.norm(directions14, axis=1)[:, None]
    original = next(r for r in review['local_capture_perturbations']
                    if r['n_links'] == 14 and r['amplitude'] == 1e-12)
    for index, direction in enumerate(directions14):
        trial = initial14.copy()
        trial[1:15] += 1e-12*direction[:14]
        trial[16:] += 1e-12*direction[14:]
        result = screen(cfg14, trial, gain14, 8.)
        old = original['episodes'][index]
        assert result['steps'] == old['steps']
        assert result['maximum_raw_action'] == old['maximum_raw_action']
        assert result['maximum_cart'] == old['maximum_cart']
        records.append(dict(center='accepted14_handoff', n_links=14, amplitude=1e-12,
                            direction=index, sign=1, reproduced_review=True, result=result))
    directions15 = np.random.default_rng(20261018).normal(size=(4, 30))
    directions15 /= np.linalg.norm(directions15, axis=1)[:, None]
    centers = dict(upright_origin=np.zeros(32),
                   transferred14_quiet_endpoint=transfer_physical_nodes(initial14[None, :], 15)[0],
                   verified15_h64_endpoint=np.asarray(h64['selected_states'])[-1])
    for name, center in centers.items():
        for amplitude in (0., 1e-14, 1e-12, 1e-10, 1e-8):
            # Arbitrary directions can obscure asymmetry at a nonzero center.
            for index, direction in enumerate(directions15[:1] if amplitude == 0 else directions15):
                for sign in ((1,) if amplitude == 0 else (1, -1)):
                    trial = center.copy()
                    trial[1:16] += sign*amplitude*direction[:15]
                    trial[17:] += sign*amplitude*direction[15:]
                    records.append(dict(center=name, n_links=15, amplitude=amplitude,
                                        direction=index, sign=sign,
                                        result=screen(cfg15, trial, gain15, 30.)))
    summary = []
    for name in centers:
        for amplitude in (0., 1e-14, 1e-12, 1e-10, 1e-8):
            rows = [r['result'] for r in records if r['center'] == name and r['amplitude'] == amplitude]
            summary.append(dict(center=name, amplitude=amplitude, episodes=len(rows),
                                local_gate_passes=sum(r['local_gate_pass'] for r in rows),
                                all_samples_upright=sum(r['all_samples_upright'] for r in rows),
                                minimum_hold_seconds=min(r['physical_hold_seconds'] for r in rows)))
    payload = dict(generated_at=utc_timestamp(), runtime=runtime_metadata(),
                   script=file_metadata(__file__), review=file_metadata(args.review),
                   verified_review_references=len(verified),
                   sources=[file_metadata(p) for p in (controller_path, policy_path, cache_path, h64_path)],
                   gain_norms=dict(n14=float(np.linalg.norm(gain14)), n15=float(np.linalg.norm(gain15))),
                   perturbation_definition='L2 normalized joint relative-angle/rate coordinates; mixed rad and rad/s numerical units; zero cart perturbation',
                   direction_seeds=dict(n14=20261017, n15=20261018),
                   directions14=directions14.tolist(), directions15=directions15.tolist(),
                   centers15={k:v.tolist() for k,v in centers.items()}, records=records, summary=summary,
                   native_transition_calls=sum(r['result']['native_transition_calls'] for r in records),
                   actual_hanging_start_episode_steps=0, canonical_release_evidence=False,
                   reserved_seeds_used=False, noisy_development_seeds_used=False, not_solution=True,
                   scope='Review reference verification, exact 400-state accepted14 continuation and matched tiny-perturbation reproduction; new 30s local15 capture screens with unchanged saved gain. Sampled directions only, not a basin boundary or canonical solve.',
                   wall_seconds=time.monotonic()-started)
    (directory/'result.json').write_text(json.dumps(payload, indent=2, sort_keys=True)+'\n')
    print(json.dumps(dict(summary=summary, native_transition_calls=payload['native_transition_calls'])), flush=True)


if __name__ == '__main__':
    main()
