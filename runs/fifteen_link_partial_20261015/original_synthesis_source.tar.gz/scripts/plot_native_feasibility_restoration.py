#!/usr/bin/env python
"""Compare short native forecasts at one retained physical state."""
import argparse,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    restoration=json.loads(Path(args.source).read_text());online=json.loads(Path(restoration['source']['path']).read_text())
    if restoration['selected_sequence'] is None:raise ValueError('A verified native restored forecast is required')
    if file_metadata(restoration['source']['path'])!=restoration['source'] or file_metadata(restoration['config']['path'])!=restoration['config']:
        raise ValueError('Source/config identity changed')
    cfg=load_config(restoration['config']['path']);n=cfg['env']['n_links'];dt=cfg['env']['timestep']*cfg['env']['frame_skip']
    prior=online['result']['trajectory'][restoration['controller_step']-1]
    old=np.r_[prior['tracking_preview']['selected_sequence'][1:],-1.]
    base=json.loads(Path(online['source']['path']).read_text())
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    predictor=MujocoTransition(env,np.eye(2*(n+1)),continuous_angles=True);forecasts=[]
    try:
        for label,actions in [('Previous suffix + −1 extension',old),('Native physical restoration',restoration['selected_sequence'])]:
            current=np.asarray(restoration['component_state']);states=[]
            for u in actions:current=predictor(current,float(np.float32(u)));states.append(current)
            states=np.asarray(states)
            if label.startswith('Native') and not np.array_equal(states,restoration['diagnostics']['selected_states']):
                raise ValueError('Restored forecast did not reproduce exactly')
            forecasts.append(dict(label=label,actions=np.asarray(actions),states=states,
                angle=np.max(np.abs(wrap_angle(np.cumsum(states[:,1:n+1],axis=1))),axis=1),
                rate=np.max(np.abs(np.cumsum(states[:,n+2:],axis=1)),axis=1)))
    finally:env.close()
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    fig,axes=plt.subplots(3,1,figsize=(7.5,7),sharex=True,layout='constrained')
    colors=['#bb4053','#243a50']
    for record,color in zip(forecasts,colors):
        t=np.arange(1,len(record['angle'])+1)*dt
        axes[0].plot(t,record['angle'],label=record['label'],color=color,lw=1.7)
        axes[1].plot(t,record['rate'],color=color,lw=1.7)
        axes[2].step(t-dt,record['actions'],where='post',color=color,lw=1.5)
    axes[0].axhline(.14,color='#7b838b',ls=':',label='Forecast angle bound 0.14 rad')
    axes[1].axhline(.25,color='#7b838b',ls=':')
    axes[0].set(ylabel='Maximum absolute angle (rad)');axes[0].legend(fontsize=9,loc='upper left')
    axes[1].set(ylabel='Maximum absolute rate (rad/s)')
    axes[2].set(ylabel='Normalized input',xlabel='Forecast time after the retained 7.60 s state (s)',ylim=(-1.1,1.1),xlim=(0,.32))
    for ax in axes:ax.grid(axis='y',alpha=.16)
    fig.suptitle('A discarded forecast seed does not establish physical infeasibility',fontsize=12)
    fig.supxlabel('15 links; isolated native forecasts, not an executed solution or a viability certificate.',fontsize=9)
    out.mkdir(parents=True,exist_ok=True);outputs=[]
    for suffix in ('png','pdf','svg'):
        path=out/f'comparison.{suffix}';fig.savefig(path,dpi=180);outputs.append(file_metadata(path))
    plt.close(fig)
    dump_json(dict(not_solution=True,benchmark_evidence=False,source=file_metadata(args.source),outputs=outputs,
        native_transition_calls=predictor.evaluations,restored_forecast_bit_identical=True,
        forecast_horizon_steps=len(restoration['selected_sequence']),reserved_seeds_used=False,
        scope='Short isolated native forecasts from one retained actual state. No plant rollout or canonical solution is depicted.'),out/'result.json')
if __name__=='__main__':main()
