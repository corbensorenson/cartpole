"""Independent R36 population, distribution, native physics and actual gate proof."""
import argparse,json
from pathlib import Path
import numpy as np,mujoco
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.angles import wrap_angle
from gcartpole.native_task_derivatives import physical_task_residual
from scripts.search_capture_sequence import fixed_state_cfg

def read(path):return json.loads(Path(path).read_text())
def same(a,b):assert np.asarray(a).tobytes()==np.asarray(b).tobytes()
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(a.root);out=Path(a.out);out.mkdir(exist_ok=False)
 m=read(root/'manifest.json');r=read(root/'execution/diagnostic/result.json');acc=read(root/'execution/inclusive_accounting.json');s=read(m['source']['path']);base=read(s['source']['path']);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in s['result']['trajectory']]]);U=np.asarray([q['action'] for q in s['result']['trajectory']],np.float32).astype(float)
 for meta in m['dependency_bundle']+[m['gain_source'],m['source_audit']]:assert meta==file_metadata(meta['path'])
 gain=np.asarray(read(m['gain_source']['path'])['gain']);cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.)
 h=m['feedforward_horizon'];tail=m['maintenance_steps'];total=h+tail;k=m['knots'];c=m['candidates'];start=m['start_step'];count=[0];attempts=0;old=mujoco.mj_step;env=None;outcomes=[];candidatecount=0
 src=np.linspace(0,1,k);tar=np.linspace(0,1,h);right=np.searchsorted(src,tar,side='right').clip(1,k-1);left=right-1;frac=(tar-src[left])/(src[right]-src[left]);basis=np.zeros((h,k));basis[np.arange(h),left]=1-frac;basis[np.arange(h),right]+=frac
 payload=dict(status='running',generated_at=utc_timestamp(),script=file_metadata(__file__),source_result=file_metadata(root/'execution/diagnostic/result.json'),source_accounting=file_metadata(root/'execution/inclusive_accounting.json'),actual_hanging_start_episode_steps=0,native_transition_ceiling=500000,canonical_release_evidence=False,not_solution=True)
 def counted(model,data,*args,**kwargs):
  n=int(kwargs.get('nstep',args[0] if args else 1));assert count[0]+n<=2000000;count[0]+=n;return old(model,data,*args,**kwargs)
 def rank(states):
  angles=np.abs(wrap_angle(np.cumsum(states[:,1:16],axis=1)));safe=(angles.max(axis=1)<.149)&(np.abs(states[:,0])<=3);bad=np.flatnonzero(~safe);prefix=int(bad[0]) if len(bad) else len(states)
  rr=physical_task_residual(states,15,m['rate_weight'],.05)
  return (0,-prefix,float(rr@rr+100*np.sum((np.maximum(angles-.149,0)/.149)**2)+100*np.sum((np.maximum(np.abs(states[:,0])-2.85,0)/.15)**2)))
 mujoco.mj_step=counted
 try:
  env=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);env.reset(seed=20265100);native=MujocoTransition(env,np.eye(32),continuous_angles=True)
  for i in range(start):attempts+=1;same(native(X[i],float(U[i])),X[i+1])
  for arm,row in zip(m['arms'],r['records'],strict=True):
   assert arm['label']==row['label'];assert row['tape']==file_metadata(row['tape']['path']);assert row['decisions']==file_metadata(row['decisions']['path'])
   with np.load(row['tape']['path']) as z:xs=z['states'];us=z['actions']
   decisions=read(row['decisions']['path'])['decisions'];assert len(decisions)==len(us)-start;same(xs[:start+1],X[:start+1]);rng=np.random.default_rng(m['search_random_seed']);warm=U[start:start+h].copy()
   for decision in decisions:
    tick=decision['tick']
    anchor=warm.copy();reference=U[tick:tick+h].copy() if tick+h<=len(U) else None;mean=np.zeros(k);std=np.full(k,arm['initial_std']);best=None
    group=[q for q in r['private_batches'] if q['label']==arm['label'] and q['tick']==tick];assert len(group)==m['cem_iterations']
    for iteration,meta in enumerate(group):
     assert meta['iteration']==iteration and meta['candidates']==c and meta['feedforward_horizon']==h and meta['maintenance_steps']==tail;assert meta['tape']==file_metadata(meta['tape']['path'])
     with np.load(meta['tape']['path']) as archive:z={key:archive[key] for key in archive.files}
     same(z['base_feedforward'],anchor);same(z['mean_before'],mean);same(z['std_before'],std)
     knots=rng.normal(mean,std,size=(c,k));knots[0]=mean;knots[1]=0.;knots[2]=-1.;knots[3]=1.;ff=np.clip(anchor+knots@basis.T,-1,1).astype(np.float32).astype(float);eligible=np.ones(c,bool);kinds=['sampled']*c;kinds[:4]=['mean','zero','minimum','maximum'];ff[4]=anchor;eligible[4]=False;kinds[4]='warm'
     if reference is not None:ff[5]=reference;eligible[5]=False;kinds[5]='reference'
     same(z['knots'],knots);same(z['feedforward_commands'],ff);same(z['update_eligible'],eligible);same(z['kinds'],np.asarray(kinds));same(ff[1],anchor)
     assert meta['unique_feedforward_sequences']==len({x.tobytes() for x in ff});assert meta['source_window_identical_candidates']==(sum(x.tobytes()==reference.tobytes() for x in ff) if reference is not None else None)
     scores=[]
     for i in range(c):
      assert meta['errors'][i] is None;assert z['completed_lengths'][i]==total and z['attempted_lengths'][i]==total;same(z['states'][i,0],xs[tick])
      for j in range(total):
       state=z['states'][i,j]
       if j<h:u=float(ff[i,j])
       else:
        physical=state.copy();physical[1:16]=wrap_angle(physical[1:16]);raw=-float(gain@physical);assert raw==z['tail_raws'][i,j-h];u=float(np.float32(np.clip(raw,-1,1)))
       assert u==z['actions'][i,j];attempts+=1;same(native(state,u),z['states'][i,j+1])
      score=rank(z['states'][i,1:]);assert score==tuple(z['scores'][i]);scores.append(score)
     winner=min(range(c),key=lambda i:scores[i]);assert winner==z['winner_index'];chosen=np.asarray(sorted(np.flatnonzero(eligible),key=lambda i:scores[i])[:m['elite_count']],int);elite=np.clip(knots[chosen],-1,1);mean=np.mean(elite,axis=0);std=np.maximum(np.std(elite,axis=0),m['minimum_std']);same(chosen,z['elite_indices']);same(mean,z['mean_after']);same(std,z['std_after']);candidatecount+=c
     if best is None or scores[winner]<best['score']:best=dict(score=scores[winner],sequence=ff[winner],states=z['states'][winner,1:],actions=z['actions'][winner],meta=meta['tape'],index=winner)
     if candidatecount%(50*c)==0:print(json.dumps(dict(batches=candidatecount//c,candidates=candidatecount,attempts=attempts)),flush=True)
    assert tuple(decision['score'])==best['score'] and decision['private_batch']==best['meta'] and decision['candidate_index']==best['index'];assert decision['selected_completed_steps']==total and decision['selected_error'] is None
    same(decision['selected_sequence'],best['sequence']);same(decision['selected_forecast'],best['states']);same(decision['selected_delivered_forecast_actions'],best['actions']);assert us[tick]==best['sequence'][0];same(xs[tick+1],best['states'][0]);warm=np.r_[best['sequence'][1:],best['sequence'][-1]]
   streak=longest=0
   for tick,u in enumerate(us):
    attempts+=1;same(native(xs[tick],float(u)),xs[tick+1]);angle=float(np.max(np.abs(wrap_angle(np.cumsum(xs[tick+1,1:16])))));streak=streak+1 if angle<.15 else 0;longest=max(longest,streak)
   assert [d['tick'] for d in decisions]==list(range(start,len(us)));same(us,us.astype(np.float32).astype(float));assert longest*.02==row['hold_seconds'] and len(us)==row['actual_hanging_start_episode_steps'];assert np.max(np.abs(xs[1:,0]))==row['maximum_cart'];assert abs(xs[-1,0])>3 and row['termination_reason']=='rail_violation' and not row['full_nominal_gate_passed'];outcomes.append({key:row[key] for key in ('label','initial_std','hold_seconds','maximum_cart','termination_reason','actual_hanging_start_episode_steps','full_nominal_gate_passed')})
  assert candidatecount==sum(q['candidates'] for q in r['private_batches']);assert attempts+r['actual_hanging_start_episode_steps']==r['total_native_transition_calls'];assert count[0]+4*r['actual_hanging_start_episode_steps']==acc['native_physics_substeps']
  payload.update(status='finished',passed=True,independent_native_candidate_forecasts=candidatecount,independent_private_batches=len(r['private_batches']),outcomes=outcomes,population_rng_and_distribution_reconstructed=True,scope='All R36 populations, residual anchors, latent-to-F32commands, eligibility, RNG, elite updates, native24step feedforward/feedback forecasts, ranks and selections independently reconstructed. Entire actual tapes and375prefix byteproved; both finite recipes negative. No causal attribution to isolated correction, robustness or impossibility certificate.')
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}');raise
 finally:
  if env is not None:env.close()
  mujoco.mj_step=old;payload.update(total_native_transition_calls=count[0]/4,native_physics_substeps=count[0],attempted_transition_calls=attempts,finished_at=utc_timestamp());dump_json(payload,out/'result.json');print({key:value for key,value in payload.items() if key!='outcomes'},flush=True)
if __name__=='__main__':main()
