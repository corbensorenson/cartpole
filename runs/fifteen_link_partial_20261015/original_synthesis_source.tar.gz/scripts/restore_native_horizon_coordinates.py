#!/usr/bin/env python
"""Bounded native-only coordinate search on delivered F32 action neighbors."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.ilqr import MujocoTransition
from gcartpole.native_action_lattice import affine_action_lattice
from gcartpole.native_task_derivatives import physical_task_residual
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    p.add_argument('--rounds',type=int,default=32)
    p.add_argument('--planning-transition-budget',type=int,default=400000)
    p.add_argument('--radii',nargs='+',type=int,default=[1,4,16,64])
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    if args.rounds<1 or args.planning_transition_budget<1 or any(not 1<=v<=4096 for v in args.radii):raise ValueError('positive bounded budgets required')
    source=json.loads(Path(args.source).read_text())
    for key in ('source','config','teacher'):
        if file_metadata(source[key]['path'])!=source[key]:raise ValueError('bound source changed')
    base=json.loads(Path(source['source']['path']).read_text());cfg=load_config(source['config']['path'])
    n=cfg['env']['n_links'];nx=2*(n+1);step=source['parameters']['start_step'];rate=source['parameters']['rate_residual_weight']
    known=np.asarray(source['last_valid_plan'],np.float32).astype(float);horizon=source['stages'][-1]['horizon_steps']
    if source['stages'][-1]['feasible_sequence_found'] or horizon!=len(known)+1:raise ValueError('first failed one-tick extension required')
    reference=np.asarray(base['controller']['controls'][step:step+horizon],np.float32).astype(float)
    if len(reference)!=horizon:raise ValueError('unpadded reference required')
    center=np.r_[known,reference[len(known):]]
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True);untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
    began=time.monotonic();rounds=[]
    def forecast(state,actions):
        current=state.copy();states=[]
        for u in actions:current=native(current,float(u));states.append(current.copy())
        return np.asarray(states)
    def measure(states,actions):
        phi=np.abs(wrap_angle(np.cumsum(states[:,1:n+1],axis=1)));cart=np.abs(states[:,0])
        feasible=bool(np.all(phi<.14) and np.all(cart<=env.rail_limit))
        violation=float(np.sum((np.maximum(phi-.14,0)/.14)**2)+np.sum((np.maximum(cart-env.rail_limit,0)/env.rail_limit)**2))
        residual=physical_task_residual(states,n,rate,.1);cost=float(residual@residual+1e-4*np.sum((actions-reference)**2))
        return (0 if feasible else 1,violation,cost),feasible,float(np.max(phi))
    payload=dict(not_solution=True,canonical_release_evidence=False,source=file_metadata(args.source),parameters=vars(args),runtime=runtime_metadata(),
        rounds=rounds,actual_episode_steps=0,optimizer_transition_calls=0,native_local_derivative_transition_calls=0,
        reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Native-only greedy coordinate search on one delivered F32 input at a time. Reuse unchanged forecast-prefix states only inside isolated planner data. Rank feasible first,then squared normalized hard-angle/rail violations,then existing squared physical-task+action cost. No smooth Jacobian or MILP proposal. First feasible plan requires independent whole-plan byte replay;no actual episode or infeasibility certificate.')
    try:
        state=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
        for row in base['result']['trajectory'][:step]:
            state=native(state,float(np.float32(row['action'])))
            if state.tobytes()!=np.asarray(row['qpos']+row['qvel']).tobytes():raise ValueError('cold prefix changed')
        checked=forecast(state,known)
        if checked.tobytes()!=np.asarray(source['last_valid_forecast_states']).tobytes():raise ValueError('known plan changed')
        states=forecast(state,center);score,found,maximum=measure(states,center)
        payload.update(initial_sequence=center.tolist(),initial_score=list(score),initial_maximum_angle=maximum)
        planning_before=native.evaluations;seen={center.tobytes()};status='round_limit'
        for index in range(args.rounds):
            if found:status='feasible_plan_found';break
            best=None;visited=invalid=0;round_before=native.evaluations
            for radius in args.radii:
                spacing,lower,upper=affine_action_lattice(center,radius)
                for coordinate in range(horizon):
                    for offset in sorted(set([int(lower[coordinate]),int(upper[coordinate])])):
                        if offset==0:continue
                        actions=center.copy();actions[coordinate]+=spacing[coordinate]*offset
                        key=actions.tobytes()
                        if key in seen:continue
                        if native.evaluations-planning_before+horizon-coordinate>args.planning_transition_budget:status='planning_transition_budget';break
                        seen.add(key);visited+=1
                        if actions.tobytes()!=actions.astype(np.float32).astype(float).tobytes():raise ValueError('proposal is not delivered F32')
                        try:
                            tail=forecast(state if coordinate==0 else states[coordinate-1],actions[coordinate:])
                            candidate_states=np.vstack([states[:coordinate],tail])
                            candidate_score,feasible,angle=measure(candidate_states,actions)
                        except SimulationError:invalid+=1;continue
                        if candidate_score<score and (best is None or candidate_score<best[0]):
                            best=(candidate_score,actions,candidate_states,feasible,angle,coordinate,offset,radius)
                    if status=='planning_transition_budget':break
                if status=='planning_transition_budget':break
            improved=best is not None
            if improved:score,center,states,found,maximum,coordinate,offset,radius=best
            rounds.append(dict(round=index,improved=improved,feasible_plan_found=found,score=list(score),maximum_angle=maximum,
                tested_candidates=visited,invalid_candidates=invalid,native_planning_transition_calls=native.evaluations-round_before,
                changed_coordinate=coordinate if improved else None,offset_ulps=offset if improved else None,radius_ulps=radius if improved else None))
            payload.update(last_finite_center=center.tolist(),last_finite_score=list(score),feasible_sequence_found=found,
                native_forecast_transition_calls=native.evaluations,total_native_transition_calls=native.evaluations,
                native_planning_transition_calls=native.evaluations-planning_before,wall_seconds=time.monotonic()-began)
            dump_json(payload,out/'result.progress.json')
            print(json.dumps(rounds[-1]),flush=True)
            if status=='planning_transition_budget':break
            if not improved:status='no_improving_tested_coordinate';break
        replay_calls=0
        if found:
            replayed=forecast(state,center);replay_calls=horizon
            if replayed.tobytes()!=states.tobytes() or not measure(replayed,center)[1]:raise ValueError('selected plan failed independent whole byte replay')
            status='feasible_plan_found'
        if untouched.tobytes()!=np.r_[env.data.qpos,env.data.qvel].tobytes():raise ValueError('planner changed live simulator state')
        payload.update(status=status,feasible_sequence_found=found,selected_sequence=center.tolist() if found else None,
            selected_states=states.tolist() if found else None,last_finite_center=center.tolist(),last_finite_score=list(score),
            source_prefix_byte_identical=True,last_valid_forecast_byte_identical=True,live_state_unchanged=True,
            native_prefix_and_initial_forecast_transition_calls=planning_before,
            native_planning_transition_calls=native.evaluations-planning_before-replay_calls,
            independent_selected_plan_replay_transition_calls=replay_calls,native_forecast_transition_calls=native.evaluations,
            total_native_transition_calls=native.evaluations,wall_seconds=time.monotonic()-began)
        dump_json(payload,out/'result.json')
    finally:env.close()


if __name__=='__main__':main()
