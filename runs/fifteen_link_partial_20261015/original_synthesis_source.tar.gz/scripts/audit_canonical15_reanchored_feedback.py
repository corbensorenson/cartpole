"""Independent measured-reference feedback, protected-prefix and actual proof."""
import argparse,json
from pathlib import Path
import numpy as np,mujoco
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.native_protected_minimax import protected_trust_proposal
from gcartpole.native_minimax import bounded_affine_minimax
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix
from scripts.audit_canonical15_native_minimax import lp_gap
read=lambda p:json.loads(Path(p).read_text())
def same(a,b):assert np.asarray(a).tobytes()==np.asarray(b).tobytes()
def physical(xs,m):return np.r_[(wrap_angle(np.cumsum(xs[:,1:16],axis=1))/m['angle_limit']).ravel(),xs[:,0]/m['rail_limit']]
def maintenance_features(x,m):return np.r_[wrap_angle(np.cumsum(x[1:16]))/m['angle_scale'],x[0]/3,.1*x[16]/.5]
def gainraw(gain,x):
 y=x.copy();y[1:16]=wrap_angle(y[1:16]);return -float(gain@y)
def rank(z,m):
 h=len(z['feedforward']);xs=z['states'][1:]
 if len(xs)!=h:return [1,1,1e100,1e100,0]
 angles=abs(wrap_angle(np.cumsum(xs[:,1:16],axis=1)));ok=(np.max(angles,axis=1)<m['angle_limit'])&(abs(xs[:,0])<=m['rail_limit']);bad=np.flatnonzero(~ok);prefix=int(bad[0]) if len(bad) else h;f=physical(xs,m);ex=np.maximum(abs(f)-1,0);return [0,0 if np.all(ok) else 1,float(np.max(abs(f))),float(ex@ex),-prefix]
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);args=p.parse_args();root=Path(args.root);out=Path(args.out);out.mkdir(exist_ok=False);m=read(root/'manifest.json');r=read(root/'execution/diagnostic/result.json');acc=read(root/'execution/inclusive_accounting.json');j=read(root/'execution/execution.json');assert j['status']=='finished' and j['returncode']==0 and r['status']=='finished';s=read(m['source']['path']);base=read(s['source']['path']);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in s['result']['trajectory']]]);U=np.asarray([q['action'] for q in s['result']['trajectory']],np.float32).astype(float);start=m['start_step'];track=m['tracking_steps'];gain=np.asarray(read(m['gain_source']['path'])['gain'])
 with np.load(m['tracking_array']['path']) as z:K=z['gains'][m['tracking_variant_index']];same(z['states'],X[start:start+track+1])
 cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);env=NLinkCartPoleEnv(cfg,progress=1.,seed=m['nominal_seed']);env.reset(seed=m['nominal_seed']);native=MujocoTransition(env,np.eye(32),continuous_angles=True);count=[0];old=mujoco.mj_step
 def counted(model,data,*args,**kw):
  n=int(kw.get('nstep',args[0] if args else 1));assert count[0]+n<=4*m['audit_native_transition_ceiling'];count[0]+=n;return old(model,data,*args,**kw)
 mujoco.mj_step=counted;loaded={};lp_checks=0;scalar_checks=0;maxgap=0;failed=0;outcomes=[]
 try:
  for tick in range(start+track):same(native(X[tick],float(U[tick])),X[tick+1])
  contexts=[]
  for context in r['reference_contexts']:
   assert context['index']==len(contexts) and context['tape']==file_metadata(context['tape']['path']) and context['gain_scale']==m['feedback_scales'][context['runtime']]
   with np.load(context['tape']['path']) as archive:z={k:archive[k] for k in archive.files}
   assert z['states'].shape==(m['horizon']+1,32) and z['actions'].shape==(m['horizon'],);contexts.append(z)
  for row in r['private_forecasts']:
   assert row['tape']==file_metadata(row['tape']['path'])
   with np.load(row['tape']['path']) as archive:z={k:archive[k] for k in archive.files}
   context=r['reference_contexts'][row['reference_context']];reference=contexts[row['reference_context']]['states'];runtime_gains=context['gain_scale']*K;assert context['runtime']==row['runtime'];same(z['states'][0],X[start]);assert len(z['actions'])==row['attempted_steps'] and len(z['states'])-1==row['completed_steps'];error=None
   for i,u in enumerate(z['actions']):
    raw=float(z['feedforward'][i])+float(runtime_gains[i]@(z['states'][i]-reference[i])) if i<track else float(z['feedforward'][i]);assert raw==z['raw_actions'][i] and float(np.float32(np.clip(raw,-1,1)))==u
    try:prediction=native(z['states'][i],float(u))
    except SimulationError as e:error=f'SimulationError: {e}';failed+=1;assert i==len(z['actions'])-1 and len(z['states'])==len(z['actions']);same(z['failed_post_state'],np.r_[native.data.qpos,native.data.qvel]);assert float(z['failed_time'])==float(native.data.time);break
    same(prediction,z['states'][i+1])
   if row['projection_index'] is not None and r['force_projections'][row['projection_index']].get('status')=='failed_anchors':
    assert error is None and len(z['states'])==len(z['feedforward']);error='Projection anchors failed; native grid retained'
   assert error==row['error'];assert rank(z,m)==row['score'];loaded[row['index']]=z
  tail_oracle_calls=0;tail_scalar_checks=0;tail_maxgap=0.;force_outcomes=[]
  for row in r['force_projections']:
   assert row['tape']==file_metadata(row['tape']['path']);center=loaded[row['parent_forecast']]
   with np.load(row['tape']['path']) as archive:z={k:archive[k] for k in archive.files}
   os,oa,raws=z['states'],z['actions'],z['raw_actions'];state=center['states'][-1] if row.get('status')=='failed_anchors' else center['states'][-2];assert len(os)==len(row['errors'])
   for i,(pair,u,raw) in enumerate(zip(os,oa,raws,strict=True)):
    same(pair[0],state);assert float(np.float32(np.clip(raw,-1,1)))==u;error=None
    try:pred=native(pair[0],float(u))
    except SimulationError as e:error=f'SimulationError: {e}';same(z['failed_post_states'][i],np.r_[native.data.qpos,native.data.qvel]);assert float(z['failed_times'][i])==float(native.data.time)
    else:same(pred,pair[1])
    assert error==row['errors'][i];tail_oracle_calls+=1
   def peak(index):return float(np.max(abs(physical(os[index,1:2],m)))) if row['errors'][index] is None else 1e100
   grid=np.unique(np.r_[np.linspace(-1,1,m['inner_grid_points']).astype(np.float32).astype(float),np.float32(row['input_last_hint']).astype(float)]);same(grid,row['grid_actions']);ids=row['grid_candidate_ids'];assert ids==list(range(len(grid)));same(oa[ids],grid);minus=ids[int(np.flatnonzero(grid==-1)[0])];plus=ids[int(np.flatnonzero(grid==1)[0])]
   if row.get('status')=='failed_anchors':
    assert row['errors'][minus] is not None or row['errors'][plus] is not None;assert len(os)==len(grid) and len(center['states'])==len(center['feedforward']) and r['private_forecasts'][row['parent_forecast']]['projection_index']==row['index'];continue
   fp,fm=physical(os[plus,1:2],m),physical(os[minus,1:2],m);proposal=bounded_affine_minimax(fm,fp);assert proposal==row['affine_proposal'];tail_maxgap=max(tail_maxgap,lp_gap(fm,fp,proposal));tail_scalar_checks+=1;proposal_id=len(grid);assert row['affine_candidate_id']==proposal_id and raws[proposal_id]==proposal
   best=min(range(len(ids)),key=lambda i:peak(ids[i]));left=float(grid[max(0,best-1)]);right=float(grid[min(len(grid)-1,best+1)]);assert row['initial_bracket']==[left,right];ratio=(np.sqrt(5)-1)/2;c=right-ratio*(right-left);d=left+ratio*(right-left);ci,di=row['golden_initial_ids'];assert [ci,di]==[len(grid)+1,len(grid)+2] and raws[ci]==c and raws[di]==d
   for iteration,history in enumerate(row['golden_history']):
    if peak(ci)<=peak(di):right,d,di=d,c,ci;c=right-ratio*(right-left);ci=len(grid)+3+iteration;branch='left';new=ci;assert raws[new]==c
    else:left,c,ci=c,d,di;d=left+ratio*(right-left);di=len(grid)+3+iteration;branch='right';new=di;assert raws[new]==d
    expected=dict(iteration=iteration,branch=branch,left=left,right=right,c=c,d=d,candidate_c=ci,candidate_d=di,new_candidate=new);assert history==expected
   assert len(row['golden_history'])==m['inner_golden_iterations'] and len(os)==len(grid)+3+m['inner_golden_iterations'];winner=min(range(len(os)),key=lambda i:(peak(i),abs(oa[i]),i));assert row['winner_index']==winner and row['selected_last_action']==oa[winner] and row['selected_next_peak']==peak(winner);same(center['states'][-1],os[winner,1]);assert center['feedforward'][-1]==oa[winner] and center['actions'][-1]==oa[winner] and r['private_forecasts'][row['parent_forecast']]['projection_index']==row['index']
  def verify_proposal(row,arm):
   nonlocal lp_checks
   h=m['horizon'];indices=np.asarray(m['optimization_action_indices'],int);nk=len(indices);basis=np.zeros((h,nk));basis[indices,np.arange(nk)]=1.;z=loaded[row['center_before']];eps=np.asarray(row['derivative_epsilons']);assert len(eps)==basis.shape[1] and len(row['derivative_pairs'])==basis.shape[1];columns=[];valid_indices=[]
   for k,(pi,mi) in enumerate(row['derivative_pairs']):
    zp,zm=loaded[pi],loaded[mi];same(zp['feedforward'][:-1],(z['feedforward']+eps[k]*basis[:,k])[:-1]);same(zm['feedforward'][:-1],(z['feedforward']-eps[k]*basis[:,k])[:-1])
    if len(zp['states'])!=h+1 or len(zm['states'])!=h+1:columns.append(np.zeros(16*h))
    else:
     valid_indices.append(k);columns.append((physical(zp['states'][1:],m)-physical(zm['states'][1:],m))/(2*eps[k]))
   assert all(r['private_forecasts'][q]['reference_context']==r['private_forecasts'][row['center_before']]['reference_context'] for pair in row['derivative_pairs'] for q in pair)
   criteria=row['locality_filter'];model=r['secant_models'][row['secant_model_index']];valid_indices=[q['parameter_index'] for q in model['column_diagnostics'] if q['complete'] and q['matched_first_actions'] and (criteria['maximum_feature_drift'] is None or max(q['plus_center_maximum_feature_drift'],q['minus_center_maximum_feature_drift'])<=criteria['maximum_feature_drift']) and (criteria['maximum_asymmetry'] is None or q['central_asymmetry_maximum']<=criteria['maximum_asymmetry'])];assert valid_indices==row['valid_parameter_indices']
   if not valid_indices:assert row['status']=='no_valid_secant_columns' and row['accepted'] is None and row['parameter_step'] is None and not row['backtracks'] and row['center_after']==row['center_before'];return
   protected_indices=np.r_[np.arange(15*m['protected_steps']),15*h+np.arange(m['protected_steps'])];assert row['protect_prefix'] is True and row['protected_feature_indices']==protected_indices.tolist();f=physical(z['states'][1:],m);jac=np.column_stack(columns);radii=np.asarray(row['trust_radii']);subdelta,diag=protected_trust_proposal(f,jac[:,valid_indices],radii[valid_indices],protected_indices=protected_indices,action_values=z['feedforward'][:-1],action_basis=basis[:-1,valid_indices],solver_seconds=m['lp_seconds']);delta=None if subdelta is None else np.zeros(nk);
   if delta is not None:delta[valid_indices]=subdelta
   assert diag==row['lp'];lp_checks+=1;accepted=None
   if delta is None:assert row['parameter_step'] is None and not row['backtracks']
   else:
    same(delta,row['parameter_step']);
    if len(protected_indices):assert np.max(abs((f+jac@delta)[protected_indices]))<=1+1e-7
    assert np.max(abs(delta)/radii)<=1+1e-8 and np.max(abs(z['feedforward']+basis@delta))<=1+1e-7 and np.max(abs(f+jac@delta))<=diag['lp_epigraph']+1e-7
    for power,bt in enumerate(row['backtracks']):
     assert power==bt['power'];candidate=loaded[bt['forecast_index']];assert r['private_forecasts'][bt['forecast_index']]['reference_context']==r['private_forecasts'][row['center_before']]['reference_context'];same(candidate['feedforward'][:-1],(z['feedforward']+basis@(delta/(2**power)))[:-1])
     prefix_admissible=False
     if len(candidate['states'])==h+1:
      first=candidate['states'][1:1+m['protected_steps']];prefix_admissible=bool(np.max(abs(wrap_angle(np.cumsum(first[:,1:16],axis=1))))<m['angle_limit'] and np.max(abs(first[:,0]))<=m['rail_limit'])
      pred=f+jac@(delta/(2**power));actual=physical(candidate['states'][1:],m);assert bt['changed_delivered_prefix_inputs']==int(np.count_nonzero(candidate['actions'][:-1]!=z['actions'][:-1]));assert bt['predicted_physical_peak']==float(np.max(abs(pred))) and bt['observed_physical_peak']==float(np.max(abs(actual))) and bt['maximum_normalized_prediction_error']==float(np.max(abs(pred-actual)))
     assert bt['native_prefix_planning_admissible']==prefix_admissible
     if rank(candidate,m)<rank(z,m) and prefix_admissible:accepted=bt['forecast_index'];assert power==len(row['backtracks'])-1
   assert row['accepted']==accepted and row['center_after']==(row['center_before'] if accepted is None else accepted)
  with np.load(m['center_tape']['path']) as archive:source_center={k:archive[k] for k in archive.files}
  indices=np.asarray(m['optimization_action_indices'],int);nk=len(indices);arm=dict(basis='independent',parameters=nk);h=m['horizon'];basis=np.zeros((h,nk));basis[indices,np.arange(nk)]=1.;model_checks=0
  def spacing(actions):
   single=np.asarray(actions[:-1],np.float32);return np.maximum(np.nextafter(single,np.float32(np.inf)).astype(float)-single.astype(float),single.astype(float)-np.nextafter(single,np.float32(-np.inf)).astype(float))
  for model in r['secant_models']:
   z=loaded[model['center_before']];steps=spacing(z['actions'])[indices];eps=model['secant_ulps']*steps;assert model['optimization_action_indices']==indices.tolist() and model['secant_ulps'] in m['secant_ulps_grid'];same(model['epsilons'],eps);same(model['action_spacing'],steps);f=physical(z['states'][1:],m);valid=[];assert len(model['derivative_pairs'])==nk and len(model['column_diagnostics'])==nk
   assert r['private_forecasts'][model['center_before']]['runtime']==model['runtime']
   for k,((pi,mi),diag) in enumerate(zip(model['derivative_pairs'],model['column_diagnostics'],strict=True)):
    zp,zm=loaded[pi],loaded[mi];same(zp['feedforward'][:-1],(z['feedforward']+eps[k]*basis[:,k])[:-1]);same(zm['feedforward'][:-1],(z['feedforward']-eps[k]*basis[:,k])[:-1]);complete=len(zp['states'])==h+1 and len(zm['states'])==h+1
    action_index=int(indices[k]);matched=len(zp['actions'])>action_index and len(zm['actions'])>action_index and zp['actions'][action_index]==float(np.float32(z['actions'][action_index]+eps[k])) and zm['actions'][action_index]==float(np.float32(z['actions'][action_index]-eps[k]));expected=dict(parameter_index=k,action_index=action_index,complete=complete,matched_first_actions=bool(matched),plus_error=r['private_forecasts'][pi]['error'],minus_error=r['private_forecasts'][mi]['error'])
    assert r['private_forecasts'][pi]['runtime']==r['private_forecasts'][mi]['runtime']==model['runtime']
    same(zp['states'][:action_index+1],z['states'][:action_index+1]);same(zm['states'][:action_index+1],z['states'][:action_index+1]);same(zp['actions'][:action_index],z['actions'][:action_index]);same(zm['actions'][:action_index],z['actions'][:action_index])
    if complete:
     if matched:valid.append(k)
     fp,fm=physical(zp['states'][1:],m),physical(zm['states'][1:],m);expected.update(plus_center_maximum_feature_drift=float(np.max(abs(fp-f))),minus_center_maximum_feature_drift=float(np.max(abs(fm-f))),central_asymmetry_maximum=float(np.max(abs(fp+fm-2*f))),plus_changed_prefix_inputs=int(np.count_nonzero(zp['actions'][:-1]!=z['actions'][:-1])),minus_changed_prefix_inputs=int(np.count_nonzero(zm['actions'][:-1]!=z['actions'][:-1])),plus_raw_peak=float(np.max(abs(zp['raw_actions']))),minus_raw_peak=float(np.max(abs(zm['raw_actions']))))
    assert diag==expected
   assert model['valid_parameter_indices']==valid;model_checks+=1
  def checked_proposal(row,radius,center,runtime):
   assert row['center_before']==center and row['radius_ulps']==radius and row['runtime']==runtime;model=r['secant_models'][row['secant_model_index']];assert model['center_before']==center and model['derivative_pairs']==row['derivative_pairs'] and model['runtime']==runtime and row['secant_ulps']==model['secant_ulps'];same(row['derivative_epsilons'],model['epsilons']);same(row['trust_radii'],radius*np.asarray(model['action_spacing']));verify_proposal(row,arm)
  used_rebases=[]
  def checked_rebase(parent,runtime,event):
   matches=[q for q in r['rebases'] if q['parent_forecast']==parent and q['runtime']==runtime and q['event']==event];assert len(matches)==1;rb=matches[0];used_rebases.append(rb);context=r['reference_contexts'][rb['context_index']];assert context['parent_forecast']==parent and context['event']==event and context['runtime']==runtime;zp=loaded[parent];zr=loaded[rb['forecast_index']];same(contexts[rb['context_index']]['states'],zp['states']);same(contexts[rb['context_index']]['actions'],zp['actions']);same(zr['feedforward'][:-1],zp['actions'][:-1]);same(zr['states'][:-1],zp['states'][:-1]);same(zr['actions'][:-1],zp['actions'][:-1]);assert r['private_forecasts'][rb['forecast_index']]['reference_context']==rb['context_index'] and rank(zr,m)<=rank(zp,m);return rb['forecast_index']
  selected_outcomes=[]
  assert [ar['runtime'] for ar in r['arms']]==m['runtimes']
  for ar in r['arms']:
   runtime=ar['runtime'];zi=loaded[ar['initial_forecast']];same(zi['states'][:-1],source_center['states'][:-1]);same(zi['actions'][:-1],source_center['actions'][:-1]);same(zi['feedforward'][:-1],source_center['actions'][:-1]);ci=r['private_forecasts'][ar['initial_forecast']]['reference_context'];assert r['reference_contexts'][ci]['parent_forecast'] is None and r['reference_contexts'][ci]['event']=='initial';same(contexts[ci]['states'],source_center['states']);same(contexts[ci]['actions'],source_center['actions']);assert rank(zi,m)[2]<=float(np.max(abs(physical(source_center['states'][1:],m))))
   best_index=ar['initial_forecast'];best_case=None;assert len(ar['calibrations'])==len(m['secant_ulps_grid'])*len(m['locality_filters'])*len(m['trust_ulps'])
   for i,row in enumerate(ar['calibrations']):
    assert row['secant_ulps']==m['secant_ulps_grid'][i//(len(m['locality_filters'])*len(m['trust_ulps']))];assert row['locality_filter']==m['locality_filters'][(i//len(m['trust_ulps']))%len(m['locality_filters'])];radius=m['trust_ulps'][i%len(m['trust_ulps'])];checked_proposal(row,radius,ar['initial_forecast'],runtime)
    if i%(len(m['locality_filters'])*len(m['trust_ulps'])):assert row['secant_model_index']==ar['calibrations'][i-1]['secant_model_index']
    if rank(loaded[row['center_after']],m)<rank(loaded[best_index],m):best_index=row['center_after'];best_case=i
   assert best_case==ar['selected_calibration_case']
   if best_case is None:assert not ar['refinement']
   else:
    chosen=ar['calibrations'][best_case];best_index=checked_rebase(best_index,runtime,'calibration_selected')
    for iteration,row in enumerate(ar['refinement']):
     assert row['locality_filter']==chosen['locality_filter'] and row['secant_ulps']==chosen['secant_ulps'];assert row['iteration']==iteration and rank(loaded[best_index],m)[1]!=0;checked_proposal(row,chosen['radius_ulps'],best_index,runtime);best_index=checked_rebase(row['center_after'],runtime,f'refinement_{iteration}') if row['accepted'] is not None else row['center_after']
     if row['accepted'] is None:assert iteration==len(ar['refinement'])-1
   assert best_index==ar['selected_forecast'] and len(ar['refinement'])<=m['refinement_iterations'] and ar['selected_score']==rank(loaded[best_index],m);selected_outcomes.append(dict(runtime=runtime,selected_calibration_case=best_case,score=rank(loaded[best_index],m),final_next_angle=float(np.max(abs(wrap_angle(np.cumsum(loaded[best_index]['states'][-1,1:16]))))),selected_force_newtons=float(loaded[best_index]['actions'][-1])*80))
  assert used_rebases==r['rebases'] and len(contexts)==len(m['runtimes'])+len(used_rebases)
  assert r['selected_arm']==min(range(len(r['arms'])),key=lambda i:tuple(r['arms'][i]['selected_score']))
  om=m['maintenance'];maintenance_by_label={}
  for d in r['maintenance_decisions']:
   assert d['tape']==file_metadata(d['tape']['path'])
   with np.load(d['tape']['path']) as archive:z={k:archive[k] for k in archive.files}
   os=z['states'];oa=z['actions'];raws=z['raw_actions'];assert all(e is None for e in d['errors'])
   for pair,u,raw in zip(os,oa,raws,strict=True):assert float(np.float32(np.clip(raw,-1,1)))==u;same(native(pair[0],float(u)),pair[1])
   mi,pi=d['first_minus_id'],d['first_plus_id'];state=os[mi,0];same(os[pi,0],state);assert oa[mi]==-1 and oa[pi]==1;minus,plus=maintenance_features(os[mi,1],om),maintenance_features(os[pi,1],om);proposal=bounded_affine_minimax(minus,plus);assert proposal==d['proposal'];maxgap=max(maxgap,lp_gap(minus,plus,proposal));scalar_checks+=1;raw=gainraw(gain,state);assert raw==d['gain_raw'];source=float(U[d['tick']]) if d['tick']<len(U) else 0.;assert source==d['source_action'];values=[proposal,-1.,1.,0.,source,d['last_action']]+[proposal+(np.clip(raw,-1,1)-proposal)/(2**p) for p in range(om['backoff_powers'])];commands=[];prs=[];seen=set()
   for v in values:
    u=float(np.float32(np.clip(v,-1,1)));key=np.float32(u).tobytes()
    if key not in seen:seen.add(key);commands.append(u);prs.append(float(v))
   same(z['candidate_actions'],commands);same(z['candidate_raw_proposals'],prs);scores=[]
   for i,c in enumerate(d['candidates']):
    fi,sm,sp,si=c['first_id'],c['second_minus_id'],c['second_plus_id'],c['second_id'];assert oa[fi]==commands[i];same(os[fi,0],state);same(os[sm,0],os[fi,1]);same(os[sp,0],os[fi,1]);same(os[si,0],os[fi,1]);assert oa[sm]==-1 and oa[sp]==1;minus,plus=maintenance_features(os[sm,1],om),maintenance_features(os[sp,1],om);raw2=bounded_affine_minimax(minus,plus);assert c['second_raw']==raw2==raws[si];maxgap=max(maxgap,lp_gap(minus,plus,raw2));scalar_checks+=1;score=[0,float(max(np.max(abs(maintenance_features(os[fi,1],om))),np.max(abs(maintenance_features(os[si,1],om))))),abs(float(commands[i]))];assert score==c['score'];scores.append(tuple(score))
   winner=min(range(len(scores)),key=lambda i:scores[i]);assert winner==d['winner_index'];d=dict(d,verified_action=commands[winner],verified_prediction=os[d['candidates'][winner]['first_id'],1]);maintenance_by_label.setdefault(d['label'],{})[d['tick']]=d
  actual_ticks=0
  for row in r['actual_records']:
   assert row['tape']==file_metadata(row['tape']['path'])
   with np.load(row['tape']['path']) as z:xs=z['states'];us=z['actions'];raws=z['raw_actions']
   selected=loaded[row['selected_forecast_index']];ci=r['private_forecasts'][row['selected_forecast_index']]['reference_context'];reference=contexts[ci]['states'];runtime_gains=r['reference_contexts'][ci]['gain_scale']*K;h=row['horizon'];same(xs[:start+1],X[:start+1]);same(xs[start:start+h+1],selected['states']);safe=np.max(abs(wrap_angle(np.cumsum(xs[1:,1:16],axis=1))),axis=1)<.15;streak=longest=0
   for tick,u in enumerate(us):
    if tick<start:raw=float(U[tick]);assert u==raw
    elif tick<start+h:
     i=tick-start;raw=float(selected['feedforward'][i])+float(runtime_gains[i]@(xs[tick]-reference[i])) if i<track else float(selected['feedforward'][i]);assert float(np.float32(np.clip(raw,-1,1)))==u
    else:
     d=maintenance_by_label[row['label']][tick];assert d['last_action']==us[tick-1] and d['verified_action']==u;same(xs[tick+1],d['verified_prediction']);raw=u
    assert raw==raws[tick];same(native(xs[tick],float(u)),xs[tick+1]);streak=streak+1 if safe[tick] else 0;longest=max(longest,streak)
   maxcart=float(np.max(abs(xs[:,0])));assert len(us)==row['actual_hanging_start_episode_steps'] and longest*.02==row['hold_seconds'] and maxcart==row['maximum_cart'];passed=len(us)==1500 and longest>=250 and maxcart<=3 and row['termination_reason']=='time_limit' and not row['simulation_error'];assert row['full_nominal_gate_passed']==passed
   if row['termination_reason']=='rail_violation':assert abs(xs[-1,0])>3
   elif row['termination_reason']=='time_limit':assert len(us)==1500 and maxcart<=3
   else:raise AssertionError('Unexpected actual failure requires explicit audit')
   actual_ticks+=len(us);outcomes.append({k:row[k] for k in ('label','horizon','hold_seconds','maximum_cart','termination_reason','actual_hanging_start_episode_steps','full_nominal_gate_passed','tape')})
  complete_projections=sum(q.get('status')!='failed_anchors' for q in r['force_projections'])
  assert actual_ticks==r['actual_hanging_start_episode_steps'];assert native.evaluations+actual_ticks-complete_projections==r['total_native_transition_calls'];assert count[0]+4*actual_ticks-4*complete_projections==acc['native_physics_substeps'];assert native.evaluations<=m['audit_native_transition_ceiling'];dump_json(dict(status='finished',passed=True,generated_at=utc_timestamp(),scope=m['scope'],outcomes=outcomes,reference_contexts_proved=len(contexts),native_prefix_preserving_rebases_proved=len(used_rebases),private_forecasts_proved=len(loaded),private_errors_proved=failed,failed_private_poststates_and_times_proved=True,selected_outcomes=selected_outcomes,calibration_cases_proved=sum(len(ar['calibrations']) for ar in r['arms']),secant_model_diagnostics_proved=model_checks,refinement_rounds_proved=sum(len(ar['refinement']) for ar in r['arms']),force_projections_proved=len(r['force_projections']),tail_native_oracles_proved=tail_oracle_calls,tail_scalar_affine_optimality_checks=tail_scalar_checks,tail_maximum_scalar_optimality_gap=tail_maxgap,golden_histories_and_selection_proved=True,trust_lp_reexports_and_primal_feasibility_checks=lp_checks,trust_lp_optimality_scope='Shared HiGHS proposal re-export and independently calculated primal/trust/action/epigraph feasibility; no independent multivariate optimality certificate.',maintenance_decisions_proved=len(r['maintenance_decisions']),maintenance_scalar_affine_optimality_checks=scalar_checks,maximum_scalar_relative_affine_optimality_gap=maxgap,total_native_transition_calls=count[0]/4,native_physics_substeps=count[0],attempted_transition_calls=native.evaluations,actual_hanging_start_episode_steps=0,source_actual_ticks_proved=actual_ticks,all_actual_and_private_native_tapes_actions_history_gates_verified=True,source_accounting=file_metadata(root/'execution/inclusive_accounting.json')),out/'result.json');print(dict(calls=native.evaluations,outcomes=outcomes,forecasts=len(loaded),lp_checks=lp_checks),flush=True)
 finally:env.close();mujoco.mj_step=old
if __name__=='__main__':main()
