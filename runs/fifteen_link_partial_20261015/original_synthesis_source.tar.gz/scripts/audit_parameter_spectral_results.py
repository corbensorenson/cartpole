"""Read-only verification of spectral maps, corrected summaries and native pilot."""
import json
from pathlib import Path
import numpy as np
import mpmath
from gcartpole.angles import wrap_angle
from gcartpole.evidence import file_metadata,utc_timestamp


def main():
    rows=[];ctx=mpmath.mp.clone();ctx.dps=100
    for name,count,script in (
        ('parameter_eigenstructure_20261003_damping_schema',129,'map_parameter_eigenstructure.py'),
        ('parameter_eigenstructure_20261003_verified',129,'verify_parameter_eigenstructure.py'),
        ('parameter_feedback_transients_20261003',24,'analyze_parameter_feedback_transients.py'),
        ('spectral_parameter_interactions_20261003',8,'compare_spectral_parameter_interactions.py')):
        directory=Path('runs')/name;journal=json.loads((directory/'execution.json').read_text())
        assert journal['status']=='finished' and journal['returncode']==0
        for ref in journal['frozen_inputs']:assert file_metadata(directory/'snapshot'/ref['path'])['sha256']==ref['sha256']
        result=directory/'diagnostic/result.json';d=json.loads(result.read_text());assert len(d['records'])==count
        snap=file_metadata(directory/'snapshot/scripts'/script);assert snap['sha256']==d['script']['sha256']
        assert not d['canonical_release_evidence'] and not d['reserved_seeds_used'] and d['not_solution']
        item=dict(directory=str(directory),result=file_metadata(result),execution=file_metadata(directory/'execution.json'),
                  frozen_script=snap,records=count,not_solution=True,canonical_release_evidence=False,reserved_seeds_used=False)
        if 'damping_schema' in name:
            assert all(ctx.mpf(r['spectrum']['normalized_backward_gram_condition'])==0 for r in d['records'])
            assert all(ctx.mpf(v)>0 for r in d['records'] for v in r['spectrum']['normalized_backward_gram_eigenvalues'])
            item.update(total_native_transition_calls=0,raw_condition_summaries_are_invalid=True,
                        frozen_spectral_code=file_metadata(directory/'snapshot/src/gcartpole/spectral_geometry.py'))
        elif 'verified' in name:
            assert d['independent_gramian_spectra_verified']==129 and d['source']==file_metadata(d['source']['path'])
            for r in d['records']:
                assert file_metadata(r['config']['path'])==r['config'];s=r['spectrum'];v=[ctx.mpf(x) for x in s['normalized_backward_gram_eigenvalues']]
                assert min(v)>0 and len(v)==r['n_links']
                assert abs(ctx.mpf(s['normalized_backward_gram_condition'])-max(v)/min(v))/ctx.mpf(s['normalized_backward_gram_condition'])<ctx.mpf('1e-95')
                assert ctx.mpf(s['log_determinant_identity_error'])<ctx.mpf('1e-33')
                assert ctx.mpf(s['original_eigenvalues_relative_reproduction_error'])<ctx.mpf('1e-40')
            item.update(total_native_transition_calls=0,all129_positive_and_independently_recomputed=True,
                binary64_nonpositive_count=sum(not r['spectrum']['binary64_normalized_gram_spectrum_positive'] for r in d['records']),
                frozen_spectral_code=file_metadata(directory/'snapshot/src/gcartpole/spectral_geometry.py'))
        elif 'transients' in name:
            episodes=sum(len(r['episodes']) for r in d['records']);assert episodes==144
            for r in d['records']:
                assert ctx.mpf(r['rounded_gain_model_spectral_radius'])<1
                for e in r['episodes']:
                    assert e['tape']==file_metadata(e['tape']['path'])
                    assert all(ctx.mpf(h['decomposition_identity_error'])<ctx.mpf('1e-75')*max(ctx.mpf(h['native_state_norm']),ctx.mpf(1)) for h in e['history'])
            item.update(total_native_transition_calls=0,existing_tapes_analyzed=144)
        else:
            actual=proof=episodes=repeats=passes=0;tapes=[]
            for r in d['records']:
                assert r['config']==file_metadata(r['config']['path']);dt=.005*r['frame_skip']
                for e in r['episodes']:
                    assert e['tape']==file_metadata(e['tape']['path']);tapes.append(e['tape']);episodes+=1
                    assert e['steps']==e['actual_local_episode_steps']==e['independent_tape_replay_transition_calls']
                    assert e['total_native_transition_calls']==2*e['steps'] and e['independent_tape_replay_bytes_exact']
                    with np.load(e['tape']['path']) as tape:
                        states=tape['states'];actions=tape['actions'];n=r['n_links']
                        assert states.shape==(e['steps']+1,2*(n+1)) and actions.shape==(e['steps'],)
                        assert np.all(np.isfinite(states)) and np.all(np.isfinite(actions)) and np.all(np.abs(actions)<=1)
                        assert actions.tobytes()==actions.astype(np.float32).astype(float).tobytes()
                        maximum=streak=0
                        for upright in np.max(np.abs(wrap_angle(np.cumsum(states[1:,1:n+1],axis=1))),axis=1)<.15:
                            streak=streak+1 if upright else 0;maximum=max(maximum,streak)
                        assert abs(maximum*dt-e['sampled_physical_hold_seconds'])<1e-12
                        gate=bool(e['steps']==round(30/dt) and e['termination_reason']=='time_limit' and maximum*dt>=5 and np.max(np.abs(states[:,0]))<=3)
                        assert gate==e['local_full_episode_gate_passed'];passes+=gate
                    actual+=e['steps'];proof+=e['steps'];repeats+=e.get('original_baseline_states_actions_and_call_counts_byte_exact',False)
            assert episodes==32 and repeats==4 and actual==proof==81852
            assert d['total_native_transition_calls']==actual+proof==163704<=d['native_transition_ceiling']
            assert d['actual_hanging_start_episode_steps']==0
            item.update(total_native_transition_calls=163704,actual_local_episode_steps=actual,
                independent_tape_replay_transition_calls=proof,episodes=32,passes=int(passes),exact_repeated_baseline_tapes=4,
                tapes=tapes,frozen_helper=file_metadata(directory/'snapshot/scripts/map_parameter_capture_redesign.py'),
                frozen_spectral_code=file_metadata(directory/'snapshot/src/gcartpole/spectral_geometry.py'))
        rows.append(item)
    failed=Path('runs/parameter_eigenstructure_20261003');j=json.loads((failed/'execution.json').read_text())
    assert j['status']=='failed' and j['returncode']==1
    assert "KeyError: 'joint_damping'" in (failed/'output.log').read_text()
    assert not list((failed/'diagnostic/configs').glob('*.json'))
    rows.append(dict(directory=str(failed),execution=file_metadata(failed/'execution.json'),
                    frozen_script=file_metadata(failed/'snapshot/scripts/map_parameter_eigenstructure.py'),
                    output=file_metadata(failed/'output.log'),total_native_transition_calls=0,
                    failure='Wrong damping key during case declaration, before any plant analysis or physics. Corrected morphology.start/end.total_damping in new execution.',
                    status='failed',not_solution=True,canonical_release_evidence=False))
    figures=Path('runs/parameter_eigenstructure_20261003_verified/diagnostic/figures/figures.json');f=json.loads(figures.read_text())
    for ref in f['figures']:assert ref==file_metadata(ref['path'])
    result=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),studies=rows,figures=file_metadata(figures),
                passed=True,total_new_native_transition_calls=163704,native_transition_calls_for_this_audit=0,
                scope='Read-only source snapshot/hash/spectral consistency/algebraic decomposition/physical sampled gate and accounting verification; no additional behavior replay.')
    path=Path('runs/parameter_eigenstructure_20261003_verified/parameter_spectral_results_verified.json')
    path.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='studies'}))


if __name__=='__main__':main()
