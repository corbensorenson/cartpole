#!/usr/bin/env python
"""Compare whole-horizon replanning with a fixed verified suffix extension."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.ilqr import MujocoTransition
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.native_task_derivatives import physical_task_residual,chained_physical_task_jacobian
from gcartpole.native_sequence_feasibility import restore_native_sequence,extend_verified_native_sequence
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-inputs',required=True);parser.add_argument('--directory',required=True)
    parser.add_argument('--max-function-evaluations',type=int,default=20)
    parser.add_argument('--rate-residual-weight',type=float,default=1.)
    parser.add_argument('--search-methods',nargs='+',choices=('whole_horizon','fixed_suffix_extension'),default=['whole_horizon','fixed_suffix_extension'])
    args=parser.parse_args();out=Path(args.directory)
    if not np.isfinite(args.rate_residual_weight) or args.rate_residual_weight<=0:
        raise ValueError('finite positive rate residual weight required')
    if (out/'result.json').exists():raise FileExistsError(out)
    inputs=json.loads(Path(args.plan_inputs).read_text());records=[];began=time.monotonic()
    total_native=total_derivative=0
    for case in inputs['cases']:
        for key in ('source','config','teacher'):
            if file_metadata(case[key]['path'])!=case[key]:raise ValueError('Bound plan inputs changed')
        source=json.loads(Path(case['source']['path']).read_text());teacher=json.loads(Path(case['teacher']['path']).read_text())
        cfg=load_config(case['config']['path']);n=cfg['env']['n_links'];nx=2*(n+1)
        if (teacher['source']!=case['source'] or teacher['config']!=case['config']
                or not teacher['inherited_prefix_states_and_actions_bit_identical']
                or teacher['physical_tape_diagnostics']['maximum_dynamics_defect']!=0.):
            raise ValueError('Source-aligned independently verified teacher required')
        env=NLinkCartPoleEnv(fixed_state_cfg(cfg,source['selected_state'],30.),progress=1.,seed=source['seed'])
        env.reset(seed=source['seed'])
        native=MujocoTransition(env,np.eye(nx),continuous_angles=True)
        local=FourthOrderMujocoTransition(env,np.eye(nx),continuous_angles=True)
        untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
        row=case['first_plan'];step=row['step'];u=np.asarray(row['diagnostic']['selected_sequence'],np.float32).astype(float)
        horizon=len(u);commit=16
        if horizon!=32 or not row['diagnostic']['feasible_sequence_found']:raise ValueError('Verified H32 first plan required')
        actual=source['result']['trajectory'][step-1]
        initial=np.asarray(actual['qpos']+actual['qvel']);current=initial.copy();predictions=[]
        for action in u:current=native(current,float(action));predictions.append(current.copy())
        predictions=np.asarray(predictions)
        def admissible(states):
            return bool(np.all(np.abs(states[:,0])<=env.rail_limit) and
                np.max(np.abs(wrap_angle(np.cumsum(states[:,1:n+1],axis=1))))<.14)
        if not admissible(predictions):raise ValueError('Captured first plan is not natively angle-admissible')
        actual_angle=float(np.max(np.abs(wrap_angle(np.cumsum(predictions[:,1:n+1],axis=1)))))
        if actual_angle!=row['diagnostic']['maximum_predicted_absolute_angle']:
            raise ValueError('Captured first plan prediction differs from original execution')
        residual=lambda states:physical_task_residual(states,n,args.rate_residual_weight,.1)
        jac=lambda state,actions,states:chained_physical_task_jacobian(local,state,actions,states,
            n_links=n,rate_weight=args.rate_residual_weight,state_epsilon=source['controller']['state_epsilon'],
            action_epsilon=source['controller']['action_epsilon'],angle_band=.1)
        ref=np.asarray(source['controller']['controls'][step+commit:step+commit+horizon])
        teach=np.asarray([r['action'] for r in teacher['result']['trajectory'][step+commit:step+commit+horizon]],np.float32).astype(float)
        if len(ref)!=horizon or len(teach)!=horizon:raise ValueError('Unpadded aligned source/teacher inputs required')
        suffix=u[commit:];expected=predictions[commit:];state=predictions[commit-1]
        methods=[]
        try:
            for method in args.search_methods:
                before=native.evaluations;derivative_before=local.evaluations;started=time.monotonic()
                if method=='whole_horizon':
                    seeds=[ref,np.r_[suffix,np.zeros(commit)],teach]
                    selected,diag=restore_native_sequence(native,state,seeds,reference_actions=ref,
                        constraint_residual=residual,admissible=admissible,constraint_jacobian=jac,
                        max_evaluations=args.max_function_evaluations,action_regularization=.01)
                else:
                    seeds=[ref[len(suffix):],np.zeros(commit),teach[len(suffix):]]
                    selected,diag=extend_verified_native_sequence(native,state,suffix,expected,seeds,
                        reference_actions=ref[len(suffix):],constraint_residual=residual,admissible=admissible,
                        constraint_jacobian=jac,max_evaluations=args.max_function_evaluations,action_regularization=.01)
                if native.evaluations-before!=diag['native_transition_calls']:raise ValueError('Planning budget mismatch')
                forecast=diag.pop('selected_states');replay_calls=0;gap=None
                if selected is not None:
                    check=state.copy();replayed=[]
                    for action in selected:check=native(check,float(action));replayed.append(check.copy())
                    replay_calls=len(selected)
                    gap=float(np.max(np.abs(np.asarray(replayed)-np.asarray(forecast))))
                    if gap!=0. or not admissible(np.asarray(replayed)):raise ValueError('Selected native plan failed exact replay')
                methods.append(dict(method=method,feasible_sequence_found=selected is not None,
                    selected_sequence=None if selected is None else selected.tolist(),selected_states=forecast,
                    maximum_predicted_absolute_angle=None if forecast is None else float(np.max(np.abs(wrap_angle(np.cumsum(np.asarray(forecast)[:,1:n+1],axis=1))))),
                    maximum_predicted_absolute_rate=None if forecast is None else float(np.max(np.abs(np.cumsum(np.asarray(forecast)[:,n+2:],axis=1)))),
                    native_planning_transition_calls=diag['native_transition_calls'],
                    independent_selected_plan_replay_transition_calls=replay_calls,maximum_selected_plan_replay_defect=gap,
                    native_local_derivative_transition_calls=local.evaluations-derivative_before,
                    wall_seconds=time.monotonic()-started,diagnostic=diag))
                print(json.dumps(dict(start_step=step,method=method,feasible=selected is not None,
                    planning_calls=diag['native_transition_calls'],derivative_calls=local.evaluations-derivative_before)),flush=True)
            if not np.array_equal(untouched,np.r_[env.data.qpos,env.data.qvel]):raise ValueError('Forecast search changed live simulator state')
            records.append(dict(start_step=step,source=case['source'],config=case['config'],teacher=case['teacher'],
                prefix_plan_native_transition_calls=horizon,first_plan_matches_original_native_angle_summary=True,
                forecast_endpoint_absolute_angle_max=float(np.max(np.abs(wrap_angle(np.cumsum(predictions[-1,1:n+1]))))),
                forecast_endpoint_absolute_rate_max=float(np.max(np.abs(np.cumsum(predictions[-1,n+2:])))),
                live_simulator_state_unchanged=True,methods=methods))
        finally:
            total_native+=native.evaluations;total_derivative+=local.evaluations;env.close()
    dump_json(dict(not_solution=True,canonical_release_evidence=False,parameters=vars(args),plan_inputs=file_metadata(args.plan_inputs),
        records=records,native_forecast_transition_calls=total_native,native_local_derivative_transition_calls=total_derivative,
        total_native_transition_calls=total_native+total_derivative,wall_seconds=time.monotonic()-began,
        runtime=runtime_metadata(),reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Fixed actual source states and recorded admissible first plans. Search methods use native angle admissibility, band0.10,the declared rate weight/evaluation budget,three aligned seeds and composed native4/MP100 derivatives. Extension fixes16 known inputs and optimizes16 new inputs at the independently forecast endpoint; its residual excludes the fixed prefix. This changes search dimension,objective horizon and seed alignment together. No executed episode or recursive viability is inferred.'),out/'result.json')


if __name__=='__main__':main()
