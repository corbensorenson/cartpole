"""Read-only audit of step-size versus additional-iteration native comparisons."""
import argparse,json
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json,load_config
from gcartpole.evidence import file_metadata,utc_timestamp
from scripts.audit_armature_route_increment import journal,checked,tape,read


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',required=True);args=p.parse_args();root=Path(args.directory)
    checked(file_metadata(root/'verified.json'));previous=read(root/'verified.json');assert previous['passed']
    rows=[];total=actual=0;passing=[]
    source0='runs/armature_route_continuation_20261003/armature0.99_passing_physical_initializer.json'
    cases=[('armature0.98_repair16','armature0.98_repair16_native_defect_feedback','armature0.98_repair16_handoff_screen',.98,root/'armature0.98_repair8/diagnostic/candidate.json'),
           ('armature0.989_repair8','armature0.989_repair8_native_defect_feedback','armature0.989_repair8_handoff_screen',.989,Path(source0))]
    for repair_name,feedback_name,screen_name,ratio,initial in cases:
        folder=root/repair_name;e=journal(folder);d=read(folder/'diagnostic/result.json')
        assert d['status']=='finished' and d['initializer']==file_metadata(initial) and d['optimizer_iterations']==8
        for key in ('candidate','config','initializer'):checked(d[key])
        cfg=load_config(d['config']['path']);assert cfg['env']['joint_armature']==.0005*ratio
        expected=load_config(root/'armature0.99.json');cfg['env']['joint_armature']=expected['env']['joint_armature'];assert cfg==expected
        x,u,gate=tape(d);candidate=read(d['candidate']['path']);assert candidate['controller']['frozen_prefix_steps']==0
        assert candidate['selected_state']==read(source0)['selected_state']
        assert d['partial_transition_substeps']==0 and d['native_physics_substeps']==4*d['total_native_transition_calls']
        total+=d['total_native_transition_calls'];actual+=len(u)
        rows.append(dict(directory=str(folder),execution=e,result=file_metadata(folder/'diagnostic/result.json'),
            candidate=d['candidate'],config=d['config'],initializer=d['initializer'],tape=d['tape'],
            total_native_transition_calls=d['total_native_transition_calls'],actual_hanging_start_episode_steps=len(u),
            full_nominal_component_gate_passed=gate,maximum_model_defect=candidate['controller']['final_trajectory_diagnostics']['maximum_dynamics_defect'],
            median_model_defect=candidate['controller']['final_trajectory_diagnostics']['median_dynamics_defect']))
        ff=root/feedback_name;ej=journal(ff);f=read(ff/'diagnostic/result.json');assert f['status']=='finished'
        assert f['source']==d['candidate'] and f['config']==d['config']
        for key in ('source','config','reference'):checked(f[key])
        ref=np.load(f['reference']['path']);assert np.array_equal(ref['states'],np.array(candidate['search']['nominal_coordinate_states']))
        assert np.array_equal(ref['controls'],np.array(candidate['controller']['controls']))
        assert np.array_equal(ref['defects'],ref['native_predictions']-ref['states'][1:])
        assert f['native_reference_design_calls']==88900 and f['upright_gain_design_calls']==62
        assert f['partial_transition_substeps']==0 and f['native_physics_substeps']==4*f['total_native_transition_calls']
        for r in f['records']:tape(r)
        total+=f['total_native_transition_calls'];actual+=f['actual_hanging_start_episode_steps']
        rows.append(dict(directory=str(ff),execution=ej,result=file_metadata(ff/'diagnostic/result.json'),
            config=f['config'],source=f['source'],reference=f['reference'],records=f['records'],
            total_native_transition_calls=f['total_native_transition_calls'],actual_hanging_start_episode_steps=f['actual_hanging_start_episode_steps'],
            maximum_native_reference_defect=f['maximum_native_reference_defect'],maximum_feedforward_offset=f['maximum_feedforward_offset']))
        sf=root/screen_name;affine=next(r for r in f['records'] if r['affine'])
        available=[sec for sec in range(6,14) if sec*50<=affine['actual_hanging_start_episode_steps']]
        if sf.exists():
            es=journal(sf);s=read(sf/'diagnostic/result.json');assert s['source']==file_metadata(ff/'diagnostic/result.json')
            assert s['handoff_seconds']==available
            prefix=np.load(affine['tape']['path'])
            for r in s['records']:
                xx,uu,gg=tape(r);steps=round(r['handoff_seconds']/.02)
                assert xx[:steps+1].tobytes()==prefix['states'][:steps+1].tobytes() and uu[:steps].tobytes()==prefix['actions'][:steps].tobytes()
                assert r['total_native_transition_calls']==2*len(uu)
                if gg:passing.append((repair_name,r,f))
            total+=s['total_native_transition_calls'];actual+=s['actual_hanging_start_episode_steps']
            rows.append(dict(directory=str(sf),execution=es,result=file_metadata(sf/'diagnostic/result.json'),
                records=s['records'],config=s['config'],total_native_transition_calls=s['total_native_transition_calls'],actual_hanging_start_episode_steps=s['actual_hanging_start_episode_steps']))
        else:assert not available
    assert total<=2288000
    payload=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),helper=file_metadata('scripts/audit_armature_route_increment.py'),
        passed=True,previous_batch=file_metadata(root/'verified.json'),studies=rows,
        total_new_native_transition_calls=int(total),actual_hanging_start_episode_steps=actual,
        combined_turn_native_transition_calls=previous['total_new_native_transition_calls']+int(total),
        combined_turn_actual_hanging_start_episode_steps=previous['actual_hanging_start_episode_steps']+actual,
        native_transition_calls_for_this_audit=0,not_solution=True,canonical_release_evidence=False,
        reserved_seeds_used=False,noisy_development_seeds_used=False,
        full_passing_handoffs=[dict(variant=a,handoff_seconds=b['handoff_seconds']) for a,b,_ in passing])
    if passing:
        name,r,f=min(passing,key=lambda item:(item[0]!='armature0.98_repair16',item[1]['handoff_seconds']))
        actual_tape=np.load(r['tape']['path']);steps=round(r['handoff_seconds']/.02);reference=np.load(f['reference']['path'])
        gains=np.vstack([reference['feedback_gains'][:steps],np.tile(-np.array(f['gain']),(700-steps,1))])
        path=root/(('armature0.98' if name=='armature0.98_repair16' else 'armature0.989')+'_passing_physical_initializer.json')
        dump_json(dict(selected_state=read(source0)['selected_state'],controller=dict(controls=actual_tape['actions'][:700].tolist(),
            feedback_gains=gains.tolist(),coordinate_transform=np.eye(30).tolist(),continuous_angles=True,physical_shooting=True,capture_start_seconds=9.),
            search=dict(nominal_coordinate_states=actual_tape['states'][:701].tolist()),source=f['source'],passing_tape=r['tape'],
            config=f['config'],seed=0,not_solution=True,initialization_only=True,selected_variant=name,selected_handoff_seconds=r['handoff_seconds'],
            scope='Actual700tick states/F32controls from a full30s passing target-plant altered14episode; physical continuation initializer only.'),path)
        payload['passing_physical_initializer']=file_metadata(path)
    dump_json(payload,root/'verified_step_iterations.json');print(json.dumps(dict(passed=True,total_native_calls=int(total),actual_steps=actual,passing=payload['full_passing_handoffs'])))

if __name__=='__main__':main()
