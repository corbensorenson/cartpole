"""Compare joint native projected previews at frozen local15 initial states."""
import argparse
import json
from pathlib import Path
import time
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata,utc_timestamp
from gcartpole.ilqr import MujocoTransition
from gcartpole.joint_projected_control import JointProjectedController
from gcartpole.upright_mechanics import upright_rk4_matrices
from scripts.search_capture_sequence import fixed_state_cfg


COMPARISONS=[
    ('two_receding',2,(0,1),1),
    ('two_committed',2,(0,1),2),
    ('four_receding',4,(0,1,2,3),1),
    ('four_long_projection',4,(0,1,2,4,8,16,32,64,100),1),
]
FORCE_AWARE_COMPARISONS=[
    ('guarded_response_target',dict(reference_mode='linear',projection_scaling='response',future_force_limit=1.)),
    ('guarded_force_target',dict(reference_mode='linear',projection_scaling='force',future_force_limit=1.)),
    ('guarded_zero_capture',dict(reference_mode='zero',projection_scaling='force',future_force_limit=1.)),
]
CONSTRAINT_COMPARISONS=[
    ('matched_projected',dict(reference_mode='linear',projection_scaling='force',future_force_limit=1.,correction_mode='projected')),
    ('restore_violations',dict(reference_mode='linear',projection_scaling='force',future_force_limit=1.,correction_mode='restore_violations')),
    ('minimize_peak',dict(reference_mode='linear',projection_scaling='force',future_force_limit=1.,correction_mode='minimize_peak')),
]
FULL_DELAYS=(0,1,2,3,4,6,8,10,12,16,20,24,32,48,64,100)
HORIZON_COMPARISONS=[
    ('matched_reserve_nine',4,(0,1,2,4,8,16,32,64,100)),
    ('reserve_four_full_projection',4,FULL_DELAYS),
    ('reserve_eight_full_projection',8,FULL_DELAYS),
    ('reserve_sixteen_full_projection',16,FULL_DELAYS),
]
CONTINUITY_COMPARISONS=[
    ('matched_restore',False,False),
    ('adaptive_only',True,False),
    ('warm_only',False,True),
    ('adaptive_warm',True,True),
]


def episode(cfg,initial,gain,a,b,horizon,delays,commit,controller_options=None):
    local=fixed_state_cfg(cfg,dict(qpos=initial[:16].tolist(),qvel=initial[16:].tolist()),30.)
    for key in ('init_qpos_scale_start','init_qpos_scale_end'):local['env'].pop(key,None)
    env=NLinkCartPoleEnv(local,progress=1.,seed=0);env.reset(seed=0)
    forecast=NLinkCartPoleEnv(cfg,progress=1.,seed=0);forecast.reset(seed=0)
    predictor=MujocoTransition(forecast,np.eye(32),continuous_angles=True)
    assert predictor.data is not env.data
    policy=JointProjectedController(predictor,a,b,gain,n_links=15,horizon=horizon,projection_delays=delays,
                                    **(controller_options or {}))
    initial_actual=np.r_[env.data.qpos,env.data.qvel]
    assert initial_actual.tobytes()==initial.tobytes()
    states=[initial_actual];actions=[];plans=[];first_failure=None
    longest=streak=0;maximum_angle=maximum_rate=maximum_cart=0.
    began=time.monotonic();finished=False
    try:
        while len(actions)<env.max_steps and not finished:
            before=predictor.evaluations
            sequence,expected,diag=policy.select(states[-1])
            assert predictor.evaluations-before==diag['native_transition_calls']
            plans.append(dict(start_step=len(actions),actions=sequence.tolist(),forecast=expected.tolist(),diagnostics=diag))
            for index in range(min(commit,horizon,env.max_steps-len(actions))):
                action=float(sequence[index])
                assert action==float(np.float32(action)) and abs(action)<=1
                _,_,terminated,truncated,info=env.step([action])
                current=np.r_[env.data.qpos,env.data.qvel]
                assert current.tobytes()==expected[index].tobytes()
                states.append(current);actions.append(action)
                angle=float(np.max(np.abs(wrap_angle(np.cumsum(current[1:16])))))
                rate=float(np.max(np.abs(np.cumsum(current[17:]))))
                maximum_angle=max(maximum_angle,angle);maximum_rate=max(maximum_rate,rate)
                maximum_cart=max(maximum_cart,abs(float(current[0])))
                streak=streak+1 if angle<.15 else 0;longest=max(longest,streak)
                if angle>=.15 and first_failure is None:first_failure=len(actions)*.02
                if terminated or truncated:
                    finished=True;break
        planning=predictor.evaluations
        for index,action in enumerate(actions):
            assert predictor(states[index],action).tobytes()==states[index+1].tobytes()
        proof=predictor.evaluations-planning
        assert proof==len(actions)
        ceiling=int(np.ceil(1500/commit))*policy.native_transition_ceiling_per_plan+3000
        assert planning+2*len(actions)<=ceiling
        return dict(steps=len(actions),physical_hold_seconds=longest*.02,first_angle_failure_seconds=first_failure,
            local_gate_pass=len(actions)==1500 and longest*.02>=5 and
                info['termination_reason']=='time_limit' and not info['simulation_error'],
            all_samples_upright=first_failure is None,maximum_angle=maximum_angle,
            maximum_absolute_rate=maximum_rate,maximum_cart=maximum_cart,
            maximum_delivered_action=max(abs(u) for u in actions),at_force_bound_steps=sum(abs(u)==1 for u in actions),
            termination_reason=info['termination_reason'],simulation_error=info['simulation_error'],
            every_committed_forecast_matches_live_bytes=True,independent_actual_tape_replay_bytes_exact=True,
            planning_transition_calls=planning,actual_local_episode_steps=len(actions),
            independent_actual_tape_replay_transition_calls=proof,total_native_transition_calls=planning+2*len(actions),
            native_transition_ceiling=ceiling,initial_state=initial.tolist(),actions=actions,
            states=[v.tolist() for v in states],plans=plans,wall_seconds=time.monotonic()-began)
    finally:
        env.close();forecast.close()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline',required=True);parser.add_argument('--spectral-component',required=True)
    parser.add_argument('--directory',required=True)
    parser.add_argument('--comparison-mode',choices=('model-following','force-aware','constraint','constraint-horizon','continuity'),default='model-following')
    parser.add_argument('--force-aware-component')
    parser.add_argument('--constraint-component')
    parser.add_argument('--gain-label',choices=('saved_baseline','moderately_separated_decay'))
    args=parser.parse_args();out=Path(args.directory)
    if args.comparison_mode in ('constraint','constraint-horizon','continuity') and not args.force_aware_component:
        parser.error('constraint comparison requires the frozen force-aware result')
    if args.comparison_mode in ('constraint-horizon','continuity') and not args.constraint_component:
        parser.error('horizon comparison requires the frozen constraint result')
    if out.exists():raise FileExistsError(out)
    out.mkdir(parents=True)
    baseline=json.loads(Path(args.baseline).read_text());spectral=json.loads(Path(args.spectral_component).read_text())
    assert spectral['baseline']==file_metadata(args.baseline)
    cache_ref=next(r for r in baseline['sources'] if r['path'].endswith('capture_cache.json'))
    assert cache_ref==file_metadata(cache_ref['path'])
    saved=json.loads(Path(cache_ref['path']).read_text())
    selected=next(r for r in spectral['records'] if r['label']=='moderately_separated_decay')
    assert selected['status']=='finished'
    gains=dict(saved_baseline=np.asarray(saved['gain']),moderately_separated_decay=np.asarray(selected['gain']))
    if args.gain_label:
        gains={args.gain_label:gains[args.gain_label]}
    direction=np.asarray(baseline['directions15'])[0]
    initial=np.zeros(32);initial[1:16]=1e-12*direction[:15];initial[17:]=1e-12*direction[15:]
    previous=None
    if args.force_aware_component:
        previous=json.loads(Path(args.force_aware_component).read_text())
        assert previous['baseline']==file_metadata(args.baseline)
        assert previous['spectral_component']==file_metadata(args.spectral_component)
        assert np.asarray(previous['initial_state']).tobytes()==initial.tobytes()
    previous_constraint=None
    if args.constraint_component:
        previous_constraint=json.loads(Path(args.constraint_component).read_text())
        assert previous_constraint['baseline']==file_metadata(args.baseline)
        assert previous_constraint['spectral_component']==file_metadata(args.spectral_component)
        assert np.asarray(previous_constraint['initial_state']).tobytes()==initial.tobytes()
    cfg=load_config('configs/swingup15_uniform.yaml')
    env=NLinkCartPoleEnv(cfg,progress=1.,seed=0);env.reset(seed=0)
    a,b,mechanics=upright_rk4_matrices(env,decimal_digits=100);env.close()
    comparisons=([(label,h,delays,commit,{}) for label,h,delays,commit in COMPARISONS]
        if args.comparison_mode=='model-following' else
        [(label,4,(0,1,2,4,8,16,32,64,100),1,options) for label,options in
         (CONSTRAINT_COMPARISONS if args.comparison_mode=='constraint' else FORCE_AWARE_COMPARISONS)])
    if args.comparison_mode=='constraint-horizon':
        options=dict(reference_mode='linear',projection_scaling='force',future_force_limit=1.,correction_mode='minimize_peak')
        comparisons=[(label,h,delays,1,options) for label,h,delays in HORIZON_COMPARISONS]
    if args.comparison_mode=='continuity':
        comparisons=[(label,4,(0,1,2,4,8,16,32,64,100),1,
            dict(reference_mode='linear',projection_scaling='force',future_force_limit=1.,
                correction_mode='restore_violations',adaptive_trust=adaptive,warm_start=warm))
            for label,adaptive,warm in CONTINUITY_COMPARISONS]
    ceiling=sum((int(np.ceil(1500/c))*(3*h+3*(4*h*h+4*h)+2*h*h+(h if options.get('warm_start') else 0))+3000)*len(gains)
                for _,h,_,c,options in comparisons)
    payload=dict(generated_at=utc_timestamp(),runtime=runtime_metadata(),parameters=vars(args),
        script=file_metadata(__file__),policy_code=file_metadata('src/gcartpole/joint_projected_control.py'),
        baseline=file_metadata(args.baseline),spectral_component=file_metadata(args.spectral_component),
        config=file_metadata('configs/swingup15_uniform.yaml'),mechanics=mechanics,
        comparisons=[dict(label=l,horizon=h,projection_delays=list(d),commit_steps=c,controller_options=o)
                     for l,h,d,c,o in comparisons],
        gains={k:v.tolist() for k,v in gains.items()},initial_state=initial.tolist(),records=[],
        total_native_transition_calls=0,planning_transition_calls=0,actual_local_episode_steps=0,
        independent_actual_tape_replay_transition_calls=0,native_transition_ceiling=ceiling,
        actual_hanging_start_episode_steps=0,optimizer_transition_calls=0,reserved_seeds_used=False,
        noisy_development_seeds_used=False,canonical_release_evidence=False,not_solution=True,
        scope='Local15 pilot episodes:two frozen gains and declared joint-projection/commitment or force-aware comparisons on first frozen positive direction1e-12. MP100 terminal projected residuals,three native-checked Newton rounds/five delivered derivative nodes per control,0.01trust/1e-5epsilon. Optional linear future feedback demand cap is a model search proxy,not a nonlinear certificate. Independent native forecast/live and whole-tape byte equality mandatory. No hanging-start,recursive feasibility,disturbance basin or real-time claim.')
    if previous is not None:
        payload['force_aware_component']=file_metadata(args.force_aware_component)
    if previous_constraint is not None:
        payload['constraint_component']=file_metadata(args.constraint_component)
    if args.comparison_mode in ('constraint','constraint-horizon','continuity'):
        payload['constraint_recipe']=dict(solver='HiGHS bounded minimax with original MP100 model check',
            solver_seconds_per_subproblem=1.,normalized_epigraph_check_tolerance=1e-7,
            explicit_rows='All native preview absolute angles/rates/cart, intermediate baseline feedback and declared delayed terminal baseline requests',
            projected_fallback_on_solver_rejection=True,
            native_transition_budget_matched_per_episode=args.comparison_mode!='continuity',
            modeled_requests_are_not_actual_joint_policy_future_actions=True)
    if args.comparison_mode=='continuity':
        payload['continuity_recipe']=dict(adaptive_initial_maximum_radius=.01,
            adaptive_minimum_radius=8e-5,shrink_factor=.25,expand_factor=2.,
            poor_row_error_threshold=.25,good_row_error_threshold=.1,
            row_error_scale='max(1,predicted normalized constraint peak)',
            poor_reduction_ratio=.25,good_reduction_ratio=.75,
            false_predicted_feasibility_always_shrinks=True,
            radius_persists_between_plans=True,
            warm_requires_previous_preview_feasible_and_measured_state_byte_match=True,
            warm_append='bounded F32 baseline request at previous terminal state',
            warm_cost_ceiling_extra_native_transitions_per_plan=4,
            common_inclusive_per_episode_budget=435000,
            cold_intrinsic_per_episode_ceiling=429000,warm_intrinsic_per_episode_ceiling=435000,
            scope='Separate adaptive-only, warm-only and combined arms, same3rounds and sources. '
                  'Warm candidates cost at most four additional native transitions per plan. '
                  'Measured model disagreement, not added iterations alone, controls trust. '
                  'Previous states are private predictions; no live state is replaced.')
    began=time.monotonic()
    for label,horizon,delays,commit,options in comparisons:
        for gain_label,gain in gains.items():
            result=episode(cfg,initial,gain,a,b,horizon,delays,commit,options)
            if label=='matched_projected':
                old=next(r for r in previous['records'] if r['label']=='guarded_force_target' and r['gain_label']==gain_label)
                for key in ('states','actions'):
                    assert np.asarray(result[key]).tobytes()==np.asarray(old['result'][key]).tobytes()
                assert result['planning_transition_calls']==old['result']['planning_transition_calls']
                result['previous_force_scaled_baseline_actions_states_and_call_counts_byte_exact']=True
            if label=='matched_reserve_nine':
                old=next(r for r in previous_constraint['records'] if r['label']=='minimize_peak' and r['gain_label']==gain_label)
                for key in ('states','actions'):
                    assert np.asarray(result[key]).tobytes()==np.asarray(old['result'][key]).tobytes()
                assert result['planning_transition_calls']==old['result']['planning_transition_calls']
                result['previous_minimax_reserve_actions_states_and_call_counts_byte_exact']=True
            if label=='matched_restore':
                old=next(r for r in previous_constraint['records'] if r['label']=='restore_violations' and r['gain_label']==gain_label)
                for key in ('states','actions'):
                    assert np.asarray(result[key]).tobytes()==np.asarray(old['result'][key]).tobytes()
                assert result['planning_transition_calls']==old['result']['planning_transition_calls']
                result['previous_restoration_actions_states_and_call_counts_byte_exact']=True
            payload['records'].append(dict(label=label,gain_label=gain_label,horizon=horizon,
                projection_delays=list(delays),commit_steps=commit,controller_options=options,result=result))
            for key in ('total_native_transition_calls','planning_transition_calls','actual_local_episode_steps',
                        'independent_actual_tape_replay_transition_calls'):payload[key]+=result[key]
            assert payload['total_native_transition_calls']<=payload['native_transition_ceiling']
            payload['wall_seconds']=time.monotonic()-began;dump_json(payload,out/'result.progress.json')
            print(json.dumps(dict(label=label,gain=gain_label,steps=result['steps'],hold=result['physical_hold_seconds'],
                pass30=result['local_gate_pass'],first_angle_failure=result['first_angle_failure_seconds'],
                calls=result['total_native_transition_calls'],totalcalls=payload['total_native_transition_calls'])),flush=True)
    payload['wall_seconds']=time.monotonic()-began;dump_json(payload,out/'result.json')


if __name__=='__main__':main()
