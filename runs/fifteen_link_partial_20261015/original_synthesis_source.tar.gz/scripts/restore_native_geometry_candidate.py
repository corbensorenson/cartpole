"""Natively verify representable proposals from a source-bound constraint geometry."""
import argparse,json,time
from collections import Counter
from itertools import islice
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.native_action_lattice import affine_action_lattice
from gcartpole.native_sparse_stream import fixed_span_supports
from gcartpole.native_sparse_integer import sparse_integer_minimax
from gcartpole.simulation import SimulationError
from gcartpole.native_task_derivatives import physical_task_residual,chained_physical_task_jacobian
from gcartpole.native_bound_objective import bound_diagnostics,native_bound_score
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.audit_native_null_constraint_geometry import source_support_spans


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('source','directory'):p.add_argument('--'+key,required=True)
    p.add_argument('--geometry',required=True)
    p.add_argument('--max-candidates',type=int,default=16)
    p.add_argument('--planning-transition-budget',type=int,default=1008)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    if min(args.max_candidates,args.planning_transition_budget)<1:raise ValueError('positive finite component budgets required')
    began=time.monotonic();source=json.loads(Path(args.source).read_text());params=source['parameters']
    if source['feasible_sequence_found'] or not source['live_state_unchanged']:raise ValueError('verified failing center required')
    spans=source_support_spans(source)
    geometry=json.loads(Path(args.geometry).read_text())
    if geometry['source']!=file_metadata(args.source) or not geometry['final_native_states_and_score_exact']:raise ValueError('source-aligned geometry required')
    if params['bound_objective']!='maximum':raise ValueError('verified maximum-objective source required')
    original=json.loads(Path(source['source']['path']).read_text());growth=original;ancestry=[];seen=set()
    if file_metadata(source['source']['path'])!=source['source']:raise ValueError('growth source changed')
    while not all(k in original for k in ('config','teacher','parameters')):
        ref=original['source']
        if ref['path'] in seen or len(ancestry)>=8 or file_metadata(ref['path'])!=ref:raise ValueError('changed/cyclic physical ancestry')
        seen.add(ref['path']);ancestry.append(ref);original=json.loads(Path(ref['path']).read_text())
    for key in ('source','config','teacher'):
        if file_metadata(original[key]['path'])!=original[key]:raise ValueError('physical input changed')
    cfg=load_config(original['config']['path']);n=cfg['env']['n_links'];nx=2*(n+1)
    base=json.loads(Path(original['source']['path']).read_text());step=original['parameters']['start_step'];rate=original['parameters']['rate_residual_weight']
    center=np.asarray(source['last_finite_center']);h=len(center);limit=params['forecast_angle_limit']
    ref=np.asarray(base['controller']['controls'][step:step+h],np.float32).astype(float)
    if len(ref)!=h:raise ValueError('unpadded physical reference required')
    spacing,lower,upper=affine_action_lattice(center,4096)
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True);local=FourthOrderMujocoTransition(env,np.eye(nx),continuous_angles=True)
    untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
    try:
        state=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
        for row in base['result']['trajectory'][:step]:
            state=native(state,float(np.float32(row['action'])))
            if state.tobytes()!=np.asarray(row['qpos']+row['qvel']).tobytes():raise ValueError('cold prefix changed')
        def forecast(actions):
            current=state.copy();states=[]
            for u in actions:current=native(current,float(u));states.append(current.copy())
            return np.asarray(states)
        known=forecast(np.asarray(growth['last_valid_plan']))
        if known.tobytes()!=np.asarray(growth['last_valid_forecast_states']).tobytes():raise ValueError('known plan changed')
        states=forecast(center);diagnostics=bound_diagnostics(states,n,limit,env.rail_limit)
        residual=physical_task_residual(states,n,rate,.1);cost=float(residual@residual+1e-4*np.sum((center-ref)**2))
        if (states.tobytes()!=np.asarray(source['last_finite_states']).tobytes()
                or list(native_bound_score(diagnostics,cost,params['bound_objective']))!=source['last_finite_score']):raise ValueError('final native states/score changed')
        groups=[sorted((r for r in geometry['records'] if r['cancelled_rank']==rank and 'best_rounded_offsets' in r),
            key=lambda r:(r['best_rounded_predicted_normalized_peak'],r['indices']))[:8] for rank in (3,2)]
        proposals=[]
        for index in range(8):
            for group in groups:
                if index<len(group):proposals.append(group[index])
        proposals=proposals[:args.max_candidates];records=[];score=tuple(source['last_finite_score'])
        selected=center.copy();selected_states=states.copy();found=False;cache={center.tobytes()};planning_before=native.evaluations
        def measure(candidate,actions):
            d=bound_diagnostics(candidate,n,limit,env.rail_limit);r=physical_task_residual(candidate,n,rate,.1)
            return native_bound_score(d,float(r@r+1e-4*np.sum((actions-ref)**2)),'maximum'),d
        for proposal in proposals:
            support=np.asarray(proposal['indices']);integers=np.asarray(proposal['best_rounded_offsets'])
            if (not np.issubdtype(support.dtype,np.integer) or support.shape!=(5,) or np.any(np.diff(support)<=0)
                    or support[0]<0 or support[-1]>=h or not np.issubdtype(integers.dtype,np.integer)
                    or integers.shape!=(5,) or np.any(integers<lower[support]) or np.any(integers>upper[support])):raise ValueError('bound geometry candidate differs from its delivered lattice')
            actions=center.copy();actions[support]+=spacing[support]*integers;key=actions.tobytes()
            if key in cache:continue
            if np.any(abs(actions)>1) or key!=actions.astype(np.float32).astype(float).tobytes():raise ValueError('candidate not delivered force-bounded F32')
            if native.evaluations-planning_before+h>args.planning_transition_budget:break
            cache.add(key);record=dict(indices=support.tolist(),offsets=integers.tolist(),cancelled_rank=proposal['cancelled_rank'],
                predicted_maximum_angle=proposal['best_rounded_predicted_maximum_angle']);records.append(record)
            try:
                candidate=forecast(actions);new_score,d=measure(candidate,actions)
                record.update(native_score=list(new_score),native_bound_diagnostics=d)
                if new_score<score:score=new_score;selected=actions.copy();selected_states=candidate.copy()
                if d['feasible']:found=True;break
            except SimulationError as error:record['invalid_forecast']=str(error)
        planning_calls=native.evaluations-planning_before;checked=forecast(selected)
        if checked.tobytes()!=selected_states.tobytes() or measure(checked,selected)[0]!=score:raise ValueError('independent final finite tape/score changed')
        if untouched.tobytes()!=np.r_[env.data.qpos,env.data.qvel].tobytes():raise ValueError('candidate search changed live state')
        data=dict(parameters=dict(**vars(args),forecast_angle_limit=limit,bound_objective='maximum',move_arity=5,support_spans=spans),
            source=source['source'],repaired_from=file_metadata(args.source),geometry=file_metadata(args.geometry),input_ancestry=ancestry,
            records=records,horizon_steps=h,initial_sequence=center.tolist(),initial_score=source['last_finite_score'],
            last_finite_center=selected.tolist(),last_finite_states=selected_states.tolist(),last_finite_score=list(score),
            feasible_sequence_found=found,selected_sequence=selected.tolist() if found else None,selected_states=selected_states.tolist() if found else None,
            final_bound_diagnostics=measure(checked,selected)[1],source_final_states_and_score_exact=True,
            known_plan_byte_identical=True,live_state_unchanged=True,independent_final_plan_replay_byte_identical=True,
            native_prefix_and_initial_forecast_transition_calls=planning_before,native_planning_transition_calls=planning_calls,
            independent_last_finite_plan_replay_transition_calls=h,native_forecast_transition_calls=native.evaluations,
            native_local_derivative_transition_calls=0,total_native_transition_calls=native.evaluations,
            actual_episode_steps=0,optimizer_transition_calls=0,reserved_seeds_used=False,noisy_development_seeds_used=False,
            not_solution=True,canonical_release_evidence=False,runtime=runtime_metadata(),wall_seconds=time.monotonic()-began,
            scope='Cold-replay failed center/known plan;native-check at most16delivered geometry candidates from a frozen source-bound model,with no new derivative builds. Only native scores/final tape proof accept admissibility. No actual episode,global feasibility or canonical record.')
        dump_json(data,out/'result.json');print(json.dumps(dict(found=found,score=list(score),maximum_angle=data['final_bound_diagnostics']['maximum_angle'],native_calls=data['total_native_transition_calls'],tested_candidates=len(records))))
    finally:env.close()


if __name__=='__main__':main()
