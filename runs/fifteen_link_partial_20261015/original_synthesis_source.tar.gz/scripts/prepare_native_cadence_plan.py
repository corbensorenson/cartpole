#!/usr/bin/env python
"""Lift a verified native input tape to a finer cadence on the same physics grid.

Outputs are planning adapters, never a feedback controller or actual episode.
Every shared boundary is checked before permitting a changed-cadence search.
"""
import argparse
import copy
import json
from pathlib import Path
import time

import numpy as np

from gcartpole.angles import wrap_angle
from gcartpole.config import dump_json, load_config, save_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, runtime_metadata
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg


def lifted_replay(transition, initial_state, actions, expected, *, ratio, n_links):
    if ratio < 1 or int(ratio) != ratio:
        raise ValueError('positive integer cadence ratio required')
    actions = np.asarray(actions, np.float32).astype(float)
    expected = np.asarray(expected, float)
    state = np.asarray(initial_state, float).copy()
    if expected.shape != (len(actions), 2 * (n_links + 1)) or state.shape != expected.shape[1:]:
        raise ValueError('aligned physical state and action tape required')
    states = []
    for action, boundary in zip(actions, expected):
        for _ in range(ratio):
            state = transition(state, float(action))
            states.append(state.copy())
        if state.tobytes() != boundary.tobytes():
            raise ValueError('finer-cadence shared physical boundary changed')
    return state, np.asarray(states), np.repeat(actions, ratio)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True)
    parser.add_argument('--directory', required=True)
    parser.add_argument('--frame-skip', type=int, choices=(1, 2), default=2)
    args = parser.parse_args()
    out = Path(args.directory)
    if any((out / name).exists() for name in ('result.json', 'auxiliary_config.yaml',
                                             'planning_basis.json', 'action_seed_adapter.json')):
        raise FileExistsError(out)
    repair = json.loads(Path(args.source).read_text())
    if not repair['feasible_sequence_found'] or not (
            repair.get('last_valid_forecast_byte_identical') or repair.get('known_plan_byte_identical')):
        raise ValueError('independently verified source tape required')
    source = repair
    ancestry = [file_metadata(args.source)]
    seen = {args.source}
    while not all(key in source for key in ('config', 'teacher', 'parameters')):
        ref = source['source']
        if ref['path'] in seen or len(ancestry) >= 9 or file_metadata(ref['path']) != ref:
            raise ValueError('changed or cyclic source ancestry')
        seen.add(ref['path'])
        ancestry.append(ref)
        source = json.loads(Path(ref['path']).read_text())
    for key in ('source', 'config', 'teacher'):
        if file_metadata(source[key]['path']) != source[key]:
            raise ValueError('changed physical source inputs')
    base = json.loads(Path(source['source']['path']).read_text())
    teacher = json.loads(Path(source['teacher']['path']).read_text())
    cfg = load_config(source['config']['path'])
    old_skip = cfg['env']['frame_skip']
    if args.frame_skip >= old_skip or old_skip % args.frame_skip:
        raise ValueError('finer cadence must divide the original held interval')
    ratio = old_skip // args.frame_skip
    finer = copy.deepcopy(cfg)
    finer['env']['frame_skip'] = args.frame_skip
    n = cfg['env']['n_links']
    step = source['parameters']['start_step']
    initial = np.asarray(base['selected_state']['qpos'] + base['selected_state']['qvel'])
    prefix = base['result']['trajectory'][:step]
    actions = np.asarray(repair['selected_sequence'], np.float32).astype(float)
    expected = np.asarray(repair['selected_states'])
    began = time.monotonic()
    env = NLinkCartPoleEnv(fixed_state_cfg(finer, base['selected_state'], 30.),
                          progress=1., seed=base['seed'])
    env.reset(seed=base['seed'])
    unchanged = np.r_[env.data.qpos.copy(), env.data.qvel.copy()]
    native = MujocoTransition(env, np.eye(2 * (n + 1)), continuous_angles=True)
    try:
        state, prefix_states, prefix_actions = lifted_replay(native, initial,
            [row['action'] for row in prefix],
            [row['qpos'] + row['qvel'] for row in prefix], ratio=ratio, n_links=n)
        _, states, fine_actions = lifted_replay(native, state, actions, expected,
                                               ratio=ratio, n_links=n)
        max_angle = float(np.max(np.abs(wrap_angle(np.cumsum(states[:, 1:n + 1], axis=1)))))
        max_cart = float(np.max(np.abs(states[:, 0])))
        if max_angle >= .149 or max_cart > env.rail_limit:
            raise ValueError('intermediate finer-cadence plan violates declared native bounds')
        if unchanged.tobytes() != np.r_[env.data.qpos, env.data.qvel].tobytes():
            raise ValueError('planning lift changed live environment')
        out.mkdir(parents=True, exist_ok=True)
        config_path = out / 'auxiliary_config.yaml'
        save_config(finer, config_path)
        basis = dict(not_solution=True, auxiliary_cadence=True, actual_episode_steps=0,
            selected_state=base['selected_state'], seed=base['seed'],
            controller=dict(controls=np.repeat(np.asarray(base['controller']['controls'],
                np.float32).astype(float), ratio).tolist(),
                state_epsilon=base['controller']['state_epsilon'],
                action_epsilon=base['controller']['action_epsilon']),
            result=dict(trajectory=[dict(action=float(u), qpos=s[:n+1].tolist(),
                qvel=s[n+1:].tolist()) for u, s in zip(prefix_actions, prefix_states)]),
            original_source=source['source'],
            scope='Auxiliary planning basis with native-verified cold prefix and duplicated reference inputs; '
                  'no transferred feedback gains, actual episode, or controller claim.')
        base_path = out / 'planning_basis.json'
        dump_json(basis, base_path)
        teacher_path = out / 'action_seed_adapter.json'
        dump_json(dict(not_solution=True, original_teacher=source['teacher'],
            scope='Duplicated action-only proposal seeds; not an executed finer-cadence episode.',
            result=dict(trajectory=[dict(action=float(u)) for u in np.repeat(
                np.asarray([row['action'] for row in teacher['result']['trajectory']], np.float32), ratio)])),
            teacher_path)
        report = dict(not_solution=True, canonical_release_evidence=False, auxiliary_cadence=True,
            actual_episode_steps=0, optimizer_transition_calls=0,
            noisy_development_seeds_used=False, reserved_seeds_used=False,
            original_repair=file_metadata(args.source), original_input_ancestry=ancestry,
            original_config=source['config'], original_source=source['source'],
            original_teacher=source['teacher'], config=file_metadata(config_path),
            source=file_metadata(base_path), teacher=file_metadata(teacher_path),
            parameters=dict(start_step=step*ratio,
                rate_residual_weight=source['parameters']['rate_residual_weight']),
            lift_parameters=vars(args), runtime=runtime_metadata(),
            original_control_dt=cfg['env']['timestep']*old_skip,
            control_dt=finer['env']['timestep']*args.frame_skip,
            physics_timestep=cfg['env']['timestep'], physics_steps_per_transition=args.frame_skip,
            cadence_ratio=ratio, native_transition_calls=native.evaluations,
            native_physics_steps=native.evaluations*args.frame_skip,
            shared_prefix_and_plan_boundaries_byte_identical=True,
            intermediate_maximum_plan_angle=max_angle, intermediate_maximum_plan_cart=max_cart,
            feasible_sequence_found=True, known_plan_byte_identical=True,
            selected_sequence=fine_actions.tolist(), selected_states=states.tolist(),
            live_state_unchanged=True, wall_seconds=time.monotonic()-began,
            scope='Auxiliary cadence lift on unchanged physics grid. All original boundaries match bytes; '
                  'intermediate finer-grid nodes retain declared bounds. Adapter supports offline input search only; '
                  'it does not reuse old gains, execute an actual episode, or advance the canonical record.')
        dump_json(report, out / 'result.json')
        print(json.dumps({k:report[k] for k in ['cadence_ratio','native_transition_calls',
            'native_physics_steps','intermediate_maximum_plan_angle',
            'shared_prefix_and_plan_boundaries_byte_identical']}), flush=True)
    finally:
        env.close()


if __name__ == '__main__':
    main()
