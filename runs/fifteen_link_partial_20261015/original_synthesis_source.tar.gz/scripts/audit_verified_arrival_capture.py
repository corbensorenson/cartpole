#!/usr/bin/env python
"""Compare quieter verified arrivals against the saved directional capture law."""
import argparse,json
from pathlib import Path
import mpmath
import numpy as np
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,runtime_metadata,data_sha256
from gcartpole.angles import wrap_angle


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',action='append',required=True)
    p.add_argument('--base',required=True);p.add_argument('--capture-cache',required=True)
    p.add_argument('--directory',required=True);args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    base=json.loads(Path(args.base).read_text());cache=json.loads(Path(args.capture_cache).read_text())
    if cache['source']!=file_metadata(args.base) or not cache['maintenance_factor_reproduced_bit_identically']:
        raise ValueError('aligned reproduced capture factor and gain required')
    gain=np.asarray(cache['gain']);factor=np.asarray(base['lyapunov']['factor']);n=len(base['selected_state']['qpos'])-1
    if cache['factor_sha256']!=data_sha256(factor.tolist()) or not np.array_equal(base['controller']['coordinate_transform'],np.eye(2*(n+1))):
        raise ValueError('saved physical metric identity differs')
    ctx=mpmath.mp.clone();ctx.dps=100;records=[]
    for path in args.source:
        data=json.loads(Path(path).read_text())
        if not data['feasible_sequence_found'] or not data['known_plan_byte_identical'] or not data['live_state_unchanged']:
            raise ValueError('verified native plan required')
        states=np.asarray(data['selected_states']);state=states[-1].copy();state[1:n+1]=wrap_angle(state[1:n+1])
        if state.shape!=gain.shape:raise ValueError('capture dimensions differ')
        value_vec=ctx.matrix(factor.tolist())*ctx.matrix(state.tolist())
        mp_value=ctx.fsum(v*v for v in value_vec);mp_action=-ctx.fsum(ctx.mpf(float(k))*ctx.mpf(float(x)) for k,x in zip(gain,state))
        rates=np.cumsum(state[n+2:]);raw_action=-float(gain@state)
        records.append(dict(source=file_metadata(path),horizon_steps=len(states),
            maximum_forecast_absolute_angle=float(np.max(np.abs(wrap_angle(np.cumsum(states[:,1:n+1],axis=1))))),
            terminal_absolute_rate_max=float(np.max(np.abs(rates))),terminal_absolute_rate_rms=float(np.sqrt(np.mean(rates*rates))),
            binary64_raw_normalized_capture_action=raw_action,mp100_raw_normalized_capture_action=str(mp_action),
            clipped_capture_action=float(np.clip(raw_action,-1,1)),mp100_action_exceeds_force_limit=abs(mp_action)>1,
            binary64_saved_capture_value=float(np.sum((factor@state)**2)),mp100_saved_capture_value=str(mp_value)))
    dump_json(dict(not_solution=True,canonical_release_evidence=False,parameters=vars(args),runtime=runtime_metadata(),
        source=file_metadata(args.base),capture_cache=file_metadata(args.capture_cache),records=records,
        native_transition_calls=0,actual_episode_steps=0,reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Read-only terminal-state comparison using unchanged saved binary64 physical gain/factor,reevaluated with MP100 contractions. Lower Euclidean rate norm need not lower directional capture value. This metric and saturated action are diagnostics,not nonlinear infeasibility or capture certificates.'),out/'result.json')
    print(json.dumps(records),flush=True)


if __name__=='__main__':main()
