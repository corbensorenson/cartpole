"""Independent native secant/trust calibration and selected actual controller proof."""
import argparse,json
from pathlib import Path
import numpy as np,mujoco
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.native_trust_minimax import affine_trust_proposal
from gcartpole.native_minimax import bounded_affine_minimax
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix
from scripts.audit_canonical15_native_minimax import lp_gap
read=lambda p:json.loads(Path(p).read_text())
def same(a,b):assert np.asarray(a).tobytes()==np.asarray(b).tobytes()
def physical(xs,m):return np.r_[(wrap_angle(np.cumsum(xs[:,1:16],axis=1))/m['angle_limit']).ravel(),xs[:,0]/m['rail_limit']]
def maintenance_features(x,m):return np.r_[wrap_angle(np.cumsum(x[1:16]))/m['angle_scale'],x[0]/3,.1*x[16]/.5]
def gainraw(gain,x):
 y=x.copy();y[1:16]=wrap_angle(y[1:16]);return -float(gain@y)
def rank(z,m):
 h=len(z['feedforward']);xs=z['states'][1:]
 if len(xs)!=h:return [1,1,1e100,1e100,0]
 angles=abs(wrap_angle(np.cumsum(xs[:,1:16],axis=1)));ok=(np.max(angles,axis=1)<m['angle_limit'])&(abs(xs[:,0])<=m['rail_limit']);bad=np.flatnonzero(~ok);prefix=int(bad[0]) if len(bad) else h;f=physical(xs,m);ex=np.maximum(abs(f)-1,0);return [0,0 if np.all(ok) else 1,float(np.max(abs(f))),float(ex@ex),-prefix]
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);args=p.parse_args();root=Path(args.root);out=Path(args.out);out.mkdir(exist_ok=False);m=read(root/'manifest.json');r=read(root/'execution/diagnostic/result.json');acc=read(root/'execution/inclusive_accounting.json');j=read(root/'execution/execution.json');assert j['status']=='finished' and j['returncode']==0 and r['status']=='finished';s=read(m['source']['path']);base=read(s['source']['path']);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in s['result']['trajectory']]]);U=np.asarray([q['action'] for q in s['result']['trajectory']],np.float32).astype(float);start=m['start_step'];track=m['tracking_steps'];gain=np.asarray(read(m['gain_source']['path'])['gain'])
 with np.load(m['tracking_array']['path']) as z:K=z['gains'][m['tracking_variant_index']];same(z['states'],X[start:start+track+1])
 cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);env=NLinkCartPoleEnv(cfg,progress=1.,seed=m['nominal_seed']);env.reset(seed=m['nominal_seed']);native=MujocoTransition(env,np.eye(32),continuous_angles=True);count=[0];old=mujoco.mj_step
 def counted(model,data,*args,**kw):
  n=int(kw.get('nstep',args[0] if args else 1));assert count[0]+n<=4*m['audit_native_transition_ceiling'];count[0]+=n;return old(model,data,*args,**kw)
 mujoco.mj_step=counted;loaded={};lp_checks=0;scalar_checks=0;maxgap=0;failed=0;outcomes=[]
 try:
  for tick in range(start+track):same(native(X[tick],float(U[tick])),X[tick+1])
  for row in r['private_forecasts']:
   assert row['tape']==file_metadata(row['tape']['path'])
   with np.load(row['tape']['path']) as archive:z={k:archive[k] for k in archive.files}
   same(z['states'][0],X[start]);assert len(z['actions'])==row['attempted_steps'] and len(z['states'])-1==row['completed_steps'];error=None
   for i,u in enumerate(z['actions']):
    raw=float(z['feedforward'][i])+float(K[i]@(z['states'][i]-X[start+i])) if i<track else float(z['feedforward'][i]);assert raw==z['raw_actions'][i] and float(np.float32(np.clip(raw,-1,1)))==u
    try:prediction=native(z['states'][i],float(u))
    except SimulationError as e:error=f'SimulationError: {e}';failed+=1;assert i==len(z['actions'])-1 and len(z['states'])==len(z['actions']);same(z['failed_post_state'],np.r_[native.data.qpos,native.data.qvel]);assert float(z['failed_time'])==float(native.data.time);break
    same(prediction,z['states'][i+1])
   assert error==row['error'];assert rank(z,m)==row['score'];loaded[row['index']]=z
  with np.load(m['center_tape']['path']) as z:
   same(loaded[r['initial_forecast']]['states'],z['states']);same(loaded[r['initial_forecast']]['feedforward'],z['feedforward'])
  def verify_proposal(row,h):
   nonlocal lp_checks
   nk=m['tracking_knots'];basis=np.zeros((h,nk+h-track));basis[:track,:nk]=interpolation_matrix(nk,track);basis[track:,nk:]=np.eye(h-track);z=loaded[row['center_before']];eps=np.asarray(row['derivative_epsilons']);assert len(eps)==basis.shape[1] and len(row['derivative_pairs'])==basis.shape[1];columns=[];valid=True
   for k,(pi,mi) in enumerate(row['derivative_pairs']):
    zp,zm=loaded[pi],loaded[mi];same(zp['feedforward'],z['feedforward']+eps[k]*basis[:,k]);same(zm['feedforward'],z['feedforward']-eps[k]*basis[:,k])
    if len(zp['states'])!=h+1 or len(zm['states'])!=h+1:valid=False
    else:columns.append((physical(zp['states'][1:],m)-physical(zm['states'][1:],m))/(2*eps[k]))
   if not valid:assert row['status']=='incomplete_secant_forecasts' and row['accepted'] is None and row['parameter_step'] is None and not row['backtracks'] and row['center_after']==row['center_before'];return
   f=physical(z['states'][1:],m);jac=np.column_stack(columns);radii=np.asarray(row['trust_radii']);delta,diag=affine_trust_proposal(f,jac,radii,action_values=z['feedforward'],action_basis=basis,solver_seconds=m['lp_seconds']);assert diag==row['lp'];lp_checks+=1;accepted=None
   if delta is None:assert row['parameter_step'] is None and not row['backtracks']
   else:
    same(delta,row['parameter_step']);assert np.max(abs(delta)/radii)<=1+1e-8 and np.max(abs(z['feedforward']+basis@delta))<=1+1e-7 and np.max(abs(f+jac@delta))<=diag['lp_epigraph']+1e-7
    for power,bt in enumerate(row['backtracks']):
     assert power==bt['power'];candidate=loaded[bt['forecast_index']];same(candidate['feedforward'],z['feedforward']+basis@(delta/(2**power)))
     if len(candidate['states'])==h+1:
      pred=f+jac@(delta/(2**power));actual=physical(candidate['states'][1:],m);assert bt['predicted_physical_peak']==float(np.max(abs(pred))) and bt['observed_physical_peak']==float(np.max(abs(actual))) and bt['maximum_normalized_prediction_error']==float(np.max(abs(pred-actual)))
     if rank(candidate,m)<rank(z,m):accepted=bt['forecast_index'];assert power==len(row['backtracks'])-1
   assert row['accepted']==accepted and row['center_after']==(row['center_before'] if accepted is None else accepted)
  h=m['calibration_horizon'];nk=m['tracking_knots'];initial_index=r['initial_forecast'];best_index=initial_index;best_case=None;assert len(r['calibrations'])==len(m['tracking_epsilons'])*len(m['tracking_trust_radii'])
  for index,row in enumerate(r['calibrations']):
   epsilon=m['tracking_epsilons'][index//len(m['tracking_trust_radii'])];radius=m['tracking_trust_radii'][index%len(m['tracking_trust_radii'])];assert row['tracking_epsilon']==epsilon and row['tracking_trust_radius']==radius and row['center_before']==initial_index;expected_eps=np.r_[np.full(nk,epsilon),np.full(h-track,m['tail_epsilon'])];same(row['derivative_epsilons'],expected_eps);same(row['trust_radii'],np.r_[np.full(nk,radius),np.full(h-track,m['tail_trust_radius'])]);verify_proposal(row,h)
   if index%len(m['tracking_trust_radii']):assert row['derivative_pairs']==r['calibrations'][index-1]['derivative_pairs']
   candidate=row['center_after']
   if rank(loaded[candidate],m)<rank(loaded[best_index],m):best_index=candidate;best_case=index
  assert r['selected_calibration_case']==best_case
  if best_case is None:assert not r['refinement']
  else:
   chosen=r['calibrations'][best_case];epsilon=chosen['tracking_epsilon'];radius=chosen['tracking_trust_radius']
   for iteration,row in enumerate(r['refinement']):
    assert row['iteration']==iteration and row['center_before']==best_index;verify_proposal(row,h);same(row['derivative_epsilons'],np.r_[np.full(nk,epsilon),np.full(h-track,m['tail_epsilon'])]);same(row['trust_radii'],np.r_[np.full(nk,radius),np.full(h-track,m['tail_trust_radius'])]);best_index=row['center_after']
  assert r['selected_forecast']==best_index
  for stage in r['stages']:
   assert rank(loaded[best_index],m)[1]==0;h=stage['horizon'];center=stage['initial_forecast'];same(loaded[center]['feedforward'][:len(loaded[best_index]['feedforward'])],loaded[best_index]['feedforward']);assert h in m['extension_horizons']
   for row in stage['history']:assert row['center_before']==center;verify_proposal(row,h);center=row['center_after']
   assert center==stage['selected_forecast'] and rank(loaded[center],m)==stage['selected_score'];best_index=center
  om=m['maintenance'];maintenance_by_label={}
  for d in r['maintenance_decisions']:
   assert d['tape']==file_metadata(d['tape']['path'])
   with np.load(d['tape']['path']) as archive:z={k:archive[k] for k in archive.files}
   os=z['states'];oa=z['actions'];raws=z['raw_actions'];assert all(e is None for e in d['errors'])
   for pair,u,raw in zip(os,oa,raws,strict=True):assert float(np.float32(np.clip(raw,-1,1)))==u;same(native(pair[0],float(u)),pair[1])
   mi,pi=d['first_minus_id'],d['first_plus_id'];state=os[mi,0];same(os[pi,0],state);assert oa[mi]==-1 and oa[pi]==1;minus,plus=maintenance_features(os[mi,1],om),maintenance_features(os[pi,1],om);proposal=bounded_affine_minimax(minus,plus);assert proposal==d['proposal'];maxgap=max(maxgap,lp_gap(minus,plus,proposal));scalar_checks+=1;raw=gainraw(gain,state);assert raw==d['gain_raw'];source=float(U[d['tick']]) if d['tick']<len(U) else 0.;assert source==d['source_action'];values=[proposal,-1.,1.,0.,source,d['last_action']]+[proposal+(np.clip(raw,-1,1)-proposal)/(2**p) for p in range(om['backoff_powers'])];commands=[];prs=[];seen=set()
   for v in values:
    u=float(np.float32(np.clip(v,-1,1)));key=np.float32(u).tobytes()
    if key not in seen:seen.add(key);commands.append(u);prs.append(float(v))
   same(z['candidate_actions'],commands);same(z['candidate_raw_proposals'],prs);scores=[]
   for i,c in enumerate(d['candidates']):
    fi,sm,sp,si=c['first_id'],c['second_minus_id'],c['second_plus_id'],c['second_id'];assert oa[fi]==commands[i];same(os[fi,0],state);same(os[sm,0],os[fi,1]);same(os[sp,0],os[fi,1]);same(os[si,0],os[fi,1]);assert oa[sm]==-1 and oa[sp]==1;minus,plus=maintenance_features(os[sm,1],om),maintenance_features(os[sp,1],om);raw2=bounded_affine_minimax(minus,plus);assert c['second_raw']==raw2==raws[si];maxgap=max(maxgap,lp_gap(minus,plus,raw2));scalar_checks+=1;score=[0,float(max(np.max(abs(maintenance_features(os[fi,1],om))),np.max(abs(maintenance_features(os[si,1],om))))),abs(float(commands[i]))];assert score==c['score'];scores.append(tuple(score))
   winner=min(range(len(scores)),key=lambda i:scores[i]);assert winner==d['winner_index'];d=dict(d,verified_action=commands[winner],verified_prediction=os[d['candidates'][winner]['first_id'],1]);maintenance_by_label.setdefault(d['label'],{})[d['tick']]=d
  actual_ticks=0
  for row in r['actual_records']:
   assert row['tape']==file_metadata(row['tape']['path'])
   with np.load(row['tape']['path']) as z:xs=z['states'];us=z['actions'];raws=z['raw_actions']
   selected=loaded[row['selected_forecast_index']];h=row['horizon'];same(xs[:start+1],X[:start+1]);same(xs[start:start+h+1],selected['states']);safe=np.max(abs(wrap_angle(np.cumsum(xs[1:,1:16],axis=1))),axis=1)<.15;streak=longest=0
   for tick,u in enumerate(us):
    if tick<start:raw=float(U[tick]);assert u==raw
    elif tick<start+h:
     i=tick-start;raw=float(selected['feedforward'][i])+float(K[i]@(xs[tick]-X[tick])) if i<track else float(selected['feedforward'][i]);assert float(np.float32(np.clip(raw,-1,1)))==u
    else:
     d=maintenance_by_label[row['label']][tick];assert d['last_action']==us[tick-1] and d['verified_action']==u;same(xs[tick+1],d['verified_prediction']);raw=u
    assert raw==raws[tick];same(native(xs[tick],float(u)),xs[tick+1]);streak=streak+1 if safe[tick] else 0;longest=max(longest,streak)
   maxcart=float(np.max(abs(xs[:,0])));assert len(us)==row['actual_hanging_start_episode_steps'] and longest*.02==row['hold_seconds'] and maxcart==row['maximum_cart'];passed=len(us)==1500 and longest>=250 and maxcart<=3 and row['termination_reason']=='time_limit' and not row['simulation_error'];assert row['full_nominal_gate_passed']==passed
   if row['termination_reason']=='rail_violation':assert abs(xs[-1,0])>3
   elif row['termination_reason']=='time_limit':assert len(us)==1500 and maxcart<=3
   else:raise AssertionError('Unexpected actual failure requires explicit audit')
   actual_ticks+=len(us);outcomes.append({k:row[k] for k in ('label','horizon','hold_seconds','maximum_cart','termination_reason','actual_hanging_start_episode_steps','full_nominal_gate_passed','tape')})
  assert actual_ticks==r['actual_hanging_start_episode_steps'];assert native.evaluations+actual_ticks==r['total_native_transition_calls'];assert count[0]+4*actual_ticks==acc['native_physics_substeps'];assert native.evaluations<=m['audit_native_transition_ceiling'];dump_json(dict(status='finished',passed=True,generated_at=utc_timestamp(),scope=m['scope'],outcomes=outcomes,private_forecasts_proved=len(loaded),private_errors_proved=failed,failed_private_poststates_and_times_proved=True,calibration_cases_proved=len(r['calibrations']),selected_calibration_case=best_case,refinement_rounds_proved=len(r['refinement']),trust_lp_reexports_and_primal_feasibility_checks=lp_checks,trust_lp_optimality_scope='Shared HiGHS proposal re-export and independently calculated primal/trust/action/epigraph feasibility; no independent multivariate optimality certificate.',maintenance_decisions_proved=len(r['maintenance_decisions']),maintenance_scalar_affine_optimality_checks=scalar_checks,maximum_scalar_relative_affine_optimality_gap=maxgap,total_native_transition_calls=count[0]/4,native_physics_substeps=count[0],attempted_transition_calls=native.evaluations,actual_hanging_start_episode_steps=0,source_actual_ticks_proved=actual_ticks,all_actual_and_private_native_tapes_actions_history_gates_verified=True,source_accounting=file_metadata(root/'execution/inclusive_accounting.json')),out/'result.json');print(dict(calls=native.evaluations,outcomes=outcomes,forecasts=len(loaded),lp_checks=lp_checks),flush=True)
 finally:env.close();mujoco.mj_step=old
if __name__=='__main__':main()
