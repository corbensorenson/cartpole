"""Read-only audit of the declared native swing/capture recipe and accounting."""
import argparse,json,math
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json,load_config
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.physical_prefix import select_physical_prefix
from scripts.audit_armature_route_increment import checked,journal,read,tape


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',required=True);a=p.parse_args();root=Path(a.directory)
    source_path='runs/armature_route_increment_20261003/armature0.98_passing_physical_initializer.json';source=read(source_path)
    cfg=load_config(root/'armature0.98.json');rows=[];parents=[]
    baseline=root/'source0.98_replay';b=read(baseline/'diagnostic/result.json');bj=journal(baseline)
    for key in ('config','initializer','candidate'):checked(b[key])
    x,u,gate=tape(b);checked(source['passing_tape']);old=np.load(source['passing_tape']['path'])
    assert gate and b['optimizer_iterations']==0 and b['initializer']==file_metadata(source_path)
    assert x.tobytes()==old['states'].tobytes() and u.tobytes()==old['actions'].tobytes()
    rows.append(dict(directory=str(baseline),execution=bj,result=file_metadata(baseline/'diagnostic/result.json'),config=b['config'],initializer=b['initializer'],candidate=b['candidate'],tape=b['tape'],hold_seconds=b['result']['max_upright_streak_seconds'],full_nominal_component_gate_passed=gate,total_native_transition_calls=b['total_native_transition_calls'],actual_hanging_start_episode_steps=len(u)))
    for ratio in (.97,.95):
        folder=root/f'target{ratio}';pj=journal(folder);path=folder/'diagnostic/result.json';d=read(path);assert d['status']=='finished'
        for key in ('config','initializer','memo','script'):checked(d[key])
        assert d['initializer']==file_metadata(source_path) and not d['reserved_seeds_used'] and not d['noisy_development_seeds_used']
        target=load_config(d['config']['path']);assert target['env']['joint_armature']==.0005*ratio
        target['env']['joint_armature']=cfg['env']['joint_armature'];assert target==cfg
        stages={};stage_rows=[]
        for s in d['stages']:
            checked(s['result']);assert journal(Path(s['directory']))==s['execution'];r=read(s['result']['path']);assert r['status']=='finished'
            assert s['total_native_transition_calls']==r['total_native_transition_calls'] and s['actual_hanging_start_episode_steps']==r.get('actual_hanging_start_episode_steps',0)
            assert r['config']==d['config'];checked(r['config'])
            assert not r.get('reserved_seeds_used',False) and not r.get('noisy_development_seeds_used',False)
            if 'native_physics_substeps' in r:assert r['partial_transition_substeps']==0 and r['native_physics_substeps']==4*r['total_native_transition_calls']
            assert r['total_native_transition_calls']<=r['native_transition_ceiling']
            row=dict(s);row['role']='primitive';row['config']=r['config'];row['records']=r.get('records',[])
            if 'tape' in r:
                xx,uu,gg=tape(r);c=read(r['candidate']['path']);checked(r['candidate']);checked(r['initializer'])
                assert c['selected_state']==source['selected_state'];assert c['controller']['coordinate_transform']==np.eye(30).tolist()
                row.update(candidate=r['candidate'],initializer=r['initializer'],tape=r['tape'],hold_seconds=r['result']['max_upright_streak_seconds'],full_nominal_component_gate_passed=gg,maximum_model_defect=c['controller']['final_trajectory_diagnostics']['maximum_dynamics_defect'])
                assert xx[1:].tobytes()==np.array([q['qpos']+q['qvel'] for q in c['result']['trajectory']]).tobytes()
            for rr in r.get('records',[]):tape(rr)
            for key in ('source','reference','source_result','gain_source'):
                if key in r and isinstance(r[key],dict) and 'sha256' in r[key]:checked(r[key])
            stages[s['name']]=r;stage_rows.append(row)
        assert sum(s['total_native_transition_calls'] for s in stage_rows)==d['total_native_transition_calls']<=3000000
        assert sum(s['actual_hanging_start_episode_steps'] for s in stage_rows)==d['actual_hanging_start_episode_steps']
        selected=None;selected_gains=None;selected_record=None;selected_repair=None
        for entry in d['selection_history']:
            it=entry['after_cumulative_iterations'];repair=stages[f'full_repair{it}'];assert repair['optimizer_iterations']==8 and repair['entire_horizon_free']
            expected_initial=file_metadata(source_path) if it==8 else stages['full_repair8']['candidate'];assert repair['initializer']==expected_initial
            c=read(repair['candidate']['path']);options=[('saved_solver',repair,np.array(c['controller']['feedback_gains']))]
            if f'native_feedback{it}' in stages:
                f=stages[f'native_feedback{it}'];assert f['source']==repair['candidate'] and f['native_reference_design_calls']==88900 and f['upright_gain_design_calls']==62
                ref=np.load(f['reference']['path']);assert np.array_equal(ref['states'],c['search']['nominal_coordinate_states'])
                assert select_physical_prefix(np.load(repair['tape']['path'])['states'],14) is None
                options.extend((rr['label'],rr,ref['feedback_gains']) for rr in f['records'])
            choices=[]
            for priority,(method,rr,gains) in enumerate(options):
                sel=select_physical_prefix(np.load(rr['tape']['path'])['states'],14)
                if sel:choices.append((sel['steps'],-priority,method,rr,gains,sel))
            chosen=max(choices,key=lambda v:(v[0],v[1])) if choices else None
            expected=None if chosen is None else dict(method=chosen[2],tape=chosen[3]['tape'],**chosen[5]);assert expected==entry['selected']
            if chosen:selected=chosen[5];selected_gains=chosen[4];selected_record=chosen[3];selected_repair=repair
        if selected is None:
            assert len(d['selection_history'])==2 and not d['component_passed'] and 'capture_suffix8' not in stages
        else:
            checked(d['physical_prefix_initializer']);seed=read(d['physical_prefix_initializer']['path']);steps=selected['steps'];origin=np.load(selected_record['tape']['path'])
            assert seed['physical_prefix_tape']==selected_record['tape'] and seed['physical_prefix_selection']==selected
            assert np.array(seed['search']['nominal_coordinate_states'])[:steps+1].tobytes()==origin['states'][:steps+1].tobytes()
            assert np.array(seed['controller']['controls'])[:steps].tobytes()==origin['actions'][:steps].tobytes()
            assert np.array(seed['controller']['feedback_gains'])[:steps].tobytes()==selected_gains[:steps].tobytes()
            suffix=stages['capture_suffix8'];c=read(suffix['candidate']['path']);assert suffix['initializer']==d['physical_prefix_initializer']
            assert suffix['optimize_suffix_start_seconds']==selected['seconds'] and c['controller']['frozen_prefix_steps']==steps and c['search']['optimized_horizon_steps']==700-steps
            for key in ('controls','feedback_gains'):assert np.array(c['controller'][key])[:steps].tobytes()==np.array(seed['controller'][key])[:steps].tobytes()
            assert np.array(c['search']['nominal_coordinate_states'])[:steps+1].tobytes()==origin['states'][:steps+1].tobytes()
            sx,su,_=tape(suffix);assert sx[:steps+1].tobytes()==origin['states'][:steps+1].tobytes() and su[:steps].tobytes()==origin['actions'][:steps].tobytes()
            available=[float(h) for h in range(math.ceil(selected['seconds']),14) if 50*h<=len(su)];assert available==d['available_handoff_seconds']
            passed=[]
            if available:
                screen=stages['saved_feedback_handoffs'];assert [rr['handoff_seconds'] for rr in screen['records']]==available
                for rr in screen['records']:
                    xx,uu,gg=tape(rr);h=round(rr['handoff_seconds']/.02)
                    assert xx[:h+1].tobytes()==sx[:h+1].tobytes() and uu[:h].tobytes()==su[:h].tobytes()
                    if gg:passed.append(rr)
                assert screen['total_native_transition_calls']==sum(rr['total_native_transition_calls'] for rr in screen['records'])
            assert bool(passed)==d['component_passed']
            if passed:
                checked(d['passing_physical_initializer']);physical=read(d['passing_physical_initializer']['path']);best=min(passed,key=lambda v:v['handoff_seconds']);tt=np.load(best['tape']['path']);h=round(best['handoff_seconds']/.02)
                gain_result=read(screen['gain_source']['path']);gain=np.array(gain_result['gain']);k=np.vstack([np.array(c['controller']['feedback_gains'])[:h],np.tile(-gain,(700-h,1))])
                assert physical['passing_tape']==best['tape'] and physical['selected_handoff_seconds']==best['handoff_seconds']
                assert np.array(physical['search']['nominal_coordinate_states']).tobytes()==tt['states'][:701].tobytes()
                assert np.array(physical['controller']['controls']).tobytes()==tt['actions'][:700].tobytes() and np.array(physical['controller']['feedback_gains']).tobytes()==k.tobytes()
        rows.extend(stage_rows);parents.append(dict(directory=str(folder),execution=pj,result=file_metadata(path),config=d['config'],role='pipeline_parent_not_additive',selection_history=d['selection_history'],component_passed=d['component_passed'],termination=d['termination'],total_native_transition_calls=d['total_native_transition_calls'],actual_hanging_start_episode_steps=d['actual_hanging_start_episode_steps'],passing_physical_initializer=d.get('passing_physical_initializer')))
    total=sum(r['total_native_transition_calls'] for r in rows);actual=sum(r['actual_hanging_start_episode_steps'] for r in rows);assert total<=6020000
    result=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),passed=True,studies=rows,pipelines=parents,source_initializer=file_metadata(source_path),total_new_native_transition_calls=int(total),actual_hanging_start_episode_steps=actual,native_transition_calls_for_this_audit=0,canonical_release_evidence=False,not_solution=True,reserved_seeds_used=False,noisy_development_seeds_used=False,baseline_whole_actual_tape_byte_identical=True,selection_reproduced=True,budget_scope='Baseline plus primitive stages once; pipeline parent counts overlap their children and are excluded from total.',highest_verified_count=14,canonical15_unchanged=True)
    dump_json(result,root/'verified.json');print(json.dumps(dict(passed=True,primitive_executions=len(rows),pipelines=len(parents),nativecalls=int(total),actual_steps=actual,component_passes=[r['directory'] for r in parents if r['component_passed']])))

if __name__=='__main__':main()
