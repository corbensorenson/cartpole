#!/usr/bin/env python
"""Separate added joint inertia from count-dependent capture conditioning."""
import argparse,copy,hashlib,json,time
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.generalized_modes import chain_normal_modes
from gcartpole.lqr_design import high_precision_discrete_lqr
from gcartpole.upright_mechanics import upright_rk4_matrices
from scripts.audit_link_count_frontier import WEIGHTS,exact_capture
from scripts.make_lqr_checkpoint import absolute_angle_cost


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',default='configs/swingup15_uniform.yaml')
    p.add_argument('--counts',type=int,nargs='+',default=[15,20])
    p.add_argument('--armature-factors',type=float,nargs='+',default=[1.,.1,0.])
    p.add_argument('--frame-skips',type=int,nargs='+',default=[4])
    p.add_argument('--directory',required=True)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    if min(args.counts)<1 or any(not np.isfinite(v) or v<0 for v in args.armature_factors) or any(v not in (1,2,4) for v in args.frame_skips):
        raise ValueError('positive counts, finite nonnegative armature factors and frame skips1/2/4 required')
    base=load_config(args.config);original=base['env']['joint_armature'];began=time.monotonic()
    result=dict(not_solution=True,canonical_release_evidence=False,config=file_metadata(args.config),
        parameters=vars(args),runtime=runtime_metadata(),records=[],actual_local_episode_steps=0,
        optimizer_transition_calls=0,reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Auxiliary local components. The existing joint_armature scalar and declared control frame skip are the only configuration axes within count; rods, hub-free geometry, mass, force, rail, damping and native timestep stay fixed. This scalar changes both cart translational and hinge rotational armature, explicitly reported. No hanging-start solve, robustness basin or canonical count promotion is inferred.')
    for n in args.counts:
        directions=np.random.default_rng(20265500+n).uniform(-1,1,(4,2*n))
        for frame_skip in args.frame_skips:
            for factor in args.armature_factors:
                cfg=copy.deepcopy(base);cfg['env'].update(n_links=n,joint_armature=original*factor,frame_skip=frame_skip)
                record=dict(n_links=n,armature_factor=factor,control_frame_skip=frame_skip,control_hz=1/(cfg['env']['timestep']*frame_skip),resolved_config=cfg,paired_directions=directions.tolist(),
                    local_capture={},nominal_case_is_canonical_geometry=factor==1. and frame_skip==4)
                result['records'].append(record);env=NLinkCartPoleEnv(cfg,progress=1.,seed=0)
                try:
                    env.reset(seed=0);modes=chain_normal_modes(env)
                    a,b,mechanics=upright_rk4_matrices(env,decimal_digits=100)
                    roots=np.sort(np.log(np.abs(np.linalg.eigvals(np.asarray(a.tolist(),float))))/env.dt)
                    unstable=roots[roots>1e-5]
                    record.update(native_xml_sha256=hashlib.sha256(env.xml.encode()).hexdigest(),
                        cart_armature=float(env.model.dof_armature[0]),hinge_armature=env.model.dof_armature[1:].tolist(),
                        fastest_hanging_frequency_hz=float(np.max(modes.angular_frequencies)/(2*np.pi)),
                        hanging_joint_mass_condition=float(np.linalg.cond(modes.joint_mass_matrix)),
                        upright_binary64_growth_rates=unstable.tolist(),
                        minimum_adjacent_upright_growth_rate_separation=float(np.min(np.diff(unstable))) if len(unstable)>1 else None,
                        growth_rate_scope='Eigenvalues of binary64 rounded analytic RK4 matrices; descriptive, not a conditioning/reachability certificate.',
                        mechanics=mechanics)
                    design_began=time.monotonic()
                    gain,_,diag=high_precision_discrete_lqr(a.tolist(),b.tolist(),absolute_angle_cost(n,WEIGHTS),np.array([[1000.]]),
                        decimal_digits=100,preserve_input_precision=True)
                    record.update(design_diagnostics=diag,gain=gain.ravel().tolist(),design_wall_seconds=time.monotonic()-design_began)
                except (ValueError,np.linalg.LinAlgError,ZeroDivisionError) as error:
                    record['error']=f'{type(error).__name__}: {error}'
                finally:env.close()
                if 'error' not in record:
                    for amplitude in (1e-5,1e-9,1e-13):
                        episodes=[exact_capture(cfg,dict(qpos=np.r_[0.,amplitude*d[:n]].tolist(),
                            qvel=np.r_[0.,amplitude*d[n:]].tolist()),gain.ravel(),seconds=30.) for d in directions]
                        record['local_capture'][str(amplitude)]=dict(episodes=episodes,successes=sum(
                            e['success'] and e['termination_reason']=='time_limit' and e['steps']==round(30/(cfg['env']['timestep']*frame_skip)) and e['trajectory_clean']
                            and e['max_hold_seconds']>=5 and e['max_cart_excursion']<=3 for e in episodes))
                        result['actual_local_episode_steps']+=sum(e['steps'] for e in episodes)
                dump_json(result,out/'result.progress.json')
                print(json.dumps(dict(n_links=n,factor=factor,frame_skip=frame_skip,error=record.get('error'),
                    gain_norm=record.get('design_diagnostics',{}).get('gain_norm'),
                    fastest_frequency_hz=record.get('fastest_hanging_frequency_hz'),
                    successes={k:v['successes'] for k,v in record['local_capture'].items()})),flush=True)
    result['wall_seconds']=time.monotonic()-began;dump_json(result,out/'result.json')


if __name__=='__main__':main()
