#!/usr/bin/env python
"""Compare frozen generalist periodic reduction with stable small-error wrapping."""
import argparse
import json
import runpy
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata, utc_timestamp
from gcartpole.generalized_solver import periodic_coordinate_error


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',required=True)
    parser.add_argument('--old-module',required=True)
    parser.add_argument('--directory',required=True)
    args=parser.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    old=runpy.run_path(args.old_module)['periodic_coordinate_error']
    data=json.loads(Path(args.source).read_text());records=[]
    for record in data['records']:
        n=record['n_links'];nx=2*(n+1);transform=np.eye(nx)
        gain=np.asarray(next(d for d in record['unique_designs'] if d['method']=='analytic_mp100')['gain'])
        directions=np.asarray(record['paired_directions'])
        for amplitude in (1e-5,1e-9,1e-13,1e-16,1e-20):
            rows=[]
            for direction in directions:
                current=np.r_[0.,amplitude*direction[:n],0.,amplitude*direction[n:]]
                prior=old(current,np.zeros(nx),transform)
                stable=periodic_coordinate_error(current,np.zeros(nx),transform)
                assert np.array_equal(stable,current)
                raw_old=-float(gain@prior);raw_new=-float(gain@stable)
                rows.append(dict(maximum_coordinate_error=float(np.max(np.abs(prior-current))),
                    old_erased_nonzero_hinge_errors=int(np.sum((prior[1:n+1]==0)&(current[1:n+1]!=0))),
                    raw_action_old=raw_old,raw_action_stable=raw_new,
                    delivered_action_old=float(np.float32(np.clip(raw_old,-1,1))),
                    delivered_action_stable=float(np.float32(np.clip(raw_new,-1,1)))))
            records.append(dict(n_links=n,amplitude=amplitude,rows=rows,
                maximum_coordinate_error=max(r['maximum_coordinate_error'] for r in rows),
                maximum_raw_action_difference=max(abs(r['raw_action_old']-r['raw_action_stable']) for r in rows),
                delivered_action_changed_directions=sum(r['delivered_action_old']!=r['delivered_action_stable'] for r in rows)))
    dump_json(dict(not_solution=True,canonical_release_evidence=False,generated_at=utc_timestamp(),
        source=file_metadata(args.source),old_module=file_metadata(args.old_module),
        current_module=file_metadata('src/gcartpole/generalized_solver.py'),records=records,
        native_transition_calls=0,optimizer_transition_calls=0,
        scope='Pure arithmetic comparison on paired physical errors and saved gains. Frozen old implementation is executed directly. Stable helper retains every in-range error exactly. No new physics, basin, hanging-start or canonical solve is claimed; current continuous-angle frontier tracking does not use this generalist periodic-error path.'),out/'result.json')


if __name__=='__main__':main()
