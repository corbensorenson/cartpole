#!/usr/bin/env python
"""Measure local LTV transients about a saved orbit using MP arithmetic.

These are finite-difference linear models, not native execution certificates.
"""
import argparse
import json
from pathlib import Path
from time import monotonic
import mpmath
import numpy as np
from gcartpole.config import load_config, dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, runtime_metadata
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', required=True); p.add_argument('--config', required=True)
    p.add_argument('--out', required=True); p.add_argument('--episode-index', type=int, default=1)
    p.add_argument('--steps', type=int, default=150)
    args = p.parse_args(); out = Path(args.out)
    if out.exists(): raise FileExistsError(out)
    if args.steps < 1: raise ValueError('positive step budget required')
    source = json.loads(Path(args.source).read_text()); cfg = load_config(args.config)
    if source['config'] != file_metadata(args.config) or not 0 <= args.episode_index < len(source['episode_results']):
        raise ValueError('matched source/config and existing episode required')
    x = np.asarray(source['search']['nominal_coordinate_states']); u = np.asarray(source['controller']['controls'])
    k = np.asarray(source['controller']['feedback_gains']); nx, n = x.shape[1], cfg['env']['n_links']
    if (x.shape != (len(u)+1,2*(n+1)) or k.shape != (len(u),nx)
            or not np.array_equal(source['controller']['coordinate_transform'],np.eye(nx))):
        raise ValueError('physical-coordinate periodic source required')
    prior = source['episode_results'][args.episode_index]
    actual_initial = np.r_[prior['selected_state']['qpos'],prior['selected_state']['qvel']]
    initial_error = actual_initial-x[0]
    env = NLinkCartPoleEnv(cfg, progress=1., seed=0); env.reset(seed=0)
    begun = monotonic()
    try:
        transition = FourthOrderMujocoTransition(env, np.eye(nx), continuous_angles=True)
        derivatives = [transition.linearize(z,float(v),state_epsilon=.0002,action_epsilon=.0005)
                       for z,v in zip(x[:-1],u)]
        gaps = np.asarray([transition(z,float(v))-next_z for z,v,next_z in zip(x[:-1],u,x[1:])])
        calls = transition.evaluations
    finally: env.close()
    ctx = mpmath.mp.clone(); ctx.dps = 100
    matrix = lambda a: ctx.matrix(np.asarray(a,dtype=float).tolist())
    a = [matrix(pair[0]) for pair in derivatives]; b = [matrix(pair[1]) for pair in derivatives]
    gain = [matrix(row[None]) for row in k]; g = [matrix(row) for row in gaps]
    records = []
    for mode in ('mp_unsaturated_zero_defect','mp_unsaturated_measured_defect',
                 'mp_bounded_float32_measured_defect','binary64_feedback_bounded_float32_measured_defect'):
        e = matrix(initial_error); rows = []; saturated = 0; reason = 'step_budget'
        for step in range(args.steps):
            phase = step % len(u)
            correction = ((gain[phase]*e)[0] if not mode.startswith('binary64') else
                          ctx.mpf(float(k[phase]@np.asarray(e.tolist(),dtype=float).ravel())))
            raw = ctx.mpf(float(u[phase]))+correction
            saturated += int(abs(raw)>1)
            applied = raw
            if 'bounded' in mode:
                applied = ctx.mpf(float(np.float32(float(max(ctx.mpf(-1),min(ctx.mpf(1),raw))))))
            e = a[phase]*e+b[phase]*(applied-ctx.mpf(float(u[phase])))
            if not mode.endswith('zero_defect'): e += g[phase]
            absolute_error = [sum(e[j+1] for j in range(i+1)) for i in range(n)]
            cart = ctx.mpf(float(x[phase+1,0]))+e[0]
            rows.append(dict(step=step+1,time_seconds=(step+1)*cfg['env']['timestep']*cfg['env']['frame_skip'],
                raw_action=float(raw),applied_action=float(applied), cart=float(cart),
                maximum_cart_error=float(abs(e[0])), maximum_absolute_angle_error=float(max(abs(v) for v in absolute_error))))
            # Explicit local stop; subsequent behavior cannot be inferred from this model.
            if abs(e[0])>.25 or max(abs(v) for v in absolute_error)>.05:
                reason='declared_local_error_guard_crossed'; break
        records.append(dict(mode=mode, termination_reason=reason, steps=len(rows), saturated_steps=saturated,
            maximum_raw_action=max(abs(row['raw_action']) for row in rows),
            maximum_cart_error=max(row['maximum_cart_error'] for row in rows),
            maximum_absolute_angle_error=max(row['maximum_absolute_angle_error'] for row in rows), rows=rows))
        print(json.dumps({k:v for k,v in records[-1].items() if k!='rows'}),flush=True)
    dump_json(dict(not_solution=True, benchmark_evidence=False, source=file_metadata(args.source),
        config=file_metadata(args.config), runtime=runtime_metadata(), parameters=vars(args),
        actual_initial_error=initial_error.tolist(), measured_nominal_gaps=gaps.tolist(),
        maximum_measured_nominal_gap=float(np.max(np.abs(gaps))), derivative_transition_calls=calls,
        native_comparison={k:v for k,v in prior.items() if not isinstance(v,(dict,list))}, records=records,
        wall_time_seconds=monotonic()-begun,
        scope='Same binary64 fourth-order native derivative inputs and saved feedback. MP100 propagates the approximate linear model. Zero-defect cases omit known forcing; measured-defect cases include it. Initial error is measured from the actual selected state. Stop at cart error0.25m or absolute-angle error0.05rad; these guards are empirical locality limits, not certificates. No nonlinear remainder is modeled, no claim of native causality or real-time feasibility.'),out)


if __name__=='__main__': main()
