"""Sparse native state/control refinement; actual replay is the acceptance test."""
import argparse,json,time
from pathlib import Path
import numpy as np
from scipy import sparse
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.native_multiple_shooting_minimax_v2 import assemble_multiple_shooting_minimax,solve_multiple_shooting_minimax
from gcartpole.native_minimax import bounded_affine_minimax
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.solve_canonical15_native_minimax import features,gain_raw,first_proposals
read=lambda p:json.loads(Path(p).read_text())
def score(states,m):
 h=m['horizon'];xs=np.asarray(states)
 if len(xs)!=h+1:return [1,1,1e100,1e100,0]
 capture=xs[1+m['capture_offset']:];angles=abs(wrap_angle(np.cumsum(capture[:,1:16],axis=1)));safe=(np.max(angles,axis=1)<m['angle_limit'])&(abs(capture[:,0])<=m['rail_limit']);bad=np.flatnonzero(~safe);prefix=int(bad[0]) if len(bad) else len(capture);f=np.r_[angles.ravel()/m['angle_limit'],abs(xs[1:,0])/m['rail_limit']];ex=np.maximum(f-1,0);return [0,0 if np.all(safe) and np.max(abs(xs[:,0]))<=m['rail_limit'] else 1,float(np.max(f)),float(ex@ex),-prefix]
def protected(states,m):
 return len(states)==m['horizon']+1 and np.max(abs(wrap_angle(np.cumsum(states[1+m['capture_offset']:1+m['capture_offset']+m['protected_steps'],1:16],axis=1))))<m['angle_limit'] and np.max(abs(states[:,0]))<=m['rail_limit']
def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--directory',required=True);a=p.parse_args();m=read(a.manifest);out=Path(a.directory);out.mkdir(exist_ok=False);(out/'private').mkdir();h=m['horizon'];base=read(m['controller_source']['path']);s=read(m['source']['path']);U=np.asarray([q['action'] for q in s['result']['trajectory']],np.float32).astype(float);gain=np.asarray(read(m['gain_source']['path'])['gain'])
 for key in ('config','source','source_audit','gain_source','controller_source','center_tape','native_design','design_audit'):assert m[key]==file_metadata(m[key]['path'])
 assert read(m['source_audit']['path'])['passed'] and read(m['design_audit']['path'])['passed']
 with np.load(m['native_design']['path']) as z:X=z['states'].copy();V=z['actions'].copy();A0=z['A'].copy();B0=z['B'].copy();K=z['gains'].copy()
 initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);assert X[0].tobytes()==initial.tobytes();C=np.zeros((15,32));C[:,1:16]=np.tril(np.ones((15,15)));cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);env=NLinkCartPoleEnv(cfg,progress=1.,seed=m['nominal_seed']);env.reset(seed=m['nominal_seed']);began=time.monotonic();actual_ticks=0;current_role='source';payload=dict(status='running',generated_at=utc_timestamp(),manifest=file_metadata(a.manifest),script=file_metadata(__file__),kernel=file_metadata('src/gcartpole/native_multiple_shooting_minimax_v2.py'),runtime=runtime_metadata(),queries=[],forecasts=[],gap_checks=[],models=[],proposals=[],arms=[],rebases=[],maintenance_decisions=[],actual_records=[],not_solution=True,canonical_release_evidence=False,noisy_development_seeds_used=False,reserved_seeds_used=False)
 class Recorded(FourthOrderMujocoTransition):
  def __init__(self,*args,**kw):super().__init__(*args,**kw);self.buffer=[];self.attempts=0
  def flush(self):
   if not self.buffer:return
   qs=self.buffer;path=out/'private'/f'queries_{len(payload["queries"]):05d}.npz';np.savez_compressed(path,states=np.asarray([q[0] for q in qs]),actions=np.asarray([q[1] for q in qs]),raw_actions=np.asarray([q[2] for q in qs]),errors=np.asarray([q[3] for q in qs]),failed_post_states=np.asarray([q[4] for q in qs]),failed_times=np.asarray([q[5] for q in qs]),roles=np.asarray([q[6] for q in qs]));payload['queries'].append(dict(first=self.attempts-len(qs),count=len(qs),tape=file_metadata(path)));self.buffer=[]
  def __call__(self,state,action):
   pair=np.full((2,32),np.nan);pair[0]=state;error='';failed=np.full(32,np.nan);ft=np.nan;self.attempts+=1
   try:pair[1]=super().__call__(state,action)
   except BaseException as e:error=f'{type(e).__name__}: {e}';failed=np.r_[self.data.qpos,self.data.qvel].copy();ft=float(self.data.time);raise
   finally:
    self.buffer.append((pair,float(np.float32(np.clip(action,-1,1))),float(action),error,failed,ft,current_role))
    if len(self.buffer)>=2048:self.flush()
   return pair[1].copy()
 native=Recorded(env,np.eye(32),continuous_angles=True)
 def forecast(reference,ff,runtime,label):
  nonlocal current_role
  index=len(payload['forecasts']);current_role=f'forecast_{index}';start=native.attempts;xs=[initial.copy()];us=[];raws=[];error=None;failed=np.full(32,np.nan);ft=np.nan;scale=m['feedback_scales'][runtime]
  try:
   for i in range(h):
    raw=float(ff[i])+float((scale*K[i])@(xs[-1]-reference[i]));u=float(np.float32(np.clip(raw,-1,1)));us.append(u);raws.append(raw);xs.append(native(xs[-1],u))
  except SimulationError as e:error=f'SimulationError: {e}';failed=np.r_[native.data.qpos,native.data.qvel].copy();ft=float(native.data.time)
  path=out/'private'/f'forecast_{index:05d}.npz';z=dict(states=np.asarray(xs),actions=np.asarray(us),raw_actions=np.asarray(raws),reference=np.asarray(reference),feedforward=np.asarray(ff),failed_post_state=failed,failed_time=np.asarray(ft));np.savez_compressed(path,**z);row=dict(index=index,runtime=runtime,label=label,tape=file_metadata(path),query_start=start,query_end=native.attempts,error=error,score=score(z['states'],m),native_protected=bool(protected(z['states'],m)));payload['forecasts'].append(row);return dict(row=row,**z)
 def gaps(reference,ff,label):
  nonlocal current_role
  index=len(payload['gap_checks']);current_role=f'gap_{index}';start=native.attempts;g=np.full((h,32),np.nan);errors=[]
  for i in range(h):
   try:g[i]=native(reference[i],float(ff[i]))-reference[i+1];errors.append(None)
   except SimulationError as e:errors.append(f'SimulationError: {e}')
  path=out/'private'/f'gaps_{index:05d}.npz';np.savez_compressed(path,states=reference,actions=ff,defects=g);row=dict(index=index,label=label,tape=file_metadata(path),query_start=start,query_end=native.attempts,errors=errors,maximum_gap=None if any(errors) else float(np.max(abs(g))));payload['gap_checks'].append(row);return index,g
 def build_model(center,fresh):
  nonlocal current_role
  index=len(payload['models']);start=native.attempts;current_role=f'model_{index}'
  if fresh:
   A=np.empty((h,32,32));B=np.empty((h,32,1))
   for i in range(h):
    A[i],B[i]=native.linearize(center['states'][i],float(center['actions'][i]),state_epsilon=m['state_epsilon'],action_epsilon=m['action_epsilon'])
    if i%100==0:print(dict(model=index,step=i,calls=native.attempts),flush=True)
  else:A=A0.copy();B=B0.copy()
  path=out/'private'/f'model_{index:05d}.npz';np.savez_compressed(path,states=center['states'],actions=center['actions'],A=A,B=B,defects=np.zeros((h,32)));row=dict(index=index,center_forecast=center['row']['index'],fresh=fresh,tape=file_metadata(path),query_start=start,query_end=native.attempts);payload['models'].append(row);return row,A,B
 def proposal(center,model,radius,runtime,label):
  mr,A,B=model;R=np.r_[np.full(16,radius),np.full(16,radius*m['velocity_radius_multiplier'])];V=radius*m['action_radius_multiplier'];problem=assemble_multiple_shooting_minimax(center['states'],center['actions'],A,B,C,wrap_angle(center['states']@C.T),capture_start=m['capture_offset'],protected_steps=m['protected_steps'],angle_limit=m['angle_limit'],rail_limit=m['rail_limit'],state_radii=R,control_radii=V);index=len(payload['proposals']);pref=out/'private'/f'lp_{index:05d}';eq=Path(str(pref)+'_equality.npz');ineq=Path(str(pref)+'_inequality.npz');meta=Path(str(pref)+'_model.npz');sparse.save_npz(eq,problem['A_eq']);sparse.save_npz(ineq,problem['A_ub']);np.savez_compressed(meta,**{k:v for k,v in problem.items() if not sparse.issparse(v)});sol,diag=solve_multiple_shooting_minimax(problem,solver_seconds=m['lp_seconds']);row=dict(index=index,label=label,runtime=runtime,center_before=center['row']['index'],model_index=mr['index'],pose_radius=radius,equality=file_metadata(eq),inequality=file_metadata(ineq),model=file_metadata(meta),diagnostics=diag,solution=None,backtracks=[],accepted=None);payload['proposals'].append(row);selected=center
  if sol is not None:
   dest=Path(str(pref)+'_solution.npz');np.savez_compressed(dest,**sol);row['solution']=file_metadata(dest)
   for power in range(m['backtrack_powers']):
    alpha=2.**(-power);ref=center['states']+alpha*sol['state_step'];ff=np.asarray(center['actions']+alpha*sol['action_step'],np.float32).astype(float);gi,g=gaps(ref,ff,label+f'_backtrack{power}');candidate=forecast(ref,ff,runtime,label+f'_backtrack{power}');bt=dict(power=power,gap_check=gi,forecast=candidate['row']['index']);row['backtracks'].append(bt)
    if candidate['row']['score']<center['row']['score'] and candidate['row']['native_protected']:selected=candidate;row['accepted']=candidate['row']['index'];break
  row['center_after']=selected['row']['index'];print(dict(proposal=label,lp=diag,backtracks=len(row['backtracks']),accepted=row['accepted'],score=selected['row']['score'],calls=native.attempts),flush=True);native.flush();dump_json(payload,out/'result.progress.json');return selected,row
 def rebase(center,runtime,event):
  baseline=forecast(center['states'],center['actions'],runtime,event);assert baseline['states'].tobytes()==center['states'].tobytes() and baseline['actions'].tobytes()==center['actions'].tobytes();gi,g=gaps(baseline['states'],baseline['actions'],event);assert np.count_nonzero(g)==0;payload['rebases'].append(dict(parent=center['row']['index'],forecast=baseline['row']['index'],gap_check=gi,runtime=runtime,event=event));return baseline
 def maintenance(state,tick,last,label):
  om=m['maintenance'];pairs=[];calls=[];errors=[];failed_states=[];failed_times=[]
  def evaluate(x,raw,role):
   u=float(np.float32(np.clip(raw,-1,1)));pair=np.full((2,32),np.nan);pair[0]=x;error=None;failed_state=np.full(32,np.nan);failed_time=np.nan
   try:pair[1]=native(x,u)
   except SimulationError as e:error=f'SimulationError: {e}';failed_state=np.r_[native.data.qpos,native.data.qvel].copy();failed_time=float(native.data.time)
   index=len(calls);failed_states.append(failed_state);failed_times.append(failed_time);calls.append((pair,u,float(raw),role));errors.append(error)
   if error is not None:
    pending=out/'private'/f'maintenance_pending_{len(payload["maintenance_decisions"]):05d}.npz';np.savez_compressed(pending,states=np.asarray([c[0] for c in calls]),actions=np.asarray([c[1] for c in calls]),raw_actions=np.asarray([c[2] for c in calls]),roles=np.asarray([c[3] for c in calls]),failed_post_states=np.asarray(failed_states),failed_times=np.asarray(failed_times));dump_json(dict(label=label,tick=tick,errors=errors,tape=file_metadata(pending)),pending.with_suffix('.json'))
   return index,pair[1] if error is None else None
  mi,minus=evaluate(state,-1.,'first_minus');pi,plus=evaluate(state,1.,'first_plus')
  if minus is None or plus is None:raise RuntimeError('Maintenance anchor failed; preserve new failed evidence')
  proposal=bounded_affine_minimax(features(minus,0.,om),features(plus,0.,om));raw=gain_raw(gain,state);source=float(U[tick]) if tick<len(U) else 0.;commands,pr=first_proposals(raw,proposal,source,last,om)
  for i,u in enumerate(commands):
   fi,first=evaluate(state,float(u),f'first_{i}');row=dict(index=i,first_id=fi,second_minus_id=None,second_plus_id=None,second_id=None,second_raw=None,score=[1,1e100,abs(float(u))])
   if first is not None:
    sm,minus=evaluate(first,-1.,f'second_minus_{i}');sp,plus=evaluate(first,1.,f'second_plus_{i}');row.update(second_minus_id=sm,second_plus_id=sp)
    if minus is not None and plus is not None:
     raw2=bounded_affine_minimax(features(minus,0.,om),features(plus,0.,om));si,second=evaluate(first,raw2,f'second_selected_{i}');row.update(second_id=si,second_raw=raw2)
     if second is not None:row['score']=[0,float(max(np.max(abs(features(first,0.,om))),np.max(abs(features(second,0.,om))))),abs(float(u))]
   pairs.append(row)
  winner=min(range(len(pairs)),key=lambda i:tuple(pairs[i]['score']));tape=out/'private'/f'maintenance_{len(payload["maintenance_decisions"]):05d}.npz';np.savez_compressed(tape,states=np.asarray([c[0] for c in calls]),actions=np.asarray([c[1] for c in calls]),raw_actions=np.asarray([c[2] for c in calls]),roles=np.asarray([c[3] for c in calls]),candidate_actions=commands,candidate_raw_proposals=pr,failed_post_states=np.asarray(failed_states),failed_times=np.asarray(failed_times));d=dict(label=label,tick=tick,tape=file_metadata(tape),errors=errors,first_minus_id=mi,first_plus_id=pi,proposal=proposal,gain_raw=raw,source_action=source,last_action=last,candidates=pairs,winner_index=winner);payload['maintenance_decisions'].append(d)
  if pairs[winner]['score'][0]:raise RuntimeError('No complete maintenance forecast')
  return float(commands[winner]),calls[pairs[winner]['first_id']][0][1]

 def actual_episode(selected,runtime):
  nonlocal actual_ticks,current_role
  actual=NLinkCartPoleEnv(cfg,progress=1.,seed=m['nominal_seed']);actual.reset(seed=m['nominal_seed']);xs=[initial.copy()];us=[];raws=[];info=None;reason=None;label=runtime+'_h441';current_role='actual_maintenance_'+runtime
  try:
   for tick in range(actual.max_steps):
    state=np.r_[actual.data.qpos,actual.data.qvel]
    if tick<h:raw=float(selected['feedforward'][tick])+float((m['feedback_scales'][runtime]*K[tick])@(state-selected['reference'][tick]));u=float(np.float32(np.clip(raw,-1,1)));prediction=selected['states'][tick+1]
    else:u,prediction=maintenance(state,tick,float(us[-1]),label);raw=u
    _,_,terminated,truncated,info=actual.step([u]);actual_ticks+=1;xs.append(np.r_[actual.data.qpos,actual.data.qvel].copy());us.append(u);raws.append(raw);assert xs[-1].tobytes()==prediction.tobytes()
    if terminated or truncated:reason=info['termination_reason'];break
  finally:
   actual.close();path=out/(label+'_actual.npz');np.savez_compressed(path,states=np.asarray(xs),actions=np.asarray(us),raw_actions=np.asarray(raws));native.flush()
  current_role='actual_replay_'+runtime
  for i,u in enumerate(us):assert native(xs[i],u).tobytes()==xs[i+1].tobytes()
  safe=np.max(abs(wrap_angle(np.cumsum(np.asarray(xs)[1:,1:16],axis=1))),axis=1)<.15;streak=longest=0
  for ok in safe:streak=streak+1 if ok else 0;longest=max(longest,streak)
  cart=float(np.max(abs(np.asarray(xs)[:,0])));passed=len(us)==1500 and longest>=250 and cart<=3 and reason=='time_limit' and not info['simulation_error'];row=dict(label=label,runtime=runtime,selected_forecast=selected['row']['index'],tape=file_metadata(path),actual_hanging_start_episode_steps=len(us),hold_seconds=longest*.02,maximum_cart=cart,termination_reason=reason,simulation_error=info['simulation_error'],full_nominal_gate_passed=passed);payload['actual_records'].append(row);print(row,flush=True)
 try:
  for i,u in enumerate(V):assert native(X[i],float(u)).tobytes()==X[i+1].tobytes()
  for runtime in m['feedback_scales']:
   baseline=forecast(X,V,runtime,'initial');assert baseline['states'].tobytes()==X.tobytes() and baseline['actions'].tobytes()==V.tobytes();model=build_model(baseline,False);best=baseline;chosen=None;ar=dict(runtime=runtime,initial=baseline['row']['index'],calibrations=[],refinements=[]);payload['arms'].append(ar)
   for radius in m['pose_radii']:
    selected,row=proposal(baseline,model,radius,runtime,runtime+f'_radius{radius}');ar['calibrations'].append(row['index'])
    if selected['row']['score']<best['row']['score']:best=selected;chosen=radius
   ar['selected_radius']=chosen
   if chosen is not None:
    best=rebase(best,runtime,'calibration_selected')
    for iteration in range(m['refinement_iterations']):
     if best['row']['score'][1]==0:break
     model=build_model(best,True);selected,row=proposal(best,model,chosen,runtime,runtime+f'_refine{iteration}');ar['refinements'].append(row['index'])
     if row['accepted'] is None:break
     best=rebase(selected,runtime,f'refine{iteration}')
   ar.update(selected=best['row']['index'],score=best['row']['score']);actual_episode(best,runtime);native.flush();dump_json(payload,out/'result.progress.json')
  payload['status']='finished'
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}');raise
 finally:
  native.flush();payload.update(total_native_transition_calls=native.attempts+actual_ticks,actual_hanging_start_episode_steps=actual_ticks,wall_seconds=time.monotonic()-began);dump_json(payload,out/'result.json');env.close()
if __name__=='__main__':main()
