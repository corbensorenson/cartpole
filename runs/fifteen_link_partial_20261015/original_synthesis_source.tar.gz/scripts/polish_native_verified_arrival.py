#!/usr/bin/env python
"""Refine a native-valid delivered plan for quieter arrival, retaining its bounds.

Task singular responses propose sparse changes; native physics decides both
feasibility and objective improvement. No forecast replaces the live state.
"""
import argparse,json,time
from pathlib import Path
import numpy as np
import mpmath
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata,data_sha256
from gcartpole.ilqr import MujocoTransition
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.native_action_pairs import balanced_action_pairs,balanced_action_triples,balanced_action_quadruples,rank_pairs_by_physical_bounds
from gcartpole.native_task_derivatives import physical_task_residual,chained_physical_task_jacobian
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.synthesize_native_coordinate_continuation import score_native_forecast


def arrival_residual(states,n_links,rate_weight,terminal_rate_weight):
    if not np.isfinite(terminal_rate_weight) or terminal_rate_weight<=0:
        raise ValueError('positive terminal rate weight required')
    residual=physical_task_residual(states,n_links,rate_weight,.1)
    residual[-n_links:]*=np.sqrt(terminal_rate_weight/5.)
    return residual


def arrival_jacobian(unbanded,states,n_links,terminal_rate_weight):
    states=np.asarray(states,float);h=len(states);n=n_links
    if (unbanded.shape!=(2*n*h+2*h+2*n,h) or not np.all(np.isfinite(unbanded))
            or not np.isfinite(terminal_rate_weight) or terminal_rate_weight<=0):
        raise ValueError('aligned unbanded task Jacobian and positive weight required')
    jac=unbanded.copy();active=np.abs(wrap_angle(np.cumsum(states[:,1:n+1],axis=1)))>.1
    jac[:n*h]*=active.ravel()[:,None]
    begin=2*n*h+2*h;jac[begin:begin+n]*=active[-1,:,None]
    jac[-n:]*=np.sqrt(terminal_rate_weight/5.)
    return jac


def endpoint_physical_jacobian(unbanded, *, n_links, horizon, rate_weight):
    """Recover the terminal relative-coordinate response from physical task rows."""
    n=n_links;h=horizon
    if unbanded.shape!=(2*n*h+2*h+2*n,h) or rate_weight<=0:
        raise ValueError('aligned raw task response and positive rate scale required')
    result=np.zeros((2*(n+1),h))
    result[0]=unbanded[2*n*h+h-1]*(1.5*np.sqrt(h)/.1)
    result[n+1]=unbanded[2*n*h+2*h-1]*(.5*np.sqrt(h)/.1)
    begin=2*n*h+2*h
    angles=unbanded[begin:begin+n]*(.15*np.sqrt(n)/np.sqrt(5))
    rates=unbanded[-n:]*(.75*np.sqrt(n)/(np.sqrt(5)*rate_weight))
    result[1:n+1]=np.diff(np.vstack([np.zeros((1,h)),angles]),axis=0)
    result[n+2:]=np.diff(np.vstack([np.zeros((1,h)),rates]),axis=0)
    return result


class DirectionalArrival:
    """Normalized stored capture directions; diagnostics, not a viability proof."""
    def __init__(self,factor,gain,initial_state,n_links,weight):
        nx=2*(n_links+1);factor=np.asarray(factor,float);gain=np.asarray(gain,float)
        if (factor.ndim!=2 or factor.shape[1]!=nx or gain.shape!=(nx,)
                or not np.all(np.isfinite(factor)) or not np.all(np.isfinite(gain))
                or not np.isfinite(weight) or weight<=0):
            raise ValueError('finite aligned capture factor/gain and positive weight required')
        self.ctx=mpmath.mp.clone();self.ctx.dps=100;self.n=n_links;self.weight=weight
        self.factor=self.ctx.matrix(factor.tolist());self.gain=self.ctx.matrix([gain.tolist()])
        state=self.state(initial_state);value=self.factor*state;action=self.gain*state
        self.value_scale=max(self.ctx.mpf(1),self.ctx.sqrt(self.ctx.fsum(v*v for v in value)))
        self.action_scale=max(self.ctx.mpf(1),abs(action[0]))
        self.mapping=self.ctx.matrix(factor.shape[0]+1,nx)
        scale=self.ctx.sqrt(weight)
        for row in range(factor.shape[0]):
            for col in range(nx):self.mapping[row,col]=scale*self.factor[row,col]/self.value_scale
        for col in range(nx):self.mapping[factor.shape[0],col]=scale*self.gain[0,col]/self.action_scale

    def state(self,state):
        state=np.asarray(state,float).copy();state[1:self.n+1]=wrap_angle(state[1:self.n+1])
        return self.ctx.matrix(state.tolist())

    def residual(self,state):
        return np.asarray(list(self.mapping*self.state(state)),float)

    def jacobian(self,endpoint_response):
        return np.asarray((self.mapping*self.ctx.matrix(endpoint_response.tolist())).tolist(),float)

    def diagnostics(self,state):
        state=self.state(state);value=self.factor*state
        return dict(saved_capture_value=float(self.ctx.fsum(v*v for v in value)),
                    raw_normalized_capture_action=-float((self.gain*state)[0]))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    p.add_argument('--terminal-rate-weight',type=float,default=100.)
    p.add_argument('--move-arity',type=int,choices=(2,3,4),default=3)
    p.add_argument('--max-support-span',type=int,default=12)
    p.add_argument('--forecast-angle-limit',type=float,default=.149)
    p.add_argument('--rounds',type=int,default=4)
    p.add_argument('--candidates-per-round',type=int,default=2000)
    p.add_argument('--total-native-transition-budget',type=int,default=500000)
    p.add_argument('--capture-cache')
    p.add_argument('--directional-weight',type=float,default=100.)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    if min(args.rounds,args.candidates_per_round,args.total_native_transition_budget)<1 or args.max_support_span<2:
        raise ValueError('positive bounded search settings required')
    plan=json.loads(Path(args.source).read_text())
    if not plan['feasible_sequence_found'] or not plan['known_plan_byte_identical'] or not plan['live_state_unchanged']:
        raise ValueError('independently verified native plan required')
    cursor=plan;ancestry=[];seen_paths=set()
    while not all(k in cursor for k in ('config','teacher','parameters')):
        ref=cursor['source'];path=ref['path']
        if path in seen_paths or len(ancestry)>=8 or file_metadata(path)!=ref:raise ValueError('plan ancestry changed or cyclic')
        seen_paths.add(path);ancestry.append(ref);cursor=json.loads(Path(path).read_text())
    for key in ('source','config','teacher'):
        if file_metadata(cursor[key]['path'])!=cursor[key]:raise ValueError('bound physical inputs changed')
    base=json.loads(Path(cursor['source']['path']).read_text());cfg=load_config(cursor['config']['path'])
    n=cfg['env']['n_links'];nx=2*(n+1);step=cursor['parameters']['start_step'];rate=cursor['parameters']['rate_residual_weight']
    actions=np.asarray(plan['selected_sequence'],np.float32).astype(float);expected=np.asarray(plan['selected_states']);h=len(actions)
    reference=np.asarray(base['controller']['controls'][step:step+h],np.float32).astype(float)
    if expected.shape!=(h,nx) or reference.shape!=actions.shape:raise ValueError('aligned physical plan required')
    directional=None
    if args.capture_cache:
        cache=json.loads(Path(args.capture_cache).read_text());factor=np.asarray(base['lyapunov']['factor'])
        if (cache['source']!=file_metadata(cursor['source']['path'])
                or not cache['maintenance_factor_reproduced_bit_identically']
                or cache['factor_sha256']!=data_sha256(factor.tolist())
                or not np.array_equal(base['controller']['coordinate_transform'],np.eye(nx))):
            raise ValueError('aligned stored physical capture metric required')
        directional=DirectionalArrival(factor,cache['gain'],expected[-1],n,args.directional_weight)
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True);local=FourthOrderMujocoTransition(env,np.eye(nx),continuous_angles=True)
    untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()];began=time.monotonic();rounds=[]
    payload=dict(not_solution=True,canonical_release_evidence=False,source=file_metadata(args.source),parameters=vars(args),
        runtime=runtime_metadata(),input_ancestry=ancestry,physical_inputs={k:cursor[k] for k in ('source','config','teacher')},
        actual_episode_steps=0,optimizer_transition_calls=0,reserved_seeds_used=False,noisy_development_seeds_used=False,
        rounds=rounds,scope='Fixed-horizon native-valid delivered F32 plan refined for weighted terminal absolute-rate cost. Every accepted proposal remains inside declared physical angle/rail bounds and lowers native task cost. A quieter forecast is not capture or an accepted record. All derivative,prefix,proposal and independent check transitions count against total budget.')
    if directional:
        payload.update(capture_cache=file_metadata(args.capture_cache),
            directional_scales=dict(value_norm=str(directional.value_scale),action_magnitude=str(directional.action_scale)),
            scope=payload['scope']+' Appended saved capture-factor and raw-action directions use fixed initial norm scales and MP100 contractions;their improvement is not bounded-maintenance viability.')
    def within_budget(calls,reserve=0):return native.evaluations+local.evaluations+calls+reserve<=args.total_native_transition_budget
    def forecast(initial,controls):
        state=initial.copy();states=[]
        for action in controls:state=native(state,float(action));states.append(state.copy())
        return np.asarray(states)
    def measure(states,controls):
        score,feasible,maximum=score_native_forecast(states,controls,reference,n_links=n,rate_weight=rate,
            angle_limit=args.forecast_angle_limit,rail_limit=env.rail_limit)
        residual=arrival_residual(states,n,rate,args.terminal_rate_weight)
        if directional:residual=np.r_[residual,directional.residual(states[-1])]
        return float(residual@residual+1e-4*np.sum((controls-reference)**2)),feasible,maximum
    def endpoints(states):
        rates=np.cumsum(states[-1,n+2:])
        result=dict(terminal_absolute_rate_max=float(np.max(np.abs(rates))),terminal_absolute_rate_rms=float(np.sqrt(np.mean(rates*rates))),
            terminal_cart_position=float(states[-1,0]),terminal_cart_velocity=float(states[-1,n+1]))
        if directional:result.update(directional.diagnostics(states[-1]))
        return result
    try:
        if not within_budget(step+h,h):raise ValueError('budget cannot verify input and final plans')
        state=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
        for row in base['result']['trajectory'][:step]:
            state=native(state,float(np.float32(row['action'])))
            if state.tobytes()!=np.asarray(row['qpos']+row['qvel']).tobytes():raise ValueError('cold source prefix changed')
        states=forecast(state,actions)
        if states.tobytes()!=expected.tobytes():raise ValueError('input forecasts differ from native replay')
        cost,feasible,maximum=measure(states,actions)
        if not feasible:raise ValueError('input plan not admissible at requested bound')
        payload.update(source_prefix_byte_identical=True,known_plan_byte_identical=True,
            initial_cost=cost,initial_maximum_angle=maximum,initial_endpoint=endpoints(states),horizon_steps=h)
        seen={actions.tobytes()};status='round_limit'
        for index in range(args.rounds):
            before=native.evaluations;local_before=local.evaluations
            if not within_budget((4*nx+6)*h,2*h):status='total_native_transition_budget';break
            raw=chained_physical_task_jacobian(local,state,actions,states,n_links=n,rate_weight=rate,
                state_epsilon=base['controller']['state_epsilon'],action_epsilon=base['controller']['action_epsilon'],angle_band=0.)
            jac=arrival_jacobian(raw,states,n,args.terminal_rate_weight);residual=arrival_residual(states,n,rate,args.terminal_rate_weight)
            if directional:
                response=endpoint_physical_jacobian(raw,n_links=n,horizon=h,rate_weight=rate)
                jac=np.vstack([jac,directional.jacobian(response)])
                residual=np.r_[residual,directional.residual(states[-1])]
            if args.move_arity==4:proposals,model=balanced_action_quadruples(actions,jac,residual,reference,max_support_span=args.max_support_span)
            elif args.move_arity==3:proposals,model=balanced_action_triples(actions,jac,residual,reference,max_support_span=args.max_support_span)
            else:proposals,model=balanced_action_pairs(actions,jac,residual,reference)
            proposals=rank_pairs_by_physical_bounds(proposals,model['spacing'],raw,states,n_links=n,
                angle_limit=args.forecast_angle_limit,rail_limit=env.rail_limit)
            spacing=np.asarray(model['spacing']);best=None;chosen=None;tested=invalid=admissible=0
            for proposal in proposals:
                if tested>=args.candidates_per_round:break
                indices=proposal['indices'];first=indices[0];controls=actions.copy()
                controls[indices]+=spacing[indices]*proposal['offsets_ulps'];key=controls.tobytes()
                if key in seen:continue
                if not within_budget(h-first,2*h):status='total_native_transition_budget';break
                if key!=controls.astype(np.float32).astype(float).tobytes():raise ValueError('nonrepresentable sparse move')
                seen.add(key);tested+=1
                try:
                    tail=forecast(state if first==0 else states[first-1],controls[first:]);candidate=np.vstack([states[:first],tail])
                    next_cost,allowed,angle=measure(candidate,controls)
                except SimulationError:invalid+=1;continue
                admissible+=allowed
                if allowed and next_cost<cost and (best is None or next_cost<best[0]):
                    best=(next_cost,controls,candidate,angle);chosen=proposal
            improved=best is not None
            if improved:
                cost,actions,states,maximum=best
                replay=forecast(state,actions)
                if replay.tobytes()!=states.tobytes() or not measure(replay,actions)[1]:raise ValueError('selected plan failed byte replay')
            rounds.append(dict(round=index,improved=improved,cost=cost,maximum_angle=maximum,tested_candidates=tested,
                invalid_candidates=invalid,admissible_candidates=int(admissible),selected_proposal=chosen,proposal_model=model,
                native_forecast_transition_calls=native.evaluations-before,native_local_derivative_transition_calls=local.evaluations-local_before,
                endpoint=endpoints(states)))
            print(json.dumps({k:rounds[-1][k] for k in ('round','improved','cost','maximum_angle','tested_candidates','endpoint')}),flush=True)
            if status=='total_native_transition_budget':break
            if not improved:status='no_improving_tested_feasible_move';break
        replay=forecast(state,actions)
        if replay.tobytes()!=states.tobytes():raise ValueError('final plan does not independently reproduce')
        if untouched.tobytes()!=np.r_[env.data.qpos,env.data.qvel].tobytes():raise ValueError('planner changed live state')
        payload.update(status=status,feasible_sequence_found=True,selected_sequence=actions.tolist(),selected_states=states.tolist(),
            final_cost=cost,final_maximum_angle=maximum,final_endpoint=endpoints(states),live_state_unchanged=True,
            native_forecast_transition_calls=native.evaluations,native_local_derivative_transition_calls=local.evaluations,
            total_native_transition_calls=native.evaluations+local.evaluations,wall_seconds=time.monotonic()-began)
        if payload['total_native_transition_calls']>args.total_native_transition_budget:raise ValueError('total budget exceeded')
        dump_json(payload,out/'result.json')
    finally:env.close()


if __name__=='__main__':main()
