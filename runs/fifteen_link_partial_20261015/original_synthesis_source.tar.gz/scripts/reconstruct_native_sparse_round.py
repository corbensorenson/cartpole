"""Reconstruct a completed sparse round and independently replay its physical tape."""
import argparse,json
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.native_action_lattice import affine_action_lattice
from gcartpole.native_task_derivatives import physical_task_residual
from gcartpole.native_bound_objective import bound_diagnostics,native_bound_score
from scripts.search_capture_sequence import fixed_state_cfg


def reconstruct_actions(source,round_index):
    rounds=source['rounds'];center=np.asarray(source['initial_sequence'],float).copy()
    if (not isinstance(round_index,int) or not 0<=round_index<len(rounds)
            or center.ndim!=1 or not len(center) or not np.all(np.isfinite(center))
            or np.max(np.abs(center))>1 or center.tobytes()!=center.astype(np.float32).astype(float).tobytes()):
        raise ValueError('delivered finite center and recorded round required')
    for r in rounds[:round_index+1]:
        if not r['improved']:continue
        proposal=r['selected_proposal'];model=r['proposal_model']
        indices=np.asarray(proposal['indices']);offsets=np.asarray(proposal['offsets_ulps'])
        spacing,lower,upper=affine_action_lattice(center,4096)
        if (indices.ndim!=1 or not len(indices) or not np.issubdtype(indices.dtype,np.integer)
                or np.any(indices<0) or np.any(indices>=len(center)) or np.any(np.diff(indices)<=0)
                or offsets.shape!=indices.shape or not np.issubdtype(offsets.dtype,np.integer)
                or np.any(offsets==0) or np.asarray(model['spacing']).tobytes()!=spacing.tobytes()
                or np.any(offsets<lower[indices]) or np.any(offsets>upper[indices])):
            raise ValueError('recorded sparse move differs from its delivered lattice')
        center[indices]+=spacing[indices]*offsets
        if center.tobytes()!=center.astype(np.float32).astype(float).tobytes():raise ValueError('reconstructed move is not delivered F32')
    return center


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True)
    p.add_argument('--round',type=int,required=True);p.add_argument('--directory',required=True);args=p.parse_args()
    out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    source=json.loads(Path(args.source).read_text());center=reconstruct_actions(source,args.round)
    full=reconstruct_actions(source,len(source['rounds'])-1)
    if full.tobytes()!=np.asarray(source['last_finite_center']).tobytes():raise ValueError('complete move history differs from saved final center')
    growth_ref=source['source']
    if file_metadata(growth_ref['path'])!=growth_ref:raise ValueError('changed growth source')
    growth=json.loads(Path(growth_ref['path']).read_text());original=growth;ancestry=[];seen=set()
    while not all(k in original for k in ('config','teacher','parameters')):
        ref=original['source']
        if ref['path'] in seen or len(ancestry)>=8 or file_metadata(ref['path'])!=ref:raise ValueError('changed/cyclic physical ancestry')
        seen.add(ref['path']);ancestry.append(ref);original=json.loads(Path(ref['path']).read_text())
    for key in ('source','config','teacher'):
        if file_metadata(original[key]['path'])!=original[key]:raise ValueError('physical input changed')
    cfg=load_config(original['config']['path']);n=cfg['env']['n_links'];nx=2*(n+1)
    base=json.loads(Path(original['source']['path']).read_text());step=original['parameters']['start_step']
    rate=original['parameters']['rate_residual_weight'];h=len(center)
    reference=np.asarray(base['controller']['controls'][step:step+h],np.float32).astype(float)
    if len(reference)!=h:raise ValueError('unpadded reference required')
    limit=source['parameters']['forecast_angle_limit'];objective=source['parameters'].get('bound_objective','sum')
    def score(states,actions):
        d=bound_diagnostics(states,n,limit,cfg['env']['rail_limit']);r=physical_task_residual(states,n,rate,.1)
        return native_bound_score(d,float(r@r+1e-4*np.sum((actions-reference)**2)),objective),d
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True);untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
    try:
        state=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
        for row in base['result']['trajectory'][:step]:
            state=native(state,float(np.float32(row['action'])))
            if state.tobytes()!=np.asarray(row['qpos']+row['qvel']).tobytes():raise ValueError('cold prefix changed')
        def forecast(actions):
            current=state.copy();states=[]
            for u in actions:current=native(current,float(u));states.append(current.copy())
            return np.asarray(states)
        known=forecast(np.asarray(growth['last_valid_plan'],np.float32).astype(float))
        if known.tobytes()!=np.asarray(growth['last_valid_forecast_states']).tobytes():raise ValueError('known plan changed')
        initial=forecast(np.asarray(source['initial_sequence']))
        if list(score(initial,np.asarray(source['initial_sequence']))[0])!=source['initial_score']:raise ValueError('initial old score changed')
        final=forecast(full)
        if final.tobytes()!=np.asarray(source['last_finite_states']).tobytes() or list(score(final,full)[0])!=source['last_finite_score']:raise ValueError('final tape/old score changed')
        states=forecast(center);old_score,diagnostics=score(states,center);record=source['rounds'][args.round]
        if list(old_score)!=record['score'] or diagnostics['maximum_angle']!=record['maximum_angle']:raise ValueError('selected round old score/angle changed')
        checked=forecast(center)
        if checked.tobytes()!=states.tobytes():raise ValueError('selected round replay differs')
        if untouched.tobytes()!=np.r_[env.data.qpos,env.data.qvel].tobytes():raise ValueError('planner changed live state')
        data=dict(source=growth_ref,reconstructed_from=file_metadata(args.source),input_ancestry=ancestry,
            parameters=dict(forecast_angle_limit=limit,bound_objective=objective),preparation_parameters=vars(args),
            horizon_steps=h,last_finite_center=center.tolist(),last_finite_states=states.tolist(),last_finite_score=list(old_score),
            known_plan_byte_identical=True,live_state_unchanged=True,source_initial_score_exact=True,source_final_tape_and_score_exact=True,
            selected_round_score_and_angle_exact=True,independent_selected_round_replay_bytes_exact=True,
            bound_diagnostics=diagnostics,feasible_sequence_found=diagnostics['feasible'],
            native_transition_calls=native.evaluations,total_native_transition_calls=native.evaluations,
            native_physics_steps=native.evaluations*env.frame_skip,actual_episode_steps=0,optimizer_transition_calls=0,
            not_solution=True,canonical_release_evidence=False,reserved_seeds_used=False,noisy_development_seeds_used=False,
            runtime=runtime_metadata(),scope='Reconstruct delivered sparse moves through one completed round;independently replay cold prefix,known plan,initial/final source scores and selected round twice. No new search,actual episode or record;the reconstructed center may remain infeasible.')
        dump_json(data,out/'result.json');print(json.dumps(dict(round=args.round,score=list(old_score),maximum_angle=diagnostics['maximum_angle'],native_calls=native.evaluations)))
    finally:env.close()
if __name__=='__main__':main()
