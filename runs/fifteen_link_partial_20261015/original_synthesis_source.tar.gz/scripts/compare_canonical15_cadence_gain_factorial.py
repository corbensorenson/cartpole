"""Matched cadence by scalar gain attenuation after one actual 50 Hz swing."""
import argparse,json,time,hashlib
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg
read=lambda p:json.loads(Path(p).read_text())
def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--directory',required=True);a=p.parse_args();m=read(a.manifest);out=Path(a.directory);out.mkdir(exist_ok=False)
 for k in ('source','config','gain_source','source_audit','matched_baseline'):assert m[k]==file_metadata(m[k]['path'])
 assert read(m['source_audit']['path'])['passed'];s=read(m['source']['path']);base=read(s['source']['path']);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in s['result']['trajectory']]]);U=np.asarray([q['action'] for q in s['result']['trajectory']],np.float32).astype(float);gain=np.asarray(read(m['gain_source']['path'])['gain']);cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.)
 assert cfg['env']['timestep']==.005 and cfg['env']['frame_skip']==4 and base['seed']==20265100
 payload=dict(status='running',generated_at=utc_timestamp(),manifest=file_metadata(a.manifest),runtime=runtime_metadata(),records=[],canonical_release_evidence=False,not_solution=True,noisy_development_seeds_used=False,reserved_seeds_used=False,optimizer_history='Not applicable: factorial fixed gain scalars, no optimization');began=time.monotonic();xmls=[]
 try:
  proofenv=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);proofenv.reset(seed=20265100);native=MujocoTransition(proofenv,np.eye(32),continuous_angles=True)
  for tick in range(m['start_step']):assert native(X[tick],float(U[tick])).tobytes()==X[tick+1].tobytes()
  for arm in m['arms']:
   skip=arm['frame_skip'];multiplier=arm['gain_multiplier'];label=arm['label'];actual=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);actual.reset(seed=20265100);actual.max_steps=m['start_step']+(6000-4*m['start_step'])//skip;xmlhash=hashlib.sha256(actual.xml.encode()).hexdigest();xmls.append(xmlhash);assert len(set(xmls))==1
   xs=[np.r_[actual.data.qpos,actual.data.qvel]];us=[];raws=[];skips=[];times=[float(actual.data.time)];infos=[];reason=None
   try:
    for tick in range(actual.max_steps):
     actual.frame_skip=4 if tick<m['start_step'] else skip;state=np.r_[actual.data.qpos,actual.data.qvel];physical=state.copy();physical[1:16]=wrap_angle(physical[1:16]);raw=float(U[tick]) if tick<m['start_step'] else multiplier*(-float(gain@physical));u=float(np.float32(np.clip(raw,-1,1)))
     _,_,terminated,truncated,info=actual.step([u]);xs.append(np.r_[actual.data.qpos,actual.data.qvel]);us.append(u);raws.append(raw);skips.append(actual.frame_skip);times.append(float(actual.data.time));infos.append(dict(terminated=bool(terminated),truncated=bool(truncated),simulation_error=info['simulation_error'],termination_reason=info['termination_reason']))
     if tick<m['start_step']:assert xs[-1].tobytes()==X[tick+1].tobytes()
     if terminated or truncated:reason=info['termination_reason'];break
   finally:actual.close()
   tape=out/(label+'_actual.npz');np.savez_compressed(tape,states=np.asarray(xs),actions=np.asarray(us),raw_actions=np.asarray(raws),frame_skips=np.asarray(skips),native_times=np.asarray(times))
   for tick,u in enumerate(us):proofenv.frame_skip=skips[tick];assert native(xs[tick],float(u)).tobytes()==xs[tick+1].tobytes()
   angles=np.max(abs(wrap_angle(np.cumsum(np.asarray(xs)[1:,1:16],axis=1))),axis=1);streak=longest=0;common_streak=common_longest=0;cumulative=0;safe_prefix=0;prefix_open=True;saturation=sum(abs(u)==1 for u in us[m['start_step']:])
   for tick,(angle,frames) in enumerate(zip(angles,skips)):
    cumulative+=frames;streak=streak+frames if angle<.15 else 0;longest=max(longest,streak)
    if cumulative%4==0:common_streak=common_streak+4 if angle<.15 else 0;common_longest=max(common_longest,common_streak)
    if tick>=m['start_step'] and prefix_open:
     if angle<.15 and abs(xs[tick+1][0])<=3 and not infos[tick]['simulation_error']:safe_prefix+=frames
     else:prefix_open=False
   maxcart=float(np.max(abs(np.asarray(xs)[:,0])));full=cumulative==6000 and reason=='time_limit' and not any(q['simulation_error'] for q in infos) and maxcart<=3;component=full and longest>=1000
   baseline_equal=None
   if skip==4 and multiplier==1.:
    with np.load(m['matched_baseline']['path']) as z:baseline_equal=bool(z['states'].tobytes()==np.asarray(xs).tobytes() and z['actions'].tobytes()==np.asarray(us).tobytes())
    assert baseline_equal
   row=dict(label=label,gain_multiplier=multiplier,maintenance_hz=200//skip,maintenance_frame_skip=skip,plant_xml_sha256=xmlhash,actual_hanging_start_episode_steps=len(us),native_substeps=cumulative,episode_elapsed_seconds=cumulative*.005,hold_seconds=longest*.005,common_50hz_hold_seconds=common_longest*.005,posthandoff_safe_prefix_seconds=safe_prefix*.005,maximum_cart=maxcart,maintenance_saturation_count=saturation,termination_reason=reason,full_duration_clean_inrail=full,cadence_component_gate_passed=component,full_nominal_gate_passed=component and skip==4,matched_baseline_byte_exact=baseline_equal,tape=file_metadata(tape),per_step_info=infos,whole_actual_tape_byte_exact=True,actual_source_prefix_byte_exact=True);payload['records'].append(row);dump_json(payload,out/'result.progress.json');print({k:v for k,v in row.items() if k not in ('per_step_info','tape')},flush=True)
  payload.update(status='finished',wall_seconds=time.monotonic()-began);dump_json(payload,out/'result.json')
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}');dump_json(payload,out/'result.failed.json');raise
 finally:
  if 'proofenv' in locals():proofenv.close()
if __name__=='__main__':main()
