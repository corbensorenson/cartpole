"""Map compiled-plant eigenvalues and simultaneous input-response geometry."""
import argparse,copy,json,time
from pathlib import Path
import mpmath
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,utc_timestamp,runtime_metadata
from gcartpole.modal_arrival import physical_factor
from gcartpole.spectral_geometry import upright_spectrum
from gcartpole.upright_mechanics import upright_rk4_matrices
from scripts.map_solved_chain_parameters import physical_metrics


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--map',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();out=Path(args.directory);out.mkdir(parents=True,exist_ok=False);(out/'configs').mkdir()
    old=json.loads(Path(args.map).read_text());ctx=mpmath.mp.clone();ctx.dps=100
    tau=ctx.sqrt(ctx.mpf(3)/ctx.mpf('9.81'));cases=[]
    # Unchanged plants first, to see the count trend before parameter variants.
    for n in range(7,21):
        if n<=14:
            source=next(r for r in old['records'] if r['n_links']==n and r['canonical_control'])
            assert source['config']==file_metadata(source['config']['path']);cfg=load_config(source['config']['path'])
        else:cfg=load_config(f'configs/swingup{n}_uniform.yaml')
        cases.append(dict(n_links=n,length_scale=1.,hub_diameter_m=0.,axis='count',variant='canonical_geometry',config=cfg))
    for n in range(7,16):
        for s in (.95,1.,1.05):
            for diameter in (0.,.05,.10,.15):
                if (s,diameter)==(1.,0.):continue
                if n<=14:
                    source=next(r for r in old['records'] if (r['n_links'],r['length_scale'],r['hub_diameter_m'])==(n,s,diameter))
                    assert source['config']==file_metadata(source['config']['path']);cfg=load_config(source['config']['path'])
                else:
                    cfg=load_config('configs/swingup15_uniform.yaml');cfg['env']['total_length']=3*s
                    if diameter:cfg['env'].update(joint_hub_radius=diameter/2,joint_hub_mass=.1/n,joint_hub_half_width=.0125)
                cases.append(dict(n_links=n,length_scale=s,hub_diameter_m=diameter,axis='geometry',variant='factorial',config=cfg))
    for n in (14,15):
        base=load_config(f'configs/swingup{n}_uniform.yaml')
        for factor in (.5,2.):
            cfg=copy.deepcopy(base);cfg['env']['joint_armature']*=factor
            cases.append(dict(n_links=n,length_scale=1.,hub_diameter_m=0.,axis='armature',variant=f'factor{factor}',config=cfg))
            cfg=copy.deepcopy(base)
            for endpoint in ('start','end'):cfg['morphology'][endpoint]['total_damping']*=factor
            cfg['env']['cart_damping']*=factor
            cases.append(dict(n_links=n,length_scale=1.,hub_diameter_m=0.,axis='damping',variant=f'factor{factor}',config=cfg))
        for frame in (2,1):
            cfg=copy.deepcopy(base);cfg['env']['frame_skip']=frame
            cases.append(dict(n_links=n,length_scale=1.,hub_diameter_m=0.,axis='control_cadence',variant=f'frame{frame}',config=cfg))
        for mass in (.4,.9):
            cfg=copy.deepcopy(base);cfg['env'].update(joint_hub_radius=.075,joint_hub_mass=mass/n,joint_hub_half_width=.0125)
            cases.append(dict(n_links=n,length_scale=1.,hub_diameter_m=.15,axis='hub_mass',variant=f'added{mass}kg',config=cfg))
    assert len(cases)==129
    result=dict(script=file_metadata(__file__),spectral_code=file_metadata('src/gcartpole/spectral_geometry.py'),
        map=file_metadata(args.map),generated_at=utc_timestamp(),runtime=runtime_metadata(),records=[],
        decimal_digits=100,state_scaling_time_seconds=str(tau),sources=['https://underactuated.mit.edu/acrobot.html'],
        native_transition_calls=0,actual_episode_steps=0,reserved_seeds_used=False,noisy_development_seeds_used=False,
        not_solution=True,canonical_release_evidence=False,
        scope='Analytic local upright/hanging mechanics from native compiled model scalars,MP100 eigenvalues. Counts7--20 canonical geometries,full7--15 length/hub factorial,and14/15 armature,damping,cadence,mass axes. No new native transitions,episodes,gain designs or count promotion. Normalize infinite unstable backward input Gramian to isolate eigenvalue/time-response similarity; report left-mode cart-input overlap separately in FIXED dimensionless whole-state coordinates. Eigenvalues do not certify nonlinear bounded-input controllability or capture.')
    began=time.monotonic()
    for i,case in enumerate(cases):
        cfg=case.pop('config');tag=f'{i:03}_n{case["n_links"]}_{case["axis"]}_{case["variant"]}_l{case["length_scale"]:.2f}_d{case["hub_diameter_m"]:.2f}'
        path=out/'configs'/f'{tag}.json';dump_json(cfg,path);row={**case,'config':file_metadata(path)}
        result['records'].append(row);env=NLinkCartPoleEnv(cfg,progress=1.,seed=0);env.reset(seed=0)
        t=time.monotonic()
        try:
            a,b,mechanics=upright_rk4_matrices(env,decimal_digits=100)
            row.update(control_hz=1/env.dt,dt=env.dt,joint_armature=cfg['env']['joint_armature'],
                       hinge_damping=env.model.dof_damping[1:].tolist(),cart_damping=float(env.model.dof_damping[0]),
                       added_hub_mass_kg=env.n*cfg['env'].get('joint_hub_mass',0.),
                       spectrum=upright_spectrum(a,b,physical_factor(ctx,env.n,tau),dt=env.dt,decimal_digits=100))
            assert row['spectrum']['unstable_mode_count']==env.n
            row['mechanics']=physical_metrics(cfg)
            row['analysis_wall_seconds']=time.monotonic()-t
        finally:env.close()
        dump_json(result,out/'result.progress.json')
        print(json.dumps(dict(index=i+1,count=len(cases),n=row['n_links'],axis=row['axis'],variant=row['variant'],
            length_scale=row['length_scale'],diameter=row['hub_diameter_m'],hz=row['control_hz'],
            fastest_growth=row['spectrum']['fastest_unstable_growth_per_second'],
            minimum_gap=row['spectrum']['minimum_adjacent_unstable_growth_gap_per_second'],
            gram_condition=row['spectrum']['normalized_backward_gram_condition'],wall=row['analysis_wall_seconds'])),flush=True)
    result['wall_seconds']=time.monotonic()-began;dump_json(result,out/'result.json')


if __name__=='__main__':main()
