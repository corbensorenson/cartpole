"""Read-only consistency audit of geometry studies and their physical tapes."""
import json
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.evidence import file_metadata,utc_timestamp

ROOT=Path('runs')


def checked(ref):
    assert ref==file_metadata(ref['path']),ref['path']


def main():
    rows=[]
    for folder,expected_count,kind in (
        ('solved_chain_parameter_map_20261003_int_normalized',96,'transfer'),
        ('solved_parameter_capture_redesign_20261003',24,'local_redesign')):
        directory=ROOT/folder;path=directory/'diagnostic/result.json';d=json.loads(path.read_text())
        journal=json.loads((directory/'execution.json').read_text());assert journal['status']=='finished' and journal['returncode']==0
        for ref in journal['frozen_inputs']:assert file_metadata(directory/'snapshot'/ref['path'])['sha256']==ref['sha256']
        assert len(d['records'])==expected_count
        assert not d['canonical_release_evidence'] and not d['reserved_seeds_used'] and d['not_solution']
        actual=proof=passes=episodes=0;paired={};tapes=[]
        for r in d['records']:
            checked(r['config'])
            for e in r['episodes']:
                checked(e['tape']);tapes.append(e['tape']);episodes+=1
                with np.load(e['tape']['path']) as tape:
                    states=tape['states'];actions=tape['actions'];n=r['n_links']
                    assert states.shape==(e['steps']+1,2*(n+1)) and actions.shape==(e['steps'],)
                    assert np.all(np.isfinite(states)) and np.all(np.isfinite(actions))
                    assert np.all(np.abs(actions)<=1) and actions.tobytes()==actions.astype(np.float32).astype(float).tobytes()
                    upright=np.max(np.abs(wrap_angle(np.cumsum(states[1:,1:n+1],axis=1))),axis=1)<.15
                    maximum=streak=0
                    for u in upright:streak=streak+1 if u else 0;maximum=max(maximum,streak)
                    assert abs(maximum*.02-e['hold_seconds'])<=.020000000001
                    passed=e['full_episode_gate_passed' if kind=='transfer' else 'local_full_episode_gate_passed']
                    if passed:
                        assert len(actions)==1500 and e['termination_reason']=='time_limit'
                        assert maximum*.02>=5 and np.max(np.abs(states[:,0]))<=3
                    if kind=='transfer':
                        assert states[0].tobytes()==np.asarray(e['initial_state']).tobytes()
                        key=n,e['noisy_start']
                        if key in paired:assert paired[key]==states[0].tobytes()
                        paired[key]=states[0].tobytes()
                assert e['independent_tape_replay_bytes_exact']
                a=e['actual_episode_steps' if kind=='transfer' else 'actual_local_episode_steps']
                assert a==e['independent_tape_replay_transition_calls']==e['steps']
                assert e['total_native_transition_calls']==2*a
                actual+=a;proof+=a;passes+=int(passed)
        assert actual==d['actual_episode_steps' if kind=='transfer' else 'actual_local_episode_steps']
        assert proof==d['independent_tape_replay_transition_calls']
        designs=d.get('gain_reconstruction_transition_calls',0)
        assert d['total_native_transition_calls']==actual+proof+designs<=d['native_transition_ceiling']
        if kind=='transfer':
            assert passes==16 and episodes==192 and designs==286
            assert all(e['full_episode_gate_passed'] for r in d['records'] if r['canonical_control'] for e in r['episodes'])
            assert all(e['hold_seconds']==0 for r in d['records'] if not r['canonical_control'] for e in r['episodes'])
        else:assert passes==70 and episodes==144
        figures=directory/'diagnostic/figures/figures.json';f=json.loads(figures.read_text());checked(f['source'])
        for ref in f['figures']:checked(ref)
        rows.append(dict(kind=kind,result=file_metadata(path),execution=file_metadata(directory/'execution.json'),
                         figures=file_metadata(figures),plants=expected_count,episodes=episodes,passes=passes,
                         actual_steps=actual,proof_calls=proof,design_calls=designs,tapes=tapes,
                         total_native_transition_calls=d['total_native_transition_calls']))
    failure=ROOT/'solved_chain_parameter_map_20261003/failure_accounting.json';d=json.loads(failure.read_text())
    checked(d['execution']);checked(d['source'])
    for ref in d['tapes']:checked(ref)
    assert d['total_native_transition_calls']==6034
    payload=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),studies=rows,
                 retained_failure=file_metadata(failure),total_geometry_study_transition_calls=610854,
                 passed=True,native_transition_calls=0,
                 scope='Read-only byte/hash/accounting and sampled physical-gate audit. Prior independent native proof flags remain execution evidence; this audit performs no additional physics.')
    assert sum(r['total_native_transition_calls'] for r in rows)+6034==610854
    path=ROOT/'solved_chain_parameter_map_20261003_int_normalized/parameter_studies_verified.json'
    path.write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps({k:v for k,v in payload.items() if k!='studies'}))


if __name__=='__main__':main()
