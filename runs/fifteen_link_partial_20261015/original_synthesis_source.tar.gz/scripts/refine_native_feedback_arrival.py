"""Native feedback-stabilized arrival refinement toward a demonstrated quiet start.

No state decision variables or live resets inside the episode. Source prefix,
whole arrival segment, short bounded feedback tail and full hanging-start replay
are all native, using delivered float32 controls. Local target is not a record.
"""
import argparse
import json
from pathlib import Path
import time
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config, dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, runtime_metadata, utc_timestamp
from gcartpole.ilqr import MujocoTransition
from gcartpole.modal_arrival import empirical_modal_factor, regularized_qr_step
from gcartpole.simulation import SimulationError
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix, scale_step_to_trust_region
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.solve_frontier_capture_increment import validate_development_seeds


def represented_state(x, n):
    """Choose the zero-upright absolute branch for search residuals only."""
    y = np.asarray(x, dtype=float).copy()
    y[1:n+1] = wrap_angle(y[1:n+1])
    absolute = np.cumsum(y[1:n+1])
    if np.any(np.abs(absolute)>=np.pi):
        y[1:n+1] = np.diff(np.r_[0., wrap_angle(absolute)])
    return y


def raw_feedback(gain, state, n):
    physical = state.copy(); physical[1:n+1] = wrap_angle(physical[1:n+1])
    return -float(gain@physical)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', required=True)
    p.add_argument('--tracking-design',required=True)
    p.add_argument('--tracking-audit',required=True)
    p.add_argument('--initial-objective-oracle',required=True)
    p.add_argument('--aligned', required=True)
    p.add_argument('--geometry', required=True)
    p.add_argument('--directory', required=True)
    p.add_argument('--start-step', type=int, default=291)
    p.add_argument('--arrival-step', type=int, default=439)
    p.add_argument('--iterations', type=int, default=6)
    p.add_argument('--knots', type=int, default=48)
    p.add_argument('--epsilon', type=float, default=1e-5)
    p.add_argument('--trust', type=float, default=.01)
    p.add_argument('--regularization', type=float, default=1e-6)
    p.add_argument('--arm-budget', type=int, default=400000)
    p.add_argument('--contraction-powers', type=int, default=8)
    p.add_argument('--verify-initial-comparison')
    args = p.parse_args();out = Path(args.directory)
    if out.exists():raise FileExistsError(out)
    if not 0 <= args.start_step < args.arrival_step or not 2 <= args.knots <= args.arrival_step-args.start_step:
        raise ValueError('bounded whole-arrival input basis required')
    if min(args.iterations,args.epsilon,args.trust,args.regularization,args.arm_budget)<=0:
        raise ValueError('positive finite search parameters required')
    if not 8 <= args.contraction_powers <= 32:
        raise ValueError('declared eight to32 contraction powers required')
    prior = None if not args.verify_initial_comparison else json.loads(Path(args.verify_initial_comparison).read_text())
    out.mkdir(parents=True);(out/'tapes').mkdir()
    saved=json.loads(Path(args.source).read_text())
    tracking_audit=json.loads(Path(args.tracking_audit).read_text());assert tracking_audit['passed']
    tracking_design=json.loads(Path(args.tracking_design).read_text());assert tracking_design['status']=='finished' and tracking_design['array']==file_metadata(tracking_design['array']['path'])
    with np.load(tracking_design['array']['path']) as aa: tracking_K=aa['gains'][2].copy();tracking_X=aa['states'].copy()
    assert tracking_design['regularizations'][2]==250000000. and tracking_K.shape==(148,32)
    objective_oracle=json.loads(Path(args.initial_objective_oracle).read_text())
    for k in ('source','config','plan_source','capture_cache'):
        assert saved[k]==file_metadata(saved[k]['path'])
    assert saved['inherited_prefix_states_and_actions_byte_identical'] and saved['actual_plan_states_byte_identical_to_forecast']
    base=json.loads(Path(saved['source']['path']).read_text())
    cfg=load_config(saved['config']['path']);n=cfg['env']['n_links'];nx=2*(n+1)
    validate_development_seeds(n,base['seed'])
    assert n==15 and cfg['env']['timestep']==.005 and cfg['env']['frame_skip']==4
    assert base['seed']==20265100
    aligned=json.loads(Path(args.aligned).read_text());geometry=json.loads(Path(args.geometry).read_text())
    assert geometry['aligned']==file_metadata(args.aligned)
    gain_label='moderately_separated_decay'
    gain=np.asarray(aligned['gains'][gain_label])
    design=next(d for d in aligned['designs'] if d['gain_label']==gain_label)
    target_row=next(r for r in geometry['records'] if r['gain_label']==gain_label and
        r['kind']=='modal_mixture' and r['amplitude']==1e-4 and r['direction']==0 and r['sign']==1)
    assert target_row['result']['local_gate_pass'] and target_row['result']['all_samples_upright']
    assert target_row['result']['tape']==file_metadata(target_row['result']['tape']['path'])
    target=np.asarray(target_row['result']['initial_state'])
    ctx,modal,w,metric=empirical_modal_factor([d['rounded_direction'] for d in design['directions']],
        n_links=n,time_scale=design['normalization']['time_scale_seconds'])
    initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
    local_cfg=fixed_state_cfg(cfg,base['selected_state'],30.)
    env=NLinkCartPoleEnv(local_cfg,progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    assert np.r_[env.data.qpos,env.data.qvel].tobytes()==initial.tobytes()
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True)
    untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
    controls=np.asarray([r['action'] for r in saved['result']['trajectory'][:args.arrival_step]],np.float32).astype(float)
    expected=np.asarray([r['qpos']+r['qvel'] for r in saved['result']['trajectory'][:args.arrival_step]])
    assert len(controls)==args.arrival_step
    interpolation=interpolation_matrix(args.knots,args.arrival_step-args.start_step)
    tail_steps=16;sample_offsets=(0,3,7,15);records=[]
    payload=dict(generated_at=utc_timestamp(),parameters=vars(args),runtime=runtime_metadata(),
        script=file_metadata(__file__),geometry_code=file_metadata('src/gcartpole/modal_arrival.py'),
        source=file_metadata(args.source),aligned=file_metadata(args.aligned),geometry=file_metadata(args.geometry),
        config=saved['config'],gain_label=gain_label,gain=gain.tolist(),target=target.tolist(),
        demonstrated_target_tape=target_row['result']['tape'],metric=metric,
        native_transition_ceiling=2*args.arm_budget+args.arrival_step+tail_steps,
        records=records,private_forecasts=[],private_tails=[],tracking_design=file_metadata(args.tracking_design),tracking_audit=file_metadata(args.tracking_audit),tracking_regularization=250000000.,tracking_gains=tracking_K.tolist(),total_native_transition_calls=0,actual_hanging_start_episode_steps=0,
        reserved_seeds_used=False,noisy_development_seeds_used=False,canonical_release_evidence=False,not_solution=True,
        scope='Canonical15 native feedback-stabilized physical/modal arrival optimization: fixed291prefix,148feedforwardcontrols plus auditedactual-reference trackingK reg250M, two-point1e-7 derivatives and26contractions. Same quiettarget/maintenancegain/factoredobjectives. Every privateforecast/tail saved, final F32native controls and full actual30s tapes proved. No state projection/reset/noisy/reserved promotion.')
    began=time.monotonic()
    forecast_counter=[0];tail_counter=[0];last_forecast_actions=[None]
    def forecast(state,tape):
        predictions=[];actions=[];current=state.copy();error=None
        is_arrival=len(tape)==args.arrival_step-args.start_step
        try:
            for i,ff in enumerate(tape):
                raw=float(ff) if not is_arrival else float(ff)+float(tracking_K[i]@(current-tracking_X[i]))
                u=float(np.float32(np.clip(raw,-1,1)))
                current=native(current,u);predictions.append(current.copy());actions.append(u)
        except BaseException as e:
            error=f'{type(e).__name__}: {e}';raise
        finally:
            forecast_counter[0]+=1;path=out/'tapes'/f'private_forecast_{forecast_counter[0]:05d}.npz'
            np.savez_compressed(path,states=np.vstack([state]+predictions),actions=np.asarray(actions),nominal_feedforward=np.asarray(tape))
            payload['private_forecasts'].append(dict(index=forecast_counter[0],arrival_feedback=is_arrival,tape=file_metadata(path),error=error,completed_steps=len(actions)))
            last_forecast_actions[0]=np.asarray(actions)
        return np.asarray(predictions)
    def tail(state):
        states=[];raws=[];actions=[];current=state.copy()
        error=None
        try:
            for _ in range(tail_steps):
                raw=raw_feedback(gain,current,n);u=float(np.float32(np.clip(raw,-1,1)))
                current=native(current,u);states.append(current.copy());raws.append(raw);actions.append(u)
        except BaseException as e:
            error=f'{type(e).__name__}: {e}';raise
        finally:
            tail_counter[0]+=1;path=out/'tapes'/f'private_tail_{tail_counter[0]:05d}.npz'
            np.savez_compressed(path,states=np.vstack([state]+states),raws=np.asarray(raws),actions=np.asarray(actions))
            payload['private_tails'].append(dict(index=tail_counter[0],tape=file_metadata(path),completed_steps=len(actions),error=error))
        return np.asarray(states),np.asarray(raws),np.asarray(actions)
    try:
        known=forecast(initial,controls)
        assert known.tobytes()==expected.tobytes()
        assert tracking_X.tobytes()==np.vstack([known[args.start_step-1],known[args.start_step:args.arrival_step]]).tobytes()
        prefix_state=initial if args.start_step==0 else known[args.start_step-1]
        source_arrival=controls[args.start_step:].copy();source_states=known[args.start_step:].copy()
        source_tail,source_raw,source_tail_actions=tail(source_states[-1])
        setup_calls=native.evaluations
        assert setup_calls==args.arrival_step+tail_steps
        tail_scale=max(ctx.mpf(1),ctx.sqrt(ctx.fsum(ctx.norm(w*ctx.matrix(represented_state(s,n).tolist()))**2 for s in source_tail[list(sample_offsets)])))
        raw_scale=max(1.,float(np.sqrt(np.mean(source_raw[list(sample_offsets)]**2))))
        payload.update(setup_native_transition_calls=setup_calls,source_full_arrival_byte_exact=True,
            initial_prefix_hold_source='Stored physical hanging-start tape, independently reproduced through arrival-step',
            frozen_tail_physical_scale=str(tail_scale),frozen_tail_raw_scale=raw_scale)
        target_mp=ctx.matrix(target.tolist())
        def target_error_at(state):
            return ctx.matrix(represented_state(state,n).tolist())-target_mp
        for label,factor in (('physical',w),('modal_factored',modal)):
            arm_before=native.evaluations;arm_actual=0;center=source_arrival.copy();states=source_states.copy()
            target_error=target_error_at(states[-1])
            endpoint_scale=max(ctx.mpf(1),ctx.norm(factor*target_error))
            scale_factor=factor/endpoint_scale
            def residual(predictions,feedback_states,raws):
                endpoint=scale_factor*target_error_at(predictions[-1])
                values=list(endpoint)
                for idx in sample_offsets:
                    physical=w*ctx.matrix(represented_state(feedback_states[idx],n).tolist())
                    values.extend(ctx.mpf('.1')*v/tail_scale for v in physical)
                    values.append(ctx.mpf('.1')*ctx.mpf(float(raws[idx]))/ctx.mpf(float(raw_scale))/2)
                return ctx.matrix(values)
            def score(predictions,feedback_states,raws,res):
                angle=np.abs(wrap_angle(np.cumsum(predictions[:,1:n+1],axis=1)))
                cart=np.abs(predictions[:,0]);excess=np.maximum(angle-.149,0)/.149
                violation=float(np.sum(excess**2)+np.sum((np.maximum(cart-3.,0)/3.)**2))
                feasible=bool(np.all(angle<.149) and np.all(cart<=3.))
                return (0 if feasible else 1,violation,float(ctx.norm(res)**2))
            feedback=source_tail.copy();raws=source_raw.copy();res=residual(states,feedback,raws)
            center_score=score(states,feedback,raws,res);rounds=[]
            assert list(center_score)==next(q for q in objective_oracle['records'] if q['label']==label)['initial_score']
            center_actions=source_arrival.copy()
            initial_score=center_score;initial_physical=np.asarray((w*target_error).tolist(),float).ravel()
            status='iteration_limit'
            def affordable(calls):
                # Reserve final arrival proof, up to1500 actual steps and1500 whole-tape proof.
                return native.evaluations-arm_before+arm_actual+calls+(args.arrival_step-args.start_step)+3000<=args.arm_budget
            for iteration in range(args.iterations):
                before=native.evaluations
                if not affordable(4*args.knots*(len(center)+tail_steps)+args.contraction_powers*(len(center)+tail_steps)):
                    status='inclusive_native_budget';break
                jac=ctx.zeros(res.rows,args.knots)
                derivative_failed=None;probe_summaries=[]
                try:
                    for column in range(args.knots):
                        samples=[]
                        for multiple in (1,-1):
                            trial=np.asarray(np.clip(center+multiple*args.epsilon*interpolation[:,column],-1,1),float)
                            predicted=forecast(prefix_state,trial);ts,tr,_=tail(predicted[-1])
                            samples.append(residual(predicted,ts,tr))
                            probe_summaries.append(dict(column=column,multiple=multiple,
                                maximum_angle=float(np.max(np.abs(wrap_angle(np.cumsum(predicted[:,1:n+1],axis=1))))),
                                endpoint_physical_difference_norm=str(ctx.norm(w*ctx.matrix((represented_state(predicted[-1],n)-represented_state(states[-1],n)).tolist())))))
                        for row in range(res.rows):
                            jac[row,column]=(samples[0][row]-samples[1][row])/(2*ctx.mpf(float(args.epsilon)))
                except (SimulationError,ValueError) as error:
                    derivative_failed=f'{type(error).__name__}: {error}'
                derivative_calls=native.evaluations-before
                if derivative_failed:
                    rounds.append(dict(iteration=iteration,derivative_failed=derivative_failed,native_derivative_calls=derivative_calls));status='native_derivative_failed';break
                step,qr_error=regularized_qr_step(ctx,jac,res,args.regularization)
                step=scale_step_to_trust_region(step,args.trust)
                proposals=[];best=None;search_before=native.evaluations
                no_op_divisors=[]
                for power in range(args.contraction_powers):
                    divisor=2**power
                    trial=np.asarray(np.clip(center+interpolation@(step/divisor),-1,1),float)
                    if trial.tobytes()==center.tobytes():
                        no_op_divisors.append(divisor);continue
                    try:
                        predicted=forecast(prefix_state,trial);trial_actions=last_forecast_actions[0].copy()
                        if trial_actions.tobytes()==center_actions.tobytes():
                            assert predicted.tobytes()==states.tobytes();no_op_divisors.append(divisor);continue
                        ts,tr,_=tail(predicted[-1]);rr=residual(predicted,ts,tr)
                        ss=score(predicted,ts,tr,rr)
                        model=res+jac*ctx.matrix((step/divisor).tolist())
                        row_error=ctx.norm(rr-model)/max(ctx.mpf(1),ctx.norm(model))
                        proposals.append(dict(divisor=divisor,score=list(ss),maximum_angle=float(np.max(np.abs(wrap_angle(np.cumsum(predicted[:,1:n+1],axis=1))))),
                            maximum_cart=float(np.max(np.abs(predicted[:,0]))),affine_residual_norm=str(ctx.norm(model)),
                            native_residual_norm=str(ctx.norm(rr)),relative_model_disagreement=str(row_error)))
                        changed=np.flatnonzero(trial_actions!=center_actions)
                        proposals[-1].update(changed_input_count=len(changed),
                            first_changed_absolute_step=int(args.start_step+changed[0]),
                            last_changed_absolute_step=int(args.start_step+changed[-1]),
                            maximum_delivered_action_change=float(np.max(np.abs(trial_actions-center_actions))),private_forecast=payload['private_forecasts'][-1]['tape'])
                        if ss<center_score and (best is None or ss<best[0]):best=(ss,trial,predicted,ts,tr,rr,divisor,trial_actions)
                    except SimulationError as error:proposals.append(dict(divisor=divisor,error=str(error)))
                improved=best is not None
                matched_prefix=None
                if prior is not None and iteration==0:
                    old=next(r for r in prior['records'] if r['label']==label)
                    assert old['initial_score']==list(initial_score)
                    previous=old['rounds'][0]['proposals']
                    matched_prefix=all(all(a[k]==b[k] for k in a) for a,b in zip(previous,proposals[:len(previous)]))
                    assert len(proposals)>=len(previous) and matched_prefix
                if improved:center_score,center,states,feedback,raws,res,selected,center_actions=best
                rounds.append(dict(iteration=iteration,improved=improved,score=list(center_score),
                    selected_divisor=selected if improved else None,qr_error=qr_error,
                    native_derivative_calls=derivative_calls,native_candidate_calls=native.evaluations-search_before,
                    proposals=proposals,maximum_knot_step=float(np.max(np.abs(step))),
                    no_op_divisors=no_op_divisors,derivative_probes=probe_summaries,
                    previous_initial_eight_contractions_exact=matched_prefix))
                print(json.dumps(dict(arm=label,iteration=iteration,improved=improved,score=list(center_score),calls=native.evaluations-arm_before)),flush=True)
                dump_json({**payload,'running_arm':label,'running_rounds':rounds,
                    'total_native_transition_calls':native.evaluations+sum(r['actual_hanging_start_episode_steps'] for r in records)},out/'result.progress.json')
                if not improved:status='no_improving_tested_contraction';break
            proof=forecast(prefix_state,center)
            assert proof.tobytes()==states.tobytes() and last_forecast_actions[0].tobytes()==center_actions.tobytes()
            delivered=np.r_[controls[:args.start_step],center]
            actual=NLinkCartPoleEnv(local_cfg,progress=1.,seed=base['seed']);actual.reset(seed=base['seed'])
            actual_states=[initial.copy()];actual_actions=[];streak=longest=0;maxcart=0.;termination=None
            try:
                for tick in range(actual.max_steps):
                    state=np.r_[actual.data.qpos,actual.data.qvel]
                    if tick<args.start_step:u=float(delivered[tick])
                    elif tick<len(delivered):
                        i=tick-args.start_step;u=float(np.float32(np.clip(float(delivered[tick])+float(tracking_K[i]@(state-tracking_X[i])),-1,1)))
                    else:u=float(np.float32(np.clip(raw_feedback(gain,state,n),-1,1)))
                    _,_,terminated,truncated,info=actual.step([u]);arm_actual+=1
                    x=np.r_[actual.data.qpos,actual.data.qvel];actual_states.append(x.copy());actual_actions.append(u)
                    if tick<args.start_step:assert x.tobytes()==known[tick].tobytes()
                    elif tick<len(delivered):assert x.tobytes()==states[tick-args.start_step].tobytes()
                    phi=np.max(np.abs(wrap_angle(np.cumsum(x[1:n+1]))))
                    streak=streak+1 if phi<.15 else 0;longest=max(longest,streak);maxcart=max(maxcart,abs(float(x[0])))
                    if terminated or truncated:termination=info['termination_reason'];break
            finally:actual.close()
            tape=out/'tapes'/f'{label}.npz';np.savez_compressed(tape,states=np.asarray(actual_states),actions=np.asarray(actual_actions))
            whole_before=native.evaluations
            for index,u in enumerate(actual_actions):assert native(actual_states[index],u).tobytes()==actual_states[index+1].tobytes()
            whole_proof=native.evaluations-whole_before
            assert whole_proof==arm_actual
            tape=out/'tapes'/f'{label}.npz';np.savez_compressed(tape,states=np.asarray(actual_states),actions=np.asarray(actual_actions))
            passed=arm_actual==1500 and longest*.02>=5 and termination=='time_limit' and not info['simulation_error'] and maxcart<=3
            physical_error=w*target_error_at(states[-1])
            row=dict(label=label,status=status,rounds=rounds,endpoint_scale=str(endpoint_scale),
                initial_score=list(initial_score),final_score=list(center_score),
                initial_physical_error_norm=float(np.linalg.norm(initial_physical)),final_physical_error_norm=str(ctx.norm(physical_error)),
                selected_feedforward_controls=center.tolist(),selected_actual_arrival_actions=center_actions.tolist(),selected_states=states.tolist(),
                endpoint_maximum_angle=float(np.max(np.abs(wrap_angle(np.cumsum(states[-1,1:n+1]))))),
                endpoint_absolute_rate_rms=float(np.sqrt(np.mean(np.cumsum(states[-1,n+2:])**2))),
                endpoint_raw_feedback_action=raw_feedback(gain,states[-1],n),
                selected_whole_arrival_byte_exact=True,actual_prefix_and_selected_arrival_byte_exact=True,
                independent_whole_actual_tape_byte_exact=True,
                actual_hanging_start_episode_steps=arm_actual,actual_hold_seconds=longest*.02,
                actual_maximum_cart=maxcart,actual_termination_reason=termination,full_nominal_gate_passed=passed,
                tape=file_metadata(tape),private_native_transition_calls=native.evaluations-arm_before,
                actual_tape_proof_calls=whole_proof,total_native_transition_calls=native.evaluations-arm_before+arm_actual,
                native_transition_ceiling=args.arm_budget)
            assert row['total_native_transition_calls']<=args.arm_budget
            records.append(row)
            payload.update(total_native_transition_calls=native.evaluations+sum(r['actual_hanging_start_episode_steps'] for r in records),
                actual_hanging_start_episode_steps=sum(r['actual_hanging_start_episode_steps'] for r in records))
            dump_json(payload,out/'result.progress.json')
            print(json.dumps(dict(arm=label,hold=row['actual_hold_seconds'],full_pass=passed,steps=arm_actual,calls=row['total_native_transition_calls'])),flush=True)
        assert np.r_[env.data.qpos,env.data.qvel].tobytes()==untouched.tobytes()
        assert payload['total_native_transition_calls']<=payload['native_transition_ceiling']
        assert payload['total_native_transition_calls']==setup_calls+sum(r['total_native_transition_calls'] for r in records)
        payload.update(live_forecast_environment_unchanged=True,wall_seconds=time.monotonic()-began)
        dump_json(payload,out/'result.json')
    finally:env.close()


if __name__=='__main__':main()
