"""Actual-prefix initializer normalization audit, with native replay controls."""
import argparse,json
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from scripts.audit_armature_route_increment import read,checked,journal,tape

def main():
 p=argparse.ArgumentParser();p.add_argument('--directory',required=True);args=p.parse_args();root=Path(args.directory);a=read(root/'verified.json');assert a['passed'];checked(a['passing_physical_initializer']);raw=read(a['passing_physical_initializer']['path']);clean=read(root/'passing_physical_initializer.json');chosen=next(r for r in a['records'] if r['tag']=='legacy' and r['offset_scale']==1 and r['handoff_seconds']==9);old=np.load(chosen['tape']['path']);K=np.array(clean['controller']['feedback_gains']);gain=np.array(read(read(root/'manifest.json')['gain_source']['path'])['gain']);assert clean['source']==a['passing_physical_initializer'] and clean['passing_tape']==chosen['tape'];assert 'result' not in clean and 'optimizer_history' not in clean['search'] and 'final_trajectory_diagnostics' not in clean['controller'];assert clean['config']==read(root/'manifest.json')['config'];assert clean['controller']['lqr_scale']==1;assert np.array(clean['controller']['controls']).tobytes()==old['actions'][:700].tobytes();assert np.array(clean['search']['nominal_coordinate_states']).tobytes()==old['states'][:701].tobytes();assert K.tobytes()==np.array(raw['controller']['feedback_gains']).tobytes() and K[450:].tobytes()==np.tile(-gain,(250,1)).tobytes()
 j=journal(root/'normalized_replay');r=read(root/'normalized_replay/diagnostic/result.json');assert r['status']=='finished' and r['source']==file_metadata(root/'normalized_source_result.json');assert [q['handoff_seconds'] for q in r['records']]==[9,14]
 for rr in r['records']:
  x,u,g=tape(rr);assert g and x.tobytes()==old['states'].tobytes() and u.tobytes()==old['actions'].tobytes();assert rr['total_native_transition_calls']==3000
 assert r['total_native_transition_calls']==6000 and r['actual_hanging_start_episode_steps']==3000 and r['partial_transition_substeps']==0 and r['native_physics_substeps']==24000
 d=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),passed=True,execution=j,result=file_metadata(root/'normalized_replay/diagnostic/result.json'),records=r['records'],source_audit=file_metadata(root/'verified.json'),passing_physical_initializer=file_metadata(root/'passing_physical_initializer.json'),full_tapes_byte_identical_to_selected_pass=2,total_new_native_transition_calls=6000,actual_hanging_start_episode_steps=3000,native_transition_calls_for_this_audit=0,canonical_release_evidence=False,not_solution=True,scope='Separate actual700tick normalizedinitializer has no staleoptimizerresult; both9/14s replays reproduce selected entire30s tape byte-for-byte. Exactaltered14only, no newdesign/robustness/canonicalcount.')
 dump_json(d,root/'initializer_verified.json');print(json.dumps(dict(passed=True,calls=6000,actualticks=3000,passing_initializer=d['passing_physical_initializer'])))
if __name__=='__main__':main()
