"""Separate trajectory perturbation feedback from the affine native defects.

Use the completed small-armature SCvx route as a fixed offline reference. Design
MP100 tracking feedback from native fourth-order secants, with/without the
native nominal defect feedforward. Both arms run continuously from hanging.
"""
import argparse
import copy
import json
import time
from pathlib import Path
import mujoco
import numpy as np
from gcartpole.config import load_config, dump_json
from gcartpole.evidence import file_metadata, utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import QuadraticTrajectoryCost, MujocoTransition
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.sqrt_ilqr import square_root_tracking_gains
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.search_fddp_capture import capture_interval_cost
from scripts.evaluate_fddp_two_expert import load_controller
from scripts.evaluate_fddp_parked_route import run_episode
from scripts.search_swingup_capture import lqr_gain


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', required=True)
    p.add_argument('--config', required=True)
    p.add_argument('--directory', required=True)
    p.add_argument('--preserve-actual-prefix-steps',type=int,default=0)
    args = p.parse_args()
    out = Path(args.directory)
    out.mkdir(parents=True, exist_ok=False)
    prior = json.loads(Path(args.source).read_text())
    cfg = load_config(args.config)
    assert cfg['env']['n_links'] == 14 and cfg['env']['frame_skip'] == 4
    c = prior['controller']
    states = np.asarray(prior['search']['nominal_coordinate_states'])
    controls = np.asarray(c['controls'])
    assert len(controls) == 700 and np.array_equal(c['coordinate_transform'], np.eye(30))
    prefix=args.preserve_actual_prefix_steps
    if not 0<=prefix<len(controls) or (prefix and c['frozen_prefix_steps']!=prefix):
        raise ValueError('preserved prefix must match the source frozen physical prefix')
    mapping = np.asarray(c['normalized_cost_mapping'])
    identity = np.eye(30)
    identity[1:15,1:15] *= c['terminal_angle_factor']
    identity[15,15] *= c['terminal_cart_velocity_factor']
    identity[16:,16:] *= c['terminal_hinge_velocity_factor']
    factor = np.diag(np.sqrt(c['terminal_state_weight']*np.diag(identity))) @ mapping
    cost = QuadraticTrajectoryCost(stage_state=c['stage_weight']*mapping.T@mapping,
        terminal_state=factor.T@factor, terminal_factor=factor, control=c['control_cost'],
        rail_soft_limit=c['rail_soft_limit'],rail_limit=3.,rail_weight=c['rail_weight'],
        wrap_angles=False, terminal_target=np.asarray(c['angle_branch_terminal_target']),
        stage_target=np.asarray(c['angle_branch_terminal_target']))
    capture = capture_interval_cost(cost, identity, mapping, c['capture_stage_weight'])
    costs = [cost]*450 + [capture]*250
    frame = 4
    counter = [0]
    ceiling = 120000
    original_step = mujoco.mj_step

    def counted_step(model, data, *positional, **keywords):
        count = int(keywords.get('nstep', positional[0] if positional else 1))
        if counter[0]+count > ceiling*frame:
            raise RuntimeError('inclusive native transition ceiling reached')
        counter[0] += count
        return original_step(model, data, *positional, **keywords)

    payload = dict(generated_at=utc_timestamp(),source=file_metadata(args.source),config=file_metadata(args.config),
        script=file_metadata(__file__),status='running',records=[],native_transition_ceiling=ceiling,
        not_solution=True,canonical_release_evidence=False,reserved_seeds_used=False,noisy_development_seeds_used=False,
        actual_hanging_start_episode_steps=0,total_native_transition_calls=0,preserve_actual_prefix_steps=prefix,
        scope='Paired perturbation-only and known-native-defect affine feedback on same fixed near-canonical14reference. Native fourth-order secants,MP100 Riccati arithmetic,zero added tracking regularization,rounded saved gains/binary64 tracking/native F32 actions. No node projection or runtime reset. Two exact unparked30s hanging-start attempts plus byte proofs; no15or reserved seeds. Linear affine repair is a candidate,not a nonlinear certificate.')
    mujoco.mj_step = counted_step
    began = time.monotonic()
    env = NLinkCartPoleEnv(cfg, progress=1., seed=0)
    env.reset(seed=0)
    native = FourthOrderMujocoTransition(env, np.eye(30), continuous_angles=True)
    try:
        predictions = np.asarray([native(x,float(u)) for x,u in zip(states,controls)])
        defects = predictions-states[1:]
        if prefix:
            assert predictions[:prefix].tobytes()==states[1:prefix+1].tobytes()
        offsets = np.zeros(len(controls))
        tail_gains = square_root_tracking_gains(native,states[prefix:],controls[prefix:],cost,running_costs=costs[prefix:],
            regularization=0.,state_epsilon=.0002,action_epsilon=.0005,decimal_digits=100,
            defect_provider=lambda i,ctx:ctx.matrix(defects[i+prefix].tolist()),
            feedforward_callback=lambda i,x:offsets.__setitem__(i+prefix,x),
            callback=lambda row:print(json.dumps(row),flush=True))
        gains=np.vstack([np.asarray(c['feedback_gains'])[:prefix],tail_gains])
        reference = out/'native_reference.npz'
        np.savez_compressed(reference,states=states,controls=controls,native_predictions=predictions,
            defects=defects,feedback_gains=gains,feedforward_offsets=offsets)
        payload.update(reference=file_metadata(reference),native_reference_design_calls=int(counter[0]/frame),
            maximum_native_reference_defect=float(np.max(np.abs(defects))),
            maximum_feedforward_offset=float(np.max(np.abs(offsets))),
            maximum_feedback_norm=float(np.max(np.linalg.norm(gains,axis=1))))
        base_controller = load_controller(Path(args.source),14,load_config('benchmarks/p1_capture_envelope.yaml'))
        before = counter[0]
        gain = lqr_gain(cfg,progress=1.,fd_eps=1e-7,control_cost=base_controller['lqr_control_cost'],
            q_weights=base_controller['lqr_weights'],decimal_digits=100)
        payload['upright_gain_design_calls'] = int((counter[0]-before)/frame)
        ecfg = fixed_state_cfg(cfg,prior['selected_state'],30.)
        for label, affine in (('perturbation_only',False),('known_defect_affine',True)):
            controller = copy.deepcopy(base_controller)
            shifted = controls + offsets if affine else controls.copy()
            controller.update(controls=np.clip(shifted,-1.,1.),feedback_gains=gains)
            result = run_episode(ecfg,controller,gain,np.zeros(30),seed=0,park_seconds=0.,cart_target=0.,
                tracking_gain_scale=1.,phase_adaptive=False,phase_window=12,include_trace=True)
            actions = np.asarray([r['action'] for r in result['trajectory']],np.float32).astype(float)
            actual = np.vstack([prior['selected_state']['qpos']+prior['selected_state']['qvel'],
                [r['qpos']+r['qvel'] for r in result['trajectory']]])
            if prefix:
                assert actual[:prefix+1].tobytes()==states[:prefix+1].tobytes()
                assert actions[:prefix].tobytes()==controls[:prefix].tobytes()
            proof_env = NLinkCartPoleEnv(ecfg,progress=1.,seed=0)
            proof_env.reset(seed=0)
            proof = MujocoTransition(proof_env,np.eye(30),continuous_angles=True)
            try:
                for i,u in enumerate(actions):
                    assert proof(actual[i],float(u)).tobytes() == actual[i+1].tobytes()
            finally:
                proof_env.close()
            assert proof.evaluations == len(actions) == result['length']
            tape = out/f'{label}.npz'
            np.savez_compressed(tape,states=actual,actions=actions)
            gate = bool(result['success'] and len(actions)==1500 and result['termination_reason']=='time_limit'
                and result['max_upright_streak_seconds']>=5 and result['max_cart_excursion']<=3
                and not result['final_info'].get('simulation_error'))
            row = dict(label=label,affine=affine,tape=file_metadata(tape),full_nominal_component_gate_passed=gate,
                actual_hanging_start_episode_steps=len(actions),independent_tape_replay_transition_calls=len(actions),
                independent_whole_actual_tape_bytes_exact=True,shifted_nominal_controls_clipped=int(np.sum(abs(shifted)>1)),
                maximum_tracking_error=float(np.max(np.abs(actual[:min(len(actual),len(states))]-states[:min(len(actual),len(states))]))),
                result={key:value for key,value in result.items() if not isinstance(value,(dict,list))})
            payload['records'].append(row)
            payload['actual_hanging_start_episode_steps'] += len(actions)
            print(json.dumps(row),flush=True)
            dump_json(payload,out/'result.progress.json')
        payload.update(status='finished',gain=gain.tolist())
    except BaseException as error:
        payload.update(status='failed',error=f'{type(error).__name__}: {error}')
        raise
    finally:
        env.close()
        mujoco.mj_step = original_step
        payload.update(total_native_transition_calls=counter[0]/frame,native_physics_substeps=counter[0],
            partial_transition_substeps=counter[0]%frame,wall_seconds=time.monotonic()-began,finished_at=utc_timestamp())
        dump_json(payload,out/'result.json')
        print(json.dumps(dict(status=payload['status'],calls=payload['total_native_transition_calls'])),flush=True)


if __name__ == '__main__':
    main()
