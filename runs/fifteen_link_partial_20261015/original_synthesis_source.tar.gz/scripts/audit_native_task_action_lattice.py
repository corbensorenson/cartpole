#!/usr/bin/env python
"""Search nearby representable action sequences from fixed actual states."""
import argparse,json,time
from pathlib import Path
import numpy as np
from scipy.optimize import Bounds,LinearConstraint,milp
from scipy.sparse import csr_matrix,eye,hstack,vstack
from gcartpole.config import dump_json,load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.ilqr import MujocoTransition
from gcartpole.native_task_derivatives import physical_task_residual,chained_physical_task_jacobian
from gcartpole.native_action_lattice import polish_native_action_lattice
from scripts.search_capture_sequence import fixed_state_cfg


def affine_action_lattice(center,radius):
    """Contiguous exact F32 grid around each center, never across a spacing change."""
    center=np.asarray(center,np.float32).astype(float);spacing=[];lower=[];upper=[]
    for value in center:
        single=np.float32(value)
        step=min(float(np.nextafter(single,np.float32(np.inf)))-value,
                 value-float(np.nextafter(single,np.float32(-np.inf))))
        offsets=np.arange(-radius,radius+1)
        affine=value+step*offsets
        valid=(np.abs(affine)<=1.)&(affine==affine.astype(np.float32).astype(float))
        left=right=radius
        while left>0 and valid[left-1]:left-=1
        while right<2*radius and valid[right+1]:right+=1
        spacing.append(step);lower.append(left-radius);upper.append(right-radius)
    return np.asarray(spacing),np.asarray(lower),np.asarray(upper)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    p.add_argument('--delivered-steps',type=int,nargs='+',default=[376,392,408])
    p.add_argument('--radii',type=int,nargs='+',default=[8,64,512])
    p.add_argument('--solver-seconds',type=float,default=10.)
    p.add_argument('--method',choices=['integer-proposal-component','production-polisher'],default='integer-proposal-component')
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    if min(args.radii)<1 or max(args.radii)>4096 or not np.isfinite(args.solver_seconds) or args.solver_seconds<=0:
        raise ValueError('positive bounded lattice and solver budgets required')
    source=json.loads(Path(args.source).read_text());cfgpath=source['config']['path'];basepath=source['source']['path']
    if file_metadata(cfgpath)!=source['config'] or file_metadata(basepath)!=source['source']:raise ValueError('Source inputs changed')
    base=json.loads(Path(basepath).read_text());cfg=load_config(cfgpath);n=cfg['env']['n_links'];nx=2*(n+1)
    horizon=source['executed_policy']['requested_horizon_steps'];rate=source['executed_policy']['residual_weights']['rate']
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True);local=FourthOrderMujocoTransition(env,np.eye(nx),continuous_angles=True)
    rows=source['result']['trajectory'];records=[];began=time.monotonic()
    def forecast(state,actions):
        current=state.copy();states=[]
        if not np.array_equal(actions,np.asarray(actions,np.float32).astype(float)) or np.max(np.abs(actions))>1:
            raise ValueError('Every proposal must be exactly representable bounded F32 inputs')
        for action in actions:current=native(current,float(action));states.append(current.copy())
        states=np.asarray(states);residual=physical_task_residual(states,n,rate)
        return residual,states
    try:
        for step in args.delivered_steps:
            row=rows[step-1];state=np.asarray(rows[step-2]['qpos']+rows[step-2]['qvel'])
            center=np.asarray(row['tracking_preview']['selected_sequence'],np.float32).astype(float)
            if len(center)!=horizon:raise ValueError('Complete retained plan required')
            residual,predictions=forecast(state,center)
            if not np.array_equal(predictions[0],row['qpos']+row['qvel']):raise ValueError('First native prediction must reproduce actual physics')
            jac=chained_physical_task_jacobian(local,state,center,predictions,n_links=n,rate_weight=rate,
                state_epsilon=base['controller']['state_epsilon'],action_epsilon=base['controller']['action_epsilon'])
            reference=np.asarray(base['controller']['controls'][step-1:step-1+horizon])
            if args.method=='production-polisher':
                selected,diagnostics=polish_native_action_lattice(native,state,center,reference_actions=reference,
                    constraint_residual=lambda states:physical_task_residual(states,n,rate),
                    constraint_jacobian=lambda initial,actions,states:jac.copy(),
                    admissible=lambda states:bool(np.all(np.abs(states[:,0])<=env.rail_limit)),
                    radii=args.radii,solver_seconds=args.solver_seconds,action_regularization=.01)
                selected_states=diagnostics.pop('selected_states')
                if selected is None or diagnostics['selected_total_cost']>diagnostics['baseline_total_cost']:
                    raise ValueError('Polisher must preserve an admissible center and nonincreasing native cost')
                selected_residual,checked_states=forecast(state,selected)
                if not np.array_equal(checked_states,selected_states):raise ValueError('Selected native lattice tape changed')
                records.append(dict(delivered_step=step,actual_first_state_bit_identical=True,
                    baseline_physical_cost=float(residual@residual),selected_physical_cost=float(selected_residual@selected_residual),
                    selected_sequence=selected.tolist(),selected_forecast_replayed_bit_identically=True,diagnostics=diagnostics))
                print(json.dumps(dict(step=step,baseline=float(residual@residual),selected=float(selected_residual@selected_residual),
                    changed=diagnostics['changed_sequence'])),flush=True)
                continue
            total_residual=np.r_[residual,.01*(center-reference)];total_jac=np.vstack([jac,.01*np.eye(horizon)])
            # Common power-of-two scaling retains the L1 objective, while keeping
            # small per-ULP coefficients above the solver's usual tiny-entry cutoff.
            scale=2.**20;record=dict(delivered_step=step,actual_first_state_bit_identical=True,
                baseline_physical_cost=float(residual@residual),searches=[])
            records.append(record)
            for radius in args.radii:
                spacing,lower,upper=affine_action_lattice(center,radius)
                d=scale*total_jac*spacing[None,:];r=scale*total_residual;m=len(r)
                matrix=vstack([hstack([csr_matrix(d),-eye(m)]),hstack([-csr_matrix(d),-eye(m)])],format='csc')
                before=time.monotonic()
                solution=milp(np.r_[np.zeros(horizon),np.ones(m)],
                    integrality=np.r_[np.ones(horizon),np.zeros(m)],
                    bounds=Bounds(np.r_[lower,np.zeros(m)],np.r_[upper,np.full(m,np.inf)]),
                    constraints=LinearConstraint(matrix,np.full(2*m,-np.inf),np.r_[-r,r]),
                    options=dict(time_limit=args.solver_seconds,mip_rel_gap=1e-3,presolve=True))
                search=dict(radius_ulps=radius,spacing=spacing.tolist(),integer_lower=lower.tolist(),integer_upper=upper.tolist(),
                    solver_status=int(solution.status),solver_success=bool(solution.success),solver_message=solution.message,
                    solver_seconds=time.monotonic()-before,solver_mip_gap=getattr(solution,'mip_gap',None),
                    solver_mip_node_count=getattr(solution,'mip_node_count',None),
                    common_residual_scale=scale,nonzero_scaled_coefficients_below1e9=int(np.count_nonzero((d!=0)&(np.abs(d)<1e-9))),trials=[])
                record['searches'].append(search)
                if solution.x is not None and np.all(np.isfinite(solution.x)):
                    integers=np.rint(solution.x[:horizon]);error=float(np.max(np.abs(integers-solution.x[:horizon])))
                    search['maximum_integer_rounding_error']=error
                    if error<=1e-5 and np.all((integers>=lower)&(integers<=upper)):
                        for exponent in range(10):
                            offsets=np.rint(integers*2.**(-exponent));candidate=center+spacing*offsets
                            physical,states=forecast(state,candidate)
                            search['trials'].append(dict(fraction=2.**(-exponent),integer_offsets=offsets.tolist(),
                                physical_cost=float(physical@physical),linear_predicted_physical_cost=float(np.sum((residual+jac@(candidate-center))**2)),
                                admissible=bool(np.all(np.isfinite(states)) and np.all(np.abs(states[:,0])<=env.rail_limit)),
                                sequence=candidate.tolist()))
                valid=[t for t in search['trials'] if t['admissible']]
                search['best_native_trial']=min(valid,key=lambda t:t['physical_cost']) if valid else None
                dump_json(dict(records=records,not_solution=True,canonical_release_evidence=False),out/'result.progress.json')
            print(json.dumps(dict(step=step,baseline=record['baseline_physical_cost'],best=[None if s['best_native_trial'] is None else s['best_native_trial']['physical_cost'] for s in record['searches']])),flush=True)
    finally:env.close()
    dump_json(dict(not_solution=True,canonical_release_evidence=False,source=file_metadata(args.source),config=file_metadata(cfgpath),
        parameters=vars(args),records=records,native_forecast_transition_calls=native.evaluations,
        native_local_derivative_transition_calls=local.evaluations,total_native_transition_calls=native.evaluations+local.evaluations,
        wall_seconds=time.monotonic()-began,runtime=runtime_metadata(),reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Fixed actual states. Local affine native4/MP100 Jacobian and mixed-integer L1 trust boxes on an exact F32 action lattice; proposals and rounded integer backtracking checked by native rollouts. L1 differs from earlier squared-loss fitting. Solver gaps/timeouts, finite model/FD/native arithmetic remain; no optimality, episode pass or viability certificate.'),out/'result.json')


if __name__=='__main__':main()
