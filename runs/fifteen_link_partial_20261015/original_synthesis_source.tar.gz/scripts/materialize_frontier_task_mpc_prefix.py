#!/usr/bin/env python
"""Independently verify a native MPC prefix and retain the source reference suffix."""
import argparse
import copy
import json
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json, load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata
from gcartpole.ilqr import MujocoTransition
from scripts.materialize_frontier_physical_prefix import splice_physical_prefix
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.solve_frontier_capture_increment import validate_development_seeds


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ('source','physical-episode','config','directory'):parser.add_argument('--'+key,required=True)
    parser.add_argument('--prefix-seconds',type=float,default=8.)
    args=parser.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    source=json.loads(Path(args.source).read_text());episode=json.loads(Path(args.physical_episode).read_text())
    cfg=load_config(args.config);dt=cfg['env']['timestep']*cfg['env']['frame_skip'];n=cfg['env']['n_links']
    steps=round(args.prefix_seconds/dt);c=source['controller'];p=episode['executed_policy']
    validate_development_seeds(n,source['seed'])
    if (not np.isclose(steps*dt,args.prefix_seconds) or not 0<steps<len(c['controls'])
        or episode['source']!=file_metadata(args.source) or episode['config']!=file_metadata(args.config)
        or p['type']!='native_physical_task_mpc_after_verified_route_prefix'
        or p['action_precision']!='float32' or p['frequency_hz']!=1/dt
        or p['predictor_data_is_separate'] is not True
        or episode['physical_tape_diagnostics']['is_exactly_feasible'] is not True
        or episode['physical_tape_diagnostics']['maximum_dynamics_defect']!=0.
        or episode['actual_tape_validation_transition_calls']<steps
        or episode['result']['trajectory_integrity'] is not True
        or not c['continuous_angles'] or c['phase_adaptive']
        or not np.array_equal(c['coordinate_transform'],np.eye(2*(n+1)))):
        raise ValueError('Requires matching source/config and a verified native actual MPC tape')
    initial=np.r_[source['selected_state']['qpos'],source['selected_state']['qvel']]
    rows=episode['result']['trajectory'];physical=np.vstack([initial,[r['qpos']+r['qvel'] for r in rows]])
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,source['selected_state'],30.),progress=1.,seed=source['seed'])
    try:
        env.reset(seed=source['seed']);transition=MujocoTransition(env,np.eye(len(initial)),continuous_angles=True)
        controls,nodes,gains,diagnostics=splice_physical_prefix(transition,initial,c['controls'],
            source['search']['nominal_coordinate_states'],c['feedback_gains'],physical,
            [r['action'] for r in rows],steps,env.rail_limit)
        if diagnostics['maximum_dynamics_defect']!=0.:raise ValueError('Prefix is not exactly native feasible')
        proposal=copy.deepcopy(source);proposal.update(not_solution=True,initialization_only=True)
        proposal['controller'].update(controls=controls.tolist(),feedback_gains=gains.tolist(),initialization_only=True)
        for key in ('solver_feedback_gains','final_trajectory_diagnostics','warm_start_diagnostics','tracking_feedback_design'):
            proposal['controller'].pop(key,None)
        proposal['search']=dict(nominal_coordinate_states=nodes.tolist())
        for key in ('result','tracking_only_comparison','shared_capture_recipe'):proposal.pop(key,None)
        proposal['physical_prefix_initialization']=dict(source=file_metadata(args.source),config=file_metadata(args.config),
            physical_episode=file_metadata(args.physical_episode),prefix_seconds=args.prefix_seconds,prefix_steps=steps,
            native_prefix_validation_transition_calls=transition.evaluations,diagnostics=diagnostics,
            suffix_nodes_controls_gains_unchanged=True,prefix_gains_unchanged=True,no_runtime_state_projection=True,
            full_development_episode_passed=False,reserved_seeds_used=False,noisy_development_seeds_used=False,
            scope='Offline materialization of actual native MPC prefix. The source reference suffix remains virtual and must be repaired; no passed hanging-start release or live state replacement.')
        dump_json(proposal,out/'result.json')
        print(json.dumps(dict(prefix_steps=steps,maximum_native_defect=diagnostics['maximum_dynamics_defect'],
            native_validation_calls=transition.evaluations,endpoint_absolute_angle_max=float(np.max(np.abs(np.cumsum(nodes[steps,1:n+1])))),
            endpoint_absolute_rate_max=float(np.max(np.abs(np.cumsum(nodes[steps,n+2:])))))))
    finally:env.close()


if __name__=='__main__':main()
