"""Reproduce first-round proposal retention from matched finished native searches."""
import argparse,json
from collections import Counter
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.native_sparse_stream import stratified_balanced_actions
from gcartpole.native_task_derivatives import physical_task_residual,chained_physical_task_jacobian
from gcartpole.native_bound_objective import bound_diagnostics,native_bound_score
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('source','control','directory'):p.add_argument('--'+key,required=True)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    paths=[Path(args.source),Path(args.control)];sources=[json.loads(p.read_text()) for p in paths]
    source=sources[0];params=source['parameters'];h=source['horizon_steps']
    center=np.asarray(source['initial_sequence']);original=json.loads(Path(source['source']['path']).read_text())
    growth=original;ancestry=[];seen=set()
    for path,data in zip(paths,sources):
        execution=json.loads((path.parent/'execution.json').read_text())
        if execution['status']!='finished' or execution['returncode']!=0:raise ValueError('completed source required')
        identities={r['path']:r['sha256'] for r in execution['frozen_inputs']}
        for name in ('native_sparse_stream','native_null_minimax','native_task_derivatives','native_bound_objective','native_action_lattice','high_order_dynamics'):
            code=f'src/gcartpole/{name}.py'
            if file_metadata(code)['sha256']!=identities[code]:raise ValueError('proposal or derivative code differs from frozen source')
        if (data['source']!=source['source'] or data['initial_center_source']!=source['initial_center_source']
                or np.asarray(data['initial_sequence']).tobytes()!=center.tobytes()):raise ValueError('common physical center required')
    if file_metadata(source['source']['path'])!=source['source']:raise ValueError('growth source changed')
    while not all(k in original for k in ('config','teacher','parameters')):
        ref=original['source']
        if ref['path'] in seen or len(ancestry)>=8 or file_metadata(ref['path'])!=ref:raise ValueError('physical ancestry changed')
        seen.add(ref['path']);ancestry.append(ref);original=json.loads(Path(ref['path']).read_text())
    for key in ('source','config','teacher'):
        if file_metadata(original[key]['path'])!=original[key]:raise ValueError('physical input changed')
    cfg=load_config(original['config']['path']);n=cfg['env']['n_links'];nx=2*(n+1)
    base=json.loads(Path(original['source']['path']).read_text());step=original['parameters']['start_step'];rate=original['parameters']['rate_residual_weight']
    ref=np.asarray(base['controller']['controls'][step:step+h],np.float32).astype(float)
    override=json.loads(Path(source['initial_center_source']['path']).read_text())
    if file_metadata(source['initial_center_source']['path'])!=source['initial_center_source']:raise ValueError('override changed')
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True);local=FourthOrderMujocoTransition(env,np.eye(nx),continuous_angles=True)
    untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
    try:
        state=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
        for row in base['result']['trajectory'][:step]:
            state=native(state,float(np.float32(row['action'])))
            if state.tobytes()!=np.asarray(row['qpos']+row['qvel']).tobytes():raise ValueError('cold prefix changed')
        def forecast(actions):
            current=state.copy();states=[]
            for u in actions:current=native(current,float(u));states.append(current.copy())
            return np.asarray(states)
        known=forecast(np.asarray(growth['last_valid_plan']))
        if known.tobytes()!=np.asarray(growth['last_valid_forecast_states']).tobytes():raise ValueError('known plan changed')
        states=forecast(center)
        if states.tobytes()!=np.asarray(override['last_finite_states']).tobytes():raise ValueError('initial physical center changed')
        d=bound_diagnostics(states,n,params['forecast_angle_limit'],env.rail_limit)
        r=physical_task_residual(states,n,rate,.1);cost=float(r@r+1e-4*np.sum((center-ref)**2))
        if list(native_bound_score(d,cost,params['bound_objective']))!=source['initial_score']:raise ValueError('initial score changed')
        residual=physical_task_residual(states,n,rate,0.)
        jac=chained_physical_task_jacobian(local,state,center,states,n_links=n,rate_weight=rate,
            state_epsilon=base['controller']['state_epsilon'],action_epsilon=base['controller']['action_epsilon'],angle_band=0.)
        records=[]
        for path,data in zip(paths,sources):
            a=data['parameters'];recorded=data['rounds'][0];old=recorded['proposal_model']
            rows,m=stratified_balanced_actions(center,jac,residual,ref,arity=a['move_arity'],
                cancelled_rank=a['cancelled_response_rank'],bound_objective=a['bound_objective'],
                coupled_null_supports=a['coupled_null_supports'],coupled_null_solver_seconds=a['coupled_null_solver_seconds'],
                states=states,n_links=n,angle_limit=a['forecast_angle_limit'],rail_limit=env.rail_limit,
                amplitudes=tuple(a['amplitudes']),support_spans=tuple(a['support_spans']),
                max_supports=a['max_supports'],max_model_proposals=a['max_model_proposals'],
                keep_proposals=a['keep_proposals'],batch_size=a['proposal_batch_size'])
            for key in ('spacing','scaled_singular_values','scored_model_proposals','tested_supports','proposal_count',
                    'direction_families_generated','coupled_null_attempted_supports','coupled_null_model_proposals','coupled_null_status_counts'):
                if m[key]!=old[key]:raise ValueError('first-round model differs: '+key)
            if recorded['selected_proposal'] not in rows:raise ValueError('recorded selected proposal missing')
            families=Counter(row['null_direction_family'] for row in rows)
            coupled=[row for row in rows if row['null_direction_family']=='coupled_minimax']
            records.append(dict(source=file_metadata(path),retained_proposals=len(rows),
                retained_direction_families=dict(families),coupled_retained=len(coupled),
                coupled_generated=m['coupled_null_model_proposals'],
                best_coupled_predicted_maximum_angle=min((r['predicted_maximum_angle'] for r in coupled),default=None),
                native_tested_candidates=recorded['tested_candidates'],invalid_native_candidates=recorded['invalid_candidates'],
                all_retained_native_checked=recorded['tested_candidates']==len(rows) and not recorded['feasible_plan_found'],
                recorded_selected_family=recorded['selected_proposal']['null_direction_family'],
                model_counters_exactly_reproduced=True))
        if forecast(center).tobytes()!=states.tobytes():raise ValueError('independent initial tape replay changed')
        if untouched.tobytes()!=np.r_[env.data.qpos,env.data.qvel].tobytes():raise ValueError('audit changed live state')
        data=dict(parameters=vars(args),records=records,input_ancestry=ancestry,
            source=file_metadata(args.source),script=file_metadata(__file__),runtime=runtime_metadata(),
            initial_native_states_and_score_exact=True,known_plan_byte_identical=True,live_state_unchanged=True,
            native_forecast_transition_calls=native.evaluations,native_local_derivative_transition_calls=local.evaluations,
            total_native_transition_calls=native.evaluations+local.evaluations,actual_episode_steps=0,
            optimizer_transition_calls=0,canonical_release_evidence=False,not_solution=True,
            reserved_seeds_used=False,noisy_development_seeds_used=False,
            scope='Cold-replay common first-round center, rebuild its native4/MP100 Jacobian, reproduce frozen proposal-model counters and selected row, count retained families. Component audit only;no new candidate native tests,actual episode or global feasibility conclusion. Native-tested counts come from finished source rounds.')
        dump_json(data,out/'result.json');print(json.dumps(records))
    finally:env.close()


if __name__=='__main__':main()
