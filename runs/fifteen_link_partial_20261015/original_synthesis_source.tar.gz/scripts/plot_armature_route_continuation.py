"""Scientific figure of native defect correction and maintenance handoff."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gcartpole.evidence import file_metadata

ROOT=Path('runs/armature_route_continuation_20261003')
source=ROOT/'armature0.99_repair8/diagnostic/candidate.json'
nominal=np.asarray(json.loads(source.read_text())['search']['nominal_coordinate_states'])
traces=[('Eight-iteration repair',ROOT/'armature0.99_repair8/diagnostic/actual_tape.npz'),
    ('Pure MP100 tracking',ROOT/'armature0.99_native_defect_feedback/diagnostic/perturbation_only.npz'),
    ('Native defect correction; handoff 14 s',ROOT/'armature0.99_native_defect_feedback/diagnostic/known_defect_affine.npz'),
    ('Native defect correction; handoff 9 s',ROOT/'armature0.99_affine_handoff_screen/diagnostic/handoff9.0.npz')]
fig,axes=plt.subplots(2,1,figsize=(11,8),gridspec_kw={'height_ratios':[1,1.15]})
colors=['#d77a32','#bb4358','#438a89','#355ac4']
axes[0].plot(np.arange(len(nominal))*.02,nominal[:,0],color='.65',lw=2,label='Optimizer reference')
tau=np.sqrt(3/9.81)
for (label,path),color in zip(traces,colors):
    with np.load(path) as tape:x=tape['states'];u=tape['actions']
    t=np.arange(len(x))*.02
    axes[0].plot(t,x[:,0],color=color,lw=1.7,label=label)
    end=min(len(x),len(nominal),451 if 'handoff 9' in label else len(nominal))
    error=x[:end]-nominal[:end]
    scaled=np.column_stack([error[:,0]/3,np.cumsum(error[:,1:15],axis=1)/.15,
        error[:,15]*tau/3,np.cumsum(error[:,16:],axis=1)*tau/.15])
    magnitude=np.max(abs(scaled),axis=1);positive=magnitude>0
    axes[1].semilogy(t[:end][positive],magnitude[positive],color=color,lw=1.7,label=label)
for bound in (-3,3):axes[0].axhline(bound,color='.3',ls='--',lw=.8)
axes[0].set(xlabel='Elapsed time (s)',ylabel='Cart position (m)',xlim=(0,30),ylim=(-3.3,3.3))
axes[0].legend(fontsize=8,loc='lower right')
axes[1].axvline(9,color=colors[-1],ls=':',lw=1)
axes[1].set(xlabel='Elapsed time before handoff (s)',ylabel='Maximum scaled state error',xlim=(0,14))
for ax in axes:ax.grid(alpha=.2);ax.spines[['top','right']].set_visible(False)
fig.suptitle('A complete route needs native defect correction and a compatible handoff',fontsize=15)
fig.tight_layout(rect=(0,.12,1,.95))
fig.text(.07,.074,'14 links; armature ×0.99, 50 Hz, ±80 N and ±3 m rail. Exact unparked hanging starts; native F32 actions.',fontsize=9)
fig.text(.07,.049,'The 9 s handoff holds 24.18 s within a full 30 s episode. The 14 s handoff later crosses the rail.',fontsize=9)
fig.text(.07,.024,'Error scales: cart 3 m, absolute angles 0.15 rad, rates by √(3/g). Auxiliary altered-plant evidence; fifteen remains unsolved.',fontsize=9)
out=ROOT/'figures';out.mkdir(exist_ok=False)
files=[]
for suffix in ('png','pdf'):
    path=out/f'native_defect_correction_and_handoff.{suffix}';fig.savefig(path,dpi=180);files.append(file_metadata(path))
(out/'figures.json').write_text(json.dumps(dict(script=file_metadata(__file__),reference=file_metadata(source),
    traces=[file_metadata(path) for _,path in traces],figures=files,native_transition_calls=0),indent=2)+'\n')
