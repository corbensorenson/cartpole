"""Zero-integration exploratory force/modal spectra of existing actual tapes."""
import argparse,csv,json,time
from pathlib import Path
import mujoco,numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata,utc_timestamp
from gcartpole.generalized_modes import chain_normal_modes
from gcartpole.trajectory_spectra import (welch_summary,force_motion_coherence,
    projected_modal_rates,first_sustained_upright_tick)


def read(path):return json.loads(Path(path).read_text())
def check(ref):assert file_metadata(ref['path'])==ref

def arrays_to_json(value):
    if isinstance(value,np.ndarray):return value.tolist()
    if isinstance(value,dict):return {k:arrays_to_json(v) for k,v in value.items()}
    if isinstance(value,list):return [arrays_to_json(v) for v in value]
    return value


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory',required=True);args=parser.parse_args()
    out=Path(args.directory);out.mkdir(parents=True,exist_ok=False)
    (out/'spectra').mkdir();(out/'figures').mkdir()
    began=time.monotonic()
    def forbidden(*args,**kwargs):raise AssertionError('zero native integration ceiling')
    mujoco.mj_step=forbidden
    source_path='runs/solved_chain_parameter_map_20261003_int_normalized/diagnostic/result.json'
    source=read(source_path);audit_path='runs/armature_route_continuation_20261003/verified.json'
    audit=read(audit_path);assert audit['passed']
    memo='research/memos/2026-10-03_harmonics_reconnaissance_plan.json'
    data=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),runtime=runtime_metadata(),
        source=file_metadata(source_path),route_audit=file_metadata(audit_path),prospective_memo=file_metadata(memo),
        scope='Read-only exploratory analysis of stored actual50Hz tapes. No resonance/causation/robustness/new solve claim.',
        native_transition_ceiling=0,total_native_transition_calls=0,actual_hanging_start_episode_steps=0,
        canonical_release_evidence=False,not_solution=True,reserved_seeds_used=False,
        fifteen_noisy_development_seeds_used=False,mode_catalog=[],traces=[],matched_prefixes=[],
        methods=dict(sample_rate_hz=50.,nyquist_hz=25.,window='periodic Hann',
            segment_seconds=2.,noverlap_fraction=.5,nfft_equals_segment_size=True,detrend='constant',
            density_units='force: N^2/Hz; fixed-basis modal rates: modal-rate^2/Hz',
            bin_spacing_hz=.5,coherence_minimum_segments=3,
            sliding_window_hop_seconds=.5,
            phase_partition='Scheduledpark; transfer ends at first post-step tick starting a continuous5s upright run, or trace end if absent; post_capture thereafter, including later failures. Full-route scheduled horizon retained separately.',
            modal_reference='Undamped hanging eigenproblem with cart acceleration as base input, compiled physical mass/stiffness, fixed mass-normalized hinge basis; not free-cart force-input poles.',
            projection='Hinge rates projected onto hanging basis; no angle wrapping/unwrap derivatives.',
            scope_limits=['Fixed-basis mode rates during large swing are descriptive, not conserved modal energy or instantaneous modes.',
                'Nonstationary peaks and coherence do not prove harmonics, resonance or causal usefulness.',
                'Hann bin spacing is not exact peak uncertainty or resolution of arbitrarily close frequencies.',
                '50Hz output cannot diagnose aliased substep motion; delivered force is zero-order held.',
                'Cart work is trapezoidal velocity quadrature on stored samples, not exact mechanical chain work.',
                'Different-count route designs/durations are confounded; only paired-prefix comparisons hold these fixed.']))
    data['methods']['scope_limits'].append('Welch averages complete overlapping windows and can omit a trailing partial window; covered and unused sample counts are recorded per spectrum. RMS and cart quadrature use the entire phase. Sliding spectra can omit fewer than25 trailing samples.')
    basis={}
    def modes_for(tag,path):
        cfg=load_config(path);env=NLinkCartPoleEnv(cfg,progress=1.,seed=0)
        try:m=chain_normal_modes(env)
        finally:env.close()
        V=m.relative_shapes;M=m.joint_mass_matrix;K=m.stiffness_matrix
        residual=K@V-(M@V)*m.squared_frequencies
        row=dict(tag=tag,n_links=m.n_links,config=file_metadata(path),modes=m.to_dict(),
            frequencies_hz=(m.angular_frequencies/(2*np.pi)).tolist(),
            mass_orthonormality_max_error=float(np.max(np.abs(V.T@M@V-np.eye(m.n_links)))),
            relative_eigen_residual=float(np.linalg.norm(residual)/max(np.linalg.norm(K@V),np.finfo(float).tiny)),
            adjacent_spacing_hz=np.diff(m.angular_frequencies/(2*np.pi)).tolist())
        data['mode_catalog'].append(row);basis[tag]=(m,V.T@M);return basis[tag]
    canonical={row['n_links']:row for row in source['records'] if row['canonical_control']}
    for n in range(7,21):
        config=canonical[n]['config']['path'] if n<=14 else f'configs/swingup{n}_uniform.yaml'
        modes_for(f'n{n}',config)
    for ratio in (.99,.95):modes_for(f'n14_armature{ratio}',f'runs/armature_route_continuation_20261003/armature{ratio:.2f}.json')
    all_sources=[];signals={}
    def analyze(tag,tape_ref,basis_tag,park_ticks,passed,scheduled_horizon_ticks=None):
        check(tape_ref);tape=np.load(tape_ref['path']);states=tape['states'];actions=tape['actions'];count=len(actions)
        modes,projector=basis[basis_tag];n=modes.n_links
        assert states.shape==(count+1,2*(n+1)) and np.all(np.isfinite(states))
        assert np.array_equal(actions.astype(np.float32).astype(float),actions) and np.max(np.abs(actions))<=1
        force=actions*80.;modal=projected_modal_rates(states[:-1],n,projector)
        start=first_sustained_upright_tick(states,n,50.)
        transfer_end=count if start is None else max(park_ticks,start)
        blocks=[('park',0,min(park_ticks,count)),('transfer',min(park_ticks,count),transfer_end),('post_capture',transfer_end,count)]
        row=dict(tag=tag,basis_tag=basis_tag,n_links=n,tape=tape_ref,steps=count,
            full_episode_gate_passed=passed,scheduled_park_seconds=park_ticks/50.,
            scheduled_route_horizon_seconds=None if scheduled_horizon_ticks is None else scheduled_horizon_ticks/50.,
            first_sustained_upright_start_seconds=None if start is None else start/50.,phases=[])
        all_sources.append(tape_ref);signals[tag]=(states,actions,force,modal)
        # Arrays for later re-analysis, including full sampled input/output and all modes.
        saved=dict(force_N=force,modal_rates=modal,sample_times_seconds=np.arange(count)/50.)
        for label,lo,hi in blocks:
            phase=dict(label=label,start_tick=lo,end_tick=hi,duration_seconds=(hi-lo)/50.)
            if hi-lo<4:phase.update(estimated=False,reason='fewer than four samples');row['phases'].append(phase);continue
            spec=welch_summary(force[lo:hi],50.);phase.update(estimated=True,
                force={k:v for k,v in spec.items() if k not in ('frequencies_hz','psd')},
                positive_cart_work_J=float(np.sum(np.maximum(force[lo:hi]*.5*(states[lo:hi,n+1]+states[lo+1:hi+1,n+1]),0))/50.),
                negative_cart_work_J=float(np.sum(np.minimum(force[lo:hi]*.5*(states[lo:hi,n+1]+states[lo+1:hi+1,n+1]),0))/50.),
                saturated_tick_fraction=float(np.mean(np.abs(actions[lo:hi])>=1)),modes=[])
            saved[label+'_frequency_hz']=spec['frequencies_hz'];saved[label+'_force_psd']=spec['psd']
            psds=[]
            for i in range(n):
                ms=welch_summary(modal[lo:hi,i],50.)
                coherence=force_motion_coherence(force[lo:hi],modal[lo:hi,i],50.)
                mr=dict(index=i,hanging_frequency_hz=float(modes.angular_frequencies[i]/(2*np.pi)),
                    spectrum={k:v for k,v in ms.items() if k not in ('frequencies_hz','psd')},
                    force_motion_coherence=arrays_to_json(coherence))
                phase['modes'].append(mr);psds.append(ms['psd'])
            saved[label+'_modal_rate_psd']=np.array(psds)
            row['phases'].append(phase)
        # Constant-resolution sliding spectrograms: no zero padding or endpoint extension.
        frames=[];spectra=[];modal_spectra=[]
        for lo in range(park_ticks,max(park_ticks,count-99),25):
            spec=welch_summary(force[lo:lo+100],50.)
            frames.append((lo+50)/50.);spectra.append(spec['psd'])
            modal_spectra.append([welch_summary(modal[lo:lo+100,i],50.)['psd'] for i in range(n)])
        saved.update(window_centers_seconds=np.array(frames),window_force_psd=np.array(spectra),
            window_modal_rate_psd=np.array(modal_spectra),window_frequency_hz=np.arange(51)*.5)
        path=out/'spectra'/f'{tag}.npz';np.savez_compressed(path,**saved);row['spectra']=file_metadata(path)
        data['traces'].append(row)
    for n,row in canonical.items():
        release=source['releases'][n-7];check(release['controller']);controller=read(release['controller']['path'])['controller']
        episode=next(e for e in row['episodes'] if not e['noisy_start'])
        analyze(f'canonical{n}',episode['tape'],f'n{n}',round(release['parameters']['park_seconds']*50),
                episode['full_episode_gate_passed'],len(controller['controls']))
    root=Path('runs/armature_route_continuation_20261003')
    for ratio in (.99,.95):
        for label,relative in (
            ('repair',f'armature{ratio:.2f}_repair8/diagnostic/actual_tape.npz'),
            ('pure',f'armature{ratio:.2f}_native_defect_feedback/diagnostic/perturbation_only.npz'),
            ('affine14',f'armature{ratio:.2f}_native_defect_feedback/diagnostic/known_defect_affine.npz')):
            analyze(f'armature{ratio}_{label}',file_metadata(root/relative),f'n14_armature{ratio}',0,False)
    screen=read(root/'armature0.99_affine_handoff_screen/diagnostic/result.json')
    # All eight handoffs, not just the selected successful initializer.
    for sec in range(6,14):
        record=next(r for r in screen['records'] if r['handoff_seconds']==sec)
        analyze(f'armature0.99_handoff{sec}',record['tape'],
                'n14_armature0.99',0,record['full_nominal_component_gate_passed'])
    for ratio in (.99,.95):
        tags=[f'armature{ratio}_{k}' for k in ('repair','pure','affine14')]
        common=min(len(signals[tag][1]) for tag in tags)
        comparison=dict(tags=tags,common_prefix_samples=common,common_duration_seconds=common/50.,force_spectra=[])
        for tag in tags:
            s=welch_summary(signals[tag][2][:common],50.)
            comparison['force_spectra'].append(dict(tag=tag,**arrays_to_json(s)))
        data['matched_prefixes'].append(comparison)
    a=signals['armature0.99_affine14'];b=signals['armature0.99_handoff9']
    assert a[0][:451].tobytes()==b[0][:451].tobytes() and a[1][:450].tobytes()==b[1][:450].tobytes()
    data['same_swing_different_outcome']=dict(failing_trace='armature0.99_affine14',passing_trace='armature0.99_handoff9',
        identical_state_prefix_steps=450,identical_action_prefix_steps=450,
        identical_first9s_force_and_modal_rate_signals=True,
        interpretation='Their successful swing signals and spectra cannot distinguish their eventual outcomes before controller handoff9s. This is evidence against swing harmonics alone being a sufficient success classifier, not evidence that mode timing is irrelevant.')
    data['input_tapes']=all_sources
    metrics_path=out/'phase_metrics.csv'
    with metrics_path.open('w') as file:
        fields=['trace','phase','seconds','passed','force_rms_N','peak_hz','bin_spacing_hz','segments','spectral_entropy','positive_cart_work_J','negative_cart_work_J']
        writer=csv.DictWriter(file,fieldnames=fields);writer.writeheader()
        for row in data['traces']:
            for p in row['phases']:
                if p['estimated']:
                    s=p['force'];writer.writerow(dict(trace=row['tag'],phase=p['label'],seconds=p['duration_seconds'],passed=row['full_episode_gate_passed'],
                        force_rms_N=s['sample_rms'],peak_hz=s['peak_frequency_hz'],bin_spacing_hz=s['bin_spacing_hz'],segments=s['segments'],
                        spectral_entropy=s['normalized_positive_frequency_entropy'],positive_cart_work_J=p['positive_cart_work_J'],negative_cart_work_J=p['negative_cart_work_J']))
    data['phase_metrics']=file_metadata(metrics_path)
    data['wall_seconds']=time.monotonic()-began
    dump_json(data,out/'result.json')
    plot(out,data,signals)
    print(json.dumps(dict(traces=len(data['traces']),mode_plants=len(data['mode_catalog']),new_native_calls=0,
        result=file_metadata(out/'result.json'))))


def plot(out,data,signals):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(2,2,figsize=(12,8),layout='constrained')
    ax=axes[0,0]
    for row in data['mode_catalog']:
        if row['tag'].startswith('n') and '_armature' not in row['tag']:
            ax.scatter([row['n_links']]*row['n_links'],row['frequencies_hz'],s=13,color='#146b87' if row['n_links']<=14 else '#be703a')
    ax.set(title='Hanging reference modes: more modes, closer spacing',xlabel='Number of links',ylabel='Undamped natural frequency (Hz)',xticks=range(7,21));ax.grid(alpha=.2)
    ax=axes[0,1]
    for row in data['traces'][:8]:
        sp=np.load(row['spectra']['path'])
        ax.plot(sp['transfer_frequency_hz'],sp['transfer_force_psd'],label=str(row['n_links']))
    ax.set(title='Successful transfers use broad force spectra',xlabel='Frequency (Hz)',ylabel='Force PSD (N²/Hz)',xlim=(0,10),yscale='log');ax.legend(title='Links',ncol=4,fontsize=8);ax.grid(alpha=.2)
    ax=axes[1,0]
    for tag,style in [('armature0.99_affine14','-'),('armature0.99_handoff9','--')]:
        force=signals[tag][2];ax.plot(np.arange(len(force))/50.,force,style,label='handoff14s: fails' if style=='-' else 'handoff9s: passes',lw=1)
    ax.axvline(9,color='black',lw=1,alpha=.6);ax.set(title='Identical first 9s; different full-episode outcomes',xlabel='Time from hanging start (s)',ylabel='Delivered force (N)');ax.legend(fontsize=8);ax.grid(alpha=.2)
    ax=axes[1,1];row=next(r for r in data['traces'] if r['tag']=='canonical14');sp=np.load(row['spectra']['path'])
    centers=sp['window_centers_seconds']-row['scheduled_park_seconds'];psd=sp['window_force_psd']
    image=ax.pcolormesh(centers,sp['window_frequency_hz'],np.log10(np.maximum(psd.T,1e-20)),shading='auto',cmap='viridis',vmin=-10,vmax=3)
    ax.set(title='Fourteen: changing spectral content through the route',xlabel='Time after park (s)',ylabel='Frequency (Hz)',ylim=(0,10));fig.colorbar(image,ax=ax,label='log₁₀ force PSD (N²/Hz)')
    fig.suptitle('Harmonics reconnaissance • actual 50Hz tapes • descriptive, not a resonance test',fontsize=14)
    files=[]
    for suffix in ('png','pdf'):
        path=out/'figures'/f'harmonics_and_modal_timing.{suffix}';fig.savefig(path,dpi=180);files.append(file_metadata(path))
    plt.close(fig)
    dump_json(dict(generated_at=utc_timestamp(),result=file_metadata(out/'result.json'),script=file_metadata(__file__),figures=files,
        color_floor_is_display_only=True,native_transition_calls=0),out/'figures'/'figures.json')

if __name__=='__main__':main()
