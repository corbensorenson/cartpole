#!/usr/bin/env python
"""Rebase an executed prefix offline, retaining the unexecuted nominal suffix.

The prefix must independently reproduce with exactly zero native defects.
The suffix remains an infeasible optimizer proposal, never a live state reset.
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np

from gcartpole.config import dump_json, load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.search_fddp_capture import warm_start_diagnostics


def verified_preview_episode(episode, source_metadata, config_metadata, steps, frequency_hz):
    policy=episode.get('executed_policy',{});diagnostics=episode.get('physical_prefix_diagnostics',{})
    if (episode.get('source')!=source_metadata or episode.get('config')!=config_metadata
            or episode.get('value_provenance',{}).get('source')!=source_metadata
            or policy.get('live_state_projection') is not False
            or policy.get('predictor_data_is_separate') is not True
            or policy.get('action_precision')!='float32' or policy.get('frequency_hz')!=frequency_hz
            or diagnostics.get('is_exactly_feasible') is not True
            or episode.get('prefix_validation_transition_calls',0)<steps
            or episode.get('result',{}).get('trajectory_integrity') is not True):
        raise ValueError('preview episode requires identical source/config and verified native physical prefix')
    return episode['result']['trajectory']


def splice_physical_prefix(transition, initial_state, controls, nodes, gains,
                           physical_states, actions, steps, rail_limit):
    controls, nodes, gains = (np.asarray(v, dtype=float) for v in (controls, nodes, gains))
    physical_states, actions = (np.asarray(v, dtype=float) for v in (physical_states, actions))
    nx = len(initial_state)
    if (not 0 < steps < len(controls) or nodes.shape != (len(controls)+1, nx)
            or gains.shape != (len(controls), nx) or len(actions) < steps
            or physical_states.ndim != 2 or physical_states.shape[1] != nx
            or len(physical_states) < steps+1):
        raise ValueError('aligned interior prefix and complete state/control/gain dimensions required')
    prefix = physical_states[:steps+1]
    if not np.array_equal(prefix[0], initial_state):
        raise ValueError('physical prefix must start from the unchanged initial state')
    if not np.all(np.isfinite(prefix)) or np.any(np.abs(prefix[:, 0]) > rail_limit):
        raise ValueError('physical prefix must be finite and inside the canonical rail')
    if not np.all(np.isfinite(actions[:steps])) or np.any(np.abs(actions[:steps]) > 1):
        raise ValueError('recorded actions must respect the physical force bound')
    delivered = actions[:steps].astype(np.float32).astype(float)
    diagnostics = warm_start_diagnostics(transition, initial_state, delivered, prefix,
                                         require_feasible=True)
    result_controls, result_nodes = controls.copy(), nodes.copy()
    result_controls[:steps] = delivered
    result_nodes[:steps+1] = prefix
    # The boundary is the actual physical state. Every later nominal node,
    # control and gain remains the original optimizer proposal.
    assert np.array_equal(result_controls[steps:], controls[steps:])
    assert np.array_equal(result_nodes[steps+1:], nodes[steps+1:])
    return result_controls, result_nodes, gains.copy(), diagnostics


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', required=True)
    p.add_argument('--config', required=True)
    p.add_argument('--prefix-seconds', type=float, required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--physical-episode',default=None,
        help='Verified online preview episode; retain the full source reference suffix.')
    args = p.parse_args()
    out = Path(args.out)
    if out.exists():
        raise FileExistsError(out)
    source = json.loads(Path(args.source).read_text())
    c = source['controller']
    cfg = fixed_state_cfg(load_config(args.config), source['selected_state'], 30.)
    nx = 2*(cfg['env']['n_links']+1)
    if (not c['continuous_angles'] or c['phase_adaptive']
            or not np.array_equal(c['coordinate_transform'], np.eye(nx))):
        raise ValueError('exact prefix materialization requires fixed-time physical coordinates')
    base = 200000+1000*cfg['env']['n_links']
    reserved = set(range(base, base+20)) | set(range(base+100, base+220)) | {base+500}
    if source['seed'] in reserved:
        raise ValueError('reserved canonical seeds cannot initialize development repairs')
    env = NLinkCartPoleEnv(cfg, progress=1., seed=source['seed'])
    try:
        env.reset(seed=source['seed'])
        steps = round(args.prefix_seconds/env.dt)
        if not np.isfinite(args.prefix_seconds) or not np.isclose(steps*env.dt, args.prefix_seconds, rtol=0, atol=1e-12):
            raise ValueError('prefix must align to native control ticks')
        initial = np.r_[source['selected_state']['qpos'], source['selected_state']['qvel']]
        rows = source['result']['trajectory']
        if args.physical_episode is not None:
            episode=json.loads(Path(args.physical_episode).read_text())
            rows=verified_preview_episode(episode,file_metadata(args.source),file_metadata(args.config),steps,1/env.dt)
        physical = np.vstack([initial, [r['qpos']+r['qvel'] for r in rows]])
        controls, nodes, gains, diagnostics = splice_physical_prefix(
            MujocoTransition(env, np.eye(nx), continuous_angles=True), initial,
            c['controls'], source['search']['nominal_coordinate_states'], c['feedback_gains'],
            physical, [r['action'] for r in rows], steps, env.rail_limit)
        proposal = copy.deepcopy(source)
        proposal.update(not_solution=True, initialization_only=True)
        proposal['controller'].update(controls=controls.tolist(), feedback_gains=gains.tolist(),
            initialization_only=True)
        proposal['controller'].pop('solver_feedback_gains', None)
        # Old whole-route diagnostics describe different nodes and must not be inherited.
        proposal['controller'].pop('final_trajectory_diagnostics', None)
        proposal['controller'].pop('warm_start_diagnostics', None)
        inherited_design=proposal['controller'].pop('tracking_feedback_design',None)
        proposal['search'] = dict(nominal_coordinate_states=nodes.tolist())
        proposal.pop('result', None)
        proposal.pop('tracking_only_comparison', None)
        proposal['physical_prefix_initialization'] = dict(source=file_metadata(args.source),
            config=file_metadata(args.config), prefix_seconds=args.prefix_seconds,
            prefix_steps=steps, diagnostics=diagnostics, suffix_nodes_controls_gains_unchanged=True,
            prefix_gains_unchanged=True, no_runtime_state_projection=True,
            physical_episode=None if args.physical_episode is None else file_metadata(args.physical_episode),
            inherited_feedback_design=inherited_design,
            reserved_seeds_used=False, release_promotion=False,
            scope='Offline executed prefix plus inherited nominal suffix; requires new full physical replay and all development/release gates.')
        dump_json(proposal, out)
        print(json.dumps(proposal['physical_prefix_initialization']))
    finally:
        env.close()


if __name__ == '__main__':
    main()
