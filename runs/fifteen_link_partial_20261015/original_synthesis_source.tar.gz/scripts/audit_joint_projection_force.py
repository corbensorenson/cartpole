"""Read saved joint preview tapes and check omitted future feedback demand."""
import argparse,json
from pathlib import Path
import mpmath
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata
from gcartpole.upright_mechanics import upright_rk4_matrices


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--out',required=True)
    args=p.parse_args();out=Path(args.out)
    if out.exists():raise FileExistsError(out)
    data=json.loads(Path(args.source).read_text());assert file_metadata(data['config']['path'])==data['config']
    env=NLinkCartPoleEnv(load_config(data['config']['path']),progress=1.,seed=0);env.reset(seed=0)
    a,b,_=upright_rk4_matrices(env,decimal_digits=100);env.close()
    ctx=mpmath.mp.clone();ctx.dps=100;a,b=ctx.matrix(a.tolist()),ctx.matrix(b.tolist())
    delays=(0,1,2,4,8,16,32,64,100);rows=[];models={}
    for label,gain in data['gains'].items():
        k=ctx.matrix([gain]);cl=a-b*k;power=ctx.eye(32);powers={0:power}
        for index in range(1,101):power=cl*power;powers[index]=power
        projections=ctx.matrix([list(k*powers[t]) for t in delays]);models[label]=(powers,projections)
    for source in data['records']:
        powers,projections=models[source['gain_label']];row={k:source[k] for k in ('label','gain_label','horizon')};row['plans']=[]
        for plan in source['result']['plans'][:20]:
            start=np.asarray(source['result']['states'][plan['start_step']]).copy();start[1:16]=wrap_angle(start[1:16])
            final=np.asarray(plan['forecast'][-1]).copy();final[1:16]=wrap_angle(final[1:16])
            requested=projections*ctx.matrix(final.tolist())
            target=projections*powers[source['horizon']]*ctx.matrix(start.tolist())
            states=np.asarray(plan['forecast']);angles=wrap_angle(np.cumsum(states[:,1:16],axis=1))
            row['plans'].append(dict(start_step=plan['start_step'],time_seconds=plan['start_step']*.02,
                preview_maximum_angle=float(np.max(np.abs(angles))),
                selected_maximum_delayed_feedback_request=str(max(abs(v) for v in requested)),
                reference_maximum_delayed_feedback_request=str(max(abs(v) for v in target)),
                selected_projected_cost=plan['diagnostics']['selected_projected_cost'],
                selected_preview_feasible=plan['diagnostics']['selected_preview_feasible']))
        rows.append(row)
        violation=next((v for v in row['plans'] if abs(ctx.mpf(v['selected_maximum_delayed_feedback_request']))>1),None)
        print(json.dumps(dict(label=row['label'],gain=row['gain_label'],first_selected_request_over1=violation)),flush=True)
    dump_json(dict(source=file_metadata(args.source),script=file_metadata(__file__),projection_delays=list(delays),
        records=rows,native_transition_calls=0,canonical_release_evidence=False,
        scope='Read-only first20saved plans. MP100 hypothetical linear feedback requests from terminal native state and model-following reference. Requests are not actually delivered;these projections do not prove nonlinear infeasibility or a maintenance basin.'),out)


if __name__=='__main__':main()
