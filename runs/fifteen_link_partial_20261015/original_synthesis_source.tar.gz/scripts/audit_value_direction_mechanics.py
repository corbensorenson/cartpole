#!/usr/bin/env python
"""Smooth MP mechanics comparison on retained native one-step direction probes."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.planar_mechanics import PlanarMechanics

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for key in ('probe','directory'):p.add_argument('--'+key,required=True)
 args=p.parse_args();out=Path(args.directory)
 if (out/'result.json').exists():raise FileExistsError(out)
 probe=json.loads(Path(args.probe).read_text())
 for key in ('source','values','forcing_audit','config'):
  if file_metadata(probe[key]['path'])!=probe[key]:raise ValueError('probe input identity changed')
 source=json.loads(Path(probe['source']['path']).read_text());values=json.loads(Path(probe['values']['path']).read_text());forcing=json.loads(Path(probe['forcing_audit']['path']).read_text());nodes=source['search']['nominal_coordinate_states'];u=source['controller']['controls']
 env=NLinkCartPoleEnv(load_config(probe['config']['path']),progress=1.,seed=source['seed']);env.reset(seed=source['seed']);model=PlanarMechanics(env,decimal_digits=100);ctx=model.ctx;norm=lambda x:float(ctx.norm(x));maxnorm=lambda x:float(max(abs(z) for z in x));baselines={};records=[];began=time.monotonic();calls=0
 try:
  for row in probe['records']:
   step=row['step'];error=ctx.matrix(row['realized_error']);native=ctx.matrix(row['native_increment']);future=ctx.matrix(values['value_factors'][step+1]);nominal=ctx.matrix(nodes[step]);x=nominal+error
   if step not in baselines:baselines[step]=model.transition(nominal,float(np.float32(u[step])));calls+=1
   smooth=model.transition(x,row['delivered_action'])-baselines[step];calls+=1
   f=next(r for r in forcing['records'] if r['step']==step);a,b=ctx.matrix(f['A']),ctx.matrix(f['B']);delta=ctx.mpf(row['delivered_action'])-ctx.mpf(row['nominal_delivered_action']);linear=a*error+b*delta
   record=dict(step=step,time_seconds=row['time_seconds'],requested_physical_amplitude=row['requested_physical_amplitude'],sign=row['sign'],incoming_value_norm=row['incoming_value_norm'],native_increment_value_norm=norm(future*native),smooth_increment_value_norm=norm(future*smooth),linear_increment_value_norm=norm(future*linear),smooth_nonlinear_remainder_value_norm=norm(future*(smooth-linear)),native_minus_smooth_increment_value_norm=norm(future*(native-smooth)),smooth_gain=norm(future*smooth)/row['incoming_value_norm'],smooth_nonlinear_remainder_physical_max=maxnorm(smooth-linear),native_minus_smooth_increment_physical_max=maxnorm(native-smooth))
   records.append(record);print(json.dumps(record),flush=True)
 finally:env.close()
 dump_json(dict(not_solution=True,benchmark_evidence=False,probe=file_metadata(args.probe),runtime=runtime_metadata(),parameters=vars(args),records=records,independent_smooth_transition_calls=calls,native_transition_calls=0,wall_seconds=time.monotonic()-began,scope='Same retained inputs and native increments. MP smooth mechanics nonlinearity and native-minus-smooth discrepancy are reported separately. Discrepancy is not isolated native rounding and no causal full-episode attribution is made.'),out/'result.json')
if __name__=='__main__':main()
