#!/usr/bin/env python
"""Compare stationary and moving value metrics on saved native capture dynamics."""
import argparse,json,time
from pathlib import Path
import mpmath,numpy as np
from gcartpole.config import dump_json,load_config
from gcartpole.evidence import file_metadata,runtime_metadata,data_sha256
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for key in ('source','tracking-source','previous-tracking-source','values','forcing-audit','config','directory'):p.add_argument('--'+key,required=True)
 args=p.parse_args();out=Path(args.directory)
 if (out/'result.json').exists():raise FileExistsError(out)
 source=json.loads(Path(args.source).read_text());tracking=json.loads(Path(args.tracking_source).read_text());values=json.loads(Path(args.values).read_text());audit=json.loads(Path(args.forcing_audit).read_text())
 previous=json.loads(Path(args.previous_tracking_source).read_text())
 for key in ('controls','feedback_gains','coordinate_transform'):
  if tracking['controller'][key]!=previous['controller'][key]:raise ValueError('export rerun changed tracking recipe')
 if tracking['search']['nominal_coordinate_states']!=previous['search']['nominal_coordinate_states']:raise ValueError('export rerun changed nominal nodes')
 if audit['source']!=file_metadata(args.source) or values['source_controller']!=file_metadata(args.source):raise ValueError('source identity mismatch')
 for key in ('controls','coordinate_transform'):
  if source['controller'][key]!=tracking['controller'][key]:raise ValueError('tracking changed physical recipe')
 nodes=np.asarray(source['search']['nominal_coordinate_states']);u=np.asarray(source['controller']['controls']);gains=np.asarray(tracking['controller']['feedback_gains'])
 if source['search']['nominal_coordinate_states']!=tracking['search']['nominal_coordinate_states'] or values['controls_sha256']!=data_sha256(u.tolist()) or values['nominal_states_sha256']!=data_sha256(nodes.tolist()) or values['config']!=file_metadata(args.config) or values['regularization']!=0 or values['decimal_digits']!=100:raise ValueError('value export provenance mismatch')
 cfg=load_config(args.config);env=NLinkCartPoleEnv(cfg,progress=1.,seed=source['seed']);env.reset(seed=source['seed']);predictor=(FourthOrderMujocoTransition if values['derivative_order']==4 else MujocoTransition)(env,np.eye(nodes.shape[1]),continuous_angles=True)
 ctx=mpmath.mp.clone();ctx.dps=100;station=ctx.matrix(source['lyapunov']['factor']);station_inverse=station**-1;records=[];began=time.monotonic()
 def measures(mat):
  rounded=np.asarray(mat.tolist(),dtype=float);return dict(maximum_absolute_coefficient=float(max(abs(x) for x in mat)),spectral_norm=float(np.linalg.svd(rounded,compute_uv=False)[0]))
 try:
  for row in audit['records']:
   step=row['step'];a,b=predictor.linearize(nodes[step],float(np.float32(u[step])),state_epsilon=values['state_epsilon'],action_epsilon=values['action_epsilon'])
   a,b=ctx.matrix(a.tolist()),ctx.matrix(b.tolist());k=ctx.matrix(gains[step].tolist()).T;closed=a+b*k
   current=ctx.matrix(values['value_factors'][step]);future=ctx.matrix(values['value_factors'][step+1]);inverse=current**-1
   analytic_a=ctx.matrix(row['A']);analytic_b=ctx.matrix(row['B'])
   records.append(dict(step=step,time_seconds=row['time_seconds'],stationary_open=measures(station*a*station_inverse),stationary_closed=measures(station*closed*station_inverse),moving_open=measures(future*a*inverse),moving_closed=measures(future*closed*inverse),moving_closed_analytic_derivative_comparison=measures(future*(analytic_a+analytic_b*k)*inverse),stationary_input_norm=float(ctx.norm(station*b)),moving_input_norm=float(ctx.norm(future*b)),stationary_gap_norm=float(ctx.norm(station*ctx.matrix(row['gap']))),moving_gap_norm=float(ctx.norm(future*ctx.matrix(row['gap'])))))
   print(json.dumps(records[-1]),flush=True)
 finally:env.close()
 dump_json(dict(not_solution=True,benchmark_evidence=False,runtime=runtime_metadata(),parameters=vars(args),source=file_metadata(args.source),tracking_source=file_metadata(args.tracking_source),value_export=file_metadata(args.values),forcing_audit=file_metadata(args.forcing_audit),records=records,native_derivative_transition_calls=predictor.evaluations,wall_seconds=time.monotonic()-began,scope='Local MP100 contractions using exported binary64 value roots and gains. Native finite derivatives match value-design recipe; analytic derivatives are a separately labeled comparison. Neither induced metric nor nominal contraction certifies nonlinear bounded capture.'),out/'result.json')
if __name__=='__main__':main()
