#!/usr/bin/env python
"""Bounded nonlinear next-step corrections on a saved periodic component.

Forecasts use a separate MuJoCo environment. This never establishes hanging-
start reachability, a canonical cadence record or real-time compute feasibility.
"""
import argparse
import json
from pathlib import Path
import time

import numpy as np

from gcartpole.config import dump_json, load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, runtime_metadata
from gcartpole.ilqr import MujocoTransition
from gcartpole.nonlinear_value_control import select_nonlinear_value_action
from gcartpole.simulation import SimulationError
from scripts.audit_periodic_capture import execute_component


def periodic_value_inputs(source, cfg, config_metadata):
    """Reject roots from a different orbit basis, period or design precision."""
    nodes = np.asarray(source['search']['nominal_coordinate_states'], dtype=float)
    controls = np.asarray(source['controller']['controls'], dtype=float)
    gains = np.asarray(source['controller']['feedback_gains'], dtype=float)
    roots = np.asarray(source['value_factors']['factors'], dtype=float)
    n, period = cfg['env']['n_links'], source['period_steps']
    nx = 2*(n+1)
    if (source['config'] != config_metadata or source['n_links'] != n
            or nodes.shape != (period+1, nx) or controls.shape != (period,)
            or gains.shape != (period, nx) or roots.shape != (period+1, nx, nx)
            or source['value_factors']['period_node_steps'] != list(range(period+1))
            or source['controller'].get('design_decimal_digits', 0) < 40
            or not np.array_equal(source['controller']['coordinate_transform'], np.eye(nx))
            or not np.array_equal(nodes[0], nodes[-1])
            or not np.isclose(source['period_seconds'], period*cfg['env']['timestep']*cfg['env']['frame_skip'], rtol=0, atol=1e-12)
            or any(not np.all(np.isfinite(value)) for value in (nodes, controls, gains, roots))
            or np.any(np.abs(controls) > 1)):
        raise ValueError('value roots, physical-coordinate orbit, precision and config must match')
    return nodes, controls, gains, roots


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', required=True)
    p.add_argument('--config', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--episode-indices', type=int, nargs='+', default=[0, 1])
    p.add_argument('--decimal-digits', type=int, default=100)
    p.add_argument('--grid-points', type=int, default=17)
    p.add_argument('--max-iterations', type=int, default=40)
    args = p.parse_args()
    out = Path(args.out)
    if out.exists():
        raise FileExistsError(out)
    if args.decimal_digits < 40 or args.grid_points < 3 or args.max_iterations < 1:
        raise ValueError('MP cost arithmetic and positive finite search budget required')
    source = json.loads(Path(args.source).read_text())
    cfg = load_config(args.config)
    nodes, controls, gains, roots = periodic_value_inputs(source, cfg, file_metadata(args.config))
    if (len(set(args.episode_indices)) != len(args.episode_indices)
            or any(not 0 <= index < len(source['episode_results']) for index in args.episode_indices)):
        raise ValueError('select unique existing component episode indices')
    seed, base = 20261900, 200000+1000*source['n_links']
    if seed in set(range(base, base+20)) | set(range(base+100, base+220)) | {base+500}:
        raise ValueError('local seed intersects reserved gate seeds')
    begun = time.monotonic()
    forecast_env = NLinkCartPoleEnv(cfg, progress=1., seed=seed)
    forecast_env.reset(seed=seed)
    predictor = MujocoTransition(forecast_env, np.eye(nodes.shape[1]), continuous_angles=True)
    episodes = []
    try:
        for index in args.episode_indices:
            old = source['episode_results'][index]
            fallbacks, improvements, evaluations = 0, 0, 0
            def selector(phase, state, baseline):
                nonlocal fallbacks, improvements, evaluations
                try:
                    action, diag = select_nonlinear_value_action(predictor, state, roots[phase+1], baseline,
                        error_function=lambda predicted: predicted-nodes[phase+1],
                        rail_limit=forecast_env.rail_limit, grid_points=args.grid_points,
                        max_iterations=args.max_iterations,
                        control_cost=source['controller']['feedback_control_cost'],
                        reference_action=float(controls[phase]), decimal_digits=args.decimal_digits,
                        candidate_actions=[controls[phase]])
                    evaluations += diag['predictor_evaluations']
                    improvements += int(diag['improves_baseline'])
                    diag['baseline_action'] = baseline
                    return action, diag
                except SimulationError as error:
                    fallbacks += 1
                    return baseline, dict(fallback=True, error=str(error))
            episode = execute_component(cfg, nodes, controls, gains, np.asarray(old['perturbation']), seed,
                                        action_selector=selector)
            if episode['selected_state'] != old['selected_state']:
                raise ValueError('matched component initial state changed')
            episode.update(source_episode_index=index,
                perturbation_absolute_angle_and_rate_scale=old['perturbation_absolute_angle_and_rate_scale'],
                predictor_evaluations=evaluations, improving_corrections=improvements, fallbacks=fallbacks)
            episodes.append(episode)
            print(json.dumps({k:v for k,v in episode.items() if not isinstance(v,(dict,list))}), flush=True)
    finally:
        forecast_env.close()
    dump_json(dict(not_solution=True, canonical_record=False, hanging_start_evidence=False,
        reserved_seeds_used=False, source=file_metadata(args.source), config=file_metadata(args.config),
        runtime=runtime_metadata(), parameters=vars(args), n_links=source['n_links'],
        episode_results=episodes, predictor_transition_calls=predictor.evaluations,
        wall_time_seconds=time.monotonic()-begun,
        executed_policy=dict(type='native_next_step_factored_periodic_value',
            control_hz=1/(cfg['env']['timestep']*cfg['env']['frame_skip']), action_precision='float32',
            cost_arithmetic_decimal_digits=args.decimal_digits, baseline_is_candidate=True,
            live_state_projection=False, native_forecasts_use_separate_environment=True,
            real_time_feasibility_established=False),
        comparison=dict(reference_controls_identical=True, nominal_nodes_identical=True,
            physical_initial_states_identical=True, perturbations_identical=True,
            scope='Only selected local component cases, not an independent hanging-start cohort')),
        out)


if __name__ == '__main__':
    main()
