"""Compatibility entry point for the explicitly scoped original partial proof."""
from scripts.audit_canonical15_variable_projection_partial import main
if __name__ == "__main__":
    main()
