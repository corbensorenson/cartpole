"""Actual canonical-fifteen residual CEM with a complete native feedback tail."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.native_preview_search import draw_cem_population,update_cem_distribution
from gcartpole.native_task_derivatives import physical_task_residual
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix
from scripts.solve_frontier_capture_increment import validate_development_seeds


def raw_feedback(gain,state):
    x=state.copy();x[1:16]=wrap_angle(x[1:16])
    return -float(gain@x)


def rank(states,horizon,rate_weight):
    if not len(states):return (1,0,1e100)
    angles=np.abs(wrap_angle(np.cumsum(states[:,1:16],axis=1)))
    safe=(np.max(angles,axis=1)<.149)&(np.abs(states[:,0])<=3)
    bad=np.flatnonzero(~safe);prefix=int(bad[0]) if len(bad) else len(states)
    if len(states)<horizon:return (1,-prefix,1e90)
    residual=physical_task_residual(states,15,rate_weight,.05)
    excess=np.maximum(angles-.149,0)/.149;rail=np.maximum(np.abs(states[:,0])-2.85,0)/.15
    return (0,-prefix,float(residual@residual+100*np.sum(excess**2)+100*np.sum(rail**2)))


def evaluate_population(native,state,population,gain,tail_steps,rate_weight):
    count,ff_steps=population.actions.shape;total=ff_steps+tail_steps
    states=np.full((count,total+1,32),np.nan);actions=np.full((count,total),np.nan)
    tail_raws=np.full((count,tail_steps),np.nan);completed=np.zeros(count,int);attempted=np.zeros(count,int)
    scores=[];errors=[]
    for i,sequence in enumerate(population.actions):
        x=state.copy();states[i,0]=x;error=None
        try:
            for j in range(total):
                if j<ff_steps:u=float(sequence[j])
                else:
                    raw=raw_feedback(gain,x);tail_raws[i,j-ff_steps]=raw
                    u=float(np.float32(np.clip(raw,-1,1)))
                actions[i,j]=u;attempted[i]+=1
                x=native(x,u);states[i,j+1]=x;completed[i]+=1
        except SimulationError as e:error=f'SimulationError: {e}'
        scores.append(rank(states[i,1:completed[i]+1],total,rate_weight));errors.append(error)
    return dict(states=states,actions=actions,tail_raws=tail_raws,completed_lengths=completed,
                attempted_lengths=attempted,scores=np.asarray(scores),errors=errors)


def main():
    p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--directory',required=True)
    a=p.parse_args();m=json.loads(Path(a.manifest).read_text());out=Path(a.directory)
    if out.exists():raise FileExistsError(out)
    for meta in m['dependency_bundle']+[m['gain_source'],m['source_audit']]:assert meta==file_metadata(meta['path'])
    assert json.loads(Path(m['source_audit']['path']).read_text())['passed']
    source=json.loads(Path(m['source']['path']).read_text());base=json.loads(Path(source['source']['path']).read_text())
    validate_development_seeds(15,base['seed']);assert base['seed']==20265100
    cfg=load_config(m['config']['path']);assert cfg['env']['n_links']==15 and cfg['env']['timestep']==.005 and cfg['env']['frame_skip']==4
    gain=np.asarray(json.loads(Path(m['gain_source']['path']).read_text())['gain']);assert gain.shape==(32,)
    initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
    X=np.vstack([initial,[q['qpos']+q['qvel'] for q in source['result']['trajectory']]])
    U=np.asarray([q['action'] for q in source['result']['trajectory']],np.float32).astype(float)
    start=m['start_step'];h=m['feedforward_horizon'];tail=m['maintenance_steps'];total=h+tail
    basis=interpolation_matrix(m['knots'],h);localcfg=fixed_state_cfg(cfg,base['selected_state'],30.)
    out.mkdir();(out/'private').mkdir();began=time.monotonic();actual_ticks=0;batch_number=0
    payload=dict(generated_at=utc_timestamp(),status='running',manifest=file_metadata(a.manifest),script=file_metadata(__file__),
        helper=file_metadata('src/gcartpole/native_preview_search.py'),runtime=runtime_metadata(),records=[],private_batches=[],
        total_native_transition_calls=0,actual_hanging_start_episode_steps=0,canonical_release_evidence=False,not_solution=True,
        noisy_development_seeds_used=False,reserved_seeds_used=False,scope=m['scope'])
    env=NLinkCartPoleEnv(localcfg,progress=1.,seed=20265100);env.reset(seed=20265100)
    native=MujocoTransition(env,np.eye(32),continuous_angles=True)
    try:
        for i in range(start):assert native(X[i],float(U[i])).tobytes()==X[i+1].tobytes()
        for arm in m['arms']:
            label=arm['label'];rng=np.random.default_rng(m['search_random_seed']);warm=None
            actual=NLinkCartPoleEnv(localcfg,progress=1.,seed=20265100);actual.reset(seed=20265100)
            xs=[initial.copy()];us=[];decisions=[];streak=longest=0;maxcart=0.;reason=None;info=None;before=native.evaluations
            try:
                for tick in range(actual.max_steps):
                    state=np.r_[actual.data.qpos,actual.data.qvel];decision=None
                    if tick<start:u=float(U[tick])
                    else:
                        if warm is None:warm=U[tick:tick+h].copy() if tick+h<=len(U) else np.zeros(h)
                        anchor=warm.copy();reference=U[tick:tick+h].copy() if tick+h<=len(U) else None
                        mean=np.zeros(m['knots']);std=np.full(m['knots'],arm['initial_std']);best=None
                        for iteration in range(m['cem_iterations']):
                            oldmean,oldstd=mean.copy(),std.copy()
                            pop=draw_cem_population(mean,std,basis,rng,candidate_count=m['candidates'],warm=anchor,reference=reference,base_actions=anchor)
                            evaluated=evaluate_population(native,state,pop,gain,tail,m['rate_weight'])
                            scores=[tuple(x) for x in evaluated['scores']]
                            winner=min(range(len(scores)),key=lambda i:scores[i])
                            mean,std,elites=update_cem_distribution(pop,scores,elite_count=m['elite_count'],minimum_std=m['minimum_std'])
                            batch_number+=1;path=out/'private'/f'batch_{batch_number:05d}.npz'
                            np.savez_compressed(path,base_feedforward=anchor,feedforward_commands=pop.actions,knots=pop.knots,
                                update_eligible=pop.update_eligible,kinds=np.asarray(pop.kinds),mean_before=oldmean,std_before=oldstd,
                                mean_after=mean,std_after=std,elite_indices=elites,winner_index=winner,
                                **{k:v for k,v in evaluated.items() if k!='errors'})
                            meta=dict(label=label,tick=tick,iteration=iteration,tape=file_metadata(path),errors=evaluated['errors'],
                                feedforward_horizon=h,maintenance_steps=tail,candidates=len(pop.actions),
                                unique_feedforward_sequences=len({seq.tobytes() for seq in pop.actions}),
                                source_window_identical_candidates=(sum(seq.tobytes()==reference.tobytes() for seq in pop.actions) if reference is not None else None))
                            payload['private_batches'].append(meta)
                            if best is None or scores[winner]<best['score']:
                                best=dict(score=scores[winner],sequence=pop.actions[winner].copy(),forecast=evaluated['states'][winner,1:].copy(),
                                    completed=int(evaluated['completed_lengths'][winner]),error=evaluated['errors'][winner],
                                    actions=evaluated['actions'][winner].copy(),batch=meta['tape'],index=winner)
                        if best['completed']==0:raise RuntimeError('No selected native first-step prediction; stop before unsafe action')
                        u=float(best['sequence'][0]);warm=np.r_[best['sequence'][1:],best['sequence'][-1]]
                        decision=dict(tick=tick,selected_sequence=best['sequence'].tolist(),selected_forecast=best['forecast'].tolist(),
                            selected_delivered_forecast_actions=best['actions'].tolist(),selected_completed_steps=best['completed'],
                            selected_error=best['error'],score=list(best['score']),private_batch=best['batch'],candidate_index=best['index'])
                        decisions.append(decision)
                    _,_,terminated,truncated,info=actual.step([u]);actual_ticks+=1
                    x=np.r_[actual.data.qpos,actual.data.qvel];xs.append(x.copy());us.append(u)
                    if tick<start:assert x.tobytes()==X[tick+1].tobytes()
                    else:assert x.tobytes()==np.asarray(decision['selected_forecast'][0]).tobytes()
                    phi=float(np.max(abs(wrap_angle(np.cumsum(x[1:16])))))
                    streak=streak+1 if phi<.15 else 0;longest=max(longest,streak);maxcart=max(maxcart,abs(float(x[0])))
                    if tick>=start and tick%25==0:
                        print(json.dumps(dict(arm=label,tick=tick,hold=longest*.02,angle=phi,calls=native.evaluations+actual_ticks)),flush=True)
                    if terminated or truncated:reason=info['termination_reason'];break
            finally:
                actual.close();tape=out/(label+'.npz');np.savez_compressed(tape,states=np.asarray(xs),actions=np.asarray(us))
                dump_json(dict(label=label,tape=file_metadata(tape),decisions=decisions),out/(label+'_decisions.json'))
            for i,u in enumerate(us):assert native(xs[i],float(u)).tobytes()==xs[i+1].tobytes()
            passed=len(us)==1500 and longest*.02>=5 and reason=='time_limit' and maxcart<=3 and not info['simulation_error']
            row=dict(label=label,initial_std=arm['initial_std'],actual_hanging_start_episode_steps=len(us),hold_seconds=longest*.02,
                maximum_cart=maxcart,termination_reason=reason,full_nominal_gate_passed=passed,tape=file_metadata(tape),
                decisions=file_metadata(out/(label+'_decisions.json')),native_forecast_and_proof_attempts=native.evaluations-before,
                actual_prefix_byte_exact=True,selected_first_prediction_byte_exact=True,independent_whole_tape_byte_exact=True)
            payload['records'].append(row);payload.update(total_native_transition_calls=native.evaluations+actual_ticks,actual_hanging_start_episode_steps=actual_ticks)
            dump_json(payload,out/'result.progress.json');print(row,flush=True)
        payload.update(status='finished',total_native_transition_calls=native.evaluations+actual_ticks,
                       actual_hanging_start_episode_steps=actual_ticks,wall_seconds=time.monotonic()-began)
        dump_json(payload,out/'result.json')
    except BaseException as e:
        payload.update(status='failed',error=f'{type(e).__name__}: {e}',total_native_transition_calls=native.evaluations+actual_ticks,
                       actual_hanging_start_episode_steps=actual_ticks)
        dump_json(payload,out/'result.failed.json');raise
    finally:env.close()

if __name__=='__main__':main()
