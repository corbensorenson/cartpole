"""Measure delivered-F32 probe locality over a saved whole arrival segment.

Private native forecasts only. Does not solve or evaluate a new hanging episode.
"""
import argparse
import json
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.ilqr import MujocoTransition
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--comparison',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();out=Path(args.directory)
    if out.exists():raise FileExistsError(out)
    out.mkdir(parents=True)
    comparison=json.loads(Path(args.comparison).read_text())
    assert comparison['source']==file_metadata(comparison['source']['path'])
    saved=json.loads(Path(comparison['source']['path']).read_text())
    assert saved['source']==file_metadata(saved['source']['path'])
    base=json.loads(Path(saved['source']['path']).read_text())
    cfg=load_config(saved['config']['path']);n=cfg['env']['n_links'];nx=2*(n+1)
    start=comparison['parameters']['start_step'];arrival=comparison['parameters']['arrival_step']
    knots=comparison['parameters']['knots'];basis=interpolation_matrix(knots,arrival-start)
    initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
    actions=np.asarray([r['action'] for r in saved['result']['trajectory'][:arrival]],np.float32).astype(float)
    expected=np.asarray([r['qpos']+r['qvel'] for r in saved['result']['trajectory'][:arrival]])
    local=fixed_state_cfg(cfg,base['selected_state'],30.)
    env=NLinkCartPoleEnv(local,progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True)
    amplitudes=(1e-5,1e-7,1e-9,1e-11,1e-13);records=[]
    payload=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),comparison=file_metadata(args.comparison),
        source=comparison['source'],amplitudes=list(amplitudes),records=records,
        scope='Fixed48 interpolation knots, five probe scales and both signs on unchanged actual148-input arrival. Cold439 source proof; each probe reuses only a byte-checked unchanged prefix. Arrival bounds measure locality, not nonlinear controllability or a limit on coordinated multi-input changes.',
        native_transition_ceiling=arrival+2*len(amplitudes)*knots*(arrival-start),
        total_native_transition_calls=0,actual_episode_steps=0,actual_hanging_start_episode_steps=0,
        reserved_seeds_used=False,noisy_development_seeds_used=False,canonical_release_evidence=False,not_solution=True)
    try:
        current=initial.copy();known=[]
        for action in actions:current=native(current,float(action));known.append(current.copy())
        known=np.asarray(known);assert known.tobytes()==expected.tobytes()
        center=actions[start:].copy();source_states=known[start:]
        payload['source_cold439_states_and_actions_exact']=True
        for amplitude in amplitudes:
            for column in range(knots):
                for sign in (1,-1):
                    trial=np.asarray(np.clip(center+sign*amplitude*basis[:,column],-1,1),np.float32).astype(float)
                    changed=np.flatnonzero(trial!=center)
                    row=dict(amplitude=amplitude,column=column,sign=sign,changed_input_count=len(changed))
                    if not len(changed):row.update(no_op_after_f32=True,native_transition_calls=0)
                    else:
                        first=int(changed[0]);before=native.evaluations
                        current=initial.copy() if start+first==0 else known[start+first-1].copy()
                        predictions=[]
                        for action in trial[first:]:current=native(current,float(action));predictions.append(current.copy())
                        states=np.vstack([source_states[:first],predictions])
                        angles=np.abs(wrap_angle(np.cumsum(states[:,1:n+1],axis=1)))
                        row.update(no_op_after_f32=False,first_changed_absolute_step=start+first,
                            last_changed_absolute_step=start+int(changed[-1]),
                            maximum_delivered_action_change=float(np.max(np.abs(trial-center))),
                            maximum_arrival_angle=float(np.max(angles)),maximum_arrival_cart=float(np.max(np.abs(states[:,0]))),
                            arrival_bounds_passed=bool(np.all(angles<.149) and np.all(np.abs(states[:,0])<=3)),
                            endpoint_state_difference_norm=float(np.linalg.norm(states[-1]-source_states[-1])),
                            native_transition_calls=native.evaluations-before)
                    records.append(row)
            payload['total_native_transition_calls']=native.evaluations
            dump_json(payload,out/'result.progress.json')
            group=[r for r in records if r['amplitude']==amplitude]
            print(json.dumps(dict(amplitude=amplitude,no_ops=sum(r['no_op_after_f32'] for r in group),
                local_nonzero=sum(r.get('arrival_bounds_passed',False) for r in group),calls=native.evaluations)),flush=True)
        assert len(records)==480 and native.evaluations==arrival+sum(r['native_transition_calls'] for r in records)
        assert native.evaluations<=payload['native_transition_ceiling']
        assert np.r_[env.data.qpos,env.data.qvel].tobytes()==untouched.tobytes()
        payload.update(live_state_unchanged=True,total_native_transition_calls=native.evaluations)
        dump_json(payload,out/'result.json')
    finally:env.close()


if __name__=='__main__':main()
