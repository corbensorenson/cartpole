"""Independent R37 candidate physics, delivered controllers, objective and search history."""
import argparse,json
from pathlib import Path
import numpy as np,mujoco
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition,QuadraticTrajectoryCost
from gcartpole.modal_arrival import empirical_modal_factor,regularized_qr_step
from gcartpole.sqrt_ilqr import square_root_tracking_gains
from scripts.refine_native_feedback_arrival import represented_state,raw_feedback
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix,scale_step_to_trust_region
from scripts.search_capture_sequence import fixed_state_cfg
read=lambda p:json.loads(Path(p).read_text())
def same(a,b):assert np.asarray(a).tobytes()==np.asarray(b).tobytes()
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(a.root);out=Path(a.out);out.mkdir(exist_ok=False);m=read(root/'manifest.json');r=read(root/'execution/diagnostic/result.json');acc=read(root/'execution/inclusive_accounting.json');source=read(m['source']['path']);base=read(source['source']['path']);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);U=np.asarray([q['action'] for q in source['result']['trajectory']],np.float32).astype(float);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in source['result']['trajectory']]]);start,end=m['start_step'],m['arrival_step'];h=end-start;tail=m['maintenance_steps'];gain=np.asarray(r['gain']);target=np.asarray(r['target']);cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.)
 assert r['tracking']==file_metadata(r['tracking']['path'])
 with np.load(r['tracking']['path']) as z:K=z['gain100'];K80=z['gain80'];A=z['A'];B=z['B'];sf=z['stage_factor'];tf=z['terminal_factor'];same(z['states'],X[start:end+1]);same(z['controls'],U[start:end])
 with np.load(m['tracking_array']['path']) as z:same(A,z['A'][:h]);same(B,z['B'][:h]);same(sf,z['stage_factor']);same(tf,z['terminal_factor'])
 same(K,K80);aligned=read(m['aligned']['path']);dd=next(q for q in aligned['designs'] if q['gain_label']=='moderately_separated_decay');ctx,modal,w,metric=empirical_modal_factor([q['rounded_direction'] for q in dd['directions']],n_links=15,time_scale=dd['normalization']['time_scale_seconds']);assert metric==r['metric'];same(gain,aligned['gains']['moderately_separated_decay']);targetmp=ctx.matrix(target.tolist());basis=interpolation_matrix(m['knots'],h);count=[0];old=mujoco.mj_step;env=None;attempts=0;cache={};residuals={};outcomes=[];history_checks=0
 payload=dict(status='running',generated_at=utc_timestamp(),script=file_metadata(__file__),source_result=file_metadata(root/'execution/diagnostic/result.json'),source_accounting=file_metadata(root/'execution/inclusive_accounting.json'),native_transition_ceiling=100000,actual_hanging_start_episode_steps=0,canonical_release_evidence=False,not_solution=True)
 def counted(model,data,*args,**kwargs):
  n=int(kwargs.get('nstep',args[0] if args else 1));assert count[0]+n<=400000;count[0]+=n;return old(model,data,*args,**kwargs)
 def objective(states,raws,label):
  factor=modal if label=='modal_factored' else w;values=list(factor*(ctx.matrix(represented_state(states[h],15).tolist())-targetmp));values.append(ctx.mpf(float(m['endpoint_raw_weight']))*ctx.asinh(ctx.mpf(float(raw_feedback(gain,states[h],15)))))
  for off in m['tail_sample_offsets']:
   values.extend(ctx.mpf(float(m['tail_physical_weight']))*v for v in w*ctx.matrix(represented_state(states[h+1+off],15).tolist()));values.append(ctx.mpf(float(m['endpoint_raw_weight']))*ctx.asinh(ctx.mpf(float(raws[h+off]))))
  res=ctx.matrix(values);arr=states[1:h+1];ang=np.abs(wrap_angle(np.cumsum(arr[:,1:16],axis=1)));viol=float(np.sum((np.maximum(ang-.149,0)/.149)**2)+np.sum((np.maximum(abs(arr[:,0])-3,0)/3)**2));safe=bool(np.all(ang<.149) and np.all(abs(arr[:,0])<=3));ts=states[h+1:];aa=np.abs(wrap_angle(np.cumsum(ts[:,1:16],axis=1)));ok=(np.max(aa,axis=1)<.149)&(abs(ts[:,0])<=3);bad=np.flatnonzero(~ok);prefix=int(bad[0]) if len(bad) else len(ts)
  return res,(0 if safe else 1,viol,-prefix,float(ctx.norm(res)**2))
 mujoco.mj_step=counted
 try:
  env=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);env.reset(seed=20265100);native=MujocoTransition(env,np.eye(32),continuous_angles=True)
  cost=QuadraticTrajectoryCost(stage_state=sf.T@sf,stage_factor=sf,terminal_state=tf.T@tf,terminal_factor=tf,control=base['controller']['control_cost'],rail_soft_limit=base['controller']['rail_soft_limit'],rail_limit=3.,rail_weight=base['controller']['rail_weight'],wrap_angles=False)
  fresh=square_root_tracking_gains(native,X[start:end+1],U[start:end],cost,regularization=m['tracking_regularization'],decimal_digits=80,mp_linearization=lambda i,x,u,ctx:(ctx.matrix(A[i].tolist()),ctx.matrix(B[i].tolist())));same(fresh,K)
  for i in range(end):attempts+=1;same(native(X[i],float(U[i])),X[i+1])
  lookup={q['index']:q for q in r['private_forecasts']}
  for q in r['private_forecasts']:
   assert q['tape']==file_metadata(q['tape']['path']);assert q['error'] is None and q['completed_steps']==h+tail and q['attempted_steps']==h+tail
   with np.load(q['tape']['path']) as archive:z={key:archive[key] for key in archive.files}
   cache[q['index']]=z;states=z['states'];actions=z['actions'];raws=z['raws'];ff=z['feedforward'];same(states[0],X[start]);same(actions,actions.astype(np.float32).astype(float));assert states.shape==(h+tail+1,32) and len(actions)==h+tail
   for i,u in enumerate(actions):
    raw=float(ff[i])+float(K[i]@(states[i]-X[start+i])) if i<h else raw_feedback(gain,states[i],15);assert raw==raws[i] and float(np.float32(np.clip(raw,-1,1)))==u;attempts+=1;same(native(states[i],float(u)),states[i+1])
   res,ss=objective(states,raws,q['label']);assert [str(v) for v in res]==q['residual'] and tuple(q['score'])==ss;residuals[q['index']]=res
   if q['index']%50==0:print(json.dumps(dict(private_tapes=q['index'],attempts=attempts)),flush=True)
  for row in r['records']:
   if row['label']!='baseline':
    current=next(q for q in r['private_forecasts'] if q['label']==row['label'] and q['kind']=='initial')['index']
    for hist in row['rounds']:
     assert not hist.get('derivative_failed');assert hist['center_index']==current;center=cache[current];res=residuals[current];jac=ctx.zeros(res.rows,m['knots']);probes=hist['probes'];assert len(probes)==2*m['knots']
     for col in range(m['knots']):
      for sign,index in zip((1,-1),probes[2*col:2*col+2]):same(cache[index]['feedforward'],np.clip(center['feedforward']+sign*m['epsilon']*basis[:,col],-1,1))
      for rr in range(res.rows):jac[rr,col]=(residuals[probes[2*col]][rr]-residuals[probes[2*col+1]][rr])/(2*ctx.mpf(float(m['epsilon'])))
     assert [[str(jac[i,j]) for j in range(jac.cols)] for i in range(jac.rows)]==hist['jacobian'];assert [str(v) for v in res]==hist['residual'];step,qrerror=regularized_qr_step(ctx,jac,res,m['regularization']);step=scale_step_to_trust_region(step,m['trust']);same(step,hist['step']);assert qrerror==hist['qr_error'];best=None;proposals={q['power']:q for q in hist['proposals']};noop=[]
     for power in range(m['contraction_powers']):
      ff=np.clip(center['feedforward']+basis@(step/(2**power)),-1,1)
      if ff.tobytes()==center['feedforward'].tobytes():noop.append(power);continue
      q=proposals[power];same(ff,cache[q['index']]['feedforward']);assert q['score']==lookup[q['index']]['score']
      if tuple(q['score'])<tuple(lookup[current]['score']) and (best is None or tuple(q['score'])<tuple(lookup[best]['score'])):best=q['index']
     assert noop==hist['nominal_no_op_powers'] and hist['selected_index']==best and hist['improved']==(best is not None)
     if best is not None:current=best
     history_checks+=1
    same(row['selected_feedforward'],cache[current]['feedforward']);assert row['selected_score']==lookup[current]['score']
   selected=next(q for q in r['private_forecasts'] if q['tape']==row['selected_forecast']);same(row['selected_feedforward'],cache[selected['index']]['feedforward']);assert row['tape']==file_metadata(row['tape']['path'])
   with np.load(row['tape']['path']) as z:xs=z['states'];us=z['actions']
   same(xs[:start+1],X[:start+1]);same(xs[start:end+1],cache[selected['index']]['states'][:h+1]);ff=np.asarray(row['selected_feedforward']);streak=longest=0
   for tick,u in enumerate(us):
    raw=float(U[tick]) if tick<start else float(ff[tick-start])+float(K[tick-start]@(xs[tick]-X[tick])) if tick<end else raw_feedback(gain,xs[tick],15);assert float(np.float32(np.clip(raw,-1,1)))==u;attempts+=1;same(native(xs[tick],float(u)),xs[tick+1]);angle=float(np.max(abs(wrap_angle(np.cumsum(xs[tick+1,1:16])))));streak=streak+1 if angle<.15 else 0;longest=max(longest,streak)
   assert len(us)==row['actual_hanging_start_episode_steps'] and longest*.02==row['hold_seconds'] and np.max(abs(xs[1:,0]))==row['maximum_cart'];assert abs(xs[-1,0])>3 and row['termination_reason']=='rail_violation' and not row['full_nominal_gate_passed'];outcomes.append(dict(label=row['label'],ticks=len(us),hold_seconds=longest*.02,maximum_cart=row['maximum_cart'],full_nominal_gate_passed=False,selected_score=selected['score'],selected_tape=selected['tape'],actual_tape=row['tape'],arrival_maximum_angle=float(np.max(abs(wrap_angle(np.cumsum(xs[end,1:16]))))),arrival_absolute_rate_rms=float(np.sqrt(np.mean(np.cumsum(xs[end,17:])**2))),arrival_raw_gain_demand=raw_feedback(gain,xs[end],15)))
  assert attempts+r['actual_hanging_start_episode_steps']==r['total_native_transition_calls'];assert count[0]+4*r['actual_hanging_start_episode_steps']==acc['native_physics_substeps']
  payload.update(status='finished',passed=True,outcomes=outcomes,independent_native_private_tapes=len(r['private_forecasts']),independent_derivative_qr_rounds=history_checks,tracking_mp80_export_byte_equal=True,scope='All375 private84arrival+50maintenance tapes and raw/F32controllercommands nativebyteproved; unnormalizedphysical/modal/asinh objectives and fulltailprefix reconstructed; allfive derivative/MP100QR/contraction histories independently reconstructed fromsavedprobes; nativecached84A/Btracking re-exported atMP80 exactly. Allthree actual hangingtapes/controllerstreams/gates proved negative. Common numericalcore helpers reused; no independent physical-model oralgorithm implementation certificate, no robustness/unreachability claim.')
 except BaseException as error:payload.update(status='failed',error=f'{type(error).__name__}: {error}');raise
 finally:
  if env is not None:env.close()
  mujoco.mj_step=old;payload.update(finished_at=utc_timestamp(),native_physics_substeps=count[0],total_native_transition_calls=count[0]/4,attempted_transition_calls=attempts);dump_json(payload,out/'result.json');print({key:value for key,value in payload.items() if key!='outcomes'},flush=True)
if __name__=='__main__':main()
