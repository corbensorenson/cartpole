#!/usr/bin/env python
"""Iterate native-accepted F32 lattice repairs of a failed horizon extension."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata,utc_timestamp
from gcartpole.ilqr import MujocoTransition
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.native_task_derivatives import physical_task_residual,chained_physical_task_jacobian
from gcartpole.native_action_lattice import polish_native_action_lattice
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ('source','directory'):parser.add_argument('--'+key,required=True)
    parser.add_argument('--horizon',type=int,default=64)
    parser.add_argument('--rounds',type=int,default=8)
    parser.add_argument('--radii',type=int,nargs='+',default=[8,64,512,4096])
    parser.add_argument('--solver-seconds',type=float,default=2.)
    parser.add_argument('--tail',choices=['reference','teacher','zero'],default='reference')
    args=parser.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    if args.rounds<1 or not np.isfinite(args.solver_seconds) or args.solver_seconds<=0:
        raise ValueError('positive bounded restoration budgets required')
    source=json.loads(Path(args.source).read_text())
    for key in ('source','config','teacher'):
        if file_metadata(source[key]['path'])!=source[key]:raise ValueError('Bound source inputs changed')
    base=json.loads(Path(source['source']['path']).read_text());teacher=json.loads(Path(source['teacher']['path']).read_text())
    cfg=load_config(source['config']['path']);n=cfg['env']['n_links'];nx=2*(n+1);step=source['parameters']['start_step']
    rate=source['parameters']['rate_residual_weight'];known=np.asarray(source['last_valid_plan'],np.float32).astype(float)
    if args.horizon<=len(known):raise ValueError('Restoration must extend the last verified horizon')
    ref=np.asarray(base['controller']['controls'][step:step+args.horizon],np.float32).astype(float)
    delivered=np.asarray([r['action'] for r in teacher['result']['trajectory'][step:step+args.horizon]],np.float32).astype(float)
    if min(len(ref),len(delivered))!=args.horizon:raise ValueError('Unpadded aligned reference/teacher required')
    appended=ref[len(known):] if args.tail=='reference' else delivered[len(known):] if args.tail=='teacher' else np.zeros(args.horizon-len(known))
    center=np.r_[known,appended]
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True);local=FourthOrderMujocoTransition(env,np.eye(nx),continuous_angles=True)
    untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()];began=time.monotonic();rounds=[]
    def forecast(state,actions):
        current=state.copy();states=[]
        for action in actions:current=native(current,float(action));states.append(current.copy())
        return np.asarray(states)
    def admissible(states):
        return bool(np.all(np.abs(states[:,0])<=env.rail_limit) and
            np.max(np.abs(wrap_angle(np.cumsum(states[:,1:n+1],axis=1))))<.14)
    residual=lambda states:physical_task_residual(states,n,rate,.1)
    def measured(states,actions):
        r=residual(states)
        return float(r@r+.01**2*np.sum((actions-ref)**2))
    jac=lambda state,actions,states:chained_physical_task_jacobian(local,state,actions,states,
        n_links=n,rate_weight=rate,state_epsilon=base['controller']['state_epsilon'],
        action_epsilon=base['controller']['action_epsilon'],angle_band=.1)
    payload=dict(not_solution=True,canonical_release_evidence=False,generated_at=utc_timestamp(),parameters=vars(args),
        source=file_metadata(args.source),config=source['config'],source_controller=source['source'],runtime=runtime_metadata(),
        rounds=rounds,actual_episode_steps=0,optimizer_transition_calls=0,reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Native F32 affine-grid MILP proposals from a finite initially inadmissible longer plan. A non-admissible center may move only to strictly lower measured native squared task+action cost;any accepted admissible plan independently replays. MILP status or lower cost alone never supplies a feasible plan,actual episode or record.')
    try:
        state=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
        for row in base['result']['trajectory'][:step]:
            state=native(state,float(np.float32(row['action'])))
            if state.tobytes()!=np.asarray(row['qpos']+row['qvel']).tobytes():raise ValueError('Cold source prefix changed')
        known_states=forecast(state,known)
        if known_states.tobytes()!=np.asarray(source['last_valid_forecast_states']).tobytes() or not admissible(known_states):
            raise ValueError('Known plan lost native feasibility')
        states=forecast(state,center);cost=measured(states,center);found=admissible(states)
        payload.update(initial_center=center.tolist(),initial_native_cost=cost,
            native_prefix_replay_transition_calls=step,native_known_plan_replay_transition_calls=len(known),
            native_initial_longer_plan_forecast_transition_calls=len(center))
        for index in range(args.rounds):
            if found:break
            before=native.evaluations;derivative_before=local.evaluations;started=time.monotonic()
            selected,diagnostic=polish_native_action_lattice(native,state,center,reference_actions=ref,
                constraint_residual=residual,constraint_jacobian=jac,admissible=admissible,
                radii=args.radii,solver_seconds=args.solver_seconds,action_regularization=.01)
            if native.evaluations-before!=diagnostic['native_transition_calls']:raise ValueError('Lattice planning budget mismatch')
            checks=0;improved=False
            if selected is not None:
                checked=forecast(state,selected);checks=len(selected)
                if checked.tobytes()!=np.asarray(diagnostic['selected_states']).tobytes() or not admissible(checked):
                    raise ValueError('Selected lattice plan failed native replay')
                center=selected.copy();states=checked;cost=measured(states,center);found=True
            else:
                candidates=[trial for search in diagnostic['searches'] for trial in search['trials']
                    if 'total_cost' in trial and trial['total_cost']<cost]
                if candidates:
                    best=min(candidates,key=lambda trial:trial['total_cost']);candidate=np.asarray(best['sequence'])
                    checked=forecast(state,candidate);checks=len(candidate);new_cost=measured(checked,candidate)
                    if new_cost!=best['total_cost']:raise ValueError('Measured candidate cost did not reproduce')
                    if new_cost<cost:center=candidate.copy();states=checked;cost=new_cost;improved=True
            diagnostic.pop('selected_states')
            rounds.append(dict(round=index,feasible_plan_found=found,lower_native_cost_inadmissible_center=improved,
                measured_native_cost=cost,maximum_predicted_absolute_angle=float(np.max(np.abs(wrap_angle(np.cumsum(states[:,1:n+1],axis=1))))),
                native_planning_transition_calls=diagnostic['native_transition_calls'],
                native_local_derivative_transition_calls=local.evaluations-derivative_before,
                independent_candidate_replay_transition_calls=checks,wall_seconds=time.monotonic()-started,diagnostic=diagnostic))
            payload.update(feasible_sequence_found=found,selected_sequence=center.tolist() if found else None,
                selected_states=states.tolist() if found else None,last_finite_center=center.tolist(),last_finite_cost=cost,
                native_forecast_transition_calls=native.evaluations,native_local_derivative_transition_calls=local.evaluations,
                total_native_transition_calls=native.evaluations+local.evaluations,wall_seconds=time.monotonic()-began)
            dump_json(payload,out/'result.progress.json')
            print(json.dumps(dict(round=index,found=found,improved=improved,cost=cost,
                planning_calls=diagnostic['native_transition_calls'],derivative_calls=local.evaluations-derivative_before)),flush=True)
            if not found and not improved:break
        if not np.array_equal(untouched,np.r_[env.data.qpos,env.data.qvel]):raise ValueError('Restoration changed live state')
        # The initial center can already be feasible; keep its accounting too.
        payload.update(feasible_sequence_found=found,selected_sequence=center.tolist() if found else None,
            selected_states=states.tolist() if found else None,last_finite_center=center.tolist(),last_finite_cost=cost,
            native_forecast_transition_calls=native.evaluations,native_local_derivative_transition_calls=local.evaluations,
            total_native_transition_calls=native.evaluations+local.evaluations,wall_seconds=time.monotonic()-began,
            live_simulator_state_unchanged=True,status='finished_bounded_native_lattice_restoration')
        dump_json(payload,out/'result.json')
    finally:env.close()


if __name__=='__main__':main()
