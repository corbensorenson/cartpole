#!/usr/bin/env python
"""Compare resynthesized local periodic capture at a declared control cadence.

Only frame_skip changes; native physics XML is checked equal to the baseline.
This produces components, never canonical hanging-start record evidence.
"""
import argparse
import copy
import json
from pathlib import Path
import subprocess
import sys

import numpy as np
import yaml

from gcartpole.config import dump_json, load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, text_sha256, utc_timestamp
from gcartpole.roadmap import validate_canonical_config


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config', required=True)
    p.add_argument('--frame-skip', type=int, required=True, choices=(1, 2))
    p.add_argument('--directory', required=True)
    args = p.parse_args()
    base = load_config(args.config)
    checked = copy.deepcopy(base); checked['env']['n_links'] = 7
    if validate_canonical_config(checked):
        raise ValueError('requires canonical baseline before a separate cadence ablation')
    cfg = copy.deepcopy(base); cfg['env']['frame_skip'] = args.frame_skip
    dt = cfg['env']['timestep']*args.frame_skip
    period = round(.4/dt)
    if period % 2 or not np.isclose(period*dt, .4, rtol=0, atol=1e-12):
        raise ValueError('the fixed2.5 Hz reference must align with the declared control cadence')
    out = Path(args.directory); out.mkdir(parents=True, exist_ok=True)
    journal = out/'cadence_component.json'
    config = out/'variant_config.yaml'
    if journal.exists() or config.exists():
        raise FileExistsError(out)
    config.write_text(yaml.safe_dump(cfg, sort_keys=False))
    old_env = NLinkCartPoleEnv(base, progress=1., seed=0)
    new_env = NLinkCartPoleEnv(cfg, progress=1., seed=0)
    try:
        if old_env.xml != new_env.xml:
            raise ValueError('cadence ablation changed native physics XML')
        xml_hash = text_sha256(old_env.xml)
    finally:
        old_env.close(); new_env.close()
    record = dict(status='running', started_at=utc_timestamp(), not_solution=True,
        canonical_record=False, hanging_start_evidence=False, reserved_seeds_used=False,
        release_promotion=False, base_config=file_metadata(args.config),
        variant_config=file_metadata(config), control_hz=1/dt, frame_skip=args.frame_skip,
        physics_timestep=cfg['env']['timestep'], physics_xml_sha256=xml_hash,
        baseline_and_variant_physics_xml_identical=True, reference_frequency_hz=2.5,
        requested_angle_amplitude=.12, initializer_force_amplitude_limit=.5,
        feedback_cost=1000, fourth_order_state_epsilon=.0002, fourth_order_action_epsilon=.0005,
        scope='Rate plus routine orbit/feedback resynthesis; bounds, physics timestep, reference frequency and local perturbation directions remain fixed. Not an identical-trajectory counterfactual.',
        stages=[])
    dump_json(record, journal)
    def stage(label, script, arguments, inputs):
        directory = out/label
        command = [sys.executable, 'scripts/run_frontier_experiment.py', '--directory', str(directory),
                   '--input', str(config), '--input', str(journal)]
        for path in inputs:
            command.extend(['--input', str(path)])
        result = directory/'result.json'
        subprocess.run([*command, '--', sys.executable, 'scripts/'+script,
                        '--config', str(config), '--out', str(result), *arguments], check=True)
        record['stages'].append(dict(label=label, result=file_metadata(result),
                                    execution=file_metadata(directory/'execution.json')))
        dump_json(record, journal)
        return result
    try:
        orbit = stage('orbit_second_order', 'audit_periodic_capture.py',
            ['--period-steps', str(period), '--angle-amplitude', '.12', '--control-cost', '1000',
             '--max-force-amplitude', '.5'], [])
        final = stage('fourth_order_feedback', 'replay_periodic_capture_feedback.py',
            ['--source', str(orbit)], [orbit])
        result = json.loads(final.read_text())
        dump_json(dict(result, cadence_ablation=dict(record)), out/'result.json')
        record.update(status='finished_component_only', result=file_metadata(out/'result.json'))
    except BaseException as error:
        record.update(status='failed_or_interrupted', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        record['finished_at'] = utc_timestamp(); dump_json(record, journal)
    print(json.dumps(dict(status=record['status'], journal=str(journal))))


if __name__ == '__main__':
    main()
