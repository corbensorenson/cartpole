#!/usr/bin/env python
"""MP local forced-error audit on a saved actual native capture interval.

Components are an algebraic decomposition using the recorded error/action.
They are not independent nonlinear counterfactuals or robustness certificates.
"""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.planar_mechanics import PlanarMechanics
from gcartpole.evidence import file_metadata,runtime_metadata
from scripts.solve_frontier_capture_increment import validate_development_seeds


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True);p.add_argument('--config',required=True)
    p.add_argument('--directory',required=True);p.add_argument('--start-step',type=int,required=True)
    p.add_argument('--end-step',type=int,required=True);p.add_argument('--decimal-digits',type=int,default=100)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    source=json.loads(Path(args.source).read_text());cfg=load_config(args.config);controller=source['controller']
    validate_development_seeds(cfg['env']['n_links'],source['seed'])
    nodes=np.asarray(source['search']['nominal_coordinate_states']);controls=np.asarray(controller['controls']);gains=np.asarray(controller['feedback_gains']);rows=source['result']['trajectory'];nx=nodes.shape[1]
    if (not controller['continuous_angles'] or controller['phase_adaptive']
            or not np.array_equal(controller['coordinate_transform'],np.eye(nx))
            or not 0<=args.start_step<args.end_step<=min(len(controls),len(rows)) or args.decimal_digits<40):
        raise ValueError('aligned executed continuous physical interval and MP precision required')
    initial=np.r_[source['selected_state']['qpos'],source['selected_state']['qvel']]
    actual=np.vstack([initial,[r['qpos']+r['qvel'] for r in rows]])
    env=NLinkCartPoleEnv(cfg,progress=1.,seed=source['seed']);env.reset(seed=source['seed'])
    model=PlanarMechanics(env,decimal_digits=args.decimal_digits);ctx=model.ctx
    predictor=MujocoTransition(env,np.eye(nx),continuous_angles=True)
    factor=ctx.matrix(source['lyapunov']['factor']);norm=lambda v:float(max(abs(x) for x in v))
    value_norm=lambda v:float(ctx.sqrt(((factor*v).T*(factor*v))[0]))
    gap_component=ctx.zeros(nx,1);action_component=ctx.zeros(nx,1);remainder_component=ctx.zeros(nx,1)
    initial_component=ctx.matrix(actual[args.start_step].tolist())-ctx.matrix(nodes[args.start_step].tolist())
    records=[];begun=time.monotonic()
    try:
        for step in range(args.start_step,args.end_step):
            nominal=ctx.matrix(nodes[step].tolist());observed=ctx.matrix(actual[step].tolist())
            error=observed-nominal;next_error=ctx.matrix(actual[step+1].tolist())-ctx.matrix(nodes[step+1].tolist())
            u=float(np.float32(controls[step]));delivered=float(np.float32(rows[step]['action']))
            independent,a,b=model.transition(nodes[step],u,derivatives=True)
            nominal_next=predictor(nodes[step],u);actual_next=predictor(actual[step],delivered)
            if not np.array_equal(actual_next,actual[step+1]):raise ValueError('actual native next state does not reproduce exactly')
            gap=ctx.matrix(nominal_next.tolist())-ctx.matrix(nodes[step+1].tolist())
            k=ctx.matrix(gains[step].tolist()).T;closed=a+b*k
            raw=float(controls[step]+gains[step]@(actual[step]-nodes[step]))
            if float(np.float32(np.clip(raw,-1,1)))!=delivered:raise ValueError('saved feedback does not reproduce delivered action')
            delta=ctx.mpf(delivered)-ctx.mpf(float(controls[step]));action_error=delta-(k*error)[0]
            remainder=next_error-gap-a*error-b*delta
            gap_component=closed*gap_component+gap;action_component=closed*action_component+b*action_error
            remainder_component=closed*remainder_component+remainder;initial_component=closed*initial_component
            component_sum=initial_component+gap_component+action_component+remainder_component
            discrepancy=ctx.matrix(nominal_next.tolist())-independent
            record=dict(step=step,time_seconds=step*env.dt,actual_error=norm(next_error),
                actual_maintenance_value_norm=value_norm(next_error),native_gap=norm(gap),native_gap_value_norm=value_norm(gap),
                remainder=norm(remainder),remainder_value_norm=value_norm(remainder),
                model_minus_native_next_state=norm(discrepancy),model_discrepancy_value_norm=value_norm(discrepancy),
                initial_component=norm(initial_component),gap_component=norm(gap_component),
                action_component=norm(action_component),remainder_component=norm(remainder_component),
                component_sum_error=norm(component_sum-next_error),action_rounding_and_clipping_error=float(action_error),
                delivered_action=delivered,raw_action=raw,native_actual_step_identical=True,
                next_gain_gap_projection=None if step+1>=len(gains) else float((ctx.matrix(gains[step+1].tolist()).T*gap)[0]),
                A=[[str(x) for x in row] for row in a.tolist()],B=[[str(x) for x in row] for row in b.tolist()],
                gap=[str(x) for x in gap],nonlinear_and_model_remainder=[str(x) for x in remainder])
            records.append(record);print(json.dumps({k:v for k,v in record.items() if not isinstance(v,list)}),flush=True)
    finally:env.close()
    summary=dict(maximum_value_weighted_gap=max(r['native_gap_value_norm'] for r in records),
        maximum_value_weighted_remainder=max(r['remainder_value_norm'] for r in records),
        maximum_component_sum_error=max(r['component_sum_error'] for r in records),
        maximum_native_vs_independent_next_state=max(r['model_minus_native_next_state'] for r in records),
        all_actual_steps_identical=True,final_components={k:records[-1][k] for k in ['actual_error','initial_component','gap_component','action_component','remainder_component']})
    dump_json(dict(not_solution=True,benchmark_evidence=False,reserved_seeds_used=False,source=file_metadata(args.source),config=file_metadata(args.config),
        runtime=runtime_metadata(),parameters=vars(args),records=records,summary=summary,
        native_forecast_transition_calls=predictor.evaluations,independent_derivative_steps=len(records),wall_seconds=time.monotonic()-begun,
        scope=__doc__),out/'result.json')
    print(json.dumps(summary),flush=True)
if __name__=='__main__':main()
