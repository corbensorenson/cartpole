#!/usr/bin/env python
"""Complete the declared repair/screen protocol after a finished tail trial.

This runner never tunes on noisy/reserved seeds or publishes a result.
"""
import argparse,json,subprocess,sys
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json,load_config
from gcartpole.evidence import file_metadata,utc_timestamp
from scripts.solve_frontier_capture_increment import physical_replay_passed


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True)
    p.add_argument('--source-manifest',required=True)
    p.add_argument('--directory',required=True)
    args=p.parse_args();source=Path(args.source);out=Path(args.directory)
    if (out/'followup.json').exists():raise FileExistsError(out)
    data=json.loads(source.read_text());execution=json.loads((source.parent/'execution.json').read_text())
    if execution['status']!='finished' or execution['returncode']!=0:raise ValueError('completed twenty-stage required')
    params=data['shared_capture_recipe']['parameters'];cfg=load_config(params['config'])
    if params['iterations']!=20 or params['optimize_suffix_start_seconds']!=0.:
        raise ValueError('declared full-horizon twenty-stage required')
    initial=data['controller']['warm_start_diagnostics']['maximum_dynamics_defect']
    final=data['controller']['final_trajectory_diagnostics']['maximum_dynamics_defect']
    accepted=sum(row.get('accepted') is True for row in data['search']['optimizer_history'])
    eligible=bool(accepted>0 and np.isfinite(initial) and np.isfinite(final) and final<initial)
    out.mkdir(parents=True,exist_ok=True);journal=out/'followup.json'
    record=dict(status='running',started_at=utc_timestamp(),source=file_metadata(source),source_manifest=file_metadata(args.source_manifest),
        config=file_metadata(params['config']),not_solution=True,canonical_release_evidence=False,
        noisy_development_seeds_used=False,reserved_seeds_used=False,conditional40_eligible=eligible,
        initial_gap=initial,final_gap=final,accepted_merit_updates=accepted,stages=[],
        scope='Declared inherited-tail continuation:conditional40 only for actual merit acceptance and smaller native gap;screen all8/9/10/12 uninterrupted physical handoffs. Preserve a full nominal20pass by screening before further optimization. No noisy cohorts,promotion or publication.')
    dump_json(record,journal)
    try:
        selected=source
        if eligible and not physical_replay_passed(data['result'],cfg):
            target=out/'conditional40';settings=dict(params,initializer=str(source),out_directory=str(target),iterations=40)
            command=[sys.executable,'scripts/synthesize_frontier_capture.py']
            for key,value in settings.items():
                if value is not None:command.extend(['--'+key.replace('_','-'),str(value)])
            if file_metadata(source)!=record['source']:raise ValueError('finished source changed')
            run=[sys.executable,'scripts/run_frontier_experiment.py','--directory',str(target),
                 '--input',str(source),'--input',params['config'],'--',*command]
            record['stages'].append(dict(label='conditional40',status='running',directory=str(target),command=command));dump_json(record,journal)
            subprocess.run(run,check=True)
            selected=target/'result.json';record['stages'][-1].update(status='finished',result=file_metadata(selected),execution=file_metadata(target/'execution.json'))
            dump_json(record,journal)
        screen=out/'physical_screen'
        command=[sys.executable,'scripts/screen_frontier_capture_candidate.py','--config',params['config'],
                 '--source',str(selected),'--source-manifest',args.source_manifest,'--directory',str(screen),
                 '--handoff-seconds','8','9','10','12']
        record['stages'].append(dict(label='physical_screen',status='running',directory=str(screen),command=command));dump_json(record,journal)
        subprocess.run(command,check=True)
        screen_result=screen/'physical_screen.json';screen_data=json.loads(screen_result.read_text())
        record['stages'][-1].update(status='finished',result=file_metadata(screen_result))
        record.update(status=screen_data['status'],selected_repair=file_metadata(selected),physical_screen=file_metadata(screen_result))
    except BaseException as error:
        record.update(status='failed_or_interrupted',error=f'{type(error).__name__}: {error}');raise
    finally:
        record['finished_at']=utc_timestamp();dump_json(record,journal)
    print(json.dumps(dict(status=record['status'],journal=str(journal))),flush=True)


if __name__=='__main__':main()
