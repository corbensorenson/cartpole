#!/usr/bin/env python
"""Compare active-column MP100 derivatives to a frozen dense reference."""
import argparse,importlib.util,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.ilqr import MujocoTransition
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.native_task_derivatives import chained_physical_task_jacobian
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ('plan-inputs','reference-module','directory'):parser.add_argument('--'+key,required=True)
    parser.add_argument('--repetitions',type=int,default=3)
    args=parser.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    if args.repetitions<1:raise ValueError('positive repetition count required')
    spec=importlib.util.spec_from_file_location('gcartpole._dense_task_jacobian_reference',args.reference_module)
    reference=importlib.util.module_from_spec(spec);spec.loader.exec_module(reference)
    inputs=json.loads(Path(args.plan_inputs).read_text());records=[];native_calls=derivative_calls=0;began=time.monotonic()
    for case in inputs['cases']:
        if file_metadata(case['source']['path'])!=case['source'] or file_metadata(case['config']['path'])!=case['config']:
            raise ValueError('Bound inputs changed')
        base=json.loads(Path(case['source']['path']).read_text());cfg=load_config(case['config']['path']);n=cfg['env']['n_links'];nx=2*(n+1)
        env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
        native=MujocoTransition(env,np.eye(nx),continuous_angles=True);local=FourthOrderMujocoTransition(env,np.eye(nx),continuous_angles=True)
        untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
        step=case['first_plan']['step'];row=base['result']['trajectory'][step-1];state=np.asarray(row['qpos']+row['qvel'])
        actions=np.asarray(case['first_plan']['diagnostic']['selected_sequence'],np.float32).astype(float)
        current=state.copy();predictions=[]
        for u in actions:current=native(current,float(u));predictions.append(current.copy())
        predictions=np.asarray(predictions)
        if float(np.max(np.abs(wrap_angle(np.cumsum(predictions[:,1:n+1],axis=1)))))!=case['first_plan']['diagnostic']['maximum_predicted_absolute_angle']:
            raise ValueError('Captured plan prediction changed')
        timings={'dense_frozen':[],'active_columns':[]};samples=[]
        try:
            for repetition in range(args.repetitions):
                jacobians={};counts={}
                order=('dense_frozen','active_columns') if repetition%2==0 else ('active_columns','dense_frozen')
                for label in order:
                    function=reference.chained_physical_task_jacobian if label=='dense_frozen' else chained_physical_task_jacobian
                    before=local.evaluations;started=time.monotonic()
                    jacobians[label]=function(local,state,actions,predictions,n_links=n,rate_weight=1.,
                        state_epsilon=base['controller']['state_epsilon'],action_epsilon=base['controller']['action_epsilon'],angle_band=.1)
                    timings[label].append(time.monotonic()-started);counts[label]=local.evaluations-before
                if jacobians['dense_frozen'].tobytes()!=jacobians['active_columns'].tobytes():
                    raise ValueError('Active-column Jacobian differs from frozen dense arithmetic')
                if counts['dense_frozen']!=counts['active_columns']:raise ValueError('Native derivative sampling changed')
                samples.append(dict(repetition=repetition,final_f64_jacobian_bit_identical=True,
                    native_derivative_calls_per_method=counts['dense_frozen']))
            if not np.array_equal(untouched,np.r_[env.data.qpos,env.data.qvel]):raise ValueError('Derivative computation changed live state')
            records.append(dict(start_step=step,final_f64_jacobians_bit_identical=True,samples=samples,wall_seconds_by_method=timings,
                median_dense_seconds=float(np.median(timings['dense_frozen'])),median_active_seconds=float(np.median(timings['active_columns'])),
                observed_median_speedup=float(np.median(timings['dense_frozen'])/np.median(timings['active_columns'])),live_state_unchanged=True))
            print(json.dumps(records[-1]),flush=True)
        finally:native_calls+=native.evaluations;derivative_calls+=local.evaluations;env.close()
    dump_json(dict(not_solution=True,canonical_release_evidence=False,parameters=vars(args),plan_inputs=file_metadata(args.plan_inputs),
        dense_reference_module=file_metadata(args.reference_module),active_module=file_metadata('src/gcartpole/native_task_derivatives.py'),
        records=records,native_forecast_transition_calls=native_calls,native_local_derivative_transition_calls=derivative_calls,
        total_native_transition_calls=native_calls+derivative_calls,wall_seconds=time.monotonic()-began,runtime=runtime_metadata(),
        optimizer_transition_calls=0,actual_episode_steps=0,reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Two captured15-link H32 plans;alternating dense/active MP100 timings,three repeats by default. Final F64 Jacobians and native sampling counts must be identical. Wall timings are observations under concurrent load,not a realtime controller certificate or new behavior result.'),out/'result.json')


if __name__=='__main__':main()
