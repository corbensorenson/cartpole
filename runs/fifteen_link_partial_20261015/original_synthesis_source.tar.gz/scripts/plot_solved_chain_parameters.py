"""Export scientific parameter maps from the completed, byte-replayed study."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from gcartpole.evidence import file_metadata


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--result',required=True)
    args=p.parse_args();source=Path(args.result);data=json.loads(source.read_text())
    assert len(data['records'])==96
    out=source.parent/'figures';out.mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
                         'axes.spines.right':False,'savefig.facecolor':'white'})
    figures=[]
    for noisy,label in ((False,'exact'),(True,'paired_noisy')):
        fig,axes=plt.subplots(2,4,figsize=(14,8),sharex=True,sharey=True)
        for n,ax in zip(data['counts'],axes.flat):
            values=np.zeros((4,3));passes=np.zeros((4,3),bool)
            for row in data['records']:
                if row['n_links']!=n:continue
                i=data['hub_diameters_m'].index(row['hub_diameter_m']);j=data['length_scales'].index(row['length_scale'])
                e=next(e for e in row['episodes'] if e['noisy_start']==noisy)
                values[i,j]=e['hold_seconds'];passes[i,j]=e['full_episode_gate_passed']
            im=ax.imshow(values,origin='lower',cmap='viridis',norm=Normalize(0,16),aspect='auto')
            for i in range(4):
                for j in range(3):
                    ax.text(j,i,f'{values[i,j]:.2f}'+('\nPASS' if passes[i,j] else ''),
                            ha='center',va='center',fontsize=9,color='black' if values[i,j]>10 else 'white')
            ax.set_title(f'{n} links');ax.set_xticks(range(3),['−5%','original','+5%'])
            ax.set_yticks(range(4),['0','5','10','15'])
        for ax in axes[1]:ax.set_xlabel('Individual link length change')
        for ax in axes[:,0]:ax.set_ylabel('Physical hub diameter (cm)')
        fig.suptitle('Released-controller transfer: longest continuous upright hold',fontsize=17,x=.06,ha='left')
        fig.text(.06,.925,'Exact hanging start' if not noisy else 'One paired noisy hanging start per plant · seed 20261030',fontsize=11)
        fig.subplots_adjust(left=.06,right=.86,bottom=.16,top=.87,hspace=.25,wspace=.12)
        fig.colorbar(im,cax=fig.add_axes([.90,.23,.017,.57]),label='Hold duration (s)')
        fig.text(.06,.075,'PASS requires a complete 30 s episode, ≥5 s upright and the original rail/force limits.',fontsize=10)
        fig.text(.06,.045,'Each row uses frozen route and feedback gains. Transfer failure does not measure difficulty after resynthesis.',fontsize=10)
        fig.text(.06,.015,'Nonzero hubs share 0.1 kg added mass; comparison to no hub also changes mass distribution.',fontsize=10)
        for suffix in ('png','pdf'):
            path=out/f'{label}_hold_map.{suffix}';fig.savefig(path,dpi=180);figures.append(file_metadata(path))
        plt.close(fig)
    # Mechanics relationships: diameter comparisons and length comparisons stay explicit.
    fig,axes=plt.subplots(2,2,figsize=(12,8))
    colors=plt.cm.viridis(np.linspace(.05,.95,8))
    fields=[('fastest_hanging_frequency_hz','Fastest hanging frequency (Hz)'),
            ('hinge_armature_to_own_body_inertia','Armature / own-body hinge inertia'),
            ('weakest_normalized_hanging_input_coupling','Weakest normalized hanging input coupling'),
            ('hanging_mass_matrix_condition','Hanging joint mass matrix condition')]
    for ax,(field,title) in zip(axes.flat,fields):
        for n,color in zip(data['counts'],colors):
            rows=sorted((r for r in data['records'] if r['n_links']==n and r['length_scale']==1.),key=lambda r:r['hub_diameter_m'])
            ax.plot([100*r['hub_diameter_m'] for r in rows],[r['mechanics'][field] for r in rows],
                    'o-',color=color,label=str(n),lw=1.4)
        ax.set_title(title,fontsize=11);ax.set_xlabel('Hub diameter (cm)');ax.set_xticks([0,5,10,15]);ax.grid(alpha=.15)
        if field!='fastest_hanging_frequency_hz':ax.set_yscale('log')
    fig.legend(*axes[0,0].get_legend_handles_labels(),title='Link count',ncol=8,
               loc='upper center',bbox_to_anchor=(.5,.945),fontsize=8)
    fig.suptitle('What hub geometry changes in the compiled plant',fontsize=17)
    fig.tight_layout(rect=[0,.075,1,.87])
    fig.text(.06,.033,'Original link length per count. Positive diameters have equal added mass; the zero point has no added hubs.',fontsize=10)
    fig.text(.06,.01,'Coordinate-specific mechanics diagnostics; no capture or controllability certificate is implied.',fontsize=10)
    for suffix in ('png','pdf'):
        path=out/f'hub_mechanics.{suffix}';fig.savefig(path,dpi=180);figures.append(file_metadata(path))
    plt.close(fig)
    fig,axes=plt.subplots(2,2,figsize=(12,8))
    for ax,(field,title) in zip(axes.flat,fields):
        for n,color in zip(data['counts'],colors):
            rows=sorted((r for r in data['records'] if r['n_links']==n and r['hub_diameter_m']==0),key=lambda r:r['length_scale'])
            baseline=next(r for r in rows if r['length_scale']==1.)['mechanics'][field]
            ax.plot([100*(r['length_scale']-1) for r in rows],
                    [100*(r['mechanics'][field]/baseline-1) for r in rows],'o-',color=color,label=str(n),lw=1.4)
        ax.set_title(title,fontsize=11);ax.set_xlabel('Individual link length change (%)')
        ax.set_ylabel('Change from same-count baseline (%)');ax.set_xticks([-5,0,5]);ax.axhline(0,color='gray',lw=.6);ax.grid(alpha=.15)
    fig.suptitle('Longer links do not change every mode in the same direction',fontsize=17)
    fig.legend(*axes[0,0].get_legend_handles_labels(),title='Link count',ncol=8,
               loc='upper center',bbox_to_anchor=(.5,.945),fontsize=8)
    fig.tight_layout(rect=[0,.06,1,.87])
    fig.text(.06,.02,'No added hubs; total rod mass, capsule radius, damping and armature fixed. Mechanics diagnostics, not solve difficulty.',fontsize=10)
    for suffix in ('png','pdf'):
        path=out/f'length_mechanics.{suffix}';fig.savefig(path,dpi=180);figures.append(file_metadata(path))
    plt.close(fig)
    # Export the entire factorial, including delivery and arrival outcomes.
    table=[]
    for r in data['records']:
        mechanics={k:v for k,v in r['mechanics'].items() if isinstance(v,(int,float))}
        for e in r['episodes']:
            table.append(dict(n_links=r['n_links'],length_scale=r['length_scale'],hub_diameter_m=r['hub_diameter_m'],
                              **mechanics,**{k:v for k,v in e.items() if isinstance(v,(int,float,bool)) or v is None}))
    with (out/'parameter_map.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)
    summary=dict(source=file_metadata(source),script=file_metadata(__file__),figures=figures,
                 table=file_metadata(out/'parameter_map.csv'),native_transition_calls=0)
    (out/'figures.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary))


if __name__=='__main__':main()
