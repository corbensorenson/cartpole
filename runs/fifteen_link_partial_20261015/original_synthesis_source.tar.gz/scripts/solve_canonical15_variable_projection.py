"""Matched native secant/trust calibration, then physical continuation refinement."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.native_trust_minimax import affine_trust_proposal
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix
from scripts.solve_canonical15_native_minimax import features,gain_raw,first_proposals
from gcartpole.native_minimax import bounded_affine_minimax
read=lambda p:json.loads(Path(p).read_text())
def physical_features(states,m):
 angles=wrap_angle(np.cumsum(states[:,1:16],axis=1))/m['angle_limit'];return np.r_[angles.reshape(-1),states[:,0]/m['rail_limit']]
def score(states,raws,h,m):
 if len(states)!=h:return (1,1,1e100,1e100,0)
 f=physical_features(states,m);safe=(np.max(abs(wrap_angle(np.cumsum(states[:,1:16],axis=1))),axis=1)<m['angle_limit'])&(abs(states[:,0])<=m['rail_limit']);bad=np.flatnonzero(~safe);prefix=int(bad[0]) if len(bad) else h;excess=np.maximum(abs(f)-1,0)
 return (0,0 if np.all(safe) else 1,float(np.max(abs(f))),float(excess@excess),-prefix)
def basis_for(h,m):
 first=m['tracking_steps'];tail=h-first;basis=np.zeros((h,m['tracking_knots']+tail));basis[:first,:m['tracking_knots']]=interpolation_matrix(m['tracking_knots'],first);basis[first:,m['tracking_knots']:]=np.eye(tail);return basis

def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--directory',required=True);a=p.parse_args();m=read(a.manifest);out=Path(a.directory);out.mkdir(exist_ok=False);(out/'private').mkdir();s=read(m['source']['path']);base=read(s['source']['path']);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in s['result']['trajectory']]]);U=np.asarray([q['action'] for q in s['result']['trajectory']],np.float32).astype(float);start=m['start_step'];track=m['tracking_steps'];gain=np.asarray(read(m['gain_source']['path'])['gain'])
 for key in ('source','config','tracking_array','tracking_audit','source_audit','gain_source','center_tape'):assert m[key]==file_metadata(m[key]['path'])
 assert read(m['tracking_audit']['path'])['passed'] and read(m['source_audit']['path'])['passed']
 with np.load(m['tracking_array']['path']) as z:K=z['gains'][m['tracking_variant_index']];assert z['states'].tobytes()==X[start:start+track+1].tobytes()
 cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);env=NLinkCartPoleEnv(cfg,progress=1.,seed=m['nominal_seed']);env.reset(seed=m['nominal_seed']);native=MujocoTransition(env,np.eye(32),continuous_angles=True);actual_ticks=0;began=time.monotonic();payload=dict(status='running',generated_at=utc_timestamp(),manifest=file_metadata(a.manifest),script=file_metadata(__file__),helper=file_metadata('src/gcartpole/native_trust_minimax.py'),runtime=runtime_metadata(),private_forecasts=[],force_projections=[],arms=[],stages=[],actual_records=[],maintenance_decisions=[],not_solution=True,canonical_release_evidence=False,noisy_development_seeds_used=False,reserved_seeds_used=False)
 def forecast(ff,label,kind):
  ff=np.asarray(ff).copy();xs=[X[start].copy()];us=[];raws=[];err=None;failed_post_state=np.full(32,np.nan);failed_time=np.nan;projection_index=None
  try:
   for i,value in enumerate(ff[:track]):
    raw=float(value)+float(K[i]@(xs[-1]-X[start+i]));u=float(np.float32(np.clip(raw,-1,1)));us.append(u);raws.append(raw);xs.append(native(xs[-1],u))
  except SimulationError as e:err=f'SimulationError: {e}';failed_post_state=np.r_[native.data.qpos,native.data.qvel].copy();failed_time=float(native.data.time)
  if err is None:
   state=xs[-1].copy();pairs=[];controls=[];query_raws=[];roles=[];errors=[];failed_states=[];failed_times=[]
   def query(raw,role):
    u=float(np.float32(np.clip(raw,-1,1)));pair=np.full((2,32),np.nan);pair[0]=state;error=None;failed_state=np.full(32,np.nan);ft=np.nan
    try:pair[1]=native(state,u)
    except SimulationError as e:error=f'SimulationError: {e}';failed_state=np.r_[native.data.qpos,native.data.qvel].copy();ft=float(native.data.time)
    index=len(pairs);pairs.append(pair);controls.append(u);query_raws.append(float(raw));roles.append(role);errors.append(error);failed_states.append(failed_state);failed_times.append(ft);return index
   def peak(i):return float(np.max(abs(physical_features(pairs[i][1:2],m)))) if errors[i] is None else 1e100
   grid=np.unique(np.r_[np.linspace(-1,1,m['inner_grid_points']).astype(np.float32).astype(float),np.float32(ff[-1]).astype(float)]);ids=[query(float(u),'grid') for u in grid];mi=ids[int(np.flatnonzero(grid==-1)[0])];pi=ids[int(np.flatnonzero(grid==1)[0])]
   assert errors[mi] is None and errors[pi] is None,'Projection anchors failed; preserve query evidence'
   proposal=bounded_affine_minimax(physical_features(pairs[mi][1:2],m),physical_features(pairs[pi][1:2],m));pid=query(proposal,'affine_minimax');bi=min(range(len(ids)),key=lambda i:peak(ids[i]));left=float(grid[max(0,bi-1)]);right=float(grid[min(len(grid)-1,bi+1)]);bracket=[left,right];ratio=(np.sqrt(5)-1)/2;c=right-ratio*(right-left);d=left+ratio*(right-left);ci=query(c,'golden_initial_c');di=query(d,'golden_initial_d');history=[]
   for iteration in range(m['inner_golden_iterations']):
    if peak(ci)<=peak(di):right,d,di=d,c,ci;c=right-ratio*(right-left);ci=query(c,'golden_c');branch='left';new=ci
    else:left,c,ci=c,d,di;d=left+ratio*(right-left);di=query(d,'golden_d');branch='right';new=di
    history.append(dict(iteration=iteration,branch=branch,left=left,right=right,c=c,d=d,candidate_c=ci,candidate_d=di,new_candidate=new))
   winner=min(range(len(pairs)),key=lambda i:(peak(i),abs(controls[i]),i));projection_index=len(payload['force_projections']);qt=out/'private'/f'projection_{projection_index:05d}.npz';np.savez_compressed(qt,states=np.asarray(pairs),actions=np.asarray(controls),raw_actions=np.asarray(query_raws),roles=np.asarray(roles),failed_post_states=np.asarray(failed_states),failed_times=np.asarray(failed_times));payload['force_projections'].append(dict(index=projection_index,parent_forecast=len(payload['private_forecasts']),tape=file_metadata(qt),errors=errors,grid_actions=grid.tolist(),grid_candidate_ids=ids,affine_proposal=proposal,affine_candidate_id=pid,initial_bracket=bracket,golden_initial_ids=[len(ids)+1,len(ids)+2],golden_history=history,winner_index=winner,selected_last_action=controls[winner],selected_next_peak=peak(winner),input_last_hint=float(ff[-1])))
   assert errors[winner] is None,'Every projected force failed'
   ff[-1]=controls[winner];us.append(controls[winner]);raws.append(controls[winner]);xs.append(pairs[winner][1].copy())
  tape=out/'private'/f'forecast_{len(payload["private_forecasts"]):05d}.npz';np.savez_compressed(tape,states=np.asarray(xs),actions=np.asarray(us),raw_actions=np.asarray(raws),feedforward=ff,failed_post_state=failed_post_state,failed_time=np.asarray(failed_time));row=dict(index=len(payload['private_forecasts']),label=label,kind=kind,tape=file_metadata(tape),projection_index=projection_index,error=err,attempted_steps=len(us),completed_steps=len(xs)-1,score=list(score(np.asarray(xs)[1:],np.asarray(raws),len(ff),m)));payload['private_forecasts'].append(row);return dict(row=row,states=np.asarray(xs),raws=np.asarray(raws),actions=np.asarray(us),ff=ff,score=tuple(row['score']))
 def maintenance(state,tick,last,label):
  om=m['maintenance'];pairs=[];calls=[];errors=[]
  def evaluate(x,raw,role):
   u=float(np.float32(np.clip(raw,-1,1)));pair=np.full((2,32),np.nan);pair[0]=x;error=None
   try:pair[1]=native(x,u)
   except SimulationError as e:error=f'SimulationError: {e}'
   index=len(calls);calls.append((pair,u,float(raw),role));errors.append(error);return index,pair[1] if error is None else None
  mi,minus=evaluate(state,-1.,'first_minus');pi,plus=evaluate(state,1.,'first_plus')
  if minus is None or plus is None:raise RuntimeError('Maintenance anchor failed; preserve new failed evidence')
  proposal=bounded_affine_minimax(features(minus,0.,om),features(plus,0.,om));raw=gain_raw(gain,state);source=float(U[tick]) if tick<len(U) else 0.;commands,pr=first_proposals(raw,proposal,source,last,om)
  for i,u in enumerate(commands):
   fi,first=evaluate(state,float(u),f'first_{i}');row=dict(index=i,first_id=fi,second_minus_id=None,second_plus_id=None,second_id=None,second_raw=None,score=[1,1e100,abs(float(u))])
   if first is not None:
    sm,minus=evaluate(first,-1.,f'second_minus_{i}');sp,plus=evaluate(first,1.,f'second_plus_{i}');row.update(second_minus_id=sm,second_plus_id=sp)
    if minus is not None and plus is not None:
     raw2=bounded_affine_minimax(features(minus,0.,om),features(plus,0.,om));si,second=evaluate(first,raw2,f'second_selected_{i}');row.update(second_id=si,second_raw=raw2)
     if second is not None:row['score']=[0,float(max(np.max(abs(features(first,0.,om))),np.max(abs(features(second,0.,om))))),abs(float(u))]
   pairs.append(row)
  winner=min(range(len(pairs)),key=lambda i:tuple(pairs[i]['score']));tape=out/'private'/f'maintenance_{len(payload["maintenance_decisions"]):05d}.npz';np.savez_compressed(tape,states=np.asarray([c[0] for c in calls]),actions=np.asarray([c[1] for c in calls]),raw_actions=np.asarray([c[2] for c in calls]),roles=np.asarray([c[3] for c in calls]),candidate_actions=commands,candidate_raw_proposals=pr);d=dict(label=label,tick=tick,tape=file_metadata(tape),errors=errors,first_minus_id=mi,first_plus_id=pi,proposal=proposal,gain_raw=raw,source_action=source,last_action=last,candidates=pairs,winner_index=winner);payload['maintenance_decisions'].append(d)
  if pairs[winner]['score'][0]:raise RuntimeError('No complete maintenance forecast')
  return float(commands[winner]),calls[pairs[winner]['first_id']][0][1]
 def actual_episode(label,selected,h):
  nonlocal actual_ticks
  actual=NLinkCartPoleEnv(cfg,progress=1.,seed=m['nominal_seed']);actual.reset(seed=m['nominal_seed']);xs=[initial.copy()];us=[];raws=[];info=None;reason=None
  try:
   for tick in range(actual.max_steps):
    state=np.r_[actual.data.qpos,actual.data.qvel]
    if tick<start:raw=float(U[tick]);u=raw
    elif tick<start+h:
     i=tick-start;raw=float(selected['ff'][i])+float(K[i]@(state-X[tick])) if i<track else float(selected['ff'][i]);u=float(np.float32(np.clip(raw,-1,1)))
    else:u,prediction=maintenance(state,tick,float(us[-1]),label);raw=u
    _,_,terminated,truncated,info=actual.step([u]);actual_ticks+=1;x=np.r_[actual.data.qpos,actual.data.qvel];xs.append(x.copy());us.append(u);raws.append(raw)
    if tick<start:assert x.tobytes()==X[tick+1].tobytes()
    elif tick<start+h:assert x.tobytes()==selected['states'][tick-start+1].tobytes()
    else:assert x.tobytes()==prediction.tobytes()
    if terminated or truncated:reason=info['termination_reason'];break
  finally:
   actual.close();tape=out/(label+'_actual.npz');np.savez_compressed(tape,states=np.asarray(xs),actions=np.asarray(us),raw_actions=np.asarray(raws))
  for tick,u in enumerate(us):assert native(xs[tick],float(u)).tobytes()==xs[tick+1].tobytes()
  safe=np.max(abs(wrap_angle(np.cumsum(np.asarray(xs)[1:,1:16],axis=1))),axis=1)<.15;streak=longest=0
  for ok in safe:streak=streak+1 if ok else 0;longest=max(longest,streak)
  maxcart=float(np.max(abs(np.asarray(xs)[:,0])));passed=len(us)==1500 and longest>=250 and maxcart<=3 and reason=='time_limit' and not info['simulation_error'];row=dict(label=label,horizon=h,selected_forecast=selected['row']['tape'],selected_forecast_index=selected['row']['index'],tape=file_metadata(tape),actual_hanging_start_episode_steps=len(us),hold_seconds=longest*.02,maximum_cart=maxcart,termination_reason=reason,simulation_error=info['simulation_error'],full_nominal_gate_passed=passed);payload['actual_records'].append(row);print(row,flush=True)
 try:
  for tick in range(start+track):assert native(X[tick],float(U[tick])).tobytes()==X[tick+1].tobytes()
  h=149
  with np.load(m['center_tape']['path']) as z:initialff=z['feedforward'].copy();expected=z['states'].copy()
  baseline=forecast(initialff,'projected_initial','initial');assert baseline['states'].tobytes()==expected.tobytes();payload['initial_forecast']=baseline['row']['index']
  def model(center,basis,eps,label):
   columns=[];pairs=[];valid=True
   for k in range(basis.shape[1]):
    plus=forecast(center['ff']+eps[k]*basis[:,k],label,f'plus_{k}');minus=forecast(center['ff']-eps[k]*basis[:,k],label,f'minus_{k}');pairs.append([plus['row']['index'],minus['row']['index']])
    if plus['score'][0] or minus['score'][0]:valid=False
    else:columns.append((physical_features(plus['states'][1:],m)-physical_features(minus['states'][1:],m))/(2*eps[k]))
   return np.column_stack(columns) if valid else None,pairs
  for arm in m['arms']:
   nk=arm['parameters'];basis=np.zeros((h,nk));basis[:track]=np.eye(track) if arm['basis']=='independent' else interpolation_matrix(nk,track);center=baseline;history=[]
   for iteration in range(m['iterations']):
    if center['score'][0] or center['score'][1]==0:break
    eps=np.full(nk,m['tracking_epsilon']);radii=np.full(nk,m['tracking_trust_radius']);label=arm['label']+f'_round{iteration}';jac,pairs=model(center,basis,eps,label);row=dict(iteration=iteration,label=label,center_before=center['row']['index'],derivative_pairs=pairs,derivative_epsilons=eps.tolist(),trust_radii=radii.tolist(),backtracks=[],accepted=None,parameter_step=None)
    selected=center
    if jac is None:row['status']='incomplete_secant_forecasts'
    else:
     f=physical_features(center['states'][1:],m);delta,lp=affine_trust_proposal(f,jac,radii,action_values=center['ff'][:track],action_basis=basis[:track],solver_seconds=m['lp_seconds']);row['lp']=lp;row['parameter_step']=None if delta is None else delta.tolist()
     if delta is not None:
      for power in range(m['backtrack_powers']):
       candidate=forecast(center['ff']+basis@(delta/(2**power)),label,f'backtrack_{power}');bt=dict(power=power,forecast_index=candidate['row']['index'])
       if not candidate['score'][0]:
        pred=f+jac@(delta/(2**power));actual=physical_features(candidate['states'][1:],m);bt.update(predicted_physical_peak=float(np.max(abs(pred))),observed_physical_peak=float(np.max(abs(actual))),maximum_normalized_prediction_error=float(np.max(abs(pred-actual))),changed_delivered_prefix_inputs=int(np.count_nonzero(candidate['actions'][:track]!=center['actions'][:track])))
       row['backtracks'].append(bt)
       if candidate['score']<center['score']:selected=candidate;row['accepted']=candidate['row']['index'];break
    row['center_after']=selected['row']['index'];history.append(row);center=selected
    print(dict(arm=arm['label'],round=iteration,selected_score=center['score'],accepted=row['accepted'],calls=native.evaluations+actual_ticks),flush=True);dump_json(payload,out/'result.progress.json')
    if row['accepted'] is None:break
   ar=dict(arm=arm,initial_forecast=baseline['row']['index'],selected_forecast=center['row']['index'],selected_score=list(center['score']),history=history);payload['arms'].append(ar);actual_episode(arm['label']+'_h149',center,h);dump_json(payload,out/'result.progress.json')
  payload['selected_arm']=min(range(len(payload['arms'])),key=lambda i:tuple(payload['arms'][i]['selected_score']))
  payload.update(status='finished',total_native_transition_calls=native.evaluations+actual_ticks,actual_hanging_start_episode_steps=actual_ticks,wall_seconds=time.monotonic()-began);assert payload['total_native_transition_calls']<=m['execution_native_transition_ceiling'];dump_json(payload,out/'result.json')
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}',total_native_transition_calls=native.evaluations+actual_ticks,actual_hanging_start_episode_steps=actual_ticks);dump_json(payload,out/'result.failed.json');raise
 finally:env.close()
if __name__=='__main__':main()
