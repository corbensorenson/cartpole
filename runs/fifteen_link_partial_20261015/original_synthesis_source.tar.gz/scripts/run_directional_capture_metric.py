"""Declared feedback-direction defect metric comparison; same costs and physicalprefix."""
import argparse,json,math,subprocess,sys,time
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp

def read(p):return json.loads(Path(p).read_text())
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--config',required=True);p.add_argument('--initializer',required=True);p.add_argument('--gain-result',required=True);p.add_argument('--memo',required=True);p.add_argument('--defect-factor-json',required=True);p.add_argument('--prefix-seconds',type=float,required=True);p.add_argument('--directory',required=True);a=p.parse_args();out=Path(a.directory);out.mkdir(parents=True,exist_ok=False);start=time.monotonic();assert a.prefix_seconds==8.
 d=dict(generated_at=utc_timestamp(),status='running',script=file_metadata(__file__),config=file_metadata(a.config),initializer=file_metadata(a.initializer),defect_factor=file_metadata(a.defect_factor_json),gain_source=file_metadata(a.gain_result),memo=file_metadata(a.memo),prefix_seconds=a.prefix_seconds,stages=[],native_transition_ceiling=674000,total_native_transition_calls=0,actual_hanging_start_episode_steps=0,component_passed=False,not_solution=True,canonical_release_evidence=False,reserved_seeds_used=False,noisy_development_seeds_used=False,scope='Same0.95altered14plant/seed0/reference and8sactualprefix; defectmetric varies. Up to8capture-only iterations, allavailable integerhandoffs. Parent count overlaps primitives; no canonical promotion.')
 def stage(name,script,args,inputs):
  folder=out/name;cmd=[sys.executable,'scripts/run_frontier_experiment.py','--directory',str(folder),'--input',a.memo,'--input',a.config]
  for v in inputs:cmd+=['--input',str(v)]
  cmd+=['--',sys.executable,script,'--directory',str(folder/'diagnostic'),*map(str,args)];print(json.dumps(dict(starting_stage=name,command=cmd)),flush=True);proc=subprocess.run(cmd);path=folder/'diagnostic/result.json'
  if not path.exists():raise RuntimeError(f'{name}: no result; childexit{proc.returncode}')
  r=read(path);row=dict(name=name,directory=str(folder),execution=file_metadata(folder/'execution.json'),result=file_metadata(path),status=r['status'],total_native_transition_calls=r['total_native_transition_calls'],actual_hanging_start_episode_steps=r.get('actual_hanging_start_episode_steps',0));d['stages'].append(row);d['total_native_transition_calls']+=row['total_native_transition_calls'];d['actual_hanging_start_episode_steps']+=row['actual_hanging_start_episode_steps'];assert d['total_native_transition_calls']<=d['native_transition_ceiling'];dump_json(d,out/'result.progress.json')
  if proc.returncode or r['status']!='finished':raise RuntimeError(f'{name}: failed; counts retained')
  return r,path
 try:
  initial=a.initializer;passing=None;selected_source=None
  for iteration in (8,):
   r,path=stage(f'capture_suffix{iteration}','scripts/run_counted_directional_capture_repair.py',['--defect-factor-json',a.defect_factor_json,'--config',a.config,'--initializer',initial,'--iterations','8','--optimize-suffix-start-seconds',a.prefix_seconds,'--native-transition-ceiling','650000'],[initial,a.defect_factor_json])
   available=[float(t) for t in range(math.ceil(a.prefix_seconds),14) if t*50<=r['actual_hanging_start_episode_steps']];d.setdefault('available_handoffs',[]).append(dict(after_cumulative_iterations=iteration,seconds=available))
   if available:
    f,_=stage(f'saved_feedback_handoffs{iteration}','scripts/screen_saved_feedback_handoffs.py',['--source-result',path,'--gain-result',a.gain_result,'--handoff-seconds',*available],[path,a.gain_result]);passes=[x for x in f['records'] if x['full_nominal_component_gate_passed']]
    if passes:passing=min(passes,key=lambda r:r['handoff_seconds']);selected_source=r['candidate'];d['full_passing_handoffs']=[x['handoff_seconds'] for x in passes];break
   initial=r['candidate']['path']
  d.update(status='finished',component_passed=bool(passing),termination='complete nominal component' if passing else 'no complete route within declared capture budget')
  if passing:
   c=read(selected_source['path']);t=np.load(passing['tape']['path']);h=round(passing['handoff_seconds']/.02);gain=np.asarray(read(a.gain_result)['gain']);k=np.vstack([np.asarray(c['controller']['feedback_gains'])[:h],np.tile(-gain,(700-h,1))]);final=out/'passing_physical_initializer.json'
   dump_json(dict(selected_state=c['selected_state'],controller=dict(controls=t['actions'][:700].tolist(),feedback_gains=k.tolist(),coordinate_transform=np.eye(30).tolist(),continuous_angles=True,physical_shooting=True,capture_start_seconds=9.),search=dict(nominal_coordinate_states=t['states'][:701].tolist()),config=d['config'],source=selected_source,passing_tape=passing['tape'],seed=0,initialization_only=True,not_solution=True,selected_handoff_seconds=passing['handoff_seconds'],scope='Actual700ticks of complete30s altered14component; initializer only,not successorplant orcanonical15.'),final);d['passing_physical_initializer']=file_metadata(final)
 except BaseException as e:d.update(status='failed',error=f'{type(e).__name__}: {e}');raise
 finally:
  d.update(finished_at=utc_timestamp(),wall_seconds=time.monotonic()-start);dump_json(d,out/'result.json');print(json.dumps(dict(status=d['status'],passed=d['component_passed'],nativecalls=d['total_native_transition_calls'],termination=d.get('termination'))),flush=True)
if __name__=='__main__':main()
