"""Matched old-gain/scale controls on frozen native references; no synthesis."""
import argparse,copy,json
from pathlib import Path
import mujoco,numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from scripts.evaluate_fddp_two_expert import load_controller
from scripts.evaluate_fddp_parked_route import run_episode
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--manifest',required=True);p.add_argument('--directory',required=True);a=p.parse_args();manifest=json.loads(Path(a.manifest).read_text());out=Path(a.directory);out.mkdir(parents=True,exist_ok=False)
    for r in [manifest['feedback_source'],*[r for case in manifest['cases'] for r in (case['source_result'],case['gain_result'])]]:assert file_metadata(r['path'])==r
    physical=json.loads(Path(manifest['feedback_source']['path']).read_text());old_gains=np.array(physical['controller']['feedback_gains']);original=mujoco.mj_step;calls=[0];frame=4
    def counted(model,data,*args,**kwargs):
        n=int(kwargs.get('nstep',args[0] if args else 1))
        if calls[0]+n>30000*frame:raise RuntimeError('native transition ceiling')
        calls[0]+=n;return original(model,data,*args,**kwargs)
    d=dict(generated_at=utc_timestamp(),status='running',script=file_metadata(__file__),manifest=file_metadata(a.manifest),feedback_source=manifest['feedback_source'],records=[],native_transition_ceiling=30000,total_native_transition_calls=0,actual_hanging_start_episode_steps=0,not_solution=True,canonical_release_evidence=False,reserved_seeds_used=False,noisy_development_seeds_used=False,scope='Samefrozenaltered14references/plant/F32actions/MP100maintenance,replaceTVfeedbackwithvalidatedsourcegainprofileat1/.25/0scale. Zeroaffineoffsets;continuousseed0no parking/projection/reset. No synthesis or causalprecisionclaim.')
    mujoco.mj_step=counted
    try:
        shared_gain=None
        for case in manifest['cases']:
            source=json.loads(Path(case['source_result']['path']).read_text());g=json.loads(Path(case['gain_result']['path']).read_text());assert source['status']=='finished' and g['status']=='finished' and source['config']==g['config'];gain=np.array(g['gain'])
            if shared_gain is None:shared_gain=gain
            else:assert shared_gain.tobytes()==gain.tobytes()
            prior=json.loads(Path(source['candidate']['path']).read_text());assert prior['selected_state']==physical['selected_state'];cfg=load_config(source['config']['path']);assert cfg['env']['n_links']==14 and cfg['env']['frame_skip']==4 and cfg['env']['joint_armature']==.0005*.95
            base=load_controller(Path(source['candidate']['path']),14,load_config('benchmarks/p1_capture_envelope.yaml'));N=len(base['controls']);assert N in (300,400,700);ecfg=fixed_state_cfg(cfg,prior['selected_state'],30.)
            for scale in manifest['scales']:
                c=copy.deepcopy(base);c['feedback_gains']=scale*old_gains[:N];before=calls[0];result=run_episode(ecfg,c,gain,np.zeros(30),seed=0,park_seconds=0.,cart_target=0.,tracking_gain_scale=1.,phase_adaptive=False,phase_window=12,include_trace=True)
                u=np.array([r['action'] for r in result['trajectory']],np.float32).astype(float);x=np.vstack([prior['selected_state']['qpos']+prior['selected_state']['qvel'],[r['qpos']+r['qvel'] for r in result['trajectory']]])
                env=NLinkCartPoleEnv(ecfg,progress=1.,seed=0);env.reset(seed=0);native=MujocoTransition(env,np.eye(30),continuous_angles=True)
                try:
                    for i,action in enumerate(u):assert native(x[i],float(action)).tobytes()==x[i+1].tobytes()
                finally:env.close()
                assert calls[0]-before==8*len(u)
                path=out/f"{case['tag']}_scale{scale}.npz";np.savez_compressed(path,states=x,actions=u)
                gate=bool(result['success'] and len(u)==1500 and result['termination_reason']=='time_limit' and result['max_upright_streak_seconds']>=5 and result['max_cart_excursion']<=3 and not result['final_info'].get('simulation_error'))
                row=dict(tag=case['tag'],feedback_scale=scale,reference_steps=N,source=source['candidate'],source_result=case['source_result'],gain_source=case['gain_result'],config=source['config'],tape=file_metadata(path),full_nominal_component_gate_passed=gate,independent_whole_actual_tape_bytes_exact=True,independent_tape_replay_transition_calls=len(u),actual_hanging_start_episode_steps=len(u),total_native_transition_calls=2*len(u),saturated_tick_fraction=float(np.mean(abs(u)>=1)),result={k:v for k,v in result.items() if not isinstance(v,(dict,list))})
                d['records'].append(row);d['actual_hanging_start_episode_steps']+=len(u);print(json.dumps(row),flush=True);dump_json(d,out/'result.progress.json')
                if gate:
                    k=np.vstack([scale*old_gains[:N],np.tile(-gain,(700-N,1))]);seed=out/f"{case['tag']}_scale{scale}_passing_initializer.json";dump_json(dict(selected_state=prior['selected_state'],controller=dict(controls=u[:700].tolist(),feedback_gains=k.tolist(),coordinate_transform=np.eye(30).tolist(),continuous_angles=True,physical_shooting=True,capture_start_seconds=9.),search=dict(nominal_coordinate_states=x[:701].tolist()),config=source['config'],passing_tape=row['tape'],selected_handoff_seconds=N*.02,seed=0,initialization_only=True,not_solution=True),seed);row['passing_physical_initializer']=file_metadata(seed)
        d.update(status='finished')
    except BaseException as e:d.update(status='failed',error=f'{type(e).__name__}: {e}');raise
    finally:
        mujoco.mj_step=original;d.update(total_native_transition_calls=calls[0]/4,native_physics_substeps=calls[0],partial_transition_substeps=calls[0]%4);dump_json(d,out/'result.json')
    print(json.dumps(dict(status=d['status'],nativecalls=d['total_native_transition_calls'],passes=sum(r['full_nominal_component_gate_passed'] for r in d['records']))))

if __name__=='__main__':main()
