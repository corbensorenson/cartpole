#!/usr/bin/env python
"""Cache independent MP planar RK4 sensitivities; never run an alternate plant.

Each analytic field call differentiates smooth held force at the saved delivered
float32 nominal action. Native MuJoCo remains the physical execution authority.
This component performs no hanging-start evaluation or release promotion.
"""
import argparse,json,multiprocessing,time
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
import mpmath
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.planar_mechanics import PlanarMechanics
from gcartpole.evidence import data_sha256,file_metadata,text_sha256,utc_timestamp,runtime_metadata
from scripts.solve_frontier_capture_increment import validate_development_seeds

_model=None

def initialize(config,seed,digits):
    global _model
    env=NLinkCartPoleEnv(config,progress=1.,seed=seed);env.reset(seed=seed)
    _model=PlanarMechanics(env,decimal_digits=digits);env.close()


def compute_step(task):
    step,state,action=task;start=time.monotonic();value,a,b=_model.transition(state,action,derivatives=True)
    return dict(step=step,state=state,delivered_nominal_action=action,
        independent_next_state=[str(v) for v in value],
        A=[[str(v) for v in row] for row in a.tolist()],B=[[str(v) for v in row] for row in b.tolist()],
        worker_seconds=time.monotonic()-start)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--config',required=True)
    p.add_argument('--directory',required=True);p.add_argument('--decimal-digits',type=int,default=100);p.add_argument('--workers',type=int,default=1)
    args=p.parse_args();out=Path(args.directory);journal=out/'derivative_cache.json'
    if journal.exists():raise FileExistsError(journal)
    if args.workers<1 or args.decimal_digits<40:raise ValueError('positive worker count and at least40 digits required')
    source=json.loads(Path(args.source).read_text());cfg=load_config(args.config);n=cfg['env']['n_links'];validate_development_seeds(n,source['seed'])
    nx=2*(n+1);controller=source['controller']
    if (not controller['continuous_angles'] or controller['phase_adaptive'] or not np.array_equal(controller['coordinate_transform'],np.eye(nx))):raise ValueError('fixed-time physical coordinates required')
    states=np.asarray(source['search']['nominal_coordinate_states'],float);controls=np.asarray(controller['controls'],float)
    if states.shape!=(len(controls)+1,nx) or not np.all(np.isfinite(states)) or not np.all(np.isfinite(controls)) or np.any(np.abs(controls)>1):raise ValueError('finite complete bounded route required')
    out.mkdir(parents=True,exist_ok=True);env=NLinkCartPoleEnv(cfg,progress=1.,seed=source['seed']);env.reset(seed=source['seed'])
    transition=MujocoTransition(env,np.eye(nx),continuous_angles=True);ctx=mpmath.mp.clone();ctx.dps=args.decimal_digits
    record=dict(status='running',started_at=utc_timestamp(),not_solution=True,benchmark_evidence=False,reserved_seeds_used=False,
        source=file_metadata(args.source),config=file_metadata(args.config),runtime=runtime_metadata(),parameters=vars(args),
        decimal_digits=args.decimal_digits,physics_xml_sha256=text_sha256(env.xml),frame_skip=env.frame_skip,
        states_sha256=data_sha256(states.tolist()),controls_sha256=data_sha256(controls.tolist()),steps=[],
        derivative='analytic_implicit_planar_acceleration_and_held_input_RK4',input_derivative='smooth_held_force_not_float32_quantizer',
        native_execution_unmodified=True,scope=__doc__)
    dump_json(record,journal);start=time.monotonic()
    tasks=[(i,states[i].tolist(),float(np.float32(controls[i]))) for i in range(len(controls))]
    try:
        with ProcessPoolExecutor(max_workers=args.workers,mp_context=multiprocessing.get_context('spawn'),initializer=initialize,initargs=(cfg,source['seed'],args.decimal_digits)) as pool:
            futures=[pool.submit(compute_step,task) for task in tasks]
            for future in as_completed(futures):
                result=future.result();i=result['step'];native=transition(states[i],tasks[i][2]);result['native_next_state']=native.tolist()
                discrepancy=ctx.matrix([ctx.mpf(float(v)) for v in native])-ctx.matrix(result['independent_next_state'])
                result['maximum_native_minus_independent_next_state']=float(max(abs(v) for v in discrepancy))
                path=out/f'step{i:04d}.json'
                if path.exists():raise FileExistsError(path)
                dump_json(result,path);record['steps'].append(dict(step=i,artifact=file_metadata(path),worker_seconds=result['worker_seconds'],maximum_native_minus_independent_next_state=result['maximum_native_minus_independent_next_state']))
                if len(record['steps'])%25==0:
                    record['observed_at']=utc_timestamp();dump_json(record,journal)
                    print(json.dumps(dict(completed_steps=len(record['steps']),total_steps=len(controls),elapsed_seconds=time.monotonic()-start)),flush=True)
        record['steps'].sort(key=lambda row:row['step']);record.update(status='finished',finished_at=utc_timestamp(),wall_seconds=time.monotonic()-start,
            sum_worker_seconds=sum(row['worker_seconds'] for row in record['steps']),maximum_native_minus_independent_next_state=max(row['maximum_native_minus_independent_next_state'] for row in record['steps']))
    except BaseException as error:
        record.update(status='failed_or_interrupted',error=f'{type(error).__name__}: {error}',finished_at=utc_timestamp(),wall_seconds=time.monotonic()-start)
        raise
    finally:dump_json(record,journal);env.close()
    print(json.dumps(dict(status=record['status'],steps=len(record['steps']),wall_seconds=record['wall_seconds'])),flush=True)

if __name__=='__main__':main()
