#!/usr/bin/env python
"""Verify exported route values and reproduce the saved maintenance metric."""
import argparse,json
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,data_sha256,utc_timestamp
from gcartpole.lqr_design import high_precision_lyapunov_factor
from gcartpole.route_value_inputs import verified_route_value_inputs
from scripts.search_swingup_capture import lqr_gain
from scripts.make_lqr_checkpoint import finite_difference_dynamics
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.solve_frontier_capture_increment import validate_development_seeds


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--value-factors',required=True);p.add_argument('--config',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();out=Path(args.directory)
    if (out/'capture_cache.json').exists():raise FileExistsError(out/'capture_cache.json')
    source,values,provenance=verified_route_value_inputs(args.source,args.value_factors,args.config);c=source['controller'];cfg=load_config(args.config);validate_development_seeds(cfg['env']['n_links'],source['seed'])
    cfg=fixed_state_cfg(cfg,source['selected_state'],30.)
    cfg['env'].setdefault('action_lqr_residual',{})['enabled']=False
    gain=lqr_gain(cfg,progress=c['lqr_progress'],fd_eps=1e-7,control_cost=c['lqr_control_cost'],q_weights=c['lqr_weights'],decimal_digits=c['lqr_decimal_digits'])
    a,b=finite_difference_dynamics(cfg,c['progress'],1e-7);mapping=np.asarray(c['normalized_cost_mapping']);transform=np.asarray(c['coordinate_transform'])
    if not np.array_equal(transform,np.eye(transform.shape[0])):raise ValueError('physical coordinates required for this metric reproduction')
    _,factor,diagnostics=high_precision_lyapunov_factor(a,b,gain,mapping,feedback_scale=c['lqr_scale'],decimal_digits=c['lqr_decimal_digits'])
    factor=factor@mapping
    if not np.array_equal(factor,source['lyapunov']['factor']) or data_sha256(factor.tolist())!=source['lyapunov']['factor_sha256']:
        raise ValueError('recomputed maintenance metric differs from saved physical factor')
    out.mkdir(parents=True,exist_ok=True)
    dump_json(dict(not_solution=True,generated_at=utc_timestamp(),source=file_metadata(args.source),config=file_metadata(args.config),
        gain=gain.tolist(),gain_sha256=data_sha256(gain.tolist()),factor_sha256=data_sha256(factor.tolist()),
        maintenance_factor_reproduced_bit_identically=True,diagnostics=diagnostics,reserved_seeds_used=False),out/'capture_cache.json')
    dump_json(dict(not_solution=True,generated_at=utc_timestamp(),provenance=provenance,
        maintenance_cache=file_metadata(out/'capture_cache.json'),reserved_seeds_used=False),out/'value_inputs_verified.json')
    print(json.dumps(dict(value_provenance=provenance['provenance'],maintenance_factor_identical=True)),flush=True)
if __name__=='__main__':main()
