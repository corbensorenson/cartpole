#!/usr/bin/env python
"""Compare fixed first-QP formulations without changing a physical trajectory."""
import argparse,json
from pathlib import Path
from time import monotonic
import numpy as np
from scipy import sparse
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.qp_backends import solve_clarabel_bounded_qp
from gcartpole.qp_conditioning import FactoredStepWhitening


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--qp-directory',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();source=Path(args.qp_directory);out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    metadata=json.loads((source/'metadata.json').read_text())
    for item in metadata['files']:
        if file_metadata(item['path'])!=item:raise ValueError('fixed-QP archive changed')
    h=sparse.load_npz(source/'hessian.npz');c=sparse.load_npz(source/'constraints.npz')
    v=np.load(source/'vectors.npz');f=np.load(source/'cost_factors.npz')
    roots=[f[str(index)] for index in range(metadata['steps'])]
    q,lo,hi=v['gradient'],v['lower'],v['upper']
    m,n,r=metadata['state_values'],metadata['physical_step_variables'],metadata['residual_rows']
    labels=('original_native_defaults','original_expanded_equilibration','cost_block_mp100_whitening')
    records=[]
    for label in labels:
        began=monotonic();hp,qp,cp,lower,upper=h,q,c,lo,hi;mapping=None;conditioning=None
        if label=='cost_block_mp100_whitening':
            conditioner=FactoredStepWhitening(roots,v['control_costs'],metadata['objective_scale'])
            hp,qp,cp,lower,upper,mapping=conditioner.transform(h,q,c,lo,hi,r)
            conditioning=conditioner.diagnostics()
        setup_seconds=monotonic()-began;began=monotonic()
        solved=solve_clarabel_bounded_qp(hp,qp,cp,lower,upper,tolerance=metadata['tolerance'],
            max_iterations=metadata['max_iterations'],
            equilibration_scaling=(1e-12,1e12) if label=='original_expanded_equilibration' else None)
        solve_seconds=monotonic()-began
        physical=solved.x if mapping is None else np.asarray(mapping@solved.x).ravel()
        finite=bool(np.all(np.isfinite(physical)))
        def violation(matrix,vector,start,end):
            value=matrix[start:end]@vector
            return float(max(0.,np.max(lo[start:end]-value),np.max(value-hi[start:end])))
        record=dict(label=label,native_status=solved.info.status,native_status_usable=solved.info.status_val in(1,2),
            native_iterations=solved.info.iter,native_primal_residual=solved.info.prim_res,native_dual_residual=solved.info.dual_res,
            conditioning=conditioning,conditioning_setup_seconds=setup_seconds,solve_seconds=solve_seconds,
            finite_mapped_solution=finite,maximum_constraint_coefficient=float(np.max(np.abs(cp.data))),
            hessian_nonzeros=hp.nnz,constraint_nonzeros=cp.nnz)
        if finite:
            groups={'dynamics':(0,m),'cost_residual':(m,m+r),'physical_step_box':(m+r,m+r+n),
                    'physical_capture_node':(m+r+n,c.shape[0]-2*m),'slack_nonnegative':(c.shape[0]-2*m,c.shape[0])}
            record['original_coordinate_bound_violation']={name:violation(c,physical,*bounds) for name,bounds in groups.items()}
            record['transformed_bound_violation']=violation(cp,solved.x,0,c.shape[0])
            record['original_scaled_qp_objective']=float(.5*physical@(h@physical)+q@physical)
            record['transformed_scaled_qp_objective']=float(.5*solved.x@(hp@solved.x)+qp@solved.x)
            record['maximum_physical_state_step']=float(np.max(np.abs(physical[:m])))
            record['maximum_physical_control_step']=float(np.max(np.abs(physical[m:n])))
        solution=out/(label+'_solution.npz')
        np.savez_compressed(solution,solver_coordinates=solved.x,physical_coordinates=physical)
        record['solution']=file_metadata(solution);records.append(record)
        dump_json(dict(not_solution=True,benchmark_evidence=False,records=records),out/'progress.json')
        print(json.dumps(record),flush=True)
    dump_json(dict(not_solution=True,benchmark_evidence=False,physical_replay_performed=False,
        runtime=runtime_metadata(),qp_metadata=file_metadata(source/'metadata.json'),parameters=vars(args),records=records,
        scope='One fixed archived first-QP. Same objective scale, tolerances, iteration budget and physical constraint values. Expanded solver equilibration and reversible MP cost-block step coordinates are separate named cases. Native statuses are not overridden. Report original-coordinate residuals and physical step limits independently; native convergence is not a hanging-start or robustness gate.'),out/'result.json')
if __name__=='__main__':main()
