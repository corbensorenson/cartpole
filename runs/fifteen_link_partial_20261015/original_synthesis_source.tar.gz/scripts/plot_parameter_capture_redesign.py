"""Plot matched local gain designs; no new physics or basin inference."""
import argparse,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from gcartpole.evidence import file_metadata

LABELS=('Original','Length −5%','Length +5%','Hub 5 cm','Hub 15 cm','Length +5%, hub 15 cm')


def main():
    p=argparse.ArgumentParser();p.add_argument('--result',required=True);args=p.parse_args()
    path=Path(args.result);d=json.loads(path.read_text());assert len(d['records'])==24
    out=path.parent/'figures';out.mkdir(exist_ok=True);figures=[]
    fig,axes=plt.subplots(2,2,figsize=(13,9),sharex=True,sharey=True)
    for n,ax in zip(d['counts'],axes.flat):
        rows=[r for r in d['records'] if r['n_links']==n];values=np.array([
            [sum(e['local_full_episode_gate_passed'] for e in r['episodes'] if e['amplitude']==a)
             for a in d['amplitudes']] for r in rows])
        ax.imshow(values,origin='upper',vmin=0,vmax=2,cmap='viridis',aspect='auto')
        for i in range(6):
            for j in range(3):ax.text(j,i,f'{values[i,j]}/2',ha='center',va='center',color='black' if values[i,j]==2 else 'white')
        ax.set_yticks(range(6),LABELS,fontsize=9);ax.set_xticks(range(3),['10⁻⁵','10⁻⁹','10⁻¹³'])
        ax.set_title(f'{n} links');ax.tick_params(labelleft=True)
    for ax in axes[1]:ax.set_xlabel('Paired relative angle/rate amplitude')
    fig.suptitle('Geometry with redesigned maintenance feedback: local 30 s passes',fontsize=16)
    fig.tight_layout(rect=[0,.12,1,.94])
    fig.text(.06,.075,'Two paired physical directions per cell. Shared cost, plant-specific MP100 gain design; native binary64 RK4/F32 action.',fontsize=10)
    fig.text(.06,.048,'Starts near upright; no hanging-start solves or certified basin widths. Nonzero hubs add equal total mass of 0.1 kg.',fontsize=10)
    fig.text(.06,.021,'A local pass requires ≥5 s upright, the full 30 s episode, clean simulation and the original ±3 m rail.',fontsize=10)
    for ext in ('png','pdf'):
        f=out/f'local_capture_pass_map.{ext}';fig.savefig(f,dpi=180);figures.append(file_metadata(f))
    plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(12,5))
    for index,label in enumerate(LABELS):
        rows=[next(r for r in d['records'] if r['n_links']==n and
             [r['length_scale'],r['hub_diameter_m']]==d['choices'][index]) for n in d['counts']]
        gains=[r['design_diagnostics']['gain_norm'] for r in rows]
        ratios=[g/next(r for r in d['records'] if r['n_links']==n and r['length_scale']==1. and r['hub_diameter_m']==0.)['design_diagnostics']['gain_norm']
                for n,g in zip(d['counts'],gains)]
        axes[0].plot(d['counts'],gains,'o-',label=label);axes[1].plot(d['counts'],ratios,'o-',label=label)
    axes[0].set_yscale('log');axes[0].set_ylabel('Gain Euclidean norm in fixed physical coordinates')
    axes[1].set_ylabel('Gain norm / same-count no-hub baseline');axes[1].axhline(1,color='gray',lw=.6)
    for ax in axes:ax.set_xlabel('Link count');ax.set_xticks(d['counts']);ax.grid(alpha=.15)
    fig.suptitle('Geometry changes required feedback gains without removing count scaling',fontsize=15)
    fig.legend(*axes[0].get_legend_handles_labels(),loc='lower center',ncol=3,bbox_to_anchor=(.5,.04),fontsize=9)
    fig.tight_layout(rect=[0,.19,1,.91]);fig.text(.06,.013,'Norm is coordinate-dependent; its reciprocal is an initial nonsaturation diagnostic, not a nonlinear capture radius.',fontsize=9)
    for ext in ('png','pdf'):
        f=out/f'redesigned_gain_relationships.{ext}';fig.savefig(f,dpi=180);figures.append(file_metadata(f))
    plt.close(fig)
    summary=dict(source=file_metadata(path),script=file_metadata(__file__),figures=figures,native_transition_calls=0,
                 successes=sum(e['local_full_episode_gate_passed'] for r in d['records'] for e in r['episodes']))
    (out/'figures.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))


if __name__=='__main__':main()
