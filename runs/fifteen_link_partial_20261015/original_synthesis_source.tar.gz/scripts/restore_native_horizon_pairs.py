#!/usr/bin/env python
"""Replay a failed continuation, then test coordinated delivered-F32 changes."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.ilqr import MujocoTransition
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.native_action_lattice import affine_action_lattice
from gcartpole.native_action_pairs import balanced_action_pairs,balanced_action_triples,balanced_action_quadruples,rank_pairs_by_physical_bounds
from gcartpole.native_sparse_stream import stream_balanced_actions,stratified_balanced_actions
from gcartpole.native_bound_objective import bound_diagnostics,native_bound_score
from gcartpole.native_task_derivatives import physical_task_residual,chained_physical_task_jacobian
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    p.add_argument('--rounds',type=int,default=4);p.add_argument('--candidates-per-round',type=int,default=5000)
    p.add_argument('--planning-transition-budget',type=int,default=800000)
    p.add_argument('--amplitudes',nargs='+',type=int,default=[1,2,4,8,16])
    p.add_argument('--center-from-stage',action='store_true')
    p.add_argument('--constraint-ranking',action='store_true')
    p.add_argument('--forecast-angle-limit',type=float,default=.14)
    p.add_argument('--initial-center-source')
    p.add_argument('--move-arity',type=int,choices=list(range(2,9)),default=2)
    p.add_argument('--max-support-span',type=int,default=12)
    p.add_argument('--stream-proposals',action='store_true')
    p.add_argument('--max-model-proposals',type=int,default=500000)
    p.add_argument('--max-supports',type=int,default=12000)
    p.add_argument('--keep-proposals',type=int,default=5000)
    p.add_argument('--proposal-batch-size',type=int,default=128)
    p.add_argument('--support-spans',nargs='+',type=int)
    p.add_argument('--cancelled-response-rank',type=int)
    p.add_argument('--bound-objective',choices=['sum','maximum'],default='sum')
    p.add_argument('--coupled-null-supports',type=int,default=0)
    p.add_argument('--coupled-null-solver-seconds',type=float,default=.2)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    if min(args.rounds,args.candidates_per_round,args.planning_transition_budget)<1:raise ValueError('positive budgets required')
    if args.stream_proposals:
        if not args.constraint_ranking or args.move_arity<3:raise ValueError('streamed proposals require unbanded constraint ranking and arity >=3')
        if min(args.max_model_proposals,args.max_supports,args.keep_proposals,args.proposal_batch_size)<1:raise ValueError('positive stream budgets required')
    elif args.move_arity>4:raise ValueError('arity >4 requires streamed proposals')
    if args.bound_objective!='sum' and not args.stream_proposals:raise ValueError('maximum objective requires streamed constraint ranking')
    if (args.coupled_null_supports<0 or not np.isfinite(args.coupled_null_solver_seconds)
            or args.coupled_null_solver_seconds<=0
            or args.coupled_null_supports and (not args.stream_proposals or args.bound_objective!='maximum'
                or args.cancelled_response_rank is None or args.cancelled_response_rank>=args.move_arity-1)):
        raise ValueError('coupled null LPs require maximum streaming with extra null freedom and bounded budgets')
    if args.cancelled_response_rank is not None and (not args.stream_proposals
            or not 1<=args.cancelled_response_rank<args.move_arity):
        raise ValueError('rank selection requires streaming and rank below arity')
    if args.support_spans and (not args.stream_proposals or args.support_spans!=sorted(set(args.support_spans))
            or min(args.support_spans)<args.move_arity-1
            or max(args.support_spans)>args.max_support_span
            or min(args.max_supports,args.max_model_proposals,args.keep_proposals)<len(args.support_spans)):
        raise ValueError('stratification requires streaming,ordered unique spans and positive per-span quotas')
    if not np.isfinite(args.forecast_angle_limit) or not .1<args.forecast_angle_limit<.15:raise ValueError('planner angle bound must lie strictly between dead zone and canonical limit')
    source=json.loads(Path(args.source).read_text())
    if source['stages'][-1]['feasible_sequence_found']:raise ValueError('first failed continuation required')
    original=source;ancestry=[];seen_paths=set()
    while not all(k in original for k in ('config','teacher','parameters')):
        metadata=original['source'];path=metadata['path']
        if path in seen_paths or len(ancestry)>=8 or file_metadata(path)!=metadata:raise ValueError('input ancestry changed or is cyclic')
        seen_paths.add(path);ancestry.append(metadata);original=json.loads(Path(path).read_text())
    for key in ('source','config','teacher'):
        if file_metadata(original[key]['path'])!=original[key]:raise ValueError('bound physical inputs changed')
    base=json.loads(Path(original['source']['path']).read_text());teacher=json.loads(Path(original['teacher']['path']).read_text())
    cfg=load_config(original['config']['path']);n=cfg['env']['n_links'];nx=2*(n+1)
    step=original['parameters']['start_step'];rate=original['parameters']['rate_residual_weight']
    known=np.asarray(source['last_valid_plan'],np.float32).astype(float);known_states=np.asarray(source['last_valid_forecast_states'])
    stage=source['stages'][-1];horizon=stage['horizon_steps']
    if horizon!=len(known)+1:raise ValueError('one-tick failing horizon required')
    reference=np.asarray(base['controller']['controls'][step:step+horizon],np.float32).astype(float)
    delivered=np.asarray([r['action'] for r in teacher['result']['trajectory']],np.float32).astype(float)
    if len(reference)!=horizon or len(delivered)<=step+horizon-1:raise ValueError('unpadded actual seeds required')
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True);local=FourthOrderMujocoTransition(env,np.eye(nx),continuous_angles=True)
    untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()];began=time.monotonic();rounds=[]
    def forecast(state,actions):
        current=state.copy();states=[]
        for u in actions:current=native(current,float(u));states.append(current.copy())
        return np.asarray(states)
    def measure(states,actions,limit=None,objective=None):
        limit=args.forecast_angle_limit if limit is None else limit
        objective=args.bound_objective if objective is None else objective
        diagnostics=bound_diagnostics(states,n,limit,env.rail_limit)
        r=physical_task_residual(states,n,rate,.1);cost=float(r@r+1e-4*np.sum((actions-reference)**2))
        return native_bound_score(diagnostics,cost,objective),diagnostics['feasible'],diagnostics['maximum_angle']
    payload=dict(not_solution=True,canonical_release_evidence=False,source=file_metadata(args.source),parameters=vars(args),runtime=runtime_metadata(),
        rounds=rounds,actual_episode_steps=0,optimizer_transition_calls=0,reserved_seeds_used=False,noisy_development_seeds_used=False,
        input_ancestry=ancestry,
        scope=f'Independently replay cold prefix,known valid plan and last failed finite center;verify original source score before new search settings. Native4/MP100 task Jacobian proposes {args.move_arity} delivered action changes using leading scaled singular-response cancellation. Two-input proposals also include direct one-ULP pairs;higher-input proposals use restricted temporal supports and rounded real null directions. Streaming optionally bounds model proposals, supports, batches and retained candidates. Predicted task cost or optional hard-bound violation rank candidates;native declared-bound admissibility/violations/task cost decide acceptance. Canonical threshold remains0.15. No actual policy,global infeasibility or record is inferred.')
    try:
        state=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
        for row in base['result']['trajectory'][:step]:
            state=native(state,float(np.float32(row['action'])))
            if state.tobytes()!=np.asarray(row['qpos']+row['qvel']).tobytes():raise ValueError('cold prefix changed')
        replay=forecast(state,known)
        if replay.tobytes()!=known_states.tobytes():raise ValueError('known native plan changed')
        source_limit=float(source['parameters'].get('forecast_angle_limit',.14))
        source_objective=source['parameters'].get('bound_objective','sum')
        if args.center_from_stage:
            center=np.asarray(stage['last_finite_sequence'],np.float32).astype(float)
        else:
            seeds=[]
            for u in dict.fromkeys([float(reference[-1]),0.,float(delivered[step+horizon-1])]):
                actions=np.r_[known,np.float32(u)].astype(np.float32).astype(float)
                states=np.vstack([known_states,native(known_states[-1],float(actions[-1]))])
                score,found,maximum=measure(states,actions,source_limit,source_objective);seeds.append((score,actions,states,found,maximum))
            score,center,states,found,maximum=min(seeds,key=lambda s:s[0])
            for r in stage['rounds']:
                if not r['improved']:continue
                i=r['changed_coordinate'];offset=r['offset_ulps'];radius=r['radius_ulps']
                spacing,lower,upper=affine_action_lattice(center,radius)
                if not lower[i]<=offset<=upper[i]:raise ValueError('saved coordinate change is outside its delivered grid')
                center[i]+=spacing[i]*offset
        states=forecast(state,center);old_score,_,maximum=measure(states,center,source_limit,source_objective)
        if list(old_score)!=stage['score'] or maximum!=stage['maximum_angle']:raise ValueError('failed finite center score does not reproduce exactly')
        if args.center_from_stage and states.tobytes()!=np.asarray(stage['last_finite_forecast_states']).tobytes():raise ValueError('failed-stage forecasts do not reproduce every byte')
        score,found,maximum=measure(states,center)
        if args.initial_center_source:
            override=json.loads(Path(args.initial_center_source).read_text())
            if (override['source']!=file_metadata(args.source) or override['horizon_steps']!=horizon
                    or not override['known_plan_byte_identical'] or not override['live_state_unchanged']):
                raise ValueError('source-aligned independently verified finite center required')
            center=np.asarray(override['last_finite_center'],np.float32).astype(float)
            if center.shape!=(horizon,) or np.any(np.abs(center)>1):raise ValueError('finite center shape/bounds differ')
            states=forecast(state,center)
            override_score,_,_=measure(states,center,override['parameters']['forecast_angle_limit'],override['parameters'].get('bound_objective','sum'))
            if (states.tobytes()!=np.asarray(override['last_finite_states']).tobytes()
                    or list(override_score)!=override['last_finite_score']):raise ValueError('override states/score do not reproduce exactly')
            payload.update(initial_center_source=file_metadata(args.initial_center_source),override_center_states_and_score_exact=True)
            score,found,maximum=measure(states,center)
        payload.update(source_prefix_byte_identical=True,known_plan_byte_identical=True,failed_center_score_exactly_reproduced=True,
            horizon_steps=horizon,initial_sequence=center.tolist(),initial_score=list(score),initial_maximum_angle=maximum,
            native_prefix_and_initial_forecast_transition_calls=native.evaluations)
        planning_before=native.evaluations;seen={center.tobytes()};status='round_limit'
        for index in range(args.rounds):
            if found:status='feasible_plan_found';break
            before=native.evaluations;derivative_before=local.evaluations;started=time.monotonic()
            band=0. if args.constraint_ranking else .1
            residual=physical_task_residual(states,n,rate,band)
            jac=chained_physical_task_jacobian(local,state,center,states,n_links=n,rate_weight=rate,
                state_epsilon=base['controller']['state_epsilon'],action_epsilon=base['controller']['action_epsilon'],angle_band=band)
            if args.stream_proposals:
                generator=stratified_balanced_actions if args.support_spans else stream_balanced_actions
                support_settings=(dict(support_spans=args.support_spans) if args.support_spans
                                  else dict(max_support_span=args.max_support_span))
                proposals,model=generator(center,jac,residual,reference,arity=args.move_arity,
                    cancelled_rank=args.cancelled_response_rank,
                    bound_objective=args.bound_objective,
                    coupled_null_supports=args.coupled_null_supports,
                    coupled_null_solver_seconds=args.coupled_null_solver_seconds,
                    states=states,n_links=n,angle_limit=args.forecast_angle_limit,rail_limit=env.rail_limit,
                    amplitudes=tuple(args.amplitudes),**support_settings,
                    max_supports=args.max_supports,max_model_proposals=args.max_model_proposals,
                    keep_proposals=args.keep_proposals,batch_size=args.proposal_batch_size)
            elif args.move_arity==4:
                proposals,model=balanced_action_quadruples(center,jac,residual,reference,amplitudes=tuple(args.amplitudes),max_support_span=args.max_support_span)
            elif args.move_arity==3:
                proposals,model=balanced_action_triples(center,jac,residual,reference,amplitudes=tuple(args.amplitudes),max_support_span=args.max_support_span)
            else:proposals,model=balanced_action_pairs(center,jac,residual,reference,amplitudes=tuple(args.amplitudes))
            if args.constraint_ranking and not args.stream_proposals:proposals=rank_pairs_by_physical_bounds(proposals,model['spacing'],jac,states,
                n_links=n,angle_limit=args.forecast_angle_limit,rail_limit=env.rail_limit)
            spacing=np.asarray(model['spacing']);best=None;tested=invalid=0;prediction_for_best=None
            minimum_inrail_angle=maximum;canonical_admissible_candidates=0
            for proposal in proposals:
                if tested>=args.candidates_per_round:break
                indices=proposal['indices'];i=indices[0];actions=center.copy();actions[indices]+=spacing[indices]*proposal['offsets_ulps'];key=actions.tobytes()
                if key in seen:continue
                if native.evaluations-planning_before+horizon-i>args.planning_transition_budget:status='planning_transition_budget';break
                seen.add(key);tested+=1
                if actions.tobytes()!=actions.astype(np.float32).astype(float).tobytes():raise ValueError('sparse proposal is not delivered F32')
                try:
                    tail=forecast(state if i==0 else states[i-1],actions[i:]);candidate=np.vstack([states[:i],tail])
                    new_score,feasible,angle=measure(candidate,actions)
                except SimulationError:invalid+=1;continue
                if np.all(np.abs(candidate[:,0])<=env.rail_limit):
                    minimum_inrail_angle=min(minimum_inrail_angle,angle)
                    canonical_admissible_candidates+=angle<.15
                if new_score<score and (best is None or new_score<best[0]):best=(new_score,actions,candidate,feasible,angle);prediction_for_best=proposal
                if feasible:break
            improved=best is not None
            if improved:score,center,states,found,maximum=best
            rounds.append(dict(round=index,improved=improved,feasible_plan_found=found,score=list(score),maximum_angle=maximum,
                tested_candidates=tested,invalid_candidates=invalid,proposal_model=model,selected_proposal=prediction_for_best,
                minimum_tested_inrail_maximum_angle=minimum_inrail_angle,canonical_angle_admissible_candidates=int(canonical_admissible_candidates),
                native_planning_transition_calls=native.evaluations-before,native_local_derivative_transition_calls=local.evaluations-derivative_before,
                wall_seconds=time.monotonic()-started))
            payload.update(last_finite_center=center.tolist(),last_finite_score=list(score),feasible_sequence_found=found,
                native_forecast_transition_calls=native.evaluations,native_local_derivative_transition_calls=local.evaluations,
                total_native_transition_calls=native.evaluations+local.evaluations,wall_seconds=time.monotonic()-began)
            dump_json(payload,out/'result.progress.json')
            print(json.dumps({k:rounds[-1][k] for k in ['round','improved','feasible_plan_found','score','maximum_angle','tested_candidates','native_planning_transition_calls']}),flush=True)
            if status=='planning_transition_budget':break
            if not improved:status='no_improving_tested_sparse_move';break
        checked=forecast(state,center)
        if checked.tobytes()!=states.tobytes() or measure(checked,center)[0]!=score:raise ValueError('selected finite sparse center failed independent whole-plan byte replay')
        if untouched.tobytes()!=np.r_[env.data.qpos,env.data.qvel].tobytes():raise ValueError('planner changed live state')
        payload.update(status='feasible_plan_found' if found else status,feasible_sequence_found=found,
            selected_sequence=center.tolist() if found else None,selected_states=states.tolist() if found else None,
            last_finite_center=center.tolist(),last_finite_states=states.tolist(),last_finite_score=list(score),
            independent_last_finite_plan_replay_transition_calls=horizon,live_state_unchanged=True,
            native_planning_transition_calls=native.evaluations-planning_before-horizon,
            native_forecast_transition_calls=native.evaluations,native_local_derivative_transition_calls=local.evaluations,
            total_native_transition_calls=native.evaluations+local.evaluations,wall_seconds=time.monotonic()-began)
        dump_json(payload,out/'result.json')
    finally:env.close()


if __name__=='__main__':main()
