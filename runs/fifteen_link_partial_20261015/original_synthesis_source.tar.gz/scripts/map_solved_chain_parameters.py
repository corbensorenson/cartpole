"""Factorial physical-parameter map on solved counts with frozen released policies.

Transfer sensitivity only; resynthesis is a separate next-stage experiment.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import time
import mujoco
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,data_sha256,utc_timestamp,runtime_metadata
from gcartpole.generalized_energy import hanging_lqr_gain
from gcartpole.generalized_modes import chain_normal_modes
from gcartpole.ilqr import MujocoTransition
from gcartpole.angles import wrap_angle
from gcartpole.upright_mechanics import upright_rk4_matrices
from scripts.evaluate_fddp_parked_route import run_episode,zero_noise_config
from scripts.evaluate_fddp_two_expert import load_controller,run_episode as legacy_episode
from scripts.search_swingup_capture import lqr_gain

WORDS=('seven','eight','nine','ten','eleven','twelve','thirteen','fourteen')


def release_inputs(n):
    folder=Path(f'runs/swingup{n}_uniform' if n==7 or n>=11 else 'runs/generalized_solver')
    path=folder/(WORDS[n-7]+'_link_swingup_manifest.json')
    manifest=json.loads(path.read_text())
    if n>=11:
        policy=json.loads(Path(manifest['policy']['path']).read_text())
        assert file_metadata(manifest['policy']['path'])['sha256']==manifest['policy']['sha256']
        config=policy['config']['path'];control=policy['controller']['path']
        parameters=policy['parameters'];gain=np.asarray(policy['capture_gain']);settle=np.asarray(policy['settle_gain'])
        design_calls=0
    else:
        policy=None;config=manifest['benchmark']['config'];control=manifest['controller']['path']
        e=manifest['experts'];parameters=dict(park_seconds=e['conditioning']['duration_seconds'],
            cart_target=e['conditioning'].get('cart_target_m',0.),tracking_gain_scale=e['swing']['tracking_gain_scale'])
        baseline=load_config(config)
        c=load_controller(Path(control),n,load_config('benchmarks/p1_capture_envelope.yaml'))
        gain=lqr_gain(baseline,progress=1.,fd_eps=1e-7,control_cost=c['lqr_control_cost'],
            q_weights=c['lqr_weights'],decimal_digits=c['lqr_decimal_digits'])
        design_calls=4*(n+1)+2
        if n==7:settle=np.asarray(e['conditioning']['gain'])
        else:
            env=NLinkCartPoleEnv(baseline,progress=1.,seed=0)
            try:settle=hanging_lqr_gain(env,control_cost=1000.,cart_position_cost=.1,cart_velocity_cost=.1)
            finally:env.close()
            design_calls+=4*(n+1)+2
    assert file_metadata(control)['sha256']==(policy['controller'] if policy else manifest['controller'])['sha256']
    controller=load_controller(Path(control),n,load_config('benchmarks/p1_capture_envelope.yaml'))
    assert controller['defer_handoff_until_horizon']
    return load_config(config),controller,gain,settle,parameters,dict(
        manifest=file_metadata(path),controller=file_metadata(control),config=file_metadata(config),
        policy=None if policy is None else file_metadata(manifest['policy']['path']),
        parameters=parameters,capture_gain=gain.tolist(),settle_gain=settle.tolist(),
        reconstruction_transition_calls=design_calls,
        gain_scope='Saved frozen gains for11--14; original canonical-design reconstruction for7--10, held fixed across all altered plants.')


def physical_metrics(cfg):
    env=NLinkCartPoleEnv(cfg,progress=1.,seed=0);env.reset(seed=0)
    try:
        modes=chain_normal_modes(env);a,b,mechanics=upright_rk4_matrices(env,decimal_digits=100)
        inertia=[]
        for quat,principal in zip(env.model.body_iquat[2:],env.model.body_inertia[2:]):
            rotation=np.zeros(9);mujoco.mju_quat2Mat(rotation,quat)
            inertia.append(float(np.sum(rotation.reshape(3,3)[1]**2*principal)))
        own=np.asarray(inertia)+env.model.body_mass[2:]*np.sum(env.model.body_ipos[2:][:,[0,2]]**2,axis=1)
        return dict(individual_link_length_m=float(env.morphology.lengths[0]),
            total_chain_mass_kg=float(np.sum(env.model.body_mass[2:])),
            rod_total_mass_kg=float(env.morphology.total_mass),
            actual_hub_diameter_m=2*float(cfg['env'].get('joint_hub_radius',0.)),
            capsule_diameter_to_spacing=float(2*cfg['env']['link_radius']/env.morphology.lengths[0]),
            hub_diameter_to_spacing=float(2*cfg['env'].get('joint_hub_radius',0.)/env.morphology.lengths[0]),
            hinge_armature_to_own_body_inertia=float(env.model.dof_armature[1]/own[0]),
            fastest_hanging_frequency_hz=float(np.max(modes.angular_frequencies)/(2*np.pi)),
            weakest_normalized_hanging_input_coupling=float(np.min(np.abs(modes.normalized_coupling))),
            hanging_mass_matrix_condition=float(np.linalg.cond(modes.joint_mass_matrix)),
            upright_maximum_open_loop_tick_growth_binary64_eigenvalues=float(np.max(np.abs(np.linalg.eigvals(np.asarray(a.tolist(),float))))),
            xml_sha256=hashlib.sha256(env.xml.encode()).hexdigest(),mechanics=mechanics,
            scope='Native compiled mass/COM/inertia. Hanging metrics and own-body inertia ratios are coordinate-specific diagnostics, not capture certificates.')
    finally:env.close()


def episode(cfg,controller,gain,settle,parameters,n,noise,path):
    seed=20261030
    ecfg=copy.deepcopy(cfg) if noise else zero_noise_config(cfg)
    initial_env=NLinkCartPoleEnv(ecfg,progress=1.,seed=seed);initial_env.reset(seed=seed)
    initial=np.r_[initial_env.data.qpos,initial_env.data.qvel].copy();initial_env.close()
    if n==7:
        result=legacy_episode(ecfg,controller,gain,seed=seed,episode=0,
            tracking_gain_scale=parameters['tracking_gain_scale'],prelude_steps=round(parameters['park_seconds']/.02),
            settle_mode='hanging_lqr',settle_gain=settle,settle_scale=1.,phase_adaptive=False,
            phase_window=12,shift_cart_nominal=True,include_trajectory=True)
    else:
        result=run_episode(ecfg,controller,gain,settle,seed=seed,park_seconds=parameters['park_seconds'],
            cart_target=parameters['cart_target'],tracking_gain_scale=parameters['tracking_gain_scale'],
            phase_adaptive=False,phase_window=12,include_trace=True)
    trace=result['trajectory'];actions=np.asarray([r.get('action',r.get('applied_action')) for r in trace],np.float32).astype(float)
    states=np.vstack([initial,[r['qpos']+r['qvel'] for r in trace]])
    env=NLinkCartPoleEnv(ecfg,progress=1.,seed=seed);env.reset(seed=seed)
    native=MujocoTransition(env,np.eye(2*(n+1)),continuous_angles=True)
    try:
        for i,u in enumerate(actions):assert native(states[i],float(u)).tobytes()==states[i+1].tobytes()
        proof=native.evaluations
    finally:env.close()
    assert proof==len(actions)==result['length']
    np.savez_compressed(path,states=states,actions=actions)
    phases=[r.get('phase',r.get('mode')) for r in trace]
    arrival=result.get('route_state')
    if arrival is None:
        arrival_max_angle=arrival_rate=None
    else:
        arrival_max_angle=float(np.max(np.abs(wrap_angle(np.cumsum(np.asarray(arrival['qpos'])[1:])))))
        arrival_rate=float(np.sqrt(np.mean(np.cumsum(np.asarray(arrival['qvel'])[1:])**2)))
    passed=bool(result['success'] and result['length']==1500 and result['termination_reason']=='time_limit'
        and result['max_upright_streak_seconds']>=5 and result['max_cart_excursion']<=3
        and not result['final_info'].get('simulation_error'))
    return dict(noisy_start=noise,seed=seed,initial_state=initial.tolist(),
        full_episode_gate_passed=passed,hold_seconds=result['max_upright_streak_seconds'],
        steps=result['length'],termination_reason=result['termination_reason'],
        maximum_cart=result['max_cart_excursion'],force_saturation_ticks=int(np.sum(np.abs(actions)>=1.)),
        capture_saturation_ticks=int(sum(abs(u)>=1. and ph=='capture_lqr' for u,ph in zip(actions,phases))),
        arrival_maximum_angle=arrival_max_angle,arrival_absolute_rate_rms=arrival_rate,
        tape=file_metadata(path),independent_tape_replay_bytes_exact=True,
        actual_episode_steps=len(actions),independent_tape_replay_transition_calls=proof,
        total_native_transition_calls=len(actions)+proof)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--directory',required=True)
    args=parser.parse_args();out=Path(args.directory)
    if out.exists():raise FileExistsError(out)
    out.mkdir(parents=True);(out/'tapes').mkdir();(out/'configs').mkdir()
    payload=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),runtime=runtime_metadata(),
        length_scales=[.95,1.,1.05],hub_diameters_m=[0.,.05,.10,.15],counts=list(range(7,15)),
        total_added_hub_mass_kg=.1,hub_mass_policy='Fixed0.1kg added across all nonzero diameters,1kg rods. Baseline nohub=1kg; hub plants=1.1kg. Radius comparisons within nonzero columns isolate radius at fixed mass/COM; baseline comparison also changes mass distribution.',
        releases=[],records=[],actual_episode_steps=0,independent_tape_replay_transition_calls=0,
        gain_reconstruction_transition_calls=0,total_native_transition_calls=0,native_transition_ceiling=576286,
        canonical_release_evidence=False,not_solution=True,reserved_seeds_used=False,
        fifteen_noisy_development_seeds_used=False,
        scope='First-stage transfer map on solved7--14. Fixed released controller/gains/settings on physical length/hub factorial. Paired exact/noisy diagnostics, not canonical cohorts. Failure means lack of transfer, not failure of a resynthesized solver or physical impossibility. Preserve all release artifacts.')
    began=time.monotonic()
    for n in range(7,15):
        baseline,controller,gain,settle,parameters,release=release_inputs(n)
        payload['releases'].append(release);payload['gain_reconstruction_transition_calls']+=release['reconstruction_transition_calls']
        baseline['env']['init_mode']='hanging';baseline['env']['action_lqr_residual']={'enabled':False}
        baseline['env']['action_lqr_switch']={'enabled':False}
        paired_initial={}
        # Canonical control first, so failure is visible before altered cases.
        choices=[(1.,0.)]+[(s,d) for s in payload['length_scales'] for d in payload['hub_diameters_m'] if (s,d)!=(1.,0.)]
        for index,(length_scale,diameter) in enumerate(choices):
            cfg=copy.deepcopy(baseline);cfg['env']['total_length']=3*length_scale
            if diameter:
                cfg['env'].update(joint_hub_radius=diameter/2,joint_hub_mass=.1/n,joint_hub_half_width=.0125)
            else:
                for k in ('joint_hub_radius','joint_hub_mass','joint_hub_half_width'):cfg['env'].pop(k,None)
            tag=f'n{n}_l{length_scale:.2f}_d{diameter:.2f}'
            config_path=out/'configs'/f'{tag}.json';dump_json(cfg,config_path)
            metrics=physical_metrics(cfg);episodes=[]
            for noise in (False,True):
                row=episode(cfg,controller,gain,settle,parameters,n,noise,out/'tapes'/f'{tag}_{int(noise)}.npz')
                initial=np.asarray(row['initial_state'])
                if noise in paired_initial:assert initial.tobytes()==paired_initial[noise]
                else:paired_initial[noise]=initial.tobytes()
                episodes.append(row)
                payload['actual_episode_steps']+=row['actual_episode_steps']
                payload['independent_tape_replay_transition_calls']+=row['independent_tape_replay_transition_calls']
            record=dict(n_links=n,length_scale=length_scale,hub_diameter_m=diameter,config=file_metadata(config_path),
                mechanics=metrics,episodes=episodes,canonical_control=(length_scale,diameter)==(1.,0.),
                initial_states_paired_byte_exact=True)
            payload['records'].append(record)
            payload['total_native_transition_calls']=payload['actual_episode_steps']+payload['independent_tape_replay_transition_calls']+payload['gain_reconstruction_transition_calls']
            assert payload['total_native_transition_calls']<=payload['native_transition_ceiling']
            dump_json(payload,out/'result.progress.json')
            print(json.dumps(dict(n=n,length_scale=length_scale,diameter=diameter,
                passes=[r['full_episode_gate_passed'] for r in episodes],holds=[r['hold_seconds'] for r in episodes],
                records=len(payload['records']),calls=payload['total_native_transition_calls'])),flush=True)
    assert len(payload['records'])==96 and payload['gain_reconstruction_transition_calls']==286
    payload.update(wall_seconds=time.monotonic()-began)
    dump_json(payload,out/'result.json')


if __name__=='__main__':main()
