"""Audit nearby-plant physical-route continuation without new integration."""
import argparse,json
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import dump_json,load_config
from gcartpole.evidence import file_metadata,utc_timestamp


def read(p):return json.loads(Path(p).read_text())
def checked(r):assert file_metadata(r['path'])==r,r['path']
def journal(folder):
    j=read(folder/'execution.json');assert j['status']=='finished' and j['returncode']==0
    for r in j['frozen_inputs']:assert file_metadata(folder/'snapshot'/r['path'])['sha256']==r['sha256']
    return file_metadata(folder/'execution.json')
def tape(row,n=14):
    checked(row['tape']);r=np.load(row['tape']['path']);x=r['states'];u=r['actions']
    assert x.shape==(len(u)+1,2*(n+1)) and np.all(np.isfinite(x)) and np.all(np.isfinite(u))
    assert np.array_equal(u,u.astype(np.float32).astype(float)) and max(abs(u))<=1
    assert len(u)==row['actual_hanging_start_episode_steps']==row['independent_tape_replay_transition_calls']
    assert row['independent_whole_actual_tape_bytes_exact']
    good=np.max(abs(wrap_angle(np.cumsum(x[1:,1:n+1],axis=1))),axis=1)<.15
    streak=maximum=0
    for g in good:streak=streak+1 if g else 0;maximum=max(maximum,streak)
    assert maximum*.02==row['result']['max_upright_streak_seconds']
    assert np.max(abs(x[:,0]))==row['result']['max_cart_excursion']
    gate=bool(len(u)==1500 and maximum>=250 and np.max(abs(x[:,0]))<=3 and row['result']['termination_reason']=='time_limit')
    assert gate==row['full_nominal_component_gate_passed']
    return x,u,gate


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',required=True);args=p.parse_args();root=Path(args.directory)
    source_path='runs/armature_route_continuation_20261003/armature0.99_passing_physical_initializer.json';source=read(source_path)
    source_config=load_config(root/'armature0.99.json');target_config=load_config(root/'armature0.98.json')
    assert source_config['env']['joint_armature']==.0005*.99 and target_config['env']['joint_armature']==.0005*.98
    compare=load_config(root/'armature0.98.json');compare['env']['joint_armature']=source_config['env']['joint_armature'];assert compare==source_config
    studies=[];total=actual=0
    for name in ('source0.99_replay','armature0.98_repair8'):
        folder=root/name;e=journal(folder);d=read(folder/'diagnostic/result.json');assert d['status']=='finished'
        for key in ('config','initializer','candidate'):checked(d[key])
        assert d['initializer']==file_metadata(source_path)
        assert d['partial_transition_substeps']==0 and d['native_physics_substeps']==4*d['total_native_transition_calls']
        assert d['total_native_transition_calls']<=d['native_transition_ceiling']
        x,u,gate=tape(d)
        candidate=read(d['candidate']['path']);assert candidate['selected_state']==source['selected_state']
        assert candidate['controller']['horizon_steps']==700 and candidate['controller']['frozen_prefix_steps']==0
        assert candidate['controller']['coordinate_transform']==np.eye(30).tolist()
        assert len(u)==candidate['result']['length']
        assert x[1:].tobytes()==np.array([r['qpos']+r['qvel'] for r in candidate['result']['trajectory']]).tobytes()
        if name=='source0.99_replay':
            old=np.load(source['passing_tape']['path']);checked(source['passing_tape'])
            assert gate and x.tobytes()==old['states'].tobytes() and u.tobytes()==old['actions'].tobytes()
            assert d['optimizer_iterations']==0
        else:assert d['optimizer_iterations']==8 and d['entire_horizon_free']
        studies.append(dict(directory=str(folder),execution=e,result=file_metadata(folder/'diagnostic/result.json'),
            tape=d['tape'],candidate=d['candidate'],config=d['config'],initializer=d['initializer'],
            full_nominal_component_gate_passed=gate,hold_seconds=d['result']['max_upright_streak_seconds'],
            total_native_transition_calls=d['total_native_transition_calls'],actual_hanging_start_episode_steps=len(u),
            maximum_model_defect=candidate['controller']['final_trajectory_diagnostics']['maximum_dynamics_defect']))
        total+=d['total_native_transition_calls'];actual+=len(u)
    versions={};passing=[]
    for variant in ('unoptimized','optimized'):
        folder=root/f'armature0.98_{variant}_native_defect_feedback';e=journal(folder);d=read(folder/'diagnostic/result.json');assert d['status']=='finished'
        for key in ('source','config','reference'):checked(d[key])
        assert d['config']==file_metadata(root/'armature0.98.json')
        assert d['native_reference_design_calls']==88900 and d['upright_gain_design_calls']==62
        assert d['partial_transition_substeps']==0 and d['native_physics_substeps']==4*d['total_native_transition_calls']
        prior=read(d['source']['path']);versions[variant]=prior
        reference=np.load(d['reference']['path'])
        assert np.array_equal(reference['states'],np.array(prior['search']['nominal_coordinate_states']))
        assert np.array_equal(reference['controls'],np.array(prior['controller']['controls']))
        assert np.array_equal(reference['defects'],reference['native_predictions']-reference['states'][1:])
        if variant=='unoptimized':
            assert np.array_equal(reference['states'],np.array(source['search']['nominal_coordinate_states']))
            assert np.array_equal(reference['controls'],np.array(source['controller']['controls']))
        for row in d['records']:
            _,_,gate=tape(row)
        actual+=d['actual_hanging_start_episode_steps'];total+=d['total_native_transition_calls']
        studies.append(dict(directory=str(folder),execution=e,result=file_metadata(folder/'diagnostic/result.json'),
            variant=variant,config=d['config'],source=d['source'],reference=d['reference'],records=d['records'],
            total_native_transition_calls=d['total_native_transition_calls'],actual_hanging_start_episode_steps=d['actual_hanging_start_episode_steps'],
            maximum_native_reference_defect=d['maximum_native_reference_defect'],maximum_feedforward_offset=d['maximum_feedforward_offset']))
        screen_folder=root/f'armature0.98_{variant}_handoff_screen'
        if screen_folder.exists():
            ej=journal(screen_folder);screen=read(screen_folder/'diagnostic/result.json');checked(screen['source'])
            assert screen['source']==file_metadata(folder/'diagnostic/result.json')
            affine=next(r for r in d['records'] if r['affine']);old=np.load(affine['tape']['path'])
            for r in screen['records']:
                x,u,gate=tape(r);steps=round(r['handoff_seconds']/.02)
                assert x[:steps+1].tobytes()==old['states'][:steps+1].tobytes() and u[:steps].tobytes()==old['actions'][:steps].tobytes()
                assert r['total_native_transition_calls']==2*len(u)
                if gate:passing.append((variant,r,d))
            assert screen['total_native_transition_calls']==sum(r['total_native_transition_calls'] for r in screen['records'])
            actual+=screen['actual_hanging_start_episode_steps'];total+=screen['total_native_transition_calls']
            studies.append(dict(directory=str(screen_folder),execution=ej,result=file_metadata(screen_folder/'diagnostic/result.json'),
                config=screen['config'],variant=variant,records=screen['records'],
                total_native_transition_calls=screen['total_native_transition_calls'],actual_hanging_start_episode_steps=screen['actual_hanging_start_episode_steps']))
    cost_keys=['terminal_state_weight','terminal_angle_factor','terminal_cart_velocity_factor','terminal_hinge_velocity_factor',
        'stage_weight','control_cost','rail_soft_limit','rail_weight','capture_stage_weight','normalized_cost_mapping','angle_branch_terminal_target']
    assert all(versions['unoptimized']['controller'][k]==versions['optimized']['controller'][k] for k in cost_keys)
    payload=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),passed=True,studies=studies,
        total_new_native_transition_calls=int(total),actual_hanging_start_episode_steps=actual,
        native_transition_calls_for_this_audit=0,canonical_release_evidence=False,not_solution=True,
        reserved_seeds_used=False,noisy_development_seeds_used=False,
        shared_cost_keys_equal=cost_keys,full_passing_handoffs=[dict(variant=a,handoff_seconds=b['handoff_seconds']) for a,b,_ in passing])
    assert total<=1308000
    if passing:
        # Prefer the no-optimizer method if it passes, then its earliest passing handoff.
        variant,row,d=min(passing,key=lambda v:(v[0]!='unoptimized',v[1]['handoff_seconds']))
        actual_tape=np.load(row['tape']['path']);steps=round(row['handoff_seconds']/.02)
        native_ref=np.load(d['reference']['path']);gains=np.vstack([native_ref['feedback_gains'][:steps],np.tile(-np.array(d['gain']),(700-steps,1))])
        x=actual_tape['states'][:701];u=actual_tape['actions'][:700]
        initializer=root/'armature0.98_passing_physical_initializer.json'
        dump_json(dict(selected_state=source['selected_state'],controller=dict(controls=u.tolist(),feedback_gains=gains.tolist(),
            coordinate_transform=np.eye(30).tolist(),continuous_angles=True,physical_shooting=True,capture_start_seconds=9.),
            search=dict(nominal_coordinate_states=x.tolist()),source=file_metadata(d['source']['path']),passing_tape=row['tape'],
            config=d['config'],seed=0,not_solution=True,initialization_only=True,
            selected_variant=variant,selected_handoff_seconds=row['handoff_seconds'],
            scope='First700actual native states/F32controls from a complete30s passing0.98altered14episode; actual feedback before handoff,negativemaintenancegainafter. Initializer only; not target-plant feasibility for the next continuation orcanonical15.'),initializer)
        payload['passing_physical_initializer']=file_metadata(initializer)
    dump_json(payload,root/'verified.json');print(json.dumps(dict(passed=True,total_native_calls=int(total),actual_steps=actual,passing=payload['full_passing_handoffs'])))

if __name__=='__main__':main()
