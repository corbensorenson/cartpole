#!/usr/bin/env python
"""Uninterrupted native physical-task MPC after a verified route prefix."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,data_sha256,runtime_metadata,utc_timestamp
from gcartpole.ilqr import MujocoTransition
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.native_task_derivatives import physical_task_residual,chained_physical_task_jacobian
from gcartpole.native_sequence_feasibility import restore_native_sequence,extend_verified_native_sequence
from gcartpole.native_action_lattice import polish_native_action_lattice
from gcartpole.nonlinear_sequence_control import shifted_preview_candidates
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.search_ilqr_capture import execute_controller
from scripts.search_fddp_capture import warm_start_diagnostics
from scripts.solve_frontier_capture_increment import validate_development_seeds,physical_replay_passed


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('source','config','capture-cache','directory'):p.add_argument('--'+key,required=True)
    p.add_argument('--horizon-steps',type=int,required=True)
    p.add_argument('--start-seconds',type=float,default=7.5)
    p.add_argument('--max-function-evaluations',type=int,default=20)
    p.add_argument('--plan-commit-steps',type=int,default=1)
    p.add_argument('--rate-residual-weight',type=float,default=.25)
    p.add_argument('--action-secant',type=float,default=1e-5)
    p.add_argument('--jacobian-method',choices=['rollout-secant','local4-chain-mp100'],default='rollout-secant')
    p.add_argument('--action-lattice-radii',type=int,nargs='*',default=[])
    p.add_argument('--lattice-solver-seconds',type=float,default=1.)
    p.add_argument('--task-angle-band',type=float,default=0.)
    p.add_argument('--forecast-angle-limit',type=float)
    p.add_argument('--retain-verified-suffix',action='store_true')
    p.add_argument('--extend-verified-suffix',action='store_true')
    p.add_argument('--native-seed-tape')
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    source=json.loads(Path(args.source).read_text());cache=json.loads(Path(args.capture_cache).read_text())
    cfg=load_config(args.config);n=cfg['env']['n_links'];dt=cfg['env']['timestep']*cfg['env']['frame_skip']
    steps=round(30/dt);start=round(args.start_seconds/dt);c=source['controller']
    validate_development_seeds(n,source['seed'])
    if (not 0<start<len(c['controls']) or not np.isclose(start*dt,args.start_seconds)
            or args.horizon_steps<2 or args.max_function_evaluations<1
            or not 1<=args.plan_commit_steps<=args.horizon_steps
            or not np.isfinite(args.rate_residual_weight) or args.rate_residual_weight<=0
            or not np.isfinite(args.action_secant) or args.action_secant<=0
            or any(not 1<=r<=4096 for r in args.action_lattice_radii)
            or not np.isfinite(args.lattice_solver_seconds) or args.lattice_solver_seconds<=0
            or not np.isfinite(args.task_angle_band) or not 0<=args.task_angle_band<.15
            or (args.forecast_angle_limit is not None and
                (not np.isfinite(args.forecast_angle_limit) or not args.task_angle_band<args.forecast_angle_limit<.15))
            or (args.extend_verified_suffix and not args.retain_verified_suffix)
            or (args.extend_verified_suffix and args.action_lattice_radii)
            or not c['continuous_angles'] or c['phase_adaptive']
            or not np.array_equal(c['coordinate_transform'],np.eye(2*(n+1)))
            or cache['source']!=file_metadata(args.source) or cache['config']!=file_metadata(args.config)):
        raise ValueError('Aligned verified physical-coordinate source/cache required')
    gain=np.asarray(cache['gain']);factor=np.asarray(source['lyapunov']['factor'])
    if data_sha256(gain.tolist())!=cache['gain_sha256'] or data_sha256(factor.tolist())!=cache['factor_sha256']:
        raise ValueError('Maintenance inputs changed')
    controls=np.asarray(c['controls']);nodes=np.asarray(source['search']['nominal_coordinate_states']);gains=np.asarray(c['feedback_gains'])
    if len(controls)<steps:
        controls=np.r_[controls,np.zeros(steps-len(controls))]
        nodes=np.vstack([nodes,np.zeros((steps+1-len(nodes),2*(n+1)))])
        gains=np.vstack([gains,np.zeros((steps-len(gains),2*(n+1)))])
    else:controls=controls[:steps];nodes=nodes[:steps+1];gains=gains[:steps]
    cfg=fixed_state_cfg(cfg,source['selected_state'],30.)
    teacher_actions=None;teacher_metadata=None
    if args.native_seed_tape:
        teacher=json.loads(Path(args.native_seed_tape).read_text())
        if (teacher['source']!=file_metadata(args.source) or teacher['config']!=file_metadata(args.config)
                or not teacher['inherited_prefix_states_and_actions_bit_identical']
                or teacher['physical_tape_diagnostics']['maximum_dynamics_defect']!=0.
                or not teacher['physical_tape_diagnostics']['is_exactly_feasible']
                or not np.isclose(teacher['executed_policy']['frequency_hz'],1/dt)):
            raise ValueError('Seed tape must be a source-aligned independently exact native trajectory')
        teacher_actions=np.asarray([r['action'] for r in teacher['result']['trajectory']],np.float32).astype(float)
        if not len(teacher_actions) or not np.all(np.isfinite(teacher_actions)) or np.any(np.abs(teacher_actions)>1):
            raise ValueError('Finite bounded native seed tape required')
        teacher_actions=np.r_[teacher_actions,np.zeros(max(0,steps-len(teacher_actions)))]
        teacher_metadata=file_metadata(args.native_seed_tape)
    env=NLinkCartPoleEnv(cfg,progress=1.,seed=source['seed']);env.reset(seed=source['seed'])
    predictor=MujocoTransition(env,np.eye(2*(n+1)),continuous_angles=True)
    local=FourthOrderMujocoTransition(env,np.eye(2*(n+1)),continuous_angles=True)
    assert predictor.data is not env.data
    previous_plan=previous_step=previous_predictions=None;planning_calls=0;derivative_calls=0;lattice_calls=0;lattice_improved=0;fallbacks=0;plans=0;committed_actions=0;retained_suffix_actions=0;extension_attempts=0;extension_successes=0;started=time.monotonic()
    def selector(step,state,baseline):
        nonlocal previous_plan,previous_step,previous_predictions,planning_calls,derivative_calls,lattice_calls,lattice_improved,fallbacks,plans,committed_actions,retained_suffix_actions,extension_attempts,extension_successes
        if step<start:return baseline,None
        elapsed=None if previous_step is None else step-previous_step
        if elapsed is not None and 0<elapsed<min(args.plan_commit_steps,len(previous_plan)):
            # Verify the predictor's previous state; never replace the actual state.
            if not np.array_equal(state,previous_predictions[elapsed-1]):
                raise ValueError('Committed native plan no longer exactly matches actual state')
            committed_actions+=1
            return float(previous_plan[elapsed]),dict(committed_prior_plan=True,
                planning_step=previous_step,plan_offset=elapsed,actual_state_bit_identical_to_prior_forecast=True,
                scope='Execute retained quantized plan input after verifying the actual state; no forecast search or live state replacement.')
        horizon=min(args.horizon_steps,steps-step)
        reference=controls[step:step+horizon]
        second=np.zeros(horizon)
        if args.plan_commit_steps>1 and elapsed is not None and 0<elapsed<len(previous_plan):
            # After a committed block, retain exactly the unexecuted suffix.
            remaining=previous_plan[elapsed:]
            second=np.r_[remaining,np.zeros(max(0,horizon-len(remaining)))][:horizon]
        elif previous_step==step-1 and len(previous_plan)>1:
            second=shifted_preview_candidates(previous_plan,int(horizon),[0.])[0]
        def task_residual(predictions):
            angles=wrap_angle(np.cumsum(predictions[:,1:n+1],axis=1))
            rates=np.cumsum(predictions[:,n+2:],axis=1)
            scale=np.sqrt(n*horizon)
            return np.r_[(angles/.15/scale).ravel(),(args.rate_residual_weight*rates/.75/scale).ravel(),
                .1*predictions[:,0]/1.5/np.sqrt(horizon),
                .1*predictions[:,n+1]/.5/np.sqrt(horizon),
                np.sqrt(5)*angles[-1]/.15/np.sqrt(n),
                np.sqrt(5)*args.rate_residual_weight*rates[-1]/.75/np.sqrt(n)]
        if args.task_angle_band>0 or args.extend_verified_suffix:
            task_residual=lambda predictions:physical_task_residual(predictions,n,args.rate_residual_weight,args.task_angle_band)
        def forecast_admissible(predictions):
            return bool(np.all(np.abs(predictions[:,0])<=env.rail_limit) and
                (args.forecast_angle_limit is None or np.max(np.abs(wrap_angle(np.cumsum(predictions[:,1:n+1],axis=1))))<args.forecast_angle_limit))
        # Preserve the existing loss arithmetic for the paired secant path.
        jacobian=None
        if args.jacobian_method=='local4-chain-mp100':
            task_residual=lambda predictions:physical_task_residual(predictions,n,args.rate_residual_weight,args.task_angle_band)
            jacobian=lambda initial,actions,predictions:chained_physical_task_jacobian(local,initial,actions,predictions,
                n_links=n,rate_weight=args.rate_residual_weight,state_epsilon=c['state_epsilon'],action_epsilon=c['action_epsilon'],angle_band=args.task_angle_band)
        before=predictor.evaluations
        derivative_before=local.evaluations
        seeds=[reference,second]
        if teacher_actions is not None:seeds.append(teacher_actions[step:step+horizon])
        if (args.extend_verified_suffix and elapsed is not None and 0<elapsed<len(previous_plan)
                and horizon>len(previous_plan)-elapsed):
            if not np.array_equal(state,previous_predictions[elapsed-1]):
                raise ValueError('Extension boundary no longer exactly matches retained native forecast')
            prefix=previous_plan[elapsed:];prefix_length=len(prefix);extension_attempts+=1
            selected,diag=extend_verified_native_sequence(predictor,state,prefix,previous_predictions[elapsed:],
                [seed[prefix_length:] for seed in seeds],reference_actions=reference[prefix_length:],
                constraint_residual=task_residual,admissible=forecast_admissible,
                derivative_epsilon=args.action_secant,max_evaluations=args.max_function_evaluations,
                action_regularization=.01,constraint_jacobian=jacobian)
            extension_successes+=selected is not None
            diag['planning_mode']='fixed_verified_suffix_then_optimized_extension'
        else:
            selected,diag=restore_native_sequence(predictor,state,seeds,reference_actions=reference,
                constraint_residual=task_residual,
                admissible=forecast_admissible,
                derivative_epsilon=args.action_secant,max_evaluations=args.max_function_evaluations,action_regularization=.01,
                constraint_jacobian=jacobian)
            diag['planning_mode']='whole_horizon_search'
        calls=predictor.evaluations-before
        if calls!=diag['native_transition_calls']:raise ValueError('Native planning budget mismatch')
        states=diag.pop('selected_states')
        if selected is not None and args.action_lattice_radii:
            lattice_before=predictor.evaluations
            polished,ld=polish_native_action_lattice(predictor,state,selected,reference_actions=reference,
                constraint_residual=task_residual,
                constraint_jacobian=lambda initial,actions,predictions:chained_physical_task_jacobian(local,initial,actions,predictions,
                    n_links=n,rate_weight=args.rate_residual_weight,state_epsilon=c['state_epsilon'],action_epsilon=c['action_epsilon'],angle_band=args.task_angle_band),
                admissible=forecast_admissible,
                radii=args.action_lattice_radii,solver_seconds=args.lattice_solver_seconds,action_regularization=.01)
            if predictor.evaluations-lattice_before!=ld['native_transition_calls']:
                raise ValueError('Native lattice planning budget mismatch')
            if polished is None or ld['selected_total_cost']>ld['baseline_total_cost']:
                raise ValueError('Native lattice polish must preserve the admissible center and nonincreasing cost')
            selected=polished;states=ld.pop('selected_states');lattice_improved+=ld['changed_sequence']
            lattice_calls+=ld['native_transition_calls'];diag['lattice_polish']=ld
            diag['continuous_restore_native_transition_calls']=calls
            calls=predictor.evaluations-before;diag['native_transition_calls']=calls
        planning_calls+=calls;diag['minimum_observed_physical_task_cost']=diag.pop('minimum_observed_constraint_violation_cost')
        diag['native_local_derivative_transition_calls']=local.evaluations-derivative_before
        derivative_calls+=local.evaluations-derivative_before
        diag['scope']=('Direct normalized physical task loss; finite native forecasts and rail bounds' +
            (', plus the declared hard absolute-angle forecast limit.' if args.forecast_angle_limit is not None else ', with no hard angle bound.')+
            ' No hard rate bound. Actual full episode decides success.')
        if selected is None:
            fallbacks+=1;action=float(np.float32(np.clip(baseline,-1,1)));diag['fallback']=True
            if args.retain_verified_suffix and elapsed is not None and 0<elapsed<len(previous_plan):
                if not np.array_equal(state,previous_predictions[elapsed-1]):
                    raise ValueError('Retained suffix no longer exactly matches actual state')
                action=float(previous_plan[elapsed]);retained_suffix_actions+=1
                diag.update(fallback_to_verified_suffix=True,planning_step=previous_step,plan_offset=elapsed,
                    actual_state_bit_identical_to_prior_forecast=True)
        else:
            previous_plan=selected.copy();previous_step=step;plans+=1;action=float(selected[0])
            predicted=np.asarray(states)
            previous_predictions=predicted.copy()
            diag['selected_sequence']=selected.tolist()
            diag['maximum_predicted_absolute_angle']=float(np.max(np.abs(wrap_angle(np.cumsum(predicted[:,1:n+1],axis=1)))))
            diag['maximum_predicted_absolute_rate']=float(np.max(np.abs(np.cumsum(predicted[:,n+2:],axis=1))))
        diag['horizon_steps']=horizon
        dump_json(dict(updated_at=utc_timestamp(),planning_step=step,time_seconds=step*dt,
            actual_absolute_angle_max=float(np.max(np.abs(wrap_angle(np.cumsum(state[1:n+1]))))),
            actual_cart_position=float(state[0]),actual_cart_velocity=float(state[n+1]),
            successful_plans=plans,fallbacks=fallbacks,committed_prior_plan_actions=committed_actions,
            planning_transition_calls=planning_calls,native_local_derivative_transition_calls=derivative_calls,
            lattice_planning_transition_calls=lattice_calls,lattice_improved_plans=lattice_improved,
            retained_verified_suffix_actions=retained_suffix_actions,
            fixed_suffix_extension_attempts=extension_attempts,fixed_suffix_extension_successes=extension_successes,
            maximum_predicted_absolute_angle=diag.get('maximum_predicted_absolute_angle'),
            scope='Last completed planning boundary; actual state before current input. Telemetry is not process liveness, episode completion or a gate.'),out/'planning_progress.json')
        if args.action_lattice_radii or args.extend_verified_suffix or step%25==0:print(json.dumps(dict(step=step,time_seconds=step*dt,action=action,diagnostic=diag)),flush=True)
        return action,diag
    try:
        result=execute_controller(cfg,progress=1.,seed=source['seed'],controls=controls,
            nominal_states=nodes,feedback_gains=gains,gain=gain,lqr_scale=c['lqr_scale'],
            transform=np.eye(2*(n+1)),lyapunov=factor.T@factor,lyapunov_factor=factor,
            handoff_lyapunov=c['handoff_lyapunov'],handoff_cart_abs=c['handoff_cart_abs'],
            handoff_angle_abs=c['handoff_angle_abs'],handoff_cart_velocity_abs=c['handoff_cart_velocity_abs'],
            handoff_hinge_velocity_rms=c['handoff_hinge_velocity_rms'],
            defer_handoff_until_horizon=True,continuous_angles=True,tracking_mode='native_physical_task_mpc',
            tracking_action_selector=selector)
        rows=result['trajectory'];original=source['result']['trajectory']
        identical=len(rows)>=start and all(a['qpos']==b['qpos'] and a['qvel']==b['qvel']
            and np.float32(a['action'])==np.float32(b['action']) for a,b in zip(rows[:start],original[:start]))
        if not identical:raise ValueError('Inherited actual prefix changed')
        initial=np.asarray(source['selected_state']['qpos']+source['selected_state']['qvel'])
        states=np.vstack([initial,[r['qpos']+r['qvel'] for r in rows]])
        actions=np.asarray([r['action'] for r in rows],dtype=np.float32).astype(float)
        physical=warm_start_diagnostics(predictor,initial,actions,states)
        if not physical['is_exactly_feasible']:raise ValueError('Actual native policy tape did not exactly reproduce')
        dump_json(dict(not_solution=True,benchmark_evidence=False,parameters=vars(args),runtime=runtime_metadata(),
            source=file_metadata(args.source),config=file_metadata(args.config),capture_cache=file_metadata(args.capture_cache),
            result=result,full_development_episode_passed=physical_replay_passed(result,cfg),
            inherited_prefix_states_and_actions_bit_identical=True,physical_tape_diagnostics=physical,
            task_planning_transition_calls=planning_calls,actual_tape_validation_transition_calls=len(rows),
            native_local_derivative_transition_calls=derivative_calls,
            lattice_planning_transition_calls=lattice_calls,lattice_improved_plans=lattice_improved,
            retained_verified_suffix_actions=retained_suffix_actions,
            fixed_suffix_extension_attempts=extension_attempts,fixed_suffix_extension_successes=extension_successes,
            total_native_transition_calls=predictor.evaluations+local.evaluations,successful_plans=plans,fallbacks=fallbacks,
            committed_prior_plan_actions=committed_actions,
            wall_time_seconds=time.monotonic()-started,reserved_seeds_used=False,noisy_development_seeds_used=False,
            executed_policy=dict(type='native_physical_task_mpc_after_verified_route_prefix',frequency_hz=1/dt,
                action_precision='float32',start_seconds=args.start_seconds,correction_until_seconds=30.,
                requested_horizon_steps=args.horizon_steps,
                targets='zero absolute angles/rates/cart position/velocity' if args.task_angle_band==0 else 'absolute angle dead zone; zero rates/cart position/velocity',
                scales=dict(angle=.15,rate=.75,cart=1.5,cart_velocity=.5),
                residual_weights=dict(angle=1.,rate=args.rate_residual_weight,cart=.1,cart_velocity=.1,terminal_multiplier=np.sqrt(5)),
                action_residual_weight=.01,max_function_evaluations_per_seed=args.max_function_evaluations,
                native_action_secant=args.action_secant,shifted_previous_plan=True,predictor_data_is_separate=True,
                jacobian_method=args.jacobian_method,
                action_lattice_radii_ulps=args.action_lattice_radii,lattice_solver_seconds_per_box=args.lattice_solver_seconds,
                lattice_acceptance='Measured native squared physical-task loss plus original action regularization must not increase; exact predicted states retained.',
                task_angle_band=args.task_angle_band,forecast_angle_limit=args.forecast_angle_limit,
                retain_verified_suffix_on_search_failure=args.retain_verified_suffix,
                extend_verified_suffix=args.extend_verified_suffix,
                extension_objective_scope='Only appended inputs/states enter the task objective when a verified suffix is fixed; full-horizon task loss otherwise.',
                native_seed_tape=teacher_metadata,
                native_seed_tape_usage='Previously delivered controls as additional search seeds, padded with zeros after recorded end. No teacher state is written to the actual plant.',
                plan_commit_steps=args.plan_commit_steps,committed_state_verification='bit identical to retained native forecast; never live state projection',
                nominal_extension='Zero controls/nodes/gains as planning/reference inputs only; never live state projection.'),
            scope='One uninterrupted exact-start30 s development episode. This policy uses direct physical task objectives and rail-admissible native forecasts, not moving value-root cost or a viability certificate. No noisy/canonical release gates are inferred.'),out/'result.json')
        print(json.dumps(dict(full_pass=physical_replay_passed(result,cfg),hold=result['max_upright_streak_seconds'],length=result['length'])),flush=True)
    finally:env.close()
if __name__=='__main__':main()
