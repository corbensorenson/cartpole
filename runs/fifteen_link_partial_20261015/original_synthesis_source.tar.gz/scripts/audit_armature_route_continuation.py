"""Read-only consistency audit of small-armature full-route repair evidence."""
import argparse
import json
from pathlib import Path
import numpy as np
from gcartpole.config import load_config, dump_json
from gcartpole.evidence import file_metadata, utc_timestamp
from gcartpole.angles import wrap_angle


def checked(ref):
    assert file_metadata(ref['path']) == ref, ref['path']


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--directory', required=True)
    args = p.parse_args()
    root = Path(args.directory)
    initializer = json.loads((root/'initializer.json').read_text())
    checked(initializer['source'])
    old = json.loads(Path(initializer['source']['path']).read_text())
    cfg0 = load_config(root/'armature1.0.json')
    rows = []
    for name, factor in (('canonical_replay', 1.), ('armature0.99_repair8', .99), ('armature0.95_repair8', .95)):
        directory = root/name
        execution = json.loads((directory/'execution.json').read_text())
        assert execution['status'] == 'finished' and execution['returncode'] == 0
        for ref in execution['frozen_inputs']:
            assert file_metadata(directory/'snapshot'/ref['path'])['sha256'] == ref['sha256']
        result_path = directory/'diagnostic/result.json'
        d = json.loads(result_path.read_text())
        for key in ('script','config','initializer','candidate','tape'):
            ref = d[key]
            if key == 'script':
                snap = file_metadata(directory/'snapshot/scripts'/Path(ref['path']).name)
                assert snap['sha256'] == ref['sha256']
            else:
                checked(ref)
        cfg = load_config(d['config']['path'])
        assert cfg['env']['joint_armature'] == cfg0['env']['joint_armature']*factor
        cfg['env']['joint_armature'] = cfg0['env']['joint_armature']
        assert cfg == cfg0
        assert d['status'] == 'finished' and d['partial_transition_substeps'] == 0
        assert d['native_physics_substeps'] == 4*d['total_native_transition_calls']
        assert d['total_native_transition_calls'] <= d['native_transition_ceiling']
        assert not any(d[k] for k in ('canonical_release_evidence','reserved_seeds_used','noisy_development_seeds_used'))
        assert d['seed'] == 0 and d['independent_whole_actual_tape_bytes_exact']
        candidate = json.loads(Path(d['candidate']['path']).read_text())
        assert candidate['selected_state'] == initializer['selected_state']
        assert candidate['controller']['frozen_prefix_steps'] == 0
        assert candidate['controller']['continuous_angles'] and candidate['controller']['physical_shooting']
        assert candidate['controller']['horizon_steps'] == 700
        with np.load(d['tape']['path']) as tape:
            states, actions = tape['states'], tape['actions']
            assert np.all(np.isfinite(states)) and np.all(np.isfinite(actions))
            assert states.shape == (len(actions)+1, 30) and np.max(np.abs(actions)) <= 1
            assert actions.tobytes() == actions.astype(np.float32).astype(float).tobytes()
            assert len(actions) == d['actual_hanging_start_episode_steps'] == d['independent_tape_replay_transition_calls']
            assert actions.tobytes() == np.asarray([r['action'] for r in candidate['result']['trajectory']],np.float32).astype(float).tobytes()
            assert states[1:].tobytes() == np.asarray([r['qpos']+r['qvel'] for r in candidate['result']['trajectory']]).tobytes()
            streak = maximum = 0
            for value in np.max(np.abs(wrap_angle(np.cumsum(states[1:,1:15],axis=1))),axis=1):
                streak = streak+1 if value < .15 else 0
                maximum = max(maximum, streak)
            assert maximum*.02 == d['result']['max_upright_streak_seconds']
            gate = bool(len(actions) == 1500 and maximum*.02 >= 5 and np.max(np.abs(states[:,0])) <= 3
                and d['result']['termination_reason'] == 'time_limit' and d['result']['trajectory_integrity'])
            assert gate == d['full_nominal_component_gate_passed']
            if factor == 1.:
                source_states = np.vstack([old['selected_state']['qpos']+old['selected_state']['qvel'],
                    [r['qpos']+r['qvel'] for r in old['result']['trajectory']]])
                source_actions = np.asarray([r['action'] for r in old['result']['trajectory']],np.float32).astype(float)
                assert states.tobytes() == source_states.tobytes() and actions.tobytes() == source_actions.tobytes()
                assert gate and d['optimizer_iterations'] == 0
            else:
                assert d['entire_horizon_free'] and d['optimizer_iterations'] == 8
                assert candidate['controller']['capture_interval_steps'] == 250
        history = candidate['search']['optimizer_history'] or []
        row = dict(directory=str(directory),result=file_metadata(result_path),execution=file_metadata(directory/'execution.json'),
            frozen_script=file_metadata(directory/'snapshot/scripts/run_counted_capture_repair.py'),
            config=d['config'],initializer=d['initializer'],candidate=d['candidate'],tape=d['tape'],
            armature_factor=factor,total_native_transition_calls=int(d['total_native_transition_calls']),
            actual_hanging_start_episode_steps=d['actual_hanging_start_episode_steps'],
            independent_tape_replay_transition_calls=d['independent_tape_replay_transition_calls'],
            native_transition_ceiling=d['native_transition_ceiling'],full_nominal_component_gate_passed=gate,
            hold_seconds=d['result']['max_upright_streak_seconds'],maximum_cart=d['result']['max_cart_excursion'],
            entire_horizon_free=d['entire_horizon_free'],optimizer_iterations=d['optimizer_iterations'],
            native_controller_trajectory_integrity=d['result']['trajectory_integrity'],
            model_is_exactly_feasible=candidate['controller']['final_trajectory_diagnostics']['is_exactly_feasible'],
            maximum_model_defect=candidate['controller']['final_trajectory_diagnostics']['maximum_dynamics_defect'],
            accepted_optimizer_steps=sum(r['accepted'] for r in history),
            not_solution=True,canonical_release_evidence=False,reserved_seeds_used=False,noisy_development_seeds_used=False)
        if history:
            row.update(first_optimizer_iteration=history[0],last_optimizer_iteration=history[-1])
        if factor == 1.:
            row['full_source_actual_states_and_actions_byte_identical'] = True
        rows.append(row)
    for factor in (.99,.95):
        directory = root/f'armature{factor}_native_defect_feedback'
        execution = json.loads((directory/'execution.json').read_text())
        assert execution['status']=='finished' and execution['returncode']==0
        for ref in execution['frozen_inputs']:
            assert file_metadata(directory/'snapshot'/ref['path'])['sha256']==ref['sha256']
        path=directory/'diagnostic/result.json';d=json.loads(path.read_text())
        for key in ('source','config','reference'):checked(d[key])
        snap=file_metadata(directory/'snapshot/scripts/refine_native_route_defect_feedback.py')
        assert snap['sha256']==d['script']['sha256'] and d['status']=='finished'
        assert not any(d[k] for k in ('canonical_release_evidence','reserved_seeds_used','noisy_development_seeds_used'))
        assert d['native_reference_design_calls']==88900 and d['upright_gain_design_calls']==62
        assert d['partial_transition_substeps']==0 and d['native_physics_substeps']==4*d['total_native_transition_calls']
        assert d['total_native_transition_calls']<=d['native_transition_ceiling']
        source=json.loads(Path(d['source']['path']).read_text())
        nominal=np.asarray(source['search']['nominal_coordinate_states']);controls=np.asarray(source['controller']['controls'])
        with np.load(d['reference']['path']) as reference:
            assert reference['states'].tobytes()==nominal.tobytes()
            assert reference['controls'].tobytes()==controls.tobytes()
            assert reference['defects'].tobytes()==(reference['native_predictions']-nominal[1:]).tobytes()
            assert np.all(np.isfinite(reference['feedback_gains'])) and np.all(np.isfinite(reference['feedforward_offsets']))
        actual=proof=0
        for e in d['records']:
            checked(e['tape']);assert e['independent_whole_actual_tape_bytes_exact']
            with np.load(e['tape']['path']) as tape:
                x,u=tape['states'],tape['actions'];assert x.shape==(len(u)+1,30)
                assert np.all(np.isfinite(x)) and np.all(np.isfinite(u)) and np.max(np.abs(u))<=1
                assert u.tobytes()==u.astype(np.float32).astype(float).tobytes()
                assert len(u)==e['actual_hanging_start_episode_steps']==e['independent_tape_replay_transition_calls']
                streak=maximum=0
                for angle in np.max(np.abs(wrap_angle(np.cumsum(x[1:,1:15],axis=1))),axis=1):
                    streak=streak+1 if angle<.15 else 0;maximum=max(maximum,streak)
                assert maximum*.02==e['result']['max_upright_streak_seconds']
                gate=bool(len(u)==1500 and maximum*.02>=5 and np.max(np.abs(x[:,0]))<=3 and e['result']['termination_reason']=='time_limit')
                assert gate==e['full_nominal_component_gate_passed']
            actual+=len(u);proof+=len(u)
        assert len(d['records'])==2 and actual==d['actual_hanging_start_episode_steps']
        assert d['total_native_transition_calls']==88900+62+actual+proof
        rows.append(dict(directory=str(directory),result=file_metadata(path),execution=file_metadata(directory/'execution.json'),
            frozen_script=snap,source=d['source'],config=d['config'],reference=d['reference'],armature_factor=factor,
            total_native_transition_calls=int(d['total_native_transition_calls']),actual_hanging_start_episode_steps=actual,
            independent_tape_replay_transition_calls=proof,native_transition_ceiling=d['native_transition_ceiling'],
            native_reference_design_calls=88900,upright_gain_design_calls=62,episodes=d['records'],
            maximum_native_reference_defect=d['maximum_native_reference_defect'],
            maximum_feedforward_offset=d['maximum_feedforward_offset'],maximum_feedback_norm=d['maximum_feedback_norm'],
            not_solution=True,canonical_release_evidence=False,reserved_seeds_used=False,noisy_development_seeds_used=False))
    directory=root/'armature0.99_affine_handoff_screen';j=json.loads((directory/'execution.json').read_text())
    assert j['status']=='finished' and j['returncode']==0
    for ref in j['frozen_inputs']:assert file_metadata(directory/'snapshot'/ref['path'])['sha256']==ref['sha256']
    path=directory/'diagnostic/result.json';d=json.loads(path.read_text());checked(d['source']);checked(d['config'])
    snap=file_metadata(directory/'snapshot/scripts/screen_native_affine_handoffs.py');assert snap['sha256']==d['script']['sha256']
    parent=json.loads(Path(d['source']['path']).read_text());prefix=next(e for e in parent['records'] if e['affine'])
    checked(prefix['tape'])
    with np.load(prefix['tape']['path']) as p:prefix_x=p['states'].copy();prefix_u=p['actions'].copy()
    assert len(d['records'])==8 and not any(d[k] for k in ('canonical_release_evidence','reserved_seeds_used','noisy_development_seeds_used'))
    for e in d['records']:
        checked(e['tape']);steps=round(e['handoff_seconds']/.02)
        assert e['independent_whole_actual_tape_bytes_exact'] and e['prefix_actual_states_and_actions_byte_identical']
        with np.load(e['tape']['path']) as p:
            x,u=p['states'],p['actions'];assert x.shape==(len(u)+1,30)
            assert np.all(np.isfinite(x)) and np.all(np.isfinite(u)) and np.max(abs(u))<=1
            assert u.tobytes()==u.astype(np.float32).astype(float).tobytes()
            assert x[:steps+1].tobytes()==prefix_x[:steps+1].tobytes() and u[:steps].tobytes()==prefix_u[:steps].tobytes()
            assert len(u)==e['actual_hanging_start_episode_steps']==e['independent_tape_replay_transition_calls']
            assert e['total_native_transition_calls']==2*len(u)
            streak=maximum=0
            for angle in np.max(np.abs(wrap_angle(np.cumsum(x[1:,1:15],axis=1))),axis=1):
                streak=streak+1 if angle<.15 else 0;maximum=max(maximum,streak)
            assert maximum*.02==e['result']['max_upright_streak_seconds']
            gate=bool(len(u)==1500 and maximum*.02>=5 and np.max(abs(x[:,0]))<=3 and e['result']['termination_reason']=='time_limit')
            assert gate==e['full_nominal_component_gate_passed']
    assert d['total_native_transition_calls']==sum(e['total_native_transition_calls'] for e in d['records'])<=24000
    rows.append(dict(directory=str(directory),result=file_metadata(path),execution=file_metadata(directory/'execution.json'),frozen_script=snap,
        source=d['source'],config=d['config'],total_native_transition_calls=d['total_native_transition_calls'],
        actual_hanging_start_episode_steps=d['actual_hanging_start_episode_steps'],independent_tape_replay_transition_calls=d['actual_hanging_start_episode_steps'],
        native_transition_ceiling=24000,episodes=d['records'],earliest_passing_handoff_seconds=9.,
        not_solution=True,canonical_release_evidence=False,reserved_seeds_used=False,noisy_development_seeds_used=False))
    init_path=root/'armature0.99_passing_physical_initializer.json';saved=json.loads(init_path.read_text())
    for k in ('source','passing_tape','config'):checked(saved[k])
    with np.load(saved['passing_tape']['path']) as tape:
        assert np.asarray(saved['search']['nominal_coordinate_states']).tobytes()==tape['states'][:701].tobytes()
        assert np.asarray(saved['controller']['controls']).tobytes()==tape['actions'][:700].tobytes()
    assert saved['selected_state']==initializer['selected_state'] and saved['controller']['capture_start_seconds']==9.
    result = dict(generated_at=utc_timestamp(),script=file_metadata(__file__),passed=True,studies=rows,
        passing_physical_initializer=file_metadata(init_path),
        total_new_native_transition_calls=sum(r['total_native_transition_calls'] for r in rows),
        actual_hanging_start_episode_steps=sum(r['actual_hanging_start_episode_steps'] for r in rows),
        native_transition_calls_for_this_audit=0,
        scope='Read-only frozen provenance, F32/native tape bookkeeping, physical sampled gate and byte-identical canonical replay. Shared eight-iteration full-route repair on near-canonical14 altered armature; no15solve or robust release claim.')
    dump_json(result,root/'verified.json')
    print(json.dumps({k:v for k,v in result.items() if k!='studies'}))


if __name__ == '__main__':
    main()
