#!/usr/bin/env python
"""Plot fixed-mass physical disks and their measured native dynamics."""
import argparse
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True)
    parser.add_argument('--directory', required=True)
    args = parser.parse_args(); out = Path(args.directory)
    if (out / 'result.json').exists(): raise FileExistsError(out)
    data = json.loads(Path(args.source).read_text())
    records = data['geometry_records']; designs = data['local_designs']
    fixed = data['parameters'].get('hub_mass_policy', 'fixed-total') == 'fixed-total'
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False,
                        'axes.spines.right': False, 'svg.fonttype': 'none'})
    fig = plt.figure(figsize=(8.8, 7.8), layout='constrained')
    grid = fig.add_gridspec(3, 2, height_ratios=[1.15, 1., 1.])
    geometry = fig.add_subplot(grid[0, :])
    for x, radius in zip([0., .35, .7], [.025, .05, .075]):
        geometry.plot([x, x], [0., .2], color='#ba5939', lw=8, zorder=1)
        geometry.add_patch(Circle((x, 0.), radius, color='#b8c7d2', ec='#243a50', zorder=2))
        geometry.plot([x-.009, x+.009], [0., 0.], color='#243a50', lw=1.5, zorder=3)
        geometry.text(x, -.112, f'{2*radius*100:g} cm hub', ha='center')
    geometry.set_aspect('equal'); geometry.set(xlim=(-.13,.83), ylim=(-.15,.23))
    geometry.axis('off'); geometry.set_title('Same 20 cm rod and proximal hinge; larger solid disk', fontsize=11)
    axes = [fig.add_subplot(grid[i,j]) for i in (1,2) for j in (0,1)]
    for n, color in [(15, '#243a50'), (20, '#43816a')]:
        family = sorted([r for r in records if r['n_links']==n and r['joint_hub_radius_m']>0], key=lambda r:r['joint_hub_radius_m'])
        x = [200*r['joint_hub_radius_m'] for r in family]
        gain = []
        for r in family:
            d = next(d for d in designs if d['config']==r['config'])
            gain.append(d['design_diagnostics']['gain_norm'])
        axes[0].plot(x, [r['fastest_hanging_frequency_hz'] for r in family], '-o', color=color, label=f'{n} links')
        axes[1].plot(x, [r['upright_per_control_tick_growth'] for r in family], '-o', color=color)
        axes[2].semilogy(x, gain, '-o', color=color)
        axes[3].plot(x, [sum(next(d for d in designs if d['config']==r['config'])['local_capture'][str(a)]['successes'] for a in (1e-5,1e-9,1e-13)) for r in family], '-o', color=color)
    labels = ['Fastest hanging mode (Hz)', 'Upright growth per 50 Hz tick', 'Local LQR gain norm', 'Native local captures / 12']
    for ax, label in zip(axes, labels):
        ax.set(xlabel='Hub diameter (cm)', ylabel=label, xticks=[5,10,15]); ax.grid(axis='y', alpha=.18)
    axes[0].legend(); axes[3].set(ylim=(-.5,12.5), yticks=[0,4,8,12])
    fig.suptitle('Hub size changes inertia, but this local controller still fails' if fixed else 'Larger, heavier hubs reduce the local feedback gain', fontsize=14)
    mass_caption = 'Fixed 1 kg rods + 0.1 kg hubs across diameter variants; chain length 3 m.' if fixed else 'Fixed density within each count: 0.1 / 0.4 / 0.9 kg hubs; 1 kg rods, 3 m chain.'
    fig.supxlabel(mass_caption + '\n30 s native local trials at relative perturbations 1e−5, 1e−9 and 1e−13.\nNo hanging-start solution or canonical count promotion is inferred.', fontsize=9)
    out.mkdir(parents=True, exist_ok=True); outputs=[]
    for suffix in ('png','pdf','svg'):
        p=out/f'comparison.{suffix}'; fig.savefig(p,dpi=180); outputs.append(file_metadata(p))
    plt.close(fig)
    dump_json(dict(not_solution=True, canonical_release_evidence=False,
        source=file_metadata(args.source), outputs=outputs, native_transition_calls=0,
        scope='Source-bound plotting only. Geometry diagram uses the 15-link rod length.'), out/'result.json')


if __name__=='__main__': main()
