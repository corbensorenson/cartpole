"""Retrospective, zero-physics reconstruction of all R42 trust-model backtracks."""
import argparse,json
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix
read=lambda p:json.loads(Path(p).read_text())
def phys(z,m):return np.r_[(wrap_angle(np.cumsum(z['states'][1:,1:16],axis=1))/m['angle_limit']).ravel(),z['states'][1:,0]/m['rail_limit']]
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);args=p.parse_args();root=Path(args.root);out=Path(args.out);out.mkdir(exist_ok=False);m=read(root/'manifest.json');r=read(root/'execution/diagnostic/result.json');a=read(root/'independent_audit/diagnostic/result.json');assert a['passed'];zmap={}
 for row in r['private_forecasts']:
  assert row['tape']==file_metadata(row['tape']['path'])
  with np.load(row['tape']['path']) as z:zmap[row['index']]={k:z[k] for k in z.files}
 rows=[];stages=[]
 for stage in r['stages']:
  h=stage['horizon'];nk=m['tracking_knots'];track=m['tracking_steps'];basis=np.zeros((h,nk+h-track));basis[:track,:nk]=interpolation_matrix(nk,track);basis[track:,nk:]=np.eye(h-track)
  for history in stage['history']:
   if 'parameter_step' not in history or history['parameter_step'] is None:continue
   center=zmap[history['center_before']];f=phys(center,m);columns=[]
   for k,(pi,mi) in enumerate(history['derivative_pairs']):columns.append((phys(zmap[pi],m)-phys(zmap[mi],m))/(2*history['derivative_epsilons'][k]))
   jac=np.column_stack(columns);delta=np.asarray(history['parameter_step']);ffstep=basis@delta
   for bt in history['backtracks']:
    actual=zmap[bt['forecast_index']];power=bt['power'];pred=f+jac@(delta/(2**power));observed=phys(actual,m);delivered_changed=np.flatnonzero(actual['actions'][:len(center['actions'])]!=center['actions']);ffchanged=np.flatnonzero(actual['feedforward']!=center['feedforward']);maximum_state_error=float(np.max(abs(observed-pred)));angle_rows=h*15;err_by_tick=np.max(abs((observed-pred)[:angle_rows].reshape(h,15)),axis=1);peak=int(np.argmax(err_by_tick));rows.append(dict(label=stage['label'],iteration=history['iteration'],power=power,forecast_index=bt['forecast_index'],accepted=history['accepted']==bt['forecast_index'],physical_predicted_peak=float(np.max(abs(pred))),physical_observed_peak=float(np.max(abs(observed))),predicted_peak_below_one=bool(np.max(abs(pred))<1),observed_peak_below_one=bool(np.max(abs(observed))<1),maximum_normalized_prediction_error=maximum_state_error,worst_angle_model_error_control_index=peak,worst_angle_model_error_episode_endpoint=start_endpoint(m,peak),first_changed_delivered_action_index=int(delivered_changed[0]) if len(delivered_changed) else None,changed_delivered_action_count=len(delivered_changed),changed_nominal_feedforward_count=len(ffchanged),maximum_feedforward_step=float(np.max(abs(ffstep/(2**power)))),nominal_tracking_feedforward_step_max=float(np.max(abs(ffstep[:track]/(2**power)))),controller_raw_peak=float(np.max(abs(actual['raw_actions'])))))
  first=zmap[stage['initial_forecast']];last=zmap[stage['selected_forecast']];changes=np.flatnonzero(last['actions']!=first['actions']);stages.append(dict(label=stage['label'],initial_physical_peak=float(np.max(abs(phys(first,m)))),selected_physical_peak=float(np.max(abs(phys(last,m)))),first_changed_delivered_episode_tick=m['start_step']+int(changes[0]) if len(changes) else None,changed_delivered_controls=len(changes),initial_raw_peak=float(np.max(abs(first['raw_actions']))),selected_raw_peak=float(np.max(abs(last['raw_actions']))),selected_last_action=float(last['actions'][-1]),selected_last_angle=float(np.max(abs(wrap_angle(np.cumsum(last['states'][-1,1:16])))))))
 failed_safe=[q for q in rows if q['predicted_peak_below_one'] and not q['observed_peak_below_one']];dump_json(dict(record_kind='retrospective_read_only_extraction',generated_at=utc_timestamp(),native_transition_calls=0,source_result=file_metadata(root/'execution/diagnostic/result.json'),source_audit=file_metadata(root/'independent_audit/diagnostic/result.json'),script=file_metadata(__file__),records=rows,stages=stages,predicted_safe_but_native_not_safe=len(failed_safe),scope='Reconstruct all saved R42 central-secant affine physical models and actual backtracks. Predicted maximum below1 is an affine-model statement, not physical feasibility. Counts exclude raw feature rows to compare physical predictions acrossarms; no new physics or unseen-direction test.'),out/'result.json');print(stages);print('predicted_safe_but_native_not_safe',len(failed_safe),'backtracks',len(rows))
def start_endpoint(m,index):return m['start_step']+index+1
if __name__=='__main__':main()
