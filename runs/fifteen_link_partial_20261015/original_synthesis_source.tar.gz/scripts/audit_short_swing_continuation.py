"""Read-only short-reference/preserved-prefix/native tape and accounting audit."""
import argparse,json,math
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json,load_config
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.physical_prefix import select_physical_prefix
from gcartpole.physical_initializers import truncate_physical_initializer,extend_actual_prefix_initializer
from scripts.audit_armature_route_increment import checked,journal,read,tape


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',required=True);a=p.parse_args();root=Path(a.directory)
    pre=read(root/'preflight_failures_verified.json');assert pre['passed'];rows=list(pre['studies']);parents=list(pre['pipelines']);source=read(pre['source_initializer']['path']);checked(pre['source_initializer'])
    for row in rows:
        for key in ('execution','result'):checked(row[key])
    setup=read(root/'setup_failures.json');assert setup['native_transition_calls']==0
    for path in setup['directories']:assert not (Path(path)/'execution.json').exists() and not (Path(path)/'diagnostic').exists()
    cfg=load_config(root/'armature0.97.json');tcfg=load_config(root/'armature0.95.json');assert cfg['env']['joint_armature']==.0005*.97 and tcfg['env']['joint_armature']==.0005*.95;tcfg['env']['joint_armature']=cfg['env']['joint_armature'];assert tcfg==cfg
    for h in (6,8):
        N=50*h;initial_path=root/f'initializer{h}.json';initial=read(initial_path);expected=truncate_physical_initializer(source,N)
        assert initial['selected_state']==expected['selected_state'] and initial['controller']==expected['controller'] and initial['search']==expected['search']
        folder=root/f'target0.95_{h}s_corrected2';pj=journal(folder);path=folder/'diagnostic/result.json';d=read(path);assert d['status']=='finished' and d['reference_horizon_seconds']==h and d['capture_start_seconds']==5.82
        for key in ('config','initializer','memo','script','whole_initializer'):checked(d[key])
        assert d['initializer']==file_metadata(initial_path) and d['whole_initializer']==pre['source_initializer']
        stages={};local=[]
        for s in d['stages']:
            checked(s['result']);assert journal(Path(s['directory']))==s['execution'];r=read(s['result']['path']);assert r['status']=='finished' and r['config']==d['config']
            assert s['total_native_transition_calls']==r['total_native_transition_calls']<=r['native_transition_ceiling'];assert s['actual_hanging_start_episode_steps']==r.get('actual_hanging_start_episode_steps',0)
            assert r['partial_transition_substeps']==0 and r['native_physics_substeps']==4*r['total_native_transition_calls']
            assert not r.get('reserved_seeds_used',False) and not r.get('noisy_development_seeds_used',False)
            row=dict(s,config=r['config'],role='primitive',records=r.get('records',[]),horizon_seconds=h)
            if 'tape' in r:
                x,u,g=tape(r);c=read(r['candidate']['path']);checked(r['candidate']);checked(r['initializer'])
                assert c['selected_state']==source['selected_state'] and c['controller']['coordinate_transform']==np.eye(30).tolist()
                assert x[1:].tobytes()==np.array([q['qpos']+q['qvel'] for q in c['result']['trajectory']]).tobytes()
                row.update(candidate=r['candidate'],initializer=r['initializer'],tape=r['tape'],full_nominal_component_gate_passed=g,hold_seconds=r['result']['max_upright_streak_seconds'],maximum_model_defect=c['controller']['final_trajectory_diagnostics']['maximum_dynamics_defect'])
            for rr in r.get('records',[]):tape(rr)
            for key in ('source','reference','gain_source'):
                if key in r:checked(r[key])
            stages[s['name']]=r;local.append(row)
        assert sum(s['total_native_transition_calls'] for s in local)==d['total_native_transition_calls']<=2200000
        assert sum(s['actual_hanging_start_episode_steps'] for s in local)==d['actual_hanging_start_episode_steps']
        selected=None;selected_record=None;selected_gains=None;direct=[]
        for e in d['selection_history']:
            it=e['after_cumulative_iterations'];r=stages[f'full_repair{it}'];c=read(r['candidate']['path'])
            assert r['optimizer_iterations']==8 and r['entire_horizon_free'] and r['horizon_seconds']==h
            assert len(c['controller']['controls'])==N and c['controller']['capture_start_seconds']==5.82 and c['controller']['capture_interval_steps']==N-291
            assert c['controller']['frozen_prefix_steps']==0 and c['search']['optimized_horizon_steps']==N
            assert r['initializer']==(file_metadata(initial_path) if it==8 else stages['full_repair8']['candidate'])
            options=[('saved_solver',r,np.array(c['controller']['feedback_gains']))]
            if f'native_feedback{it}' in stages:
                f=stages[f'native_feedback{it}'];assert f['source']==r['candidate'] and f['native_reference_design_calls']==127*N and f['upright_gain_design_calls']==62 and f['reference_steps']==N and f['capture_start_seconds']==5.82
                ref=np.load(f['reference']['path']);assert np.array_equal(ref['states'],c['search']['nominal_coordinate_states'])
                assert select_physical_prefix(np.load(r['tape']['path'])['states'][:N+1],14) is None
                options.extend((rr['label'],rr,ref['feedback_gains']) for rr in f['records'])
            choices=[]
            for priority,(method,row,gains) in enumerate(options):
                sel=select_physical_prefix(np.load(row['tape']['path'])['states'][:N+1],14)
                if sel:choices.append((sel['steps'],-priority,method,row,gains,sel))
                if row['full_nominal_component_gate_passed']:direct.append((method,row,gains,c,r['candidate']))
            chosen=max(choices,key=lambda x:(x[0],x[1])) if choices else None
            expected=None if chosen is None else dict(method=chosen[2],tape=chosen[3]['tape'],**chosen[5]);assert e['selected']==expected
            if chosen:selected=chosen[5];selected_record=chosen[3];selected_gains=chosen[4]
        passing=None;passing_gains=None;passing_h=None;gain_path=None
        if d.get('completed_short_route'):
            assert direct and 'capture_suffix8' not in stages
            method,passing,passing_gains,c,ref=direct[0];passing_h=N;assert d['completed_short_route']['method']==method and d['completed_short_route']['tape']==passing['tape']
            gain_path=[s['result']['path'] for s in d['stages'] if s['name'] in ('maintenance_gain','native_feedback16','native_feedback8') and 'gain' in read(s['result']['path'])][-1]
        elif selected:
            checked(d['physical_prefix_initializer']);seed=read(d['physical_prefix_initializer']['path']);steps=selected['steps'];origin=np.load(selected_record['tape']['path']);expected=extend_actual_prefix_initializer(source,origin['states'],origin['actions'],selected_gains,steps)
            for key in ('selected_state','controller','search'):assert seed[key]==expected[key]
            assert seed['physical_prefix_tape']==selected_record['tape'] and seed['physical_prefix_selection']==selected and seed['virtual_tail_source']==pre['source_initializer']
            suffix=stages['capture_suffix8'];c=read(suffix['candidate']['path']);assert suffix['initializer']==d['physical_prefix_initializer'] and suffix['optimize_suffix_start_seconds']==selected['seconds']
            assert c['controller']['frozen_prefix_steps']==steps and c['search']['optimized_horizon_steps']==700-steps
            for key in ('controls','feedback_gains'):assert np.array(c['controller'][key])[:steps].tobytes()==np.array(seed['controller'][key])[:steps].tobytes()
            assert np.array(c['search']['nominal_coordinate_states'])[:steps+1].tobytes()==origin['states'][:steps+1].tobytes()
            sx,su,_=tape(suffix);assert sx[:steps+1].tobytes()==origin['states'][:steps+1].tobytes() and su[:steps].tobytes()==origin['actions'][:steps].tobytes()
            available=[float(t) for t in range(math.ceil(selected['seconds']),14) if t*50<=len(su)];assert d['available_handoff_seconds']==available
            if available:
                screen=stages['saved_feedback_handoffs'];assert [rr['handoff_seconds'] for rr in screen['records']]==available;passes=[]
                for rr in screen['records']:
                    xx,uu,gg=tape(rr);step=round(rr['handoff_seconds']/.02);assert xx[:step+1].tobytes()==sx[:step+1].tobytes() and uu[:step].tobytes()==su[:step].tobytes()
                    if gg:passes.append(rr)
                assert screen['total_native_transition_calls']==sum(rr['total_native_transition_calls'] for rr in screen['records'])
                if passes:passing=min(passes,key=lambda r:r['handoff_seconds']);passing_h=round(passing['handoff_seconds']/.02);passing_gains=np.array(c['controller']['feedback_gains']);gain_path=screen['gain_source']['path']
        else:assert len(d['selection_history'])==2 and 'capture_suffix8' not in stages
        assert d['component_passed']==bool(passing)
        if passing:
            checked(d['passing_physical_initializer']);physical=read(d['passing_physical_initializer']['path']);tt=np.load(passing['tape']['path']);gain=np.array(read(gain_path)['gain']);k=np.vstack([passing_gains[:passing_h],np.tile(-gain,(700-passing_h,1))])
            assert physical['passing_tape']==passing['tape'] and physical['selected_handoff_seconds']==passing_h*.02
            assert np.array(physical['search']['nominal_coordinate_states']).tobytes()==tt['states'][:701].tobytes()
            assert np.array(physical['controller']['controls']).tobytes()==tt['actions'][:700].tobytes() and np.array(physical['controller']['feedback_gains']).tobytes()==k.tobytes()
        rows.extend(local);parents.append(dict(directory=str(folder),execution=pj,result=file_metadata(path),config=d['config'],role='pipeline_parent_not_additive',status='finished',selection_history=d['selection_history'],component_passed=d['component_passed'],termination=d['termination'],horizon_seconds=h,total_native_transition_calls=d['total_native_transition_calls'],actual_hanging_start_episode_steps=d['actual_hanging_start_episode_steps'],passing_physical_initializer=d.get('passing_physical_initializer')))
    total=sum(r['total_native_transition_calls'] for r in rows);actual=sum(r['actual_hanging_start_episode_steps'] for r in rows);assert total<=4440948
    result=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),passed=True,studies=rows,pipelines=parents,preflight=file_metadata(root/'preflight_failures_verified.json'),setup_failure_record=file_metadata(root/'setup_failures.json'),total_new_native_transition_calls=int(total),actual_hanging_start_episode_steps=actual,total_native_transition_calls_for_this_audit=0,budget_scope='All primitive source replays, retained preflight failures and corrected stages once. Four pipeline parents are nonadditive; setup-only failures add zero physics.',canonical_release_evidence=False,not_solution=True,reserved_seeds_used=False,noisy_development_seeds_used=False,source_prefix_fidelity=True,selection_reproduced=True)
    dump_json(result,root/'verified.json');print(json.dumps(dict(passed=True,nativecalls=int(total),actual_steps=actual,primitives=len(rows),pipelines=len(parents),component_passes=[p['directory'] for p in parents if p.get('component_passed')])))

if __name__=='__main__':main()
