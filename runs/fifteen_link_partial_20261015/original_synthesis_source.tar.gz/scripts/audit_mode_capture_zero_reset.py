"""Reproduce the interrupted modal screen's signed-zero initialization mismatch.

Uses reset only; no actual or private physics transitions.
"""
import argparse
import json
from pathlib import Path
import numpy as np
from gcartpole.config import load_config, dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, utc_timestamp
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--partial', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    partial = json.loads(Path(args.partial).read_text())
    assert len(partial['records']) == 22
    design = partial['designs'][0]
    sources = [(None, 0., 1, np.zeros(32))]
    sources.extend((d['mode'], amplitude, sign,
                    sign * amplitude * np.asarray(d['rounded_direction']))
                   for d in design['directions'] for amplitude in partial['amplitudes']
                   for sign in (1, -1))
    mode, amplitude, sign, initial = sources[len(partial['records'])]
    cfg = load_config('configs/swingup15_uniform.yaml')
    local = fixed_state_cfg(cfg, dict(qpos=initial[:16].tolist(), qvel=initial[16:].tolist()), 30.)
    for key in ('init_qpos_scale_start', 'init_qpos_scale_end'):
        local['env'].pop(key, None)
    env = NLinkCartPoleEnv(local, progress=1., seed=0)
    try:
        env.reset(seed=0)
        actual = np.r_[env.data.qpos, env.data.qvel]
        mismatches = np.flatnonzero(initial.view(np.uint64) != actual.view(np.uint64))
        assert len(mismatches) and np.array_equal(initial, actual)
        assert all(initial[i] == actual[i] == 0. for i in mismatches)
        normalized = initial.copy(); normalized[normalized == 0] = 0.
        assert normalized.tobytes() == actual.tobytes()
        dump_json(dict(generated_at=utc_timestamp(), script=file_metadata(__file__),
            partial=file_metadata(args.partial), mode=mode, amplitude=amplitude, sign=sign,
            bit_mismatch_indices=mismatches.tolist(), nonzero_coordinates_unchanged=True,
            only_signed_zero_mismatch=True, positive_zero_normalized_bytes_exact=True,
            native_transition_calls=0, actual_episode_steps=0,
            scope='Reset-only diagnosis of the first uncompleted modal case; no live continuation or release evidence.'), args.output)
    finally:
        env.close()


if __name__ == '__main__':
    main()
