#!/usr/bin/env python
"""Replay equivalent reference branches without changing a live plant state."""
import argparse
import json
import time
from pathlib import Path

import numpy as np

from gcartpole.config import dump_json, load_config
from gcartpole.evidence import data_sha256, file_metadata, runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.search_ilqr_capture import execute_controller
from scripts.solve_frontier_capture_increment import physical_replay_passed, validate_development_seeds


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for key in ('source', 'config', 'capture-cache', 'directory'):
        p.add_argument('--'+key, required=True)
    args = p.parse_args()
    out = Path(args.directory)
    if (out/'result.json').exists():
        raise FileExistsError(out)
    source = json.loads(Path(args.source).read_text())
    cache = json.loads(Path(args.capture_cache).read_text())
    cfg = load_config(args.config)
    c = source['controller']
    n = cfg['env']['n_links']
    validate_development_seeds(n, source['seed'])
    nodes = np.asarray(source['search']['nominal_coordinate_states'])
    controls = np.asarray(c['controls'])
    gains = np.asarray(c['feedback_gains'])
    transform = np.asarray(c['coordinate_transform'])
    gain = np.asarray(cache['gain'])
    factor = np.asarray(source['lyapunov']['factor'])
    if (not c['continuous_angles'] or c['phase_adaptive']
            or not np.array_equal(transform, np.eye(2*(n+1)))
            or cache['config'] != file_metadata(args.config)
            or data_sha256(gain.tolist()) != cache['gain_sha256']
            or data_sha256(factor.tolist()) != cache['factor_sha256']
            or cache['factor_sha256'] != source['lyapunov']['factor_sha256']
            or not cache['maintenance_factor_reproduced_bit_identically']):
        raise ValueError('Verified physical-coordinate fixed-time gain/factor inputs required')
    start = np.asarray(source['selected_state']['qpos']+source['selected_state']['qvel'])
    if not np.array_equal(start, nodes[0]):
        raise ValueError('Source selected state and initial reference disagree')
    begun = time.monotonic()
    records = []
    baseline_rows = None
    for label in ('original', 'reflected', 'positive_winding'):
        sign = -1. if label == 'reflected' else 1.
        shift = np.zeros_like(start)
        if label == 'positive_winding':
            shift[1] = 2*np.pi
        initial = sign*start+shift
        branch_nodes = sign*nodes+shift
        branch_controls = sign*controls
        state = dict(qpos=initial[:n+1].tolist(), qvel=initial[n+1:].tolist())
        branch_cfg = fixed_state_cfg(cfg, state, 30.)
        # The general fixed-state helper includes unit scale endpoints. Their
        # presence activates reset-time angle wrapping even at scale one.
        # An angle-branch experiment must preserve its declared reset branch.
        branch_cfg['env'].pop('init_qpos_scale_start', None)
        branch_cfg['env'].pop('init_qpos_scale_end', None)
        check = NLinkCartPoleEnv(branch_cfg, progress=1., seed=source['seed'])
        try:
            check.reset(seed=source['seed'])
            if not np.array_equal(np.r_[check.data.qpos, check.data.qvel], initial):
                raise ValueError('Declared branch changed during reset')
        finally:
            check.close()
        proposal = out/label/'initializer.json'
        dump_json(dict(not_solution=True, initialization_only=True, seed=source['seed'],
            selected_state=state, source=file_metadata(args.source),
            branch=dict(label=label, reflection=sign, constant_reference_shift=shift.tolist(),
                        live_state_projection=False),
            controller=dict(c, controls=branch_controls.tolist()),
            search=dict(nominal_coordinate_states=branch_nodes.tolist())), proposal)
        episode = execute_controller(branch_cfg, progress=1., seed=source['seed'],
            controls=branch_controls, nominal_states=branch_nodes, feedback_gains=gains,
            gain=gain, lqr_scale=c['lqr_scale'], transform=transform,
            lyapunov=factor.T@factor, lyapunov_factor=factor,
            handoff_lyapunov=c['handoff_lyapunov'], handoff_cart_abs=c['handoff_cart_abs'],
            handoff_angle_abs=c['handoff_angle_abs'],
            handoff_cart_velocity_abs=c['handoff_cart_velocity_abs'],
            handoff_hinge_velocity_rms=c['handoff_hinge_velocity_rms'],
            tracking_mode='angle_branch_tracking',
            defer_handoff_until_horizon=c['defer_handoff_until_horizon'],
            phase_adaptive=False, phase_window=c['phase_window'], continuous_angles=True)
        rows = episode['trajectory']
        if baseline_rows is None:
            baseline_rows = rows
            original = source['result']['trajectory']
            identical = len(rows) == len(original) and all(
                a['qpos'] == b['qpos'] and a['qvel'] == b['qvel'] and a['action'] == b['action']
                for a, b in zip(rows, original))
            if not identical:
                raise ValueError('Original replay did not reproduce its native states/actions exactly')
        overlap = min(len(rows), len(baseline_rows))
        state_errors = [float(np.max(np.abs(
            np.asarray(a['qpos']+a['qvel'])-(sign*np.asarray(b['qpos']+b['qvel'])+shift))))
            for a, b in zip(rows[:overlap], baseline_rows[:overlap])]
        action_errors = [abs(a['action']-sign*b['action'])
                         for a, b in zip(rows[:overlap], baseline_rows[:overlap])]
        payload = dict(not_solution=True, benchmark_evidence=False, seed=source['seed'],
            selected_state=state, source=file_metadata(args.source), config=file_metadata(args.config),
            branch=label, controller=dict(c, controls=branch_controls.tolist()),
            search=dict(nominal_coordinate_states=branch_nodes.tolist()), result=episode,
            full_physical_pass=physical_replay_passed(episode, branch_cfg),
            no_live_state_projection=True, declared_reset_branch_verified=True,
            native_episode_steps=len(rows))
        dump_json(payload, out/label/'result.json')
        records.append(dict(label=label, result=file_metadata(out/label/'result.json'),
            initial_qpos=state['qpos'], full_physical_pass=payload['full_physical_pass'],
            physical={k:episode[k] for k in ('length', 'success', 'termination_reason',
                'trajectory_integrity', 'max_upright_streak_seconds', 'max_cart_excursion')},
            overlapping_native_ticks=overlap, maximum_equivalent_state_error=max(state_errors),
            first_state_difference_tick=next((i+1 for i,v in enumerate(state_errors) if v>0),None),
            first_state_error_above_1e_4_tick=next((i+1 for i,v in enumerate(state_errors) if v>1e-4),None),
            maximum_equivalent_action_error=max(action_errors)))
    dump_json(dict(not_solution=True, benchmark_evidence=False, source=file_metadata(args.source),
        config=file_metadata(args.config), capture_cache=file_metadata(args.capture_cache),
        runtime=runtime_metadata(), records=records, original_replay_bit_identical=True,
        native_episode_steps=sum(r['physical']['length'] for r in records),
        wall_seconds=time.monotonic()-begun, reserved_seeds_used=False,
        noisy_development_seeds_used=False,
        scope='Auxiliary exact reset states and policy/reference transformations only. '
              'Reflection negates controls/nodes while retaining feedback gains; winding shifts '
              'q1 by 2pi at reset and in reference nodes. No live state wrapping or projection. '
              'These mathematically equivalent branches need not be numerically equivalent; '
              'no noisy robustness or canonical release is inferred.'), out/'result.json')
    print(json.dumps(records), flush=True)


if __name__ == '__main__':
    main()
