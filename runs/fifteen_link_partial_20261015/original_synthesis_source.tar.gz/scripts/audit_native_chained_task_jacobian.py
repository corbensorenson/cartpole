#!/usr/bin/env python
"""Native local derivative composition versus long-rollout task secants."""
import argparse,json,time
from pathlib import Path
import mpmath
import numpy as np
from scipy.optimize import lsq_linear
from gcartpole.angles import wrap_angle
from gcartpole.config import dump_json,load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',required=True);parser.add_argument('--directory',required=True)
    parser.add_argument('--delivered-steps',type=int,nargs='+',default=[376,392,408])
    args=parser.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    source=json.loads(Path(args.source).read_text());cfgpath=source['config']['path']
    basepath=source['source']['path']
    if file_metadata(cfgpath)!=source['config'] or file_metadata(basepath)!=source['source']:raise ValueError('Source inputs changed')
    base=json.loads(Path(basepath).read_text());cfg=load_config(cfgpath);n=cfg['env']['n_links'];nx=2*(n+1)
    horizon=source['executed_policy']['requested_horizon_steps'];rate=source['executed_policy']['residual_weights']['rate']
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True)
    local=FourthOrderMujocoTransition(env,np.eye(nx),continuous_angles=True)
    ctx=mpmath.mp.clone();ctx.dps=100;rows=source['result']['trajectory'];records=[];began=time.monotonic()
    def forecast(state,u):
        states=[];current=state.copy()
        for action in np.asarray(u,dtype=np.float32).astype(float):
            current=native(current,float(action));states.append(current.copy())
        a=np.asarray(states);angles=wrap_angle(np.cumsum(a[:,1:n+1],axis=1));rates=np.cumsum(a[:,n+2:],axis=1)
        residual=np.r_[(angles/.15/np.sqrt(n*horizon)).ravel(),(rate*rates/.75/np.sqrt(n*horizon)).ravel(),
            .1*a[:,0]/1.5/np.sqrt(horizon),.1*a[:,n+1]/.5/np.sqrt(horizon),
            np.sqrt(5)*angles[-1]/.15/np.sqrt(n),np.sqrt(5)*rate*rates[-1]/.75/np.sqrt(n)]
        return residual,a
    try:
        for step in args.delivered_steps:
            row=rows[step-1];state=np.asarray(rows[step-2]['qpos']+rows[step-2]['qvel'])
            u=np.asarray(row['tracking_preview']['selected_sequence'],dtype=np.float32).astype(float)
            if len(u)!=horizon:raise ValueError('Complete retained plan required')
            residual,states=forecast(state,u)
            if not np.array_equal(states[0],row['qpos']+row['qvel']):raise ValueError('First native forecast differs from actual state')
            reference=np.asarray(base['controller']['controls'][step-1:step-1+horizon])
            sensitivities=[];s=ctx.zeros(nx,horizon);before=local.evaluations
            for k in range(horizon):
                point=state if k==0 else states[k-1]
                a,b=local.linearize(point,float(u[k]),state_epsilon=base['controller']['state_epsilon'],
                    action_epsilon=base['controller']['action_epsilon'])
                s=ctx.matrix(a.tolist())*s
                for j in range(nx):s[j,k]+=ctx.mpf(float(b[j,0]))
                sensitivities.append(s.copy())
            # Build the physical task map in MP before rounding the final Jacobian.
            mapped=[];angle_rows=[];rate_rows=[]
            for s in sensitivities:
                angle_rows.append([sum(s[i,c] for i in range(1,j+2)) for j in range(n) for c in range(horizon)])
                rate_rows.append([sum(s[i,c] for i in range(n+2,n+j+3)) for j in range(n) for c in range(horizon)])
            for blocks,scale in [(angle_rows,1/.15/np.sqrt(n*horizon)),(rate_rows,rate/.75/np.sqrt(n*horizon))]:
                for block in blocks:
                    for j in range(n):mapped.append([v*ctx.mpf(float(scale)) for v in block[j*horizon:(j+1)*horizon]])
            for index,scale in [(0,.1/1.5/np.sqrt(horizon)),(n+1,.1/.5/np.sqrt(horizon))]:
                for s in sensitivities:mapped.append([s[index,c]*ctx.mpf(float(scale)) for c in range(horizon)])
            for block,scale in [(angle_rows[-1],np.sqrt(5)/.15/np.sqrt(n)),(rate_rows[-1],np.sqrt(5)*rate/.75/np.sqrt(n))]:
                for j in range(n):mapped.append([v*ctx.mpf(float(scale)) for v in block[j*horizon:(j+1)*horizon]])
            chained=np.asarray(ctx.matrix(mapped).tolist(),float)
            long=[];epsilon=1e-8
            for k in range(horizon):
                plus=u.copy();minus=u.copy();plus[k]=np.float32(min(1.,u[k]+epsilon));minus[k]=np.float32(max(-1.,u[k]-epsilon))
                if plus[k]==minus[k]:
                    plus[k]=min(1.,float(np.nextafter(np.float32(u[k]),np.float32(np.inf))))
                    minus[k]=max(-1.,float(np.nextafter(np.float32(u[k]),np.float32(-np.inf))))
                long.append((forecast(state,plus)[0]-forecast(state,minus)[0])/(plus[k]-minus[k]))
            secant=np.column_stack(long);methods=[]
            for label,jac in [('native_local4_chain_mp100',chained),('whole_rollout_secant1e8',secant)]:
                fitted=lsq_linear(np.vstack([jac,.01*np.eye(horizon)]),np.r_[jac@u-residual,.01*reference],
                    bounds=(-1.,1.),tol=1e-12,max_iter=200)
                delta=fitted.x-u;trials=[]
                for exponent in range(21):
                    fraction=2.**(-exponent);candidate=np.asarray(u+fraction*delta,dtype=np.float32).astype(float)
                    r,trajectory=forecast(state,candidate);admissible=bool(np.all(np.isfinite(trajectory)) and np.all(np.abs(trajectory[:,0])<=env.rail_limit))
                    trials.append(dict(fraction=fraction,physical_cost=float(r@r),admissible=admissible,
                        linear_predicted_physical_cost=float(np.sum((residual+jac@(candidate-u))**2)),sequence=candidate.tolist()))
                valid=[t for t in trials if t['admissible']];best=min(valid,key=lambda t:t['physical_cost']) if valid else None
                methods.append(dict(method=label,local_solver_success=bool(fitted.success),
                    singular_values=np.linalg.svd(jac,compute_uv=False).tolist(),trials=trials,best_native_trial=best))
            records.append(dict(delivered_step=step,actual_first_state_bit_identical=True,baseline_physical_cost=float(residual@residual),
                native_local_derivative_transition_calls=local.evaluations-before,
                chained_jacobian_relative_difference_from_whole_secant1e8=float(np.linalg.norm(chained-secant)/np.linalg.norm(secant)),
                methods=methods));print(json.dumps(dict(step=step,baseline=float(residual@residual),
                    best={m['method']:None if m['best_native_trial'] is None else m['best_native_trial']['physical_cost'] for m in methods})),flush=True)
    finally:env.close()
    dump_json(dict(not_solution=True,canonical_release_evidence=False,source=file_metadata(args.source),config=file_metadata(cfgpath),
        records=records,native_forecast_transition_calls=native.evaluations,native_local_derivative_transition_calls=local.evaluations,
        total_native_transition_calls=native.evaluations+local.evaluations,wall_seconds=time.monotonic()-began,runtime=runtime_metadata(),
        reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='One-step native fourth-order secants composed in MP100, versus direct long-rollout secants. Rounded input model/FD errors and native runtime arithmetic remain. Native backtracking evaluates quantized proposals from fixed actual states; no episode pass, exact Jacobian or global controllability claim.'),out/'result.json')


if __name__=='__main__':main()
