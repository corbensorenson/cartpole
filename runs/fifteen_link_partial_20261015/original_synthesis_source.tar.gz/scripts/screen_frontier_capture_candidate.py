#!/usr/bin/env python
"""Screen a declared repaired route, then rebuild its earliest physical pass.

This count-independent tool performs no noisy cohorts, freezing or publication.
"""
import argparse
import copy
import json
import math
from pathlib import Path
import subprocess
import sys

from gcartpole.config import dump_json, load_config
from gcartpole.evidence import file_metadata, utc_timestamp
from gcartpole.roadmap import validate_canonical_config
from scripts.solve_frontier_capture_increment import (
    HANDOFF_SECONDS, physical_replay_passed, validate_development_seeds,
)
from scripts.synthesize_inverse_increment import exact_candidate_passed
from scripts.verify_frontier_release import verify_manifest


def validate_handoff_times(seconds, dt, horizon_steps):
    """Only screen complete, tick-aligned physical prefixes of the saved route."""
    values = tuple(float(t) for t in seconds)
    if (not values or len(set(values)) != len(values)
            or any(not math.isfinite(t) or t <= 0 or t > horizon_steps*dt+1e-12
                   or not math.isclose(round(t/dt)*dt,t,rel_tol=0.,abs_tol=1e-12) for t in values)):
        raise ValueError('handoffs must be unique finite positive route-prefix control-tick times')
    return tuple(sorted(values))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config', required=True)
    p.add_argument('--source', required=True)
    p.add_argument('--source-manifest', required=True)
    p.add_argument('--directory', required=True)
    p.add_argument('--handoff-seconds',type=float,nargs='+',default=HANDOFF_SECONDS,
                   help='Explicit declared handoff bracket; defaults preserve 8/9/10/12 seconds.')
    args = p.parse_args()
    source, out = Path(args.source), Path(args.directory)
    cfg = load_config(args.config)
    canonical = copy.deepcopy(cfg); canonical['env']['n_links'] = 7
    errors = validate_canonical_config(canonical)+verify_manifest(Path(args.source_manifest))
    predecessor = json.loads(Path(args.source_manifest).read_text())
    prior = json.loads(source.read_text())
    if errors or predecessor['n_links'] != cfg['env']['n_links']-1:
        raise ValueError('requires canonical configuration and verified adjacent predecessor')
    if len(prior['selected_state']['qpos']) != cfg['env']['n_links']+1:
        raise ValueError('source link count differs')
    validate_development_seeds(cfg['env']['n_links'], prior['seed'])
    handoffs = validate_handoff_times(args.handoff_seconds,
        cfg['env']['timestep']*cfg['env']['frame_skip'],len(prior['controller']['controls']))
    journal = out/'physical_screen.json'
    if journal.exists():
        raise FileExistsError(journal)
    record = dict(status='running', started_at=utc_timestamp(), not_solution=True,
        release_promotion=False, reserved_seeds_used=False, n_links=cfg['env']['n_links'],
        seed=prior['seed'], source=file_metadata(source), config=file_metadata(args.config),
        source_manifest=file_metadata(args.source_manifest), handoff_results=[], stages=[],
        declared_handoff_seconds=list(handoffs),
        protocol='All declared handoffs / earliest full physical pass / exact rebuild; no noisy or reserved episodes.')
    out.mkdir(parents=True, exist_ok=True)
    def stage(label, script, input_source, options):
        if file_metadata(source) != record['source']:
            raise ValueError('declared source changed during screening')
        directory = out/label
        command = [sys.executable, 'scripts/run_frontier_experiment.py', '--directory', str(directory),
            '--input', str(input_source), '--input', args.config, '--input', args.source_manifest,
            '--', sys.executable, 'scripts/'+script, '--source', str(input_source),
            '--config', args.config, '--directory', str(directory), *options]
        subprocess.run(command, check=True)
        path = directory/'result.json'
        record['stages'].append(dict(label=label, execution=file_metadata(directory/'execution.json'),
                                    result=file_metadata(path)))
        dump_json(record, journal)
        return path, json.loads(path.read_text())
    dump_json(record, journal)
    try:
        for seconds in handoffs:
            path, data = stage(f'handoff{seconds:g}', 'replay_frontier_handoff.py', source,
                               ['--handoff-seconds', str(seconds)])
            record['handoff_results'].append(dict(seconds=seconds, result=file_metadata(path),
                full_physical_pass=physical_replay_passed(data['result'], cfg)))
            dump_json(record, journal)
        passing = [x for x in record['handoff_results'] if x['full_physical_pass']]
        if not passing:
            record.update(status='finished_negative', next_step='Retain negative physical evidence; no development promotion.')
        else:
            selected = min(passing, key=lambda x:x['seconds'])
            path, data = stage('physical_rebuild', 'rebuild_frontier_physical_route.py',
                               Path(selected['result']['path']), [])
            if (not exact_candidate_passed(data, cfg) or not physical_replay_passed(data['result'], cfg)
                    or data['controller']['final_trajectory_diagnostics']['maximum_dynamics_defect'] != 0
                    or not data['physical_rebuild_comparison']['all_physical_states_identical']):
                raise ValueError('candidate lacks an exact, identical, passed physical rebuild')
            record.update(status='passed_physical_requires_selection_and_noisy_development',
                selected_handoff_seconds=selected['seconds'], candidate=file_metadata(path),
                next_step='Apply the declared inter-branch selection before independent noisy development.')
    except BaseException as error:
        record.update(status='failed_or_interrupted', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        record['finished_at'] = utc_timestamp(); dump_json(record, journal)
    print(json.dumps(dict(status=record['status'], journal=str(journal))))


if __name__ == '__main__':
    main()
