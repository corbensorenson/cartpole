"""Independent replay of all full-route derivative queries and MP80 gains."""
import argparse,json
from pathlib import Path
import numpy as np,mpmath
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg
read=lambda p:json.loads(Path(p).read_text())
def same(a,b):assert np.asarray(a).tobytes()==np.asarray(b).tobytes()
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);args=p.parse_args();root=Path(args.root);out=Path(args.out);out.mkdir(exist_ok=False);m=read(root/'design_manifest.json');r=read(root/'design/diagnostic/result.json');j=read(root/'design/execution.json');assert j['status']=='finished' and j['returncode']==0 and r['passed'];base=read(m['controller_source']['path']);c=base['controller'];h=m['horizon']
 for key in ('controller_source','config','route_tape','source_audit'):assert m[key]==file_metadata(m[key]['path'])
 for key in ('derivative_array','full_gain_array','tracking_export','local_diagnostics'):assert r[key]==file_metadata(r[key]['path'])
 with np.load(m['route_tape']['path']) as z:X=z['states'][:h+1].copy();U=z['actions'][:h].copy()
 with np.load(r['full_gain_array']['path']) as z:design={k:z[k] for k in z.files}
 with np.load(r['derivative_array']['path']) as z:
  for key in ('states','actions','A','B','stage_factor','terminal_factor'):same(z[key],design[key])
 same(X,design['states']);same(U,design['actions']);D=np.asarray(c['normalized_cost_mapping']);w=np.ones(32);w[1:16]*=c['terminal_angle_factor'];w[16]*=c['terminal_cart_velocity_factor'];w[17:]*=c['terminal_hinge_velocity_factor'];tf=np.diag(np.sqrt(c['terminal_state_weight']*w))@D;sf=np.sqrt(c['stage_weight'])*D;same(tf,design['terminal_factor']);same(sf,design['stage_factor']);assert np.max(abs(X[:,0]))<=c['rail_soft_limit']
 cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);env=NLinkCartPoleEnv(cfg,progress=1.,seed=m['nominal_seed']);env.reset(seed=m['nominal_seed']);native=MujocoTransition(env,np.eye(32),continuous_angles=True);queries=0
 try:
  for i,u in enumerate(U):same(native(X[i],float(u)),X[i+1])
  assert len(r['derivative_queries'])==h
  for i,row in enumerate(r['derivative_queries']):
   assert row['step']==i and row['tape']==file_metadata(row['tape']['path']) and all(q is None for q in row['errors'])
   with np.load(row['tape']['path']) as z:pairs=z['states'];us=z['actions'];raws=z['raw_actions'];assert np.isnan(z['failed_post_states']).all() and np.isnan(z['failed_times']).all()
   assert len(pairs)==134 and len(us)==len(raws)==len(row['errors'])
   expected=[]
   for col in range(32):
    delta=np.zeros(32);delta[col]=m['state_epsilon'];expected.extend([(X[i]+delta,U[i]),(X[i]-delta,U[i]),(X[i]+2*delta,U[i]),(X[i]-2*delta,U[i])])
   center=float(np.float32(np.clip(U[i],-1,1)));eps=m['action_epsilon'];shifts=np.arange(-4,1) if center+2*eps>1 else np.arange(5) if center-2*eps< -1 else np.arange(-2,3);knots=np.asarray([float(np.float32(np.clip(center+k*eps,-1,1))) for k in shifts]);expected.extend([(X[i],center)]+[(X[i],q) for q in knots])
   for k,(x,raw) in enumerate(expected):same(x,pairs[k,0]);assert raw==raws[k] and float(np.float32(np.clip(raw,-1,1)))==us[k];same(native(x,float(us[k])),pairs[k,1]);queries+=1
   A=np.column_stack([(8*(pairs[4*k,1]-pairs[4*k+1,1])-(pairs[4*k+2,1]-pairs[4*k+3,1]))/(12*m['state_epsilon']) for k in range(32)]);offsets=(knots-center)/eps;weights=np.linalg.solve(np.vstack([offsets**k for k in range(5)]),np.array([0.,1.,0.,0.,0.]))/eps;B=(weights@(pairs[129:,1]-pairs[128,1]))[:,None];same(A,design['A'][i]);same(B,design['B'][i])
  ctx=mpmath.mp.clone();ctx.dps=80;mat=lambda x:ctx.matrix(np.asarray(x).tolist());TF=mat(tf);SF=mat(sf);P=TF.T*TF;Q=SF.T*SF;K=np.empty((h,32))
  for i in range(h-1,-1,-1):
   A=mat(design['A'][i]);B=mat(design['B'][i]);cross=B.T*P*A;H=ctx.mpf(c['control_cost'])+ctx.mpf(m['regularization'])+(B.T*P*B)[0];assert ctx.isfinite(H) and H>0;K[i]=[float(q) for q in -cross/H];P=Q+A.T*P*A-cross.T*cross/H;P=(P+P.T)/2
  residual=float(np.max(abs(K-design['gains'])));assert residual<=1e-8+1e-12*np.max(abs(design['gains']))
  with np.load(r['tracking_export']['path']) as z:same(z['states'],X[:-1]);same(z['controls'],U[:-1]);same(z['gains'],design['gains'][None,:-1])
  closed=design['A']+design['B']*design['gains'][:,None,:]
  with np.load(r['local_diagnostics']['path']) as z:
   for key,value in [('A_singular_values',np.linalg.svd(design['A'],compute_uv=False)),('closed_singular_values',np.linalg.svd(closed,compute_uv=False)),('A_eigenvalues',np.linalg.eigvals(design['A'])),('closed_eigenvalues',np.linalg.eigvals(closed)),('gain_norms',np.linalg.norm(design['gains'],axis=1))]:same(z[key],value)
  assert native.evaluations==r['total_native_transition_calls']==h+134*h;dump_json(dict(status='finished',passed=True,generated_at=utc_timestamp(),scope=m['scope'],source=file_metadata(root/'design/diagnostic/result.json'),whole_route_source_steps_proved=h,derivative_queries_proved=queries,independent_mp80_gain_residual=residual,export_and_descriptive_local_diagnostics_proved=True,total_native_transition_calls=native.evaluations,actual_hanging_start_episode_steps=0,canonical_release_evidence=False,not_solution=True),out/'result.json');print(dict(passed=True,calls=native.evaluations,mp80_residual=residual),flush=True)
 finally:env.close()
if __name__=='__main__':main()
