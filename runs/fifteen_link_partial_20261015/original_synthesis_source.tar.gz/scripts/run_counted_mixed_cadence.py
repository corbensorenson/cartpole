"""Count native substeps and completed environment calls for mixed-rate trials."""
import argparse,runpy,sys
import mujoco
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp

def main():
 p=argparse.ArgumentParser();p.add_argument('--substep-ceiling',type=int,required=True);p.add_argument('--accounting-file',required=True);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args();command=a.command[1:] if a.command[:1]==['--'] else a.command
 original=mujoco.mj_step;original_env=NLinkCartPoleEnv.step;oldargv=sys.argv;counts={'attempted_substeps':0,'completed_substeps':0,'actual_attempts':0,'actual_completed':0};by_skip={}
 record=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),command=command,substep_ceiling=a.substep_ceiling,canonical_release_evidence=False,scope='Counts in-process mj_step calls; four-substep equivalents are cost units, not mixed-rate control calls. No optimizer in this matched fixed-gain comparison.')
 def counted(model,data,*args,**kw):
  n=int(kw.get('nstep',args[0] if args else 1))
  if counts['attempted_substeps']+n>a.substep_ceiling:raise RuntimeError('mixed cadence substep ceiling reached before physics')
  counts['attempted_substeps']+=n;result=original(model,data,*args,**kw);counts['completed_substeps']+=n;return result
 def counted_env(env,action):
  counts['actual_attempts']+=1;skip=str(env.frame_skip);by_skip.setdefault(skip,{'attempts':0,'completed':0});by_skip[skip]['attempts']+=1
  result=original_env(env,action);counts['actual_completed']+=1;by_skip[skip]['completed']+=1;return result
 mujoco.mj_step=counted;NLinkCartPoleEnv.step=counted_env
 try:sys.argv=command;runpy.run_path(command[0],run_name='__main__');record['status']='finished'
 except BaseException as e:record.update(status='failed',error=f'{type(e).__name__}: {e}');raise
 finally:
  mujoco.mj_step=original;NLinkCartPoleEnv.step=original_env;sys.argv=oldargv
  record.update(counts=counts,actual_calls_by_frame_skip=by_skip,native_physics_substeps=counts['attempted_substeps'],total_native_transition_calls=counts['attempted_substeps']/4,actual_hanging_start_episode_steps=counts['actual_attempts'],finished_at=utc_timestamp());dump_json(record,a.accounting_file);print(record,flush=True)
if __name__=='__main__':main()
