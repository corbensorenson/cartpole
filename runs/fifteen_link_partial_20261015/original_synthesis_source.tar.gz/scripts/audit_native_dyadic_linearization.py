#!/usr/bin/env python
"""Native power-of-two secants versus analytic MP upright capture components."""
import argparse
import copy
import hashlib
import json
import time
from pathlib import Path

import numpy as np
from gcartpole.config import dump_json, load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, runtime_metadata, utc_timestamp
from gcartpole.ilqr import MujocoTransition
from gcartpole.lqr_design import high_precision_discrete_lqr
from gcartpole.upright_mechanics import upright_rk4_matrices
from scripts.audit_link_count_frontier import WEIGHTS, exact_capture
from scripts.make_lqr_checkpoint import absolute_angle_cost


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',default='configs/swingup15_uniform.yaml')
    parser.add_argument('--counts',type=int,nargs='+',default=[14,15,20])
    parser.add_argument('--exponents',type=int,nargs='+',default=[25,35,45,55])
    parser.add_argument('--directory',required=True)
    args=parser.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    if min(args.exponents)<20 or max(args.exponents)>100:raise ValueError('use finite small dyadic secants')
    started=time.monotonic(); records=[];base=load_config(args.config)
    result=dict(not_solution=True,canonical_release_evidence=False,generated_at=utc_timestamp(),
        parameters=vars(args),config=file_metadata(args.config),runtime=runtime_metadata(),records=records,
        native_design_transition_calls=0,actual_local_episode_steps=0,
        reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Column secants sample native binary64 RK4 and exact power-of-two F32 actions at upright. Native matrices are promoted exactly for MP100 Riccati design; binary64 gain/runtime unchanged. Agreement across secants is diagnostic, not an exact Jacobian or nonlinear basin certificate. Mixed-state tests expose nonadditive native arithmetic. All actual local episodes are auxiliary components, never hanging-start release evidence.')
    for n in args.counts:
        cfg=copy.deepcopy(base);cfg['env']['n_links']=n
        env=NLinkCartPoleEnv(cfg,progress=1.,seed=0);nx=2*(n+1)
        transition=MujocoTransition(env,np.eye(nx),continuous_angles=True)
        a_mp,b_mp,mechanics=upright_rk4_matrices(env,decimal_digits=100)
        analytic_a=np.asarray(a_mp.tolist(),float);analytic_b=np.asarray(b_mp.tolist(),float)
        directions=np.random.default_rng(20265500+n).uniform(-1,1,(4,2*n))
        mixed=np.random.default_rng(20265600+n).uniform(-1,1,(4,nx+1))
        record=dict(n_links=n,frame_skip=env.frame_skip,control_hz=1/env.dt,mechanics=mechanics,
            paired_directions=directions.tolist(),column_samples=[],unique_designs=[])
        records.append(record);unique={}
        try:
            for exponent in args.exponents:
                epsilon=2.**(-exponent);before=transition.evaluations
                a,b=transition.linearize(np.zeros(nx),0.,state_epsilon=epsilon,action_epsilon=epsilon)
                signature=hashlib.sha256(a.tobytes()+b.tobytes()).hexdigest()
                probe=[]
                for direction in mixed:
                    x=epsilon*direction[:-1];u=float(np.float32(epsilon*direction[-1]))
                    native=transition(x,u)
                    expected=a@x+b[:,0]*u
                    analytic=analytic_a@x+analytic_b[:,0]*u
                    probe.append(dict(maximum_native_column_superposition_error_over_epsilon=float(np.max(np.abs(native-expected))/epsilon),
                                      maximum_analytic_superposition_error_over_epsilon=float(np.max(np.abs(native-analytic))/epsilon)))
                sample=dict(exponent=exponent,epsilon=epsilon,native_matrix_sha256=signature,
                    a=a.tolist(),b=b.tolist(),native_transition_calls=transition.evaluations-before,
                    maximum_a_difference_from_analytic=float(np.max(np.abs(a-analytic_a))),
                    maximum_b_difference_from_analytic=float(np.max(np.abs(b-analytic_b))),mixed_state_checks=probe)
                record['column_samples'].append(sample)
                if signature not in unique:unique[signature]=(a,b,exponent)
                dump_json(result,out/'result.progress.json')
            record['unique_native_matrix_count']=len(unique)
            # Include a fresh analytic control design with the same directions.
            design_inputs=[('analytic_mp100',a_mp.tolist(),b_mp.tolist(),None)]+[
                ('native_dyadic',a.tolist(),b.tolist(),exponent) for a,b,exponent in unique.values()]
            for method,a,b,exponent in design_inputs:
                item=dict(method=method,representative_exponent=exponent,local_capture={});record['unique_designs'].append(item)
                design_started=time.monotonic()
                try:
                    gain,_,diagnostics=high_precision_discrete_lqr(a,b,absolute_angle_cost(n,WEIGHTS),np.array([[1000.]]),
                        decimal_digits=100,preserve_input_precision=True)
                    item.update(gain=gain.ravel().tolist(),design_diagnostics=diagnostics,
                        design_wall_seconds=time.monotonic()-design_started)
                    for amplitude in (1e-5,1e-9,1e-13):
                        episodes=[exact_capture(cfg,dict(qpos=np.r_[0.,amplitude*d[:n]].tolist(),
                            qvel=np.r_[0.,amplitude*d[n:]].tolist()),gain.ravel(),seconds=30.) for d in directions]
                        item['local_capture'][str(amplitude)]=dict(episodes=episodes,successes=sum(
                            e['success'] and e['termination_reason']=='time_limit' and e['steps']==1500
                            and e['trajectory_clean'] and e['max_hold_seconds']>=5 and e['max_cart_excursion']<=3 for e in episodes))
                        result['actual_local_episode_steps']+=sum(e['steps'] for e in episodes)
                except (ValueError,ZeroDivisionError,np.linalg.LinAlgError) as error:
                    item.update(error=f'{type(error).__name__}: {error}',design_wall_seconds=time.monotonic()-design_started)
                dump_json(result,out/'result.progress.json')
                print(json.dumps(dict(n_links=n,method=method,exponent=exponent,
                    error=item.get('error'),gain_norm=item.get('design_diagnostics',{}).get('gain_norm'),
                    successes={k:v['successes'] for k,v in item['local_capture'].items()})),flush=True)
        finally:
            record['native_design_transition_calls']=transition.evaluations
            result['native_design_transition_calls']+=transition.evaluations;env.close()
        dump_json(result,out/'result.progress.json')
    result['wall_seconds']=time.monotonic()-started;dump_json(result,out/'result.json')


if __name__=='__main__':main()
