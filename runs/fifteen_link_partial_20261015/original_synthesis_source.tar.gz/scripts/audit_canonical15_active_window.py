"""Cold replay of anchored-window sparse proposals and actual controllers."""
import argparse,json
from pathlib import Path
import numpy as np
from scipy import sparse
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.audit_canonical15_whole_route_repair_v2 import maintenance_features,gainraw
from gcartpole.native_minimax import bounded_affine_minimax
from scripts.audit_canonical15_native_minimax import lp_gap
read=lambda p:json.loads(Path(p).read_text())
def same(x,y):assert np.asarray(x).tobytes()==np.asarray(y).tobytes()
def archive(meta):
 assert meta==file_metadata(meta['path'])
 with np.load(meta['path']) as z:return {k:z[k].copy() for k in z.files}
def rank(xs,m):
 if len(xs)!=m['horizon']+1:return [1,1,1e100,1e100,0]
 cap=xs[1+m['capture_offset']:];a=abs(wrap_angle(np.cumsum(cap[:,1:16],axis=1)));safe=(np.max(a,axis=1)<m['angle_limit'])&(abs(cap[:,0])<=m['rail_limit']);bad=np.flatnonzero(~safe);prefix=int(bad[0]) if len(bad) else len(cap);f=np.r_[a.ravel()/m['angle_limit'],abs(xs[1:,0])/m['rail_limit']];e=np.maximum(f-1,0);return [0,0 if np.all(safe) and np.max(abs(xs[:,0]))<=m['rail_limit'] else 1,float(np.max(f)),float(e@e),-prefix]
def protected(xs,m):return len(xs)==m['horizon']+1 and np.max(abs(wrap_angle(np.cumsum(xs[1+m['capture_offset']:1+m['capture_offset']+m['protected_steps'],1:16],axis=1))))<m['angle_limit'] and np.max(abs(xs[:,0]))<=m['rail_limit']
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--directory',required=True);a=p.parse_args();root=Path(a.root);out=Path(a.directory);out.mkdir(exist_ok=False);m=read(root/'manifest_execution.json');r=read(root/'execution/diagnostic/result.json');j=read(root/'execution/execution.json');acc=read(root/'execution/inclusive_accounting.json');assert j['status']=='finished' and j['returncode']==0 and r['status']=='finished';base=read(m['controller_source']['path']);cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);env=NLinkCartPoleEnv(cfg,progress=1.,seed=m['nominal_seed']);env.reset(seed=m['nominal_seed']);native=MujocoTransition(env,np.eye(32),continuous_angles=True);h=m['horizon'];C=np.zeros((15,32));C[:,1:16]=np.tril(np.ones((15,15)));initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);design=archive(m['native_design']);K=design['gains'];parts=[];failed=0
 try:
  for part in r['queries']:
   z=archive(part['tape']);assert part['first']==sum(len(q['actions']) for q in parts) and len(z['actions'])==part['count'];parts.append(z)
   for i,(pair,u,raw) in enumerate(zip(z['states'],z['actions'],z['raw_actions'],strict=True)):
    assert float(np.float32(np.clip(raw,-1,1)))==u;error=''
    try:pred=native(pair[0],float(u))
    except SimulationError as e:error=f'SimulationError: {e}';same(z['failed_post_states'][i],np.r_[native.data.qpos,native.data.qvel]);assert z['failed_times'][i]==native.data.time;failed+=1
    else:same(pred,pair[1])
    assert error==str(z['errors'][i])
   print(dict(query_chunk=len(parts),calls=native.evaluations),flush=True)
  Q={k:np.concatenate([q[k] for q in parts]) for k in parts[0]};total=len(Q['actions']);assert total==native.evaluations;source=design['states'];actions=design['actions'];same(Q['states'][:h,0],source[:-1]);same(Q['states'][:h,1],source[1:]);same(Q['actions'][:h],actions);same(initial,source[0]);used=np.zeros(total,bool);used[:h]=True
  def sliceq(start,end,role):
   assert 0<=start<=end<=total and not np.any(used[start:end]);used[start:end]=True;assert np.all(Q['roles'][start:end]==role);return {k:v[start:end] for k,v in Q.items()}
  forecasts=[]
  for i,row in enumerate(r['forecasts']):
   assert row['index']==i;z=archive(row['tape']);q=sliceq(row['query_start'],row['query_end'],f'forecast_{i}');same(z['states'][0],initial);assert len(q['actions'])==len(z['actions']);same(q['actions'],z['actions']);same(q['raw_actions'],z['actions']);same(q['states'][:,0],z['states'][:len(z['actions'])]);n=len(z['states'])-1;same(q['states'][:n,1],z['states'][1:]);scale=m['feedback_scales'][row['runtime']]
   for t,u in enumerate(z['actions']):
    raw=float(z['feedforward'][t])+float((scale*K[t])@(z['states'][t]-z['reference'][t]));assert raw==z['raw_actions'][t] and float(np.float32(np.clip(raw,-1,1)))==u
   error=None if not np.any(q['errors']!='') else str(q['errors'][-1]);assert error==row['error'];assert row['score']==rank(z['states'],m) and row['native_protected']==bool(protected(z['states'],m));forecasts.append(z)
  gaps=[]
  for i,row in enumerate(r['gap_checks']):
   assert row['index']==i;z=archive(row['tape']);q=sliceq(row['query_start'],row['query_end'],f'gap_{i}');assert len(q['actions'])==h-row['active_start'];same(q['states'][:,0],z['states'][:-1]);same(q['actions'],z['actions']);g=q['states'][:,1]-z['states'][1:];same(z['defects'],g);errors=[None if not e else str(e) for e in q['errors']];assert errors==row['errors'];assert row['maximum_gap']==(None if any(errors) else float(np.max(abs(g))));gaps.append(z)
  models=[]
  for i,row in enumerate(r['models']):
   assert row['index']==i;z=archive(row['tape']);center=forecasts[row['center_forecast']];same(z['states'],center['states']);same(z['actions'],center['actions']);assert not np.count_nonzero(z['defects']);q=sliceq(row['query_start'],row['query_end'],f'model_{i}')
   if not row['fresh']:assert len(q['actions'])==0;same(z['A'],design['A']);same(z['B'],design['B'])
   else:
    start=row['active_start'];same(z['A'][:start],design['A'][:start]);same(z['B'][:start],design['B'][:start]);same(z['states'][:start+1],design['states'][:start+1]);same(z['actions'][:start],design['actions'][:start]);assert len(q['actions'])==134*(h-start) and np.all(q['errors']=='');eps=m['state_epsilon']
    for t in range(start,h):
     offset=134*(t-start);block=q['states'][offset:offset+134];ua=q['actions'][offset:offset+134];x=z['states'][t];u=z['actions'][t]
     for k in range(32):
      e=np.zeros(32);e[k]=eps
      for l,sgn in enumerate([1.,-1.,2.,-2.]):same(block[4*k+l,0],x+sgn*e);assert ua[4*k+l]==u
      column=(8*(block[4*k,1]-block[4*k+1,1])-(block[4*k+2,1]-block[4*k+3,1]))/(12*eps);same(z['A'][t,:,k],column)
     same(block[128,0],x);assert ua[128]==u
     for l in range(129,134):same(block[l,0],x)
     offsets=(ua[129:134]-u)/m['action_epsilon'];weights=np.linalg.solve(np.vstack([offsets**k for k in range(5)]),np.array([0.,1.,0.,0.,0.]))/m['action_epsilon'];column=weights@(block[129:134,1]-block[128,1]);same(z['B'][t,:,0],column)
   models.append(z)
  proposal_checks=[]
  for i,row in enumerate(r['proposals']):
   assert row['index']==i;center=forecasts[row['center_before']];md=models[row['model_index']];same(md['states'],center['states']);same(md['actions'],center['actions']);start=row['active_start'];nh=h-start;assert r['models'][row['model_index']]['active_start']==start;localcap=max(0,m['capture_offset']-start);localprot=max(0,min(nh,m['capture_offset']+m['protected_steps']-start)-localcap);p=archive(row['model']);eq=sparse.load_npz(row['equality']['path']);ineq=sparse.load_npz(row['inequality']['path']);assert row['equality']==file_metadata(row['equality']['path']) and row['inequality']==file_metadata(row['inequality']['path']);assert p['active_start']==start and p['steps']==nh and p['local_capture_start']==localcap and p['local_protected_steps']==localprot;sol=None if row['solution'] is None else archive(row['solution']);accepted=None
   if sol is not None:
    y=sol['scaled_solution'];dx=sol['state_step'];du=sol['action_step'];R=np.r_[np.full(16,row['pose_radius']),np.full(16,10*row['pose_radius'])];V=10*row['pose_radius'];n=len(p['objective']);same(dx[0],np.zeros(32));same(dx[1:],y[:nh*32].reshape(nh,32)*R);same(du,y[nh*32:-1]*V);same(p['state_radii'],R);same(p['control_radii'],np.full(nh,V));aerr=dx[1:]-np.einsum('ijk,ik->ij',md['A'][start:],dx[:-1])-md['B'][start:,:,0]*du[:,None];res=float(np.max(abs(aerr/R)));assert res<=1e-7;angles=wrap_angle(center['states'][start:]@C.T)+dx@C.T;cap=angles[localcap+1:]/m['angle_limit'];assert np.max(abs(cap))<=y[-1]+1e-7 and (localprot==0 or np.max(abs(cap[:localprot]))<=1+1e-7);assert np.max(abs(dx[1:]/R))<=1+1e-7 and np.max(abs(du/V))<=1+1e-7;assert np.max(abs(center['actions'][start:]+du))<=1+1e-7 and np.max(abs((center['states'][start:]+dx)[1:,0]))<=m['rail_limit']+1e-7
    assert np.max(abs(eq@y-p['b_eq']))<=1e-7 and np.max(ineq@y-p['b_ub'])<=1e-7;assert np.max(p['lower']-y)<=1e-7 and np.max(y-p['upper'])<=1e-7
    if row['selection']=='minimum_change':
     full=sol['secondary_scaled_solution'];same(full[:n],y);z=full[n:];assert len(z)==nh and np.max(abs(y[nh*32:-1])-z)<=1e-7 and np.min(z)>=-1e-7;assert y[-1]<=row['primary_diagnostics']['epigraph']+m['secondary_epigraph_slack']+1e-7;assert row['diagnostics']['sum_absolute_scaled_action_changes']==float(np.sum(abs(y[nh*32:-1])))
    else:assert row['selection']=='minimax' and 'secondary_scaled_solution' not in sol
    if not r['models'][row['model_index']]['fresh']:
     case=next(q for q in read(m['affine_screen']['path'])['cases'] if q['active_start']==start and q['pose_radius']==row['pose_radius']);cached=case['selections'][row['selection']];same(sol['scaled_solution'],archive(cached['solution'])['scaled_solution']);assert row['diagnostics']==cached['diagnostics']
    for power,bt in enumerate(row['backtracks']):
     assert bt['power']==power;candidate=forecasts[bt['forecast']];gap=gaps[bt['gap_check']];ref=center['states'].copy();ref[start:]+=2.**(-power)*dx;ff=center['actions'].copy();ff[start:]=np.asarray(center['actions'][start:]+2.**(-power)*du,np.float32).astype(float);same(candidate['reference'],ref);same(candidate['feedforward'],ff);same(gap['states'],ref[start:]);same(gap['actions'],ff[start:]);same(candidate['states'][:start+1],center['states'][:start+1]);same(candidate['actions'][:start],center['actions'][:start]);assert r['forecasts'][bt['forecast']]['runtime']==row['runtime']
     if rank(candidate['states'],m)<rank(center['states'],m) and protected(candidate['states'],m):assert power==len(row['backtracks'])-1;accepted=bt['forecast']
   else:assert not row['backtracks'] and row['diagnostics']['status']!=0
   assert accepted==row['accepted'] and row['center_after']==(row['center_before'] if accepted is None else accepted);proposal_checks.append(dict(index=i,accepted=accepted,status=row['diagnostics']['status'],backtracks=len(row['backtracks'])))
  usedrebases=[]
  def rebase(parent,runtime,event):
   rb=next(q for q in r['rebases'] if q['parent']==parent and q['runtime']==runtime and q['event']==event);assert rb not in usedrebases;usedrebases.append(rb);src=forecasts[parent];dst=forecasts[rb['forecast']];same(dst['reference'],src['states']);same(dst['feedforward'],src['actions']);same(dst['states'],src['states']);same(dst['actions'],src['actions']);assert np.count_nonzero(gaps[rb['gap_check']]['defects'])==0;return rb['forecast']
  for ar in r['arms']:
   baseline=forecasts[ar['initial']];same(baseline['states'],source);same(baseline['actions'],actions);best=ar['initial'];chosen=None;assert len(ar['calibrations'])==len(m['pose_radii'])
   for radius,pi in zip(m['pose_radii'],ar['calibrations'],strict=True):
    row=r['proposals'][pi];assert row['pose_radius']==radius and row['center_before']==ar['initial'] and row['runtime']==ar['runtime'] and row['active_start']==ar['active_start'] and row['selection']==ar['selection'];ci=row['center_after']
    if rank(forecasts[ci]['states'],m)<rank(forecasts[best]['states'],m):best=ci;chosen=radius
   assert chosen==ar['selected_radius']
   if chosen is None:assert not ar['refinements']
   else:
    best=rebase(best,ar['runtime'],ar['armkey']+'_calibration_selected')
    for iteration,pi in enumerate(ar['refinements']):
     row=r['proposals'][pi];assert row['center_before']==best and row['pose_radius']==chosen and row['runtime']==ar['runtime'] and row['active_start']==ar['active_start'] and row['selection']==ar['selection'];assert rank(forecasts[best]['states'],m)[1]!=0
     if row['accepted'] is None:assert iteration==len(ar['refinements'])-1;break
     best=rebase(row['center_after'],ar['runtime'],ar['armkey']+f'_refine{iteration}')
   assert ar['selected']==best and ar['score']==rank(forecasts[best]['states'],m);assert len(ar['refinements'])<=m['refinement_iterations']
  assert usedrebases==r['rebases'];gain=np.asarray(read(m['gain_source']['path'])['gain']);s=read(m['source']['path']);U=np.asarray([q['action'] for q in s['result']['trajectory']],np.float32).astype(float);om=m['maintenance'];maintenance={};scalarchecks=0;maxgap=0.
  for d in r['maintenance_decisions']:
   z=archive(d['tape']);os=z['states'];oa=z['actions'];raws=z['raw_actions'];assert all(e is None for e in d['errors']);mi,pi=d['first_minus_id'],d['first_plus_id'];state=os[mi,0];same(os[pi,0],state);assert oa[mi]==-1 and oa[pi]==1;minus,plus=maintenance_features(os[mi,1],om),maintenance_features(os[pi,1],om);proposal=bounded_affine_minimax(minus,plus);assert proposal==d['proposal'];maxgap=max(maxgap,lp_gap(minus,plus,proposal));scalarchecks+=1;raw=gainraw(gain,state);assert raw==d['gain_raw'];source_u=float(U[d['tick']]) if d['tick']<len(U) else 0.;assert source_u==d['source_action'];vals=[proposal,-1.,1.,0.,source_u,d['last_action']]+[proposal+(np.clip(raw,-1,1)-proposal)/(2**p) for p in range(om['backoff_powers'])];commands=[];prs=[];seen=set()
   for v in vals:
    u=float(np.float32(np.clip(v,-1,1)));key=np.float32(u).tobytes()
    if key not in seen:seen.add(key);commands.append(u);prs.append(float(v))
   same(z['candidate_actions'],commands);same(z['candidate_raw_proposals'],prs);scores=[]
   for i,c in enumerate(d['candidates']):
    fi,sm,sp,si=c['first_id'],c['second_minus_id'],c['second_plus_id'],c['second_id'];assert oa[fi]==commands[i];same(os[fi,0],state);same(os[sm,0],os[fi,1]);same(os[sp,0],os[fi,1]);same(os[si,0],os[fi,1]);assert oa[sm]==-1 and oa[sp]==1;minus,plus=maintenance_features(os[sm,1],om),maintenance_features(os[sp,1],om);raw2=bounded_affine_minimax(minus,plus);assert c['second_raw']==raw2==raws[si];maxgap=max(maxgap,lp_gap(minus,plus,raw2));scalarchecks+=1;sc=[0,float(max(np.max(abs(maintenance_features(os[fi,1],om))),np.max(abs(maintenance_features(os[si,1],om))))),abs(float(commands[i]))];assert sc==c['score'];scores.append(tuple(sc))
   winner=min(range(len(scores)),key=lambda i:scores[i]);assert winner==d['winner_index'];maintenance[(d['label'],d['tick'])]=(commands[winner],os[d['candidates'][winner]['first_id'],1],d['last_action'])
  actualsteps=0;outcomes=[]
  for row in r['actual_records']:
   z=archive(row['tape']);xs=z['states'];us=z['actions'];raws=z['raw_actions'];selected=forecasts[row['selected_forecast']];same(xs[:h+1],selected['states']);same(us[:h],selected['actions']);indices=np.flatnonzero(Q['roles']=='actual_replay_'+row['armkey']);assert len(indices)==len(us) and not np.any(used[indices]);used[indices]=True;same(Q['states'][indices,0],xs[:-1]);same(Q['states'][indices,1],xs[1:]);same(Q['actions'][indices],us);streak=longest=0;safe=np.max(abs(wrap_angle(np.cumsum(xs[1:,1:16],axis=1))),axis=1)<.15
   for tick,u in enumerate(us):
    if tick<h:raw=float(selected['feedforward'][tick])+float((m['feedback_scales'][row['runtime']]*K[tick])@(xs[tick]-selected['reference'][tick]));assert float(np.float32(np.clip(raw,-1,1)))==u
    else:command,pred,last=maintenance[(row['label'],tick)];assert command==u and last==us[tick-1];same(pred,xs[tick+1]);raw=u
    assert raw==raws[tick];streak=streak+1 if safe[tick] else 0;longest=max(longest,streak)
   cart=float(np.max(abs(xs[:,0])));passed=len(us)==1500 and longest>=250 and cart<=3 and row['termination_reason']=='time_limit' and not row['simulation_error'];assert row['hold_seconds']==longest*.02 and row['maximum_cart']==cart and row['full_nominal_gate_passed']==passed
   if row['termination_reason']=='rail_violation':assert abs(xs[-1,0])>3
   else:assert row['termination_reason']=='time_limit' and len(us)==1500 and cart<=3
   actualsteps+=len(us);outcomes.append(row)
  # Remaining queries must be byte-exact copies of maintenance query tapes, in call order.
  for ar in r['arms']:
   armkey=ar['armkey'];ids=np.flatnonzero(Q['roles']=='actual_maintenance_'+armkey);blocks=[archive(d['tape']) for d in r['maintenance_decisions'] if d['label']==armkey+'_h441'];expected=np.concatenate([z['states'] for z in blocks]) if blocks else np.empty((0,2,32));same(Q['states'][ids],expected);assert not np.any(used[ids]);used[ids]=True
   if blocks:same(Q['actions'][ids],np.concatenate([z['actions'] for z in blocks]));same(Q['raw_actions'][ids],np.concatenate([z['actions'] for z in blocks]))
  assert np.all(used) and actualsteps==r['actual_hanging_start_episode_steps'];assert total+actualsteps==r['total_native_transition_calls']==acc['total_native_transition_calls'];assert acc['native_physics_substeps']==4*(total+actualsteps) and acc['partial_transition_substeps']==0
  dump_json(dict(passed=True,status='finished',generated_at=utc_timestamp(),scope=m['scope'],all_native_queries_proved=total,failed_native_queries_proved=failed,forecasts_proved=len(forecasts),gap_tapes_proved=len(gaps),models_proved=len(models),proposals_proved=proposal_checks,rebases_proved=len(usedrebases),maintenance_decisions_proved=len(maintenance),maintenance_affine_checks=scalarchecks,maximum_affine_gap=maxgap,source_actual_ticks_proved=actualsteps,outcomes=outcomes,total_native_transition_calls=total,actual_hanging_start_episode_steps=0,lp_validation_scope='Independent approximate primal residual/epigraph/trust/angle/action/rail/L1 selection checks; high-precision separate model recurrence audit reports amplified state inconsistencies. Native actual controls are authoritative, no independent LPoptimality or robustness certificate.'),out/'result.json')
 finally:env.close()
if __name__=='__main__':main()
