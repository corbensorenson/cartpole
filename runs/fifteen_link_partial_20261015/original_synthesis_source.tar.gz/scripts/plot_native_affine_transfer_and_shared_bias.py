"""Native transfer limit and shared-entry equivalence, from audited tapes."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.config import dump_json
from gcartpole.env import wrap_angle

def save(root,fig,name,sources,audit):
 out=root/'figures';out.mkdir(exist_ok=True);paths=[]
 for ext in ['png','pdf']:
  p=out/f'{name}.{ext}';fig.savefig(p,dpi=180);paths.append(file_metadata(p))
 plt.close(fig);dump_json(dict(generated_at=utc_timestamp(),script=file_metadata(__file__),audit=file_metadata(audit),sources=sources,figures=paths,native_transition_calls=0),out/'figures.json')
root=Path('runs/native_affine_transfer_20261004');a=json.loads((root/'verified.json').read_text());assert a['passed'];fig,axes=plt.subplots(2,2,figsize=(10.5,7));sources=[]
for row,d in enumerate(a['designs']):
 ar=np.load(d['array']['path']);time=np.arange(700)*.02;cu=ar['controls'];raw=cu+ar['offsets'];ax=axes[row,0];ax.plot(time,cu,color='#586d88',label='Source nominal');ax.plot(time,raw,color='#c16030',label='With full bias, unclipped');ax.plot(time,np.clip(raw,-1,1),color='#167c68',lw=.8,label='With full bias, clipped');ax.set_yscale('symlog',linthresh=1);ax.axhline(1,color='black',ls='--',lw=.7);ax.axhline(-1,color='black',ls='--',lw=.7);ax.set_title(f"Armature factor {d['factor']:g}: offline nominal controls");ax.set_ylabel('Normalized nominal action');ax.set_xlabel('Reference time (s)');sources.append(d['array'])
 for scale,color in [(0,'#586d88'),(1,'#167c68')]:
  q=next(q for q in a['records'] if q['tag']==d['tag'] and q['offset_scale']==scale and q['handoff_seconds']==14);t=np.load(q['tape']['path']);axes[row,1].plot(np.arange(len(t['states']))*.02,t['states'][:,0],color=color,label=f'Actual bias strength {scale}');sources.append(q['tape'])
 axes[row,1].axhline(3,color='black',ls='--',lw=.7);axes[row,1].axhline(-3,color='black',ls='--',lw=.7);axes[row,1].set_title(f"Armature factor {d['factor']:g}: actual early failure");axes[row,1].set_xlabel('Actual episode time (s)');axes[row,1].set_ylabel('Cart position (m)');axes[row,1].set_xlim(0,5);axes[row,1].set_ylim(-3.3,3.3)
 for ax in axes[row]:ax.grid(alpha=.15)
axes[0,0].legend(fontsize=8);axes[0,1].legend(fontsize=8);fig.suptitle('Capture correction does not directly transfer the full swing\nActual 0.95 source, original runtime feedback retained, exact altered fourteen-link plants',fontsize=12);fig.tight_layout(rect=(0,.04,1,.92));fig.text(.5,.01,'Left: offline bias and clipping before feedback; not delivered actual actions. Right: native episodes, neither reaches upright capture.',ha='center',fontsize=8);save(root,fig,'native_affine_transfer',sources,root/'verified.json')
root=Path('runs/shared_native_bias_20261004');a=json.loads((root/'verified.json').read_text());assert a['passed'];fig,axes=plt.subplots(1,2,figsize=(10,4.1));sources=[]
for tag,color in [('baseline','#586d88'),('bias','#167c68')]:
 r=next(q for q in a['studies'] if q['directory'].endswith('baseline_handoffs_corrected' if tag=='baseline' else 'bias_handoffs'));q=next(q for q in r['records'] if q['handoff_seconds']==9);t=np.load(q['tape']['path']);x=t['states'];time=np.arange(len(x))*.02;angle=np.max(abs(wrap_angle(np.cumsum(x[:,1:15],axis=1))),axis=1);axes[0].semilogy(time,np.maximum(angle,1e-5),color=color,label=tag);axes[1].plot(time,x[:,0],color=color,label=tag);sources.append(q['tape'])
axes[0].axhline(.15,color='black',ls='--',lw=.8);axes[0].set_ylim(1e-5,4);axes[0].set_ylabel('Maximum absolute angle (rad)');axes[1].axhline(3,color='black',ls='--',lw=.8);axes[1].axhline(-3,color='black',ls='--',lw=.8);axes[1].set_ylabel('Cart position (m)')
for ax in axes:
 ax.axvspan(0,8,color='#dce2e9',alpha=.5);ax.axvline(9,color='#65707c',ls=':',lw=.8);ax.set_xlabel('Actual episode time (s)');ax.set_xlim(0,30);ax.grid(alpha=.15)
axes[0].legend();fig.suptitle('Shared solver reproduces the fixed-feedback capture correction\nArmature factor 0.95; these tapes match the earlier independent experiment byte-for-byte',fontsize=11);fig.tight_layout(rect=(0,.06,1,.87));fig.text(.5,.01,'Angles below 1e-5 rad shown at plot floor. Exact-start altered fourteen-link controls; deterministic repeats, not noisy robustness.',ha='center',fontsize=8);save(root,fig,'shared_native_bias',sources,root/'verified.json')
