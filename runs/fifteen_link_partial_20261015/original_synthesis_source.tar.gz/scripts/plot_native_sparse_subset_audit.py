#!/usr/bin/env python
"""Plot a native sparse-move subset audit without executing physics."""
import argparse,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from gcartpole.evidence import file_metadata
from gcartpole.config import dump_json,load_config


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True);p.add_argument('--out',required=True)
    p.add_argument('--actual-source',required=True)
    args=p.parse_args();data=json.loads(Path(args.source).read_text());rows=data['records']
    if not data['all_input_states_byte_identical']:raise ValueError('native byte audit required')
    actual=json.loads(Path(args.actual_source).read_text());config=data['physical_inputs']['config']
    if (file_metadata(config['path'])!=config or actual['plan_source']!=data['source']
            or not actual['actual_plan_states_byte_identical_to_forecast']
            or actual['physical_tape_diagnostics']['maximum_dynamics_defect']!=0):
        raise ValueError('aligned independently checked physical evidence required')
    n=load_config(config['path'])['env']['n_links'];arity=len(data['proposal']['indices'])
    labels=['none' if not r['changed_indices'] else '+'.join(map(str,r['changed_indices'])) for r in rows]
    values=np.asarray([r['maximum_angle'] for r in rows]);allowed=[r['declared_bound_feasible'] for r in rows]
    fig,(ax,inset)=plt.subplots(1,2,figsize=(12,5.2),layout='constrained',gridspec_kw={'width_ratios':[4,1.3]})
    colors=['#278060' if a else '#b86148' for a in allowed]
    ax.bar(np.arange(len(rows)),values,color=colors,width=.72)
    ax.axhline(.149,color='#23586a',linewidth=1.5,linestyle='--',label='planner bound 0.149 rad')
    ax.set_xticks(np.arange(len(rows)),labels,rotation=55,ha='right')
    ax.set_ylabel('Maximum cumulative absolute angle (rad)')
    ax.set_xlabel('Changed input indices (zero-based); identical initial state and other inputs')
    fig.suptitle(f'{n} links: a {arity}-input interaction in the {data["horizon_steps"]}-tick native forecast',fontweight='bold')
    ax.set_ylim(0,3.45);ax.spines[['top','right']].set_visible(False)
    ax.legend(loc='upper left',frameon=False)
    inset.bar([0,1],[values[0],values[-1]],color=[colors[0],colors[-1]],width=.6)
    inset.axhline(.149,color='#23586a',linewidth=1,linestyle='--')
    inset.set_xticks([0,1],['unchanged',f'all {arity}']);inset.set_ylim(0,max(values[0],values[-1])*1.15)
    inset.set_title('Boundary detail',fontsize=11)
    inset.spines[['top','right']].set_visible(False)
    for i,v in enumerate([values[0],values[-1]]):inset.text(i,v+.005,f'{v:.5f}',ha='center',fontsize=9)
    hold=actual['result']['max_upright_streak_seconds'];reason=actual['result']['termination_reason']
    subset_claim='All proper subsets fail this bound.' if not any(allowed[:-1]) else 'Some proper subsets also pass.'
    fig.text(.02,-.04,f'Native forecast ablation. {subset_claim} Actual tape hold: {hold:.2f} s; termination: {reason}. Development evidence.',fontsize=9)
    out=Path(args.out);out.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(out,dpi=180,bbox_inches='tight');plt.close(fig)
    dump_json(dict(source=file_metadata(args.source),actual_source=file_metadata(args.actual_source),plot=file_metadata(out),script=file_metadata(__file__),
        native_transition_calls=0,scope='Scientific plot of a completed forecast subset ablation; no new physics or record.'),out.with_suffix('.json'))


if __name__=='__main__':main()
