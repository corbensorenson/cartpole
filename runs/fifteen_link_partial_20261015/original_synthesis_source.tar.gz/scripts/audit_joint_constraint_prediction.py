"""Measure affine/F32/native discrepancies on retained constraint-pilot plans."""
import argparse
import importlib.util
import json
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, utc_timestamp
from gcartpole.ilqr import MujocoTransition
from gcartpole.native_real_minimax import quantized_box_trial
from gcartpole.upright_mechanics import upright_rk4_matrices


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--result',required=True)
    parser.add_argument('--out',required=True)
    args=parser.parse_args()
    source=Path(args.result);directory=source.parents[1]
    data=json.loads(source.read_text());execution=json.loads((directory/'execution.json').read_text())
    frozen=directory/'snapshot/src/gcartpole/joint_projected_control.py'
    assert file_metadata(frozen)['sha256']==data['policy_code']['sha256']
    for path in ('src/gcartpole/angles.py','src/gcartpole/native_real_minimax.py','src/gcartpole/ilqr.py',
                 'src/gcartpole/upright_mechanics.py','src/gcartpole/env.py'):
        ref=next(r for r in execution['frozen_inputs'] if r['path']==path)
        assert file_metadata(path)['sha256']==ref['sha256']
    spec=importlib.util.spec_from_file_location('gcartpole._joint_constraint_frozen',frozen)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    original_step=module.checked_constraint_step
    row=next(r for r in data['records'] if r['label']=='restore_violations' and r['gain_label']=='saved_baseline')
    gain=np.asarray(data['gains']['saved_baseline'])
    cfg=load_config('configs/swingup15_uniform.yaml')
    env=NLinkCartPoleEnv(cfg,progress=1.,seed=0);env.reset(seed=0)
    a,b,_=upright_rk4_matrices(env,decimal_digits=100)
    native=MujocoTransition(env,np.eye(32),continuous_angles=True)
    records=[];began=native.evaluations
    try:
        for step in (3,8,14):
            saved=next(p for p in row['result']['plans'] if p['start_step']==step)
            start=np.asarray(row['result']['states'][step]);calls=[];captured=[]
            def predict(x,u):
                y=native(x,u);calls.append((np.asarray(x).copy(),u,y.copy()));return y
            policy=module.JointProjectedController(predict,a,b,gain,n_links=15,horizon=4,
                projection_delays=row['projection_delays'],**row['controller_options'])
            ctx=policy.ctx
            def bounds(states):
                states=np.asarray(states);angles=wrap_angle(np.cumsum(states[:,1:16],axis=1))
                rates=np.cumsum(states[:,17:],axis=1)
                values=[ctx.mpf(float(v))/.149 for v in angles.ravel()]
                values.extend(ctx.mpf(float(v))/.75 for v in rates.ravel())
                values.extend(ctx.mpf(float(v))/3 for v in states[:,0])
                requests=list(policy.raw_projection*ctx.matrix(policy.physical(states[-1]).tolist()))
                requests.extend((policy.k*ctx.matrix(policy.physical(x).tolist()))[0] for x in states)
                values.extend(v/policy.future_force_limit for v in requests)
                return ctx.matrix(values)
            def previews():
                assert len(calls)%4==0
                outputs=[]
                for index in range(0,len(calls),4):
                    block=calls[index:index+4]
                    assert block[0][0].tobytes()==start.tobytes()
                    assert all(block[i][2].tobytes()==block[i+1][0].tobytes() for i in range(3))
                    outputs.append(dict(actions=tuple(v[1] for v in block),
                                        values=bounds([v[2] for v in block])))
                return outputs
            def observe(ctx,response,values,lower,upper):
                centers=[p for p in previews() if all(x==y for x,y in zip(p['values'],values))]
                assert len(centers)==1
                delta,diag=original_step(ctx,response,values,lower,upper)
                captured.append(dict(center=centers[0]['actions'],response=response.copy(),values=values.copy(),
                    lower=lower.copy(),upper=upper.copy(),delta=delta,diagnostics=diag))
                return delta,diag
            module.checked_constraint_step=observe
            actions,forecast,diag=policy.select(start)
            assert actions.tobytes()==np.asarray(saved['actions']).tobytes()
            assert forecast.tobytes()==np.asarray(saved['forecast']).tobytes()
            assert diag['native_transition_calls']==saved['diagnostics']['native_transition_calls']
            all_previews={p['actions']:p for p in previews()};comparisons=[]
            for subproblem in captured:
                item=dict(status=subproblem['diagnostics']['status'],center=list(subproblem['center']),contractions=[])
                delta=subproblem['delta']
                if delta is not None:
                    center=np.asarray(subproblem['center']);baseline=subproblem['values']
                    for fraction in (1.,.5,.25,.125):
                        delivered=quantized_box_trial(center,delta,subproblem['lower'],subproblem['upper'],fraction)
                        proposal=all_previews[tuple(delivered)]
                        ideal=baseline+subproblem['response']*ctx.matrix((fraction*delta).tolist())
                        rounded=baseline+subproblem['response']*ctx.matrix((delivered-center).tolist())
                        actual=proposal['values']
                        item['contractions'].append(dict(fraction=fraction,
                            original_affine_peak=str(max(abs(v) for v in ideal)),
                            delivered_affine_peak=str(max(abs(v) for v in rounded)),
                            native_peak=str(max(abs(v) for v in actual)),
                            maximum_action_rounding_projection_error=str(max(abs(x-y) for x,y in zip(ideal,rounded))),
                            maximum_native_minus_delivered_affine_error=str(max(abs(x-y) for x,y in zip(actual,rounded)))))
                comparisons.append(item)
            records.append(dict(start_step=step,seconds=step*.02,native_transition_calls=diag['native_transition_calls'],
                reproduced_saved_actions_forecasts_and_call_counts=True,subproblems=comparisons))
        output=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),source=file_metadata(source),
            frozen_policy=file_metadata(frozen),records=records,native_transition_calls=native.evaluations-began,
            actual_episode_steps=0,reserved_seeds_used=False,noisy_development_seeds_used=False,
            scope='Private native replanning of saved local states with frozen policy; no new live episode. '
                  'Separates affine proposal, actual F32 delivered affine prediction and native result on identical '
                  'contractions. Native-minus-affine includes curvature and derivative error, not a pure physical '
                  'nonlinear-remainder attribution. All saved plans must reproduce exactly.')
        assert output['native_transition_calls']<=3*284
        Path(args.out).write_text(json.dumps(output,indent=2,sort_keys=True)+'\n')
        print(json.dumps(dict(path=args.out,native_transition_calls=output['native_transition_calls'],records=len(records))))
    finally:
        env.close()


if __name__=='__main__':main()
