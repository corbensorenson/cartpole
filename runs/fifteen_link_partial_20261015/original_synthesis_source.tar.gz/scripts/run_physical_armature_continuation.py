"""Bounded adaptive physical-swing/capture continuation, exact fourteen only.

Stages have independent frozen journals. Parent accounting sums primitives
once, never parent+children. Physical prefix selection is declared before runs.
"""
import argparse,copy,json,math,subprocess,sys,time
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.physical_prefix import select_physical_prefix


def read(p):return json.loads(Path(p).read_text())
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--config',required=True);p.add_argument('--initializer',required=True);p.add_argument('--memo',required=True);p.add_argument('--directory',required=True);a=p.parse_args()
    out=Path(a.directory);out.mkdir(parents=True,exist_ok=False);start=time.monotonic()
    d=dict(generated_at=utc_timestamp(),status='running',script=file_metadata(__file__),config=file_metadata(a.config),initializer=file_metadata(a.initializer),memo=file_metadata(a.memo),stages=[],selection_history=[],native_transition_ceiling=3000000,total_native_transition_calls=0,actual_hanging_start_episode_steps=0,not_solution=True,canonical_release_evidence=False,reserved_seeds_used=False,noisy_development_seeds_used=False,component_passed=False,scope='Declared adaptive recipe on target altered14; up to8+8full-route repair,actual6--8sarrival selection,preservedactualprefix,suffixrepair,savedfeedbackhandoffs. Exacthangingseed0only; no15orcountpromotion.')
    def stage(name,script,args,inputs):
        folder=out/name;command=[sys.executable,'scripts/run_frontier_experiment.py','--directory',str(folder),'--input',a.memo,'--input',a.config]
        for value in inputs:command+=['--input',str(value)]
        command+=['--',sys.executable,script,'--directory',str(folder/'diagnostic'),*map(str,args)]
        print(json.dumps(dict(starting_stage=name,command=command)),flush=True)
        result=subprocess.run(command)
        path=folder/'diagnostic/result.json'
        if not path.exists():raise RuntimeError(f'{name}missing result: childexit{result.returncode}')
        r=read(path);row=dict(name=name,directory=str(folder),execution=file_metadata(folder/'execution.json'),result=file_metadata(path),total_native_transition_calls=r['total_native_transition_calls'],actual_hanging_start_episode_steps=r.get('actual_hanging_start_episode_steps',0),status=r['status'])
        d['stages'].append(row);d['total_native_transition_calls']+=row['total_native_transition_calls'];d['actual_hanging_start_episode_steps']+=row['actual_hanging_start_episode_steps']
        assert d['total_native_transition_calls']<=d['native_transition_ceiling'];dump_json(d,out/'result.progress.json')
        if result.returncode or r['status']!='finished':raise RuntimeError(f'{name}failed; primitive counts retained')
        return r,path
    def choices(rows):
        options=[]
        for priority,(method,row,reference,gains) in enumerate(rows):
            tape=np.load(row['tape']['path']);s=select_physical_prefix(tape['states'],14)
            if s:options.append((s['steps'],-priority,method,row,reference,gains,s))
        return max(options,key=lambda v:(v[0],v[1])) if options else None
    try:
        initial=a.initializer;selected=None;gain_path=None
        for iteration in (8,16):
            name=f'full_repair{iteration}';r,path=stage(name,'scripts/run_counted_capture_repair.py',['--config',a.config,'--initializer',initial,'--iterations','8','--native-transition-ceiling','1000000'],[initial])
            c=read(r['candidate']['path']);options=[('saved_solver',r,c,np.array(c['controller']['feedback_gains']))]
            selected=choices(options)
            if not selected:
                f,fp=stage(f'native_feedback{iteration}','scripts/refine_native_route_defect_feedback.py',['--config',a.config,'--source',r['candidate']['path']],[r['candidate']['path']])
                gain_path=fp;ref=np.load(f['reference']['path'])
                options.extend((e['label'],e,c,ref['feedback_gains']) for e in f['records'])
                selected=choices(options)
            d['selection_history'].append(dict(after_cumulative_iterations=iteration,selected=None if selected is None else dict(method=selected[2],tape=selected[3]['tape'],**selected[6])));dump_json(d,out/'result.progress.json')
            if selected:break
            initial=r['candidate']['path']
        if not selected:
            d.update(status='finished',termination='no recorded admissible physical arrival within declared repair budget');return
        _,_,method,row,c,gains,selection=selected;steps=selection['steps'];tape=np.load(row['tape']['path']);cfg_meta=d['config']
        physical=dict(selected_state=copy.deepcopy(c['selected_state']),controller=copy.deepcopy(c['controller']),
            search=dict(nominal_coordinate_states=copy.deepcopy(c['search']['nominal_coordinate_states'])),
            source=r['candidate'],scope='Actual recorded prefix followed by a virtual capture suffix; initialization only, no full-route evidence.')
        states=np.array(c['search']['nominal_coordinate_states']);controls=np.array(c['controller']['controls']);feedback=np.array(c['controller']['feedback_gains'])
        states[:steps+1]=tape['states'][:steps+1];controls[:steps]=tape['actions'][:steps];feedback[:steps]=gains[:steps]
        physical['search']['nominal_coordinate_states']=states.tolist();physical['controller'].update(controls=controls.tolist(),feedback_gains=feedback.tolist());physical.update(initialization_only=True,not_solution=True,physical_prefix_tape=row['tape'],physical_prefix_selection=selection)
        seed=out/'actual_prefix_initializer.json';dump_json(physical,seed);d['physical_prefix_initializer']=file_metadata(seed)
        suffix,sp=stage('capture_suffix8','scripts/run_counted_capture_repair.py',['--config',a.config,'--initializer',str(seed),'--iterations','8','--optimize-suffix-start-seconds',str(selection['seconds']),'--native-transition-ceiling','550000'],[seed])
        if gain_path is None:
            _,gain_path=stage('maintenance_gain','scripts/design_counted_maintenance_gain.py',['--config',a.config,'--source',suffix['candidate']['path']],[suffix['candidate']['path']])
        available=[float(s) for s in range(math.ceil(selection['seconds']),14) if s*50<=suffix['actual_hanging_start_episode_steps']]
        d['available_handoff_seconds']=available
        if not available:
            d.update(status='finished',termination='suffix replay failed before a compatible integer handoff');return
        screen,_=stage('saved_feedback_handoffs','scripts/screen_saved_feedback_handoffs.py',['--source-result',str(sp),'--gain-result',str(gain_path),'--handoff-seconds',*map(str,available)],[sp,gain_path])
        passed=[r for r in screen['records'] if r['full_nominal_component_gate_passed']];d['full_passing_handoffs']=[r['handoff_seconds'] for r in passed]
        d['component_passed']=bool(passed);d['status']='finished';d['termination']='complete nominal component' if passed else 'all declared handoffs failed'
        if passed:
            best=min(passed,key=lambda r:r['handoff_seconds']);xx=np.load(best['tape']['path']);h=round(best['handoff_seconds']/.02);source=read(suffix['candidate']['path']);gain=read(gain_path)['gain'];k=np.vstack([np.array(source['controller']['feedback_gains'])[:h],np.tile(-np.array(gain),(700-h,1))]);final=out/'passing_physical_initializer.json'
            dump_json(dict(selected_state=source['selected_state'],controller=dict(controls=xx['actions'][:700].tolist(),feedback_gains=k.tolist(),coordinate_transform=np.eye(30).tolist(),continuous_angles=True,physical_shooting=True,capture_start_seconds=9.),search=dict(nominal_coordinate_states=xx['states'][:701].tolist()),config=cfg_meta,source=suffix['candidate'],passing_tape=best['tape'],seed=0,initialization_only=True,not_solution=True,selected_handoff_seconds=best['handoff_seconds'],scope='Actual700ticks of full30spassing target-plant altered14episode; physicalinitializeronly,not nextplant feasibility orcanonical15.'),final)
            d['passing_physical_initializer']=file_metadata(final)
    except BaseException as e:d.update(status='failed',error=f'{type(e).__name__}: {e}');raise
    finally:
        d.update(finished_at=utc_timestamp(),wall_seconds=time.monotonic()-start);dump_json(d,out/'result.json');print(json.dumps(dict(status=d['status'],passed=d['component_passed'],nativecalls=d['total_native_transition_calls'],termination=d.get('termination'))),flush=True)

if __name__=='__main__':main()
