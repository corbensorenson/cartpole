#!/usr/bin/env python
"""Compare feedback arithmetic on a saved, independently replayed native prefix.

The saved binary64 plant state, nodes and gains remain unchanged. Higher
precision requests are rounded to binary64 before the canonical float32 action
interface. An identical delivered prefix implies an identical deterministic
physical prefix, not robustness or success beyond the observed prefix.
"""
import argparse
import json
from pathlib import Path

import mpmath
import numpy as np

from gcartpole.config import dump_json, load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, runtime_metadata, utc_timestamp
from scripts.search_capture_sequence import fixed_state_cfg


def delivered(request):
    return float(np.clip(np.float32(request), -1., 1.))


def analyze(record, digits):
    for field in ('source', 'config'):
        if file_metadata(record[field]['path']) != record[field]:
            raise ValueError('saved audit input changed')
    source = json.loads(Path(record['source']['path']).read_text())
    controller = source['controller']
    if (controller['phase_adaptive'] or not controller['continuous_angles']
            or controller['tracking_gain_scale'] != 1.):
        raise ValueError('requires fixed-time, continuous-angle unit-scale feedback')
    nodes = np.asarray(source['search']['nominal_coordinate_states'])
    transform = np.asarray(controller['coordinate_transform'])
    if not np.array_equal(transform, np.eye(nodes.shape[1])):
        raise ValueError('this arithmetic comparison requires physical-coordinate shooting')
    controls = np.asarray(controller['controls'])
    gains = np.asarray(controller['feedback_gains'])
    count = len(record['delivered_actions'])
    ctx = mpmath.mp.clone(); ctx.dps = digits
    cfg = fixed_state_cfg(load_config(record['config']['path']), source['selected_state'], 30.)
    env = NLinkCartPoleEnv(cfg, progress=1., seed=source['seed']); env.reset(seed=source['seed'])
    rows = []
    cases = {mode: dict(delivered_action_differences=0, first_difference_time=None,
                       maximum_request_difference=0., maximum_subtraction_difference=0.)
             for mode in ('dot_high_precision', 'subtraction_and_dot_high_precision')}
    maximum_native_recorded_state_gap = 0.
    for i in range(count):
        physical = np.r_[env.data.qpos.copy(), env.data.qvel.copy()]
        error = physical-nodes[i]
        expected_error = np.asarray(record['actual_nominal_errors'][i])
        if not np.array_equal(error, expected_error):
            raise ValueError('native prefix no longer reproduces the saved tracking error')
        raw = float(controls[i]+gains[i]@error)
        baseline = record['delivered_actions'][i]
        if delivered(raw) != baseline:
            raise ValueError('binary64 request does not reproduce the delivered action')
        gain_mp = [ctx.mpf(float(x)) for x in gains[i]]
        exact_difference = [ctx.mpf(float(x))-ctx.mpf(float(z)) for x,z in zip(physical,nodes[i])]
        row = dict(step=i, pre_step_seconds=i*env.dt, baseline_request=raw,
                   baseline_delivered_action=baseline, variants={})
        for mode, errors in [('dot_high_precision', [ctx.mpf(float(x)) for x in error]),
                             ('subtraction_and_dot_high_precision', exact_difference)]:
            request = float(ctx.mpf(float(controls[i]))+ctx.fsum(k*e for k,e in zip(gain_mp,errors)))
            action = delivered(request)
            difference = abs(request-raw)
            subtraction_difference = float(max(abs(e-ctx.mpf(float(v))) for e,v in zip(errors,error)))
            case = cases[mode]
            case['maximum_request_difference'] = max(case['maximum_request_difference'], difference)
            case['maximum_subtraction_difference'] = max(case['maximum_subtraction_difference'], subtraction_difference)
            if action != baseline:
                case['delivered_action_differences'] += 1
                if case['first_difference_time'] is None:
                    case['first_difference_time'] = i*env.dt
            row['variants'][mode] = dict(request=request, delivered_action=action,
                                         request_difference=difference, subtraction_difference=subtraction_difference)
        rows.append(row)
        _, _, terminated, truncated, _ = env.step(np.array([baseline], dtype=np.float32))
        observed = np.r_[env.data.qpos.copy(), env.data.qvel.copy()]
        expected = np.asarray(source['result']['trajectory'][i]['qpos']+source['result']['trajectory'][i]['qvel'])
        maximum_native_recorded_state_gap = max(maximum_native_recorded_state_gap,
                                               float(np.max(np.abs(observed-expected))))
        if not np.array_equal(observed, expected):
            raise ValueError('independent native prefix state differs')
        if (terminated or truncated) and i+1 != count:
            raise ValueError('native replay stopped before the recorded prefix ended')
    env.close()
    for case in cases.values():
        case['delivered_prefix_identical'] = case['delivered_action_differences'] == 0
        case['physical_prefix_identical_by_determinism'] = case['delivered_prefix_identical']
        case['scope'] = ('Identical delivered controls and verified binary64 replay imply identical prefix under this arithmetic change.'
                         if case['delivered_prefix_identical'] else
                         'Pointwise comparison only; after the first differing action the actual alternative physical trajectory is not established.')
    return dict(n_links=cfg['env']['n_links'], source=record['source'], config=record['config'],
                prefix_steps=count, prefix_seconds=count*cfg['env']['timestep']*cfg['env']['frame_skip'],
                maximum_native_recorded_state_gap=maximum_native_recorded_state_gap,
                physical_initialization_only=True, cases=cases, rows=rows)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--audit', required=True)
    p.add_argument('--decimal-digits', type=int, default=100)
    p.add_argument('--out', required=True)
    args = p.parse_args(); out = Path(args.out)
    if out.exists():
        raise FileExistsError(out)
    if args.decimal_digits < 40:
        raise ValueError('at least forty decimal digits required')
    audit = json.loads(Path(args.audit).read_text())
    records = [analyze(record, args.decimal_digits) for record in audit['records']]
    dump_json(dict(generated_at=utc_timestamp(), not_solution=True, benchmark_evidence=False,
                   audit=file_metadata(args.audit), parameters=vars(args), runtime=runtime_metadata(),
                   records=records,
                   scope='Matched saved binary64 gains/nodes/state operands, canonical float32 delivery and native binary64 RK4. Comparison changes dot/addition arithmetic, or subtraction plus dot/addition. It cannot restore lost model/state/gain input precision, redesign feedback, or certify unobserved states. No state overwrite after native initialization.'), out)
    for record in records:
        print(json.dumps({k:v for k,v in record.items() if k != 'rows'}), flush=True)


if __name__ == '__main__':
    main()
