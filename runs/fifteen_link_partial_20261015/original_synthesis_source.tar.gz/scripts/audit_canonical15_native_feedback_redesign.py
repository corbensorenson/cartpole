"""Independent MP80 feedback recurrence and whole native probe tape proofs."""
import argparse
from pathlib import Path
import mpmath,mujoco,numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import dump_json,load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.ilqr import MujocoTransition
from scripts.audit_armature_route_increment import checked,journal,read
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix
from scripts.search_capture_sequence import fixed_state_cfg

def independent_gains(a,control,regularization):
 ctx=mpmath.mp.clone();ctx.dps=80;mat=lambda x:ctx.matrix(np.asarray(x).tolist())
 tf=mat(a['terminal_factor']);sf=mat(a['stage_factor']);P=tf.T*tf;Q=sf.T*sf;K=np.empty((148,32))
 for i in range(147,-1,-1):
  A,B=mat(a['A'][i]),mat(a['B'][i]);S=B.T*P*A;H=ctx.mpf(control)+ctx.mpf(regularization)+(B.T*P*B)[0]
  K[i]=[float(v) for v in -S/H];P=Q+A.T*P*A-S.T*S/H;P=(P+P.T)/2
 return K

def main():
 p=argparse.ArgumentParser();p.add_argument('--directory',required=True);p.add_argument('--out',required=True);args=p.parse_args()
 root=Path(args.directory);out=Path(args.out);out.mkdir(exist_ok=False)
 m=read(root/'probe_manifest.json');r=read(root/'probes/diagnostic/result.json');d=read(root/'design_corrected/diagnostic/result.json')
 designjournal=journal(root/'design_corrected');probejournal=journal(root/'probes');assert r['status']==d['status']=='finished'
 for k in ('source','controller_source','config','gain_design','oracle_audit'):checked(m[k])
 assert read(m['oracle_audit']['path'])['passed'] and r['manifest']==file_metadata(root/'probe_manifest.json')
 assert d['manifest']==file_metadata(root/'manifest.json') and d['array']==m['gain_design']
 source=read(m['source']['path']);base=read(m['controller_source']['path']);c=base['controller']
 start,end=m['start_step'],m['arrival_step'];basis=interpolation_matrix(m['knots'],end-start)
 initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);U=np.asarray([q['action'] for q in source['result']['trajectory'][:end]],np.float32).astype(float)
 X=np.vstack([initial,[q['qpos']+q['qvel'] for q in source['result']['trajectory'][:end]]]);a=np.load(m['gain_design']['path'])
 assert a['states'].tobytes()==X[start:end+1].tobytes() and a['controls'].tobytes()==U[start:end].tobytes()
 assert np.max(abs(a['states'][:,0]))<=c['rail_soft_limit'] # no omitted active rail curvature
 residuals=[];variants={v['tag']:v for v in m['gain_variants']}
 for v in m['gain_variants']:
  K=independent_gains(a,c['control_cost'],v['regularization']);ref=a['gains'][v['array_index']]
  residual=float(np.max(abs(K-ref)));assert residual<=1e-8+1e-12*np.max(abs(ref))
  residuals.append(dict(tag=v['tag'],maximum_gain_residual=residual,byte_exact=K.tobytes()==ref.tobytes()))
 print(residuals,flush=True)
 cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);original=mujoco.mj_step;count=[0];env=None;ceiling=int(r['total_native_transition_calls'])
 payload=dict(generated_at=utc_timestamp(),status='running',script=file_metadata(__file__),manifest=file_metadata(root/'probe_manifest.json'),
  source_result=file_metadata(root/'probes/diagnostic/result.json'),design_result=file_metadata(root/'design_corrected/diagnostic/result.json'),
  native_transition_ceiling=ceiling,actual_hanging_start_episode_steps=0,not_solution=True,canonical_release_evidence=False)
 def counted(model,data,*args,**kw):
  n=int(kw.get('nstep',args[0] if args else 1))
  if count[0]+n>4*ceiling:raise RuntimeError('native proof ceiling')
  count[0]+=n;return original(model,data,*args,**kw)
 mujoco.mj_step=counted
 try:
  env=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);env.reset(seed=20265100);native=MujocoTransition(env,np.eye(32),continuous_angles=True)
  for i,u in enumerate(U):assert native(X[i],float(u)).tobytes()==X[i+1].tobytes()
  for meta in [r['baseline']]+[q['tape'] for q in r['redesigned_zero_bias_baselines']]:
   checked(meta)
   with np.load(meta['path']) as z:
    assert z['states'].tobytes()==X[start:end+1].tobytes() and z['actions'].tobytes()==U[start:end].tobytes()
    for i,u in enumerate(z['actions']):assert native(z['states'][i],float(u)).tobytes()==z['states'][i+1].tobytes()
  seen=set();nonzero=0
  for q in r['records']:
   tag,amp,column,sign=q['gain_variant'],q['amplitude'],q['column'],q['sign'];key=(tag,amp,column,sign);assert key not in seen;seen.add(key)
   v=variants[tag];K=a['gains'][v['array_index']];bias=sign*amp*basis[:,column]
   shifted=np.clip(U[start:end]+bias,-1,1).astype(np.float32).astype(float);changed=np.flatnonzero(shifted!=U[start:end])
   assert q['changed_input_count']==len(changed) and q['no_op_after_f32']==(not len(changed))
   if not len(changed):assert q['native_transition_calls']==0;continue
   checked(q['tape']);first=int(changed[0]);nonzero+=1;assert not q['simulation_error']
   with np.load(q['tape']['path']) as z:
    x,u=z['states'],z['actions'];assert len(u)==end-start-first==q['native_transition_calls']
    assert x.shape==(len(u)+1,32) and x[0].tobytes()==X[start+first].tobytes()
    commands=np.asarray([np.float32(np.clip(U[start+first+i]+bias[first+i]+K[first+i]@(x[i]-X[start+first+i]),-1,1)) for i in range(len(u))],dtype=float)
    assert commands.tobytes()==u.tobytes()
    for i,value in enumerate(u):assert native(x[i],float(value)).tobytes()==x[i+1].tobytes()
    post=np.vstack([X[start+1:start+first+1],x[1:]]);angle=np.abs(wrap_angle(np.cumsum(post[:,1:16],axis=1)))
    assert bool(np.all(angle<.149) and np.all(abs(post[:,0])<=3))==q['arrival_bounds_passed']
    assert np.max(angle)==q['maximum_arrival_angle'] and np.max(abs(post[:,0]))==q['maximum_arrival_cart']
    assert np.linalg.norm(x[-1]-X[end])==q['endpoint_state_difference_norm']
  assert len(seen)==576 and nonzero==558 and count[0]/4==ceiling==r['setup_native_calls']+sum(q['native_transition_calls'] for q in r['records'])
  assert d['total_native_transition_calls']+2*ceiling<=m['combined_native_transition_ceiling']
  summaries=[]
  for v in m['gain_variants']:
   for amp in m['amplitudes']:
    group=[q for q in r['records'] if q['gain_variant']==v['tag'] and q['amplitude']==amp];local=[q for q in group if q.get('arrival_bounds_passed')]
    summaries.append(dict(tag=v['tag'],regularization=v['regularization'],amplitude=amp,potential_probes=len(group),nonzero=len(group)-sum(q['no_op_after_f32'] for q in group),
     nonzero_local=len(local),earliest_local_changed_step=min((q['first_changed_absolute_step'] for q in local),default=None)))
  payload.update(status='finished',passed=True,summaries=summaries,independent_mp80_gain_checks=residuals,independent_native_private_tapes_byte_exact=558,
   total_combined_native_transition_calls=d['total_native_transition_calls']+2*ceiling,
   scope='Freshactual-reference physical tracking family independently MP80checked and558private native tapes/actions/locality verified. Fullgainreg250M improves earlierlocalprobecoverage in this finite domain. This jointly changes reference/cost/feedback versus inheritedK; withinfreshfamily onlyregularizationvaries. No full30s solve/noisy/reserved or derivative-accuracy certificate.')
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}');raise
 finally:
  if env is not None:env.close()
  mujoco.mj_step=original;payload.update(total_native_transition_calls=count[0]/4,native_physics_substeps=count[0],partial_transition_substeps=count[0]%4,finished_at=utc_timestamp());dump_json(payload,out/'result.json');print(payload,flush=True)

if __name__=='__main__':main()
