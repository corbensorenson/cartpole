"""Traceable scientific figures for native small-step armature comparisons."""
import argparse,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',required=True);args=p.parse_args();root=Path(args.directory)
    read=lambda p:json.loads(Path(p).read_text())
    a=read(root/'verified.json');b=read(root/'verified_step_iterations.json');assert a['passed'] and b['passed']
    out=root/'figures';out.mkdir(exist_ok=True)
    assert not (out/'physical_armature_step_and_repair.png').exists()
    fig,axes=plt.subplots(2,2,figsize=(12,8),layout='constrained')
    colors=['#a84836','#196f91','#668235','#8c5ba5']
    variants=[('unoptimized','armature0.98_unoptimized_native_defect_feedback'),('0.98 / 8','armature0.98_optimized_native_defect_feedback'),('0.98 / 8+8','armature0.98_repair16_native_defect_feedback'),('0.989 / 8','armature0.989_repair8_native_defect_feedback')]
    ax=axes[0,0];baseline=read(root/'source0.99_replay/diagnostic/result.json');x=np.load(baseline['tape']['path'])['states']
    ax.plot(np.arange(len(x))*.02,x[:,0],color='black',ls='--',label='0.99 source: passes')
    for (label,name),color in zip(variants,colors):
        r=next(v for v in read(root/name/'diagnostic/result.json')['records'] if v['affine']);x=np.load(r['tape']['path'])['states']
        ax.plot(np.arange(len(x))*.02,x[:,0],color=color,label=label)
    ax.axhline(3,color='gray',lw=1);ax.axhline(-3,color='gray',lw=1);ax.set(title='Actual affine-corrected cart motion',xlabel='Time from hanging start (s)',ylabel='Cart position (m)',xlim=(0,12));ax.legend(fontsize=8);ax.grid(alpha=.2)
    ax=axes[0,1]
    histories=[]
    for name in ('armature0.98_repair8','armature0.98_repair16'):
        c=read(root/name/'diagnostic/candidate.json');histories.extend([h['maximum_dynamics_defect'] for h in c['search']['optimizer_history']])
    ax.plot(np.arange(1,17),histories,'o-',color=colors[1],label='0.98 / 8+8 restarted repair')
    c=read(root/'armature0.989_repair8/diagnostic/candidate.json');ax.plot(np.arange(1,9),[h['maximum_dynamics_defect'] for h in c['search']['optimizer_history']],'s-',color=colors[3],label='0.989 / 8')
    ax.axvline(8.5,color='gray',lw=1,ls=':');ax.set(title='Smaller model defects do not certify native replay',xlabel='Cumulative accepted repair iteration',ylabel='Maximum raw coordinate defect',yscale='log');ax.legend(fontsize=8);ax.grid(alpha=.2)
    ax=axes[1,0]
    for (label,name),color in zip(variants,colors):
        d=read(root/name/'diagnostic/result.json');ref=np.load(d['reference']['path']);ax.plot(np.arange(700)*.02,ref['feedforward_offsets'],color=color,label=label,lw=.8)
    ax.axhline(1,color='gray',lw=1,ls=':');ax.axhline(-1,color='gray',lw=1,ls=':');ax.set(title='Unconstrained affine correction can exceed the actuator',xlabel='Reference time (s)',ylabel='Feedforward offset (normalized action)');ax.set_yscale('symlog',linthresh=.01);ax.legend(fontsize=8);ax.grid(alpha=.2)
    ax=axes[1,1]
    labels=[];holds=[];carts=[]
    for label,name in variants:
        d=read(root/name/'diagnostic/result.json')
        for r in d['records']:
            labels.append(label+'\n'+('affine' if r['affine'] else 'pure'));holds.append(r['result']['max_upright_streak_seconds']);carts.append(r['actual_hanging_start_episode_steps']*.02)
    bars=ax.bar(np.arange(len(labels)),carts,color=np.repeat(colors,2));ax.set(xticks=np.arange(len(labels)),xticklabels=labels,title='Continuous actual episodes: duration and upright hold',ylabel='Actual episode duration (s)')
    for bar,h in zip(bars,holds):ax.text(bar.get_x()+bar.get_width()/2,bar.get_height()+.1,f'{h:.2f}s hold',ha='center',fontsize=7)
    ax.tick_params(axis='x',labelsize=7);ax.grid(axis='y',alpha=.2)
    fig.suptitle('Physical-route continuation • exact altered-fourteen components • no canonical fifteen claim',fontsize=13)
    refs=[]
    for ext in ('png','pdf'):
        path=out/f'physical_armature_step_and_repair.{ext}';fig.savefig(path,dpi=180);refs.append(file_metadata(path))
    plt.close(fig)
    dump_json(dict(generated_at=utc_timestamp(),script=file_metadata(__file__),sources=[file_metadata(root/'verified.json'),file_metadata(root/'verified_step_iterations.json')],figures=refs,native_transition_calls=0),out/'figures.json')

if __name__=='__main__':main()
