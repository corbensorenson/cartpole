"""Matched zero/full native bias on one repaired reference and fixed runtime K.

Only bias strength and declared maintenance time vary inside a plant. Complete
physical tapes, including early failures, are saved before independent proofs.
This is exact-start altered-fourteen development, never release promotion.
"""
import argparse
import copy
import json
from pathlib import Path

import mujoco
import numpy as np
from gcartpole.config import dump_json, load_config
from gcartpole.evidence import data_sha256, file_metadata, utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from scripts.evaluate_fddp_two_expert import load_controller
from scripts.evaluate_fddp_parked_route import run_episode
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-result', required=True)
    p.add_argument('--gain-result', required=True)
    p.add_argument('--directory', required=True)
    p.add_argument('--native-transition-ceiling', type=int, default=18000)
    args = p.parse_args()
    read = lambda path: json.loads(Path(path).read_text())
    source, gain = read(args.source_result), read(args.gain_result)
    assert source['status'] == gain['status'] == 'finished'
    assert source['config'] == gain['config']
    for meta in (source['config'], source['candidate'], source['tape'], gain['source_audit'], gain['source_design']):
        assert meta == file_metadata(meta['path'])
    prior = read(source['candidate']['path'])
    cfg = load_config(source['config']['path'])
    assert cfg['env']['n_links'] == 14 and cfg['env']['frame_skip'] == 4
    controller = load_controller(Path(source['candidate']['path']), 14,
                                 load_config('benchmarks/p1_capture_envelope.yaml'))
    design = prior['controller']['tracking_feedback_design']
    assert design['runtime_gains_retained'] and design['defect_source'] == 'native'
    assert design['regularization_source'] == 'solver'
    assert design['regularization'] == prior['search']['optimizer_history'][-1]['regularization']
    controls = np.asarray(design['reference_controls'], dtype=float)
    offsets = np.asarray(design['feedforward_control_offsets'], dtype=float)
    assert controls.shape == offsets.shape == (700,)
    assert np.all(np.isfinite(controls)) and np.all(np.isfinite(offsets))
    assert design['reference_controls_sha256'] == data_sha256(controls.tolist())
    assert np.clip(controls + offsets, -1., 1.).tobytes() == controller['controls'].tobytes()
    with np.load(source['tape']['path']) as raw:
        raw_states, raw_actions = raw['states'].copy(), raw['actions'].copy()
    out = Path(args.directory)
    out.mkdir(parents=True, exist_ok=False)
    payload = dict(generated_at=utc_timestamp(), status='running', script=file_metadata(__file__),
        source=file_metadata(args.source_result), gain_source=file_metadata(args.gain_result),
        config=source['config'], records=[], native_transition_ceiling=args.native_transition_ceiling,
        total_native_transition_calls=0, actual_hanging_start_episode_steps=0,
        canonical_release_evidence=False, not_solution=True, reserved_seeds_used=False,
        noisy_development_seeds_used=False,
        reference_controls_sha256=data_sha256(controls.tolist()),
        runtime_feedback_sha256=data_sha256(controller['feedback_gains'].tolist()),
        scope='Same repaired reference, native offsets and retained runtimeK; zero/full bias and9/10/14s maintenance. Cached plant-specific gain, exact hanging30s, F32 actions, all actual native byte proofs. No optimizer/gain redesign or canonical/noisy promotion.')
    original_step = mujoco.mj_step
    original_env_step = NLinkCartPoleEnv.step
    substeps, actual_steps = [0], [0]

    def counted(model, data, *a, **kw):
        n = int(kw.get('nstep', a[0] if a else 1))
        if substeps[0] + n > args.native_transition_ceiling * 4:
            raise RuntimeError('inclusive native transition ceiling reached')
        substeps[0] += n
        return original_step(model, data, *a, **kw)

    def counted_env(env, action):
        actual_steps[0] += 1
        return original_env_step(env, action)

    mujoco.mj_step, NLinkCartPoleEnv.step = counted, counted_env
    try:
        for scale in (0., 1.):
            for seconds in (9., 10., 14.):
                h = round(seconds / .02)
                c = copy.deepcopy(controller)
                c.update(controls=np.clip(controls + scale * offsets, -1., 1.)[:h],
                         feedback_gains=c['feedback_gains'][:h], nominal_states=c['nominal_states'][:h+1])
                ecfg = fixed_state_cfg(cfg, prior['selected_state'], 30.)
                result = run_episode(ecfg, c, np.asarray(gain['gain']), np.zeros(30), seed=0,
                    park_seconds=0., cart_target=0., tracking_gain_scale=1.,
                    phase_adaptive=False, phase_window=12, include_trace=True)
                actions = np.asarray([r['action'] for r in result['trajectory']], np.float32).astype(float)
                states = np.vstack([prior['selected_state']['qpos'] + prior['selected_state']['qvel'],
                                    [r['qpos'] + r['qvel'] for r in result['trajectory']]])
                path = out / f'bias{scale}_handoff{seconds}.npz'
                np.savez_compressed(path, states=states, actions=actions)
                row = dict(offset_scale=scale, handoff_seconds=seconds, tape=file_metadata(path),
                    actual_hanging_start_episode_steps=len(actions),
                    handoff_reached=len(actions) > h,
                    result={k:v for k,v in result.items() if not isinstance(v, (dict,list))})
                payload['records'].append(row)
                dump_json(payload, out/'result.progress.json')
                env = NLinkCartPoleEnv(ecfg, progress=1., seed=0)
                env.reset(seed=0)
                native = MujocoTransition(env, np.eye(30), continuous_angles=True)
                try:
                    for i, u in enumerate(actions):
                        assert native(states[i], float(u)).tobytes() == states[i+1].tobytes()
                    assert native.evaluations == len(actions)
                finally:
                    env.close()
                if scale == 1.:
                    prefix = min(h, len(actions), len(raw_actions))
                    assert states[:prefix+1].tobytes() == raw_states[:prefix+1].tobytes()
                    assert actions[:prefix].tobytes() == raw_actions[:prefix].tobytes()
                    row['matched_actual_prefix_steps'] = prefix
                    if seconds == 14.:
                        assert states.tobytes() == raw_states.tobytes()
                        assert actions.tobytes() == raw_actions.tobytes()
                        row['whole_raw_bias_tape_byte_identical'] = True
                passed = bool(result['success'] and len(actions) == 1500
                    and result['termination_reason'] == 'time_limit'
                    and result['max_upright_streak_seconds'] >= 5.
                    and result['max_cart_excursion'] <= 3.
                    and not result['final_info'].get('simulation_error'))
                row.update(full_nominal_component_gate_passed=passed,
                    independent_whole_actual_tape_bytes_exact=True,
                    independent_tape_replay_transition_calls=len(actions),
                    total_native_transition_calls=2*len(actions))
                print(json.dumps(row), flush=True)
        assert actual_steps[0] == sum(r['actual_hanging_start_episode_steps'] for r in payload['records'])
        assert substeps[0] == 8*actual_steps[0]
        payload['status'] = 'finished'
    except BaseException as error:
        payload.update(status='failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        mujoco.mj_step, NLinkCartPoleEnv.step = original_step, original_env_step
        payload.update(total_native_transition_calls=substeps[0]/4,
            native_physics_substeps=substeps[0], partial_transition_substeps=substeps[0]%4,
            actual_hanging_start_episode_steps=actual_steps[0], finished_at=utc_timestamp())
        dump_json(payload, out/'result.json')


if __name__ == '__main__':
    main()
