#!/usr/bin/env python
"""Native subset ablation of a first accepted sparse horizon-extension move."""
import argparse,json
from itertools import combinations
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.native_action_lattice import affine_action_lattice
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.synthesize_native_coordinate_continuation import score_native_forecast


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    source=json.loads(Path(args.source).read_text());stage=source['stages'][0]
    if not stage['feasible_sequence_found'] or len(stage['rounds'])!=1:
        raise ValueError('first extension with a single accepted sparse round required')
    proposal=stage['rounds'][0]['selected_proposal'];indices=proposal['indices']
    if len(indices)>6 or len(indices)<2:raise ValueError('bounded sparse arity required')
    plan_ref=source['source'];plan=json.loads(Path(plan_ref['path']).read_text())
    if file_metadata(plan_ref['path'])!=plan_ref:raise ValueError('changed source plan')
    cursor=plan;ancestry=[];seen=set()
    while not all(k in cursor for k in ('config','teacher','parameters')):
        ref=cursor['source']
        if ref['path'] in seen or len(ancestry)>=8 or file_metadata(ref['path'])!=ref:raise ValueError('changed or cyclic ancestry')
        seen.add(ref['path']);ancestry.append(ref);cursor=json.loads(Path(ref['path']).read_text())
    for k in ('source','config','teacher'):
        if file_metadata(cursor[k]['path'])!=cursor[k]:raise ValueError('changed physical context')
    base=json.loads(Path(cursor['source']['path']).read_text());teacher=json.loads(Path(cursor['teacher']['path']).read_text())
    cfg=load_config(cursor['config']['path']);n=cfg['env']['n_links'];nx=2*(n+1)
    start=cursor['parameters']['start_step'];rate=cursor['parameters']['rate_residual_weight'];limit=source['parameters']['forecast_angle_limit']
    controls=np.asarray(plan['selected_sequence'],np.float32).astype(float);known=np.asarray(plan['selected_states'])
    h=len(controls)+1
    if h!=stage['horizon_steps']:raise ValueError('first one-tick extension required')
    reference=np.asarray(base['controller']['controls'][start:start+h],np.float32).astype(float)
    delivered=np.asarray([r['action'] for r in teacher['result']['trajectory']],np.float32).astype(float)
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True);untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
    def forecast(state,actions):
        states=[]
        for action in actions:state=native(state,float(action));states.append(state.copy())
        return np.asarray(states)
    def score(states,actions):return score_native_forecast(states,actions,reference,n_links=n,
        rate_weight=rate,angle_limit=limit,rail_limit=env.rail_limit)
    try:
        state=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
        for row in base['result']['trajectory'][:start]:
            state=native(state,float(np.float32(row['action'])))
            if state.tobytes()!=np.asarray(row['qpos']+row['qvel']).tobytes():raise ValueError('cold prefix differs')
        if forecast(state,controls).tobytes()!=known.tobytes():raise ValueError('known plan differs')
        seeds=[]
        for u in dict.fromkeys([float(reference[-1]),0.,float(delivered[start+h-1])]):
            actions=np.r_[controls,np.float32(u)].astype(np.float32).astype(float)
            states=np.vstack([known,native(known[-1],float(actions[-1]))])
            seeds.append((score(states,actions)[0],actions))
        _,center=min(seeds,key=lambda s:s[0]);spacing,_,_=affine_action_lattice(center,4096)
        rows=[];all_changed=None
        for count in range(len(indices)+1):
            for selected in combinations(range(len(indices)),count):
                actions=center.copy()
                for j in selected:actions[indices[j]]+=spacing[indices[j]]*proposal['offsets_ulps'][j]
                if actions.tobytes()!=actions.astype(np.float32).astype(float).tobytes():raise ValueError('non-F32 ablation input')
                states=forecast(state,actions);value,allowed,maximum=score(states,actions)
                rows.append(dict(changed_indices=[indices[j] for j in selected],move_arity=count,
                    maximum_angle=maximum,declared_bound_feasible=allowed,score=list(value),
                    maximum_cart=float(np.max(np.abs(states[:,0])))))
                if count==len(indices):all_changed=states
        if all_changed.tobytes()!=np.asarray(stage['last_finite_forecast_states']).tobytes():
            raise ValueError('all-input intervention does not reproduce accepted stage bytes')
        if untouched.tobytes()!=np.r_[env.data.qpos,env.data.qvel].tobytes():raise ValueError('planner altered live state')
        dump_json(dict(source=file_metadata(args.source),parameters=vars(args),runtime=runtime_metadata(),
            input_ancestry=ancestry,physical_inputs={k:cursor[k] for k in ('source','config','teacher')},
            proposal=proposal,horizon_steps=h,records=rows,native_transition_calls=native.evaluations,
            native_physics_steps=native.evaluations*env.frame_skip,all_input_states_byte_identical=True,
            not_solution=True,canonical_release_evidence=False,actual_episode_steps=0,optimizer_transition_calls=0,
            reserved_seeds_used=False,noisy_development_seeds_used=False,
            scope='Exact subset ablation from identical cold prefix and appended-input center. All-input forecast independently reproduces accepted stage bytes;subset failures concern this fixed move,not all moves with smaller arity. No actual episode or release evidence.'),out/'result.json')
        print(json.dumps(rows),flush=True)
    finally:env.close()


if __name__=='__main__':main()
