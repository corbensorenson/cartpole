"""Independent R39 oracle physics, scalar LP certificate and controller replay."""
import argparse,json
from pathlib import Path
import numpy as np,mujoco
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.native_minimax import bounded_affine_minimax
from scripts.search_capture_sequence import fixed_state_cfg
read=lambda p:json.loads(Path(p).read_text())
def same(a,b):assert np.asarray(a).tobytes()==np.asarray(b).tobytes()
def feat(x,weight,m):
    blocks=[wrap_angle(np.cumsum(x[1:16]))/m['angle_scale']]
    if weight:blocks.append(weight*np.cumsum(x[17:])/m['rate_scale'])
    blocks.append(np.asarray([x[0]/3,.1*x[16]/.5]));return np.concatenate(blocks)
def rawgain(gain,x):
    y=x.copy();y[1:16]=wrap_angle(y[1:16]);return -float(gain@y)
def lp_gap(minus,plus,u):
    # Independent interval feasibility and bisection, rather than enumerating
    # the proposal helper's line intersections. This certifies only its affine LP.
    a=(minus+plus)/2;b=(plus-minus)/2;a=np.r_[a,-a];b=np.r_[b,-b];positive=b>0;negative=b<0;zero=b==0
    left=0.;right=min(float(np.max(a-b)),float(np.max(a)),float(np.max(a+b)))
    for _ in range(80):
        t=(left+right)/2;lo=max(-1.,float(np.max((t-a[negative])/b[negative],initial=-1.)));hi=min(1.,float(np.min((t-a[positive])/b[positive],initial=1.)));ok=lo<=hi and np.all(a[zero]<=t)
        if ok:right=t
        else:left=t
    value=float(np.max(a+b*u));gap=abs(value-right)/max(1.,abs(value),abs(right));assert gap<1e-10;return gap

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(a.root);out=Path(a.out);out.mkdir(exist_ok=False);m=read(root/'manifest.json');r=read(root/'execution/diagnostic/result.json');acc=read(root/'execution/inclusive_accounting.json');source=read(m['source']['path']);base=read(source['source']['path']);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in source['result']['trajectory']]]);U=np.asarray([q['action'] for q in source['result']['trajectory']],np.float32).astype(float);gain=np.asarray(read(m['gain_source']['path'])['gain']);count=[0];old=mujoco.mj_step;env=None;attempts=0;oracle_calls=0;candidate_count=0;lp_checks=0;maxgap=0.;outcomes=[]
 payload=dict(status='running',generated_at=utc_timestamp(),script=file_metadata(__file__),source_result=file_metadata(root/'execution/diagnostic/result.json'),source_accounting=file_metadata(root/'execution/inclusive_accounting.json'),native_transition_ceiling=20000,actual_hanging_start_episode_steps=0,canonical_release_evidence=False,not_solution=True)
 def counted(model,data,*args,**kw):
  n=int(kw.get('nstep',args[0] if args else 1));assert count[0]+n<=80000;count[0]+=n;return old(model,data,*args,**kw)
 mujoco.mj_step=counted
 try:
  cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);env=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);env.reset(seed=20265100);native=MujocoTransition(env,np.eye(32),continuous_angles=True)
  for tick in range(m['start_step']):attempts+=1;same(native(X[tick],float(U[tick])),X[tick+1])
  for row in r['records']:
   assert row['tape']==file_metadata(row['tape']['path'])
   with np.load(row['tape']['path']) as z:xs=z['states'];us=z['actions']
   same(xs[:m['start_step']+1],X[:m['start_step']+1]);decisions=[d for d in r['decisions'] if d['label']==row['label']];assert len(decisions)==row['decisions']==len(us)-m['start_step'];assert [d['tick'] for d in decisions]==list(range(m['start_step'],len(us)))
   for d in decisions:
    tick=d['tick'];weight=row['rate_weight'];state=xs[tick];assert d['rate_weight']==weight and d['tape']==file_metadata(d['tape']['path']);assert all(error is None for error in d['errors'])
    with np.load(d['tape']['path']) as archive:z={key:archive[key] for key in archive.files}
    os=z['states'];oa=z['actions'];raws=z['raw_actions'];assert np.all(z['completed']) and len(os)==len(d['errors']);same(oa,oa.astype(np.float32).astype(float))
    for i,(pair,u,raw) in enumerate(zip(os,oa,raws,strict=True)):assert float(np.float32(np.clip(raw,-1,1)))==u;attempts+=1;oracle_calls+=1;same(native(pair[0],float(u)),pair[1])
    mi,pi=d['first_anchor_minus_id'],d['first_anchor_plus_id'];same(os[mi,0],state);same(os[pi,0],state);assert oa[mi]==-1 and oa[pi]==1;minus,plus=feat(os[mi,1],weight,m),feat(os[pi,1],weight,m);proposal=bounded_affine_minimax(minus,plus);assert proposal==d['first_affine_proposal'];maxgap=max(maxgap,lp_gap(minus,plus,proposal));lp_checks+=1
    raw=rawgain(gain,state);ref=float(U[tick]) if tick<len(U) else 0.;last=float(us[tick-1]);assert d['gain_raw_action']==raw and d['source_proposal']==ref and d['last_action']==last;nominal=float(np.clip(raw,-1,1));values=[proposal,-1.,1.,0.,ref,last]+[proposal+(nominal-proposal)/(2**p) for p in range(m['backoff_powers'])];seen=set();commands=[];proposals=[]
    for v in values:
     u=float(np.float32(np.clip(v,-1,1)));key=np.float32(u).tobytes()
     if key not in seen:seen.add(key);commands.append(u);proposals.append(float(v))
    same(z['candidate_actions'],commands);same(z['candidate_proposal_raws'],proposals);assert len(commands)==len(d['candidates'])
    scores=[]
    for i,c in enumerate(d['candidates']):
     assert c['index']==i and c['first_action']==commands[i];fi,sm,sp,si=c['first_id'],c['second_minus_id'],c['second_plus_id'],c['second_id'];same(os[fi,0],state);assert oa[fi]==commands[i];same(os[sm,0],os[fi,1]);same(os[sp,0],os[fi,1]);same(os[si,0],os[fi,1]);assert oa[sm]==-1 and oa[sp]==1;minus,plus=feat(os[sm,1],weight,m),feat(os[sp,1],weight,m);second=bounded_affine_minimax(minus,plus);assert second==c['second_raw']==raws[si];maxgap=max(maxgap,lp_gap(minus,plus,second));lp_checks+=1;score=[0,float(max(np.max(abs(feat(os[fi,1],weight,m))),np.max(abs(feat(os[si,1],weight,m))))),abs(float(commands[i]))];assert score==c['score'];scores.append(tuple(score));candidate_count+=1
    assert len(os)==2+4*len(commands);assert z['roles'].tolist()==['first_anchor_minus','first_anchor_plus']+[role for i in range(len(commands)) for role in (f'candidate_{i}_first',f'candidate_{i}_second_minus',f'candidate_{i}_second_plus',f'candidate_{i}_second_selected')];winner=min(range(len(scores)),key=lambda i:scores[i]);assert d['winner_index']==winner;selected=d['candidates'][winner];assert us[tick]==selected['first_action'];same(xs[tick+1],os[selected['first_id'],1])
   streak=longest=0
   for tick,u in enumerate(us):
    attempts+=1;same(native(xs[tick],float(u)),xs[tick+1]);angle=float(np.max(abs(wrap_angle(np.cumsum(xs[tick+1,1:16])))));streak=streak+1 if angle<.15 else 0;longest=max(longest,streak)
   assert longest*.02==row['hold_seconds'] and len(us)==row['actual_hanging_start_episode_steps'] and np.max(abs(xs[1:,0]))==row['maximum_cart'];assert row['termination_reason']=='rail_violation' and abs(xs[-1,0])>3 and not row['full_nominal_gate_passed'];outcomes.append({k:row[k] for k in ('label','rate_weight','hold_seconds','maximum_cart','actual_hanging_start_episode_steps','termination_reason','full_nominal_gate_passed')});print(dict(label=row['label'],oracle_calls=oracle_calls,lp_checks=lp_checks,attempts=attempts),flush=True)
  assert attempts+r['actual_hanging_start_episode_steps']==r['total_native_transition_calls'] and count[0]+4*r['actual_hanging_start_episode_steps']==acc['native_physics_substeps'];payload.update(status='finished',passed=True,outcomes=outcomes,independent_decisions=len(r['decisions']),independent_candidate_pairs=candidate_count,independent_oracle_transition_calls=oracle_calls,independent_scalar_lp_interval_checks=lp_checks,maximum_relative_affine_optimality_gap=maxgap,scope='Allnativeoraclecalls/rawF32inputs, candidategeneration/secondminimax/ranks/selectedfirstactions andwholeactual375prefix/tapes/gates byteproved. Helperproposals re-exported withsharedcore, independentlyvalidatedbyboundedaffineLPintervalbisection. Affineoptimalitydoesnotcertifynonlinearresponse orstability. Bothfiniteactualrecipesnegative; zero privateerrors, no newactualepisodes/noisy/reserved.')
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}');raise
 finally:
  if env is not None:env.close()
  mujoco.mj_step=old;payload.update(total_native_transition_calls=count[0]/4,native_physics_substeps=count[0],attempted_transition_calls=attempts,finished_at=utc_timestamp());dump_json(payload,out/'result.json');print({k:v for k,v in payload.items() if k!='outcomes'},flush=True)
if __name__=='__main__':main()
