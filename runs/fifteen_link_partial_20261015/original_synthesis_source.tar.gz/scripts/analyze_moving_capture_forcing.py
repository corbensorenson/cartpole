"""Counted native moving-reference error decomposition; no new control episodes.

The nominal transition already rounds its action to F32. Center the secant at
that delivered nominal action so rounding is not charged a second time.
"""
import argparse,csv,json,time
from pathlib import Path
import mujoco,numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition

def read(p):return json.loads(Path(p).read_text())
def metric():
 T=np.eye(30);T[1:15,1:15]=np.tril(np.ones((14,14)));T[16:,16:]=np.tril(np.ones((14,14)));scales=np.r_[3.,np.full(14,.15),.5,np.full(14,.75)];return T/scales[:,None]
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--manifest',required=True);p.add_argument('--directory',required=True);p.add_argument('--native-transition-ceiling',type=int,default=100000);a=p.parse_args();out=Path(a.directory);out.mkdir(parents=True,exist_ok=False);m=read(a.manifest);original=mujoco.mj_step;counter=[0];start=time.monotonic();T=metric();invT=np.linalg.inv(T)
 def counted(model,data,*args,**kw):
  n=int(kw.get('nstep',args[0] if args else 1));assert counter[0]+n<=a.native_transition_ceiling*4;counter[0]+=n;return original(model,data,*args,**kw)
 mujoco.mj_step=counted;d=dict(generated_at=utc_timestamp(),status='running',script=file_metadata(__file__),manifest=file_metadata(a.manifest),records=[],native_transition_ceiling=a.native_transition_ceiling,total_native_transition_calls=0,actual_hanging_start_episode_steps=0,not_solution=True,canonical_release_evidence=False,reserved_seeds_used=False,noisy_development_seeds_used=False,scope='Storedcapturetapes, nominalnativefourth-ordersecants andsampledhalf-incrementchecks. No newclosedloopepisodes. Nativequantization centeredatF32nominalaction; remainder combinesphysics/arithmetic/derivativeerror. Approximatepoles/products do notcertifynativecapture.')
 try:
  for case in m['cases']:
   before=counter[0];src=read(case['source_result']['path']);c=read(src['candidate']['path']);cfg=load_config(src['config']['path']);old=np.load(src['tape']['path']);ref=np.array(c['search']['nominal_coordinate_states']);u=np.array(c['controller']['controls']);k=np.array(c['controller']['feedback_gains']);first=case['first_step'];N=case['processed_steps'];assert first==c['controller']['frozen_prefix_steps'];assert N==min(100,len(old['actions'])-first,len(u)-first)>0;assert src['status']=='finished' and cfg['env']['n_links']==14 and cfg['env']['frame_skip']==4 and np.array_equal(np.array(c['controller']['coordinate_transform']),np.eye(30))
   env=NLinkCartPoleEnv(cfg,progress=1.,seed=0);env.reset(seed=0);native=FourthOrderMujocoTransition(env,np.eye(30),continuous_angles=True);As=[];Bs=[];pred=[];actual=[];Ahalf=np.zeros((N,30,30));Bhalf=np.zeros((N,30,1));mask=np.array([i in [0,10,25,50,75,99] for i in range(N)]);sensitivity=[];center=np.float32(np.clip(u[first:first+N],-1,1)).astype(float);x=old['states'][first:first+N+1];nom=ref[first:first+N+1];actions=old['actions'][first:first+N];K=k[first:first+N];delta=x-nom;track=np.array([float(K[i]@delta[i]) for i in range(N)]);command=u[first:first+N]+track;clipped=np.clip(command,-1,1);expected=clipped.astype(np.float32).astype(float);assert expected.tobytes()==actions.tobytes()
   try:
    for j in range(N):
     i=first+j;pred.append(native(ref[i],float(center[j])));A,B=native.linearize(ref[i],float(center[j]),state_epsilon=.0002,action_epsilon=.0005);As.append(A);Bs.append(B);z=native(x[j],float(actions[j]));assert z.tobytes()==x[j+1].tobytes();actual.append(z)
     if mask[j]:Ahalf[j],Bhalf[j]=native.linearize(ref[i],float(center[j]),state_epsilon=.0001,action_epsilon=.00025)
   finally:env.close()
   As=np.array(As);Bs=np.array(Bs);pred=np.array(pred);actual=np.array(actual);G=As+Bs*K[:,None,:];defect=pred-nom[1:];delivery=actions-center-track;forcing=Bs[:,:,0]*delivery[:,None];linear=np.einsum('nij,nj->ni',G,delta[:-1]);remainder=actual-pred-np.einsum('nij,nj->ni',As,delta[:-1])-Bs[:,:,0]*(actions-center)[:,None];reconstruction=linear+defect+forcing+remainder;residual=delta[1:]-reconstruction;round_term=Bs[:,:,0]*(actions-clipped)[:,None];clip_term=Bs[:,:,0]*(clipped-command)[:,None];center_term=Bs[:,:,0]*(u[first:first+N]-center)[:,None]
   physG=np.einsum('ij,njk,kl->nil',T,G,invT);eigs=np.linalg.eigvals(G);peigs=np.linalg.eigvals(physG);P=np.eye(30);products=[P.copy()];logs=[0.];log=0.;rhos=[]
   for j,gg in enumerate(physG):
    P=gg@P;s=float(np.linalg.norm(P,2));assert np.isfinite(s) and s>0;P/=s;log+=np.log10(s);logs.append(log);products.append(P.copy());rhos.append(float(np.max(np.abs(eigs[j]))))
    if mask[j]:
     gh=Ahalf[j]+Bhalf[j]*K[j][None,:];den=max(float(np.linalg.norm(gg,2)),np.finfo(float).tiny);err=float(np.linalg.norm(T@(gh-G[j])@invT,2)/den);sensitivity.append(dict(offset=j,step=first+j,relative_physical_closed_loop_matrix_change=err,primary_spectral_radius=rhos[-1],half_increment_spectral_radius=float(np.max(np.abs(np.linalg.eigvals(gh))))))
   summary=dict(tag=case['tag'],first_step=first,first_seconds=first*.02,processed_steps=N,available_end_seconds=(first+N)*.02,requested_steps=100,unavailable_steps=100-N,source_result=case['source_result'],config=src['config'],candidate=src['candidate'],actual_tape=src['tape'],role=case['role'],feedback_design=c['controller']['tracking_feedback_design'],last_optimizer_regularization=c['search']['optimizer_history'][-1]['regularization'],native_reference_prediction_calls=N,native_actual_window_proof_calls=N,native_derivative_calls=126*(N+int(np.sum(mask))),total_native_transition_calls=(counter[0]-before)/4,actual_hanging_start_episode_steps=0,tracking_actions_byte_exact=True,actual_window_native_transitions_byte_exact=True,maximum_reconstruction_residual=float(np.max(np.abs(residual))),maximum_gate_scaled_error_norm=float(np.max(np.linalg.norm(delta@T.T,axis=1))),terminal_gate_scaled_error_norm=float(np.linalg.norm(T@delta[-1])),maximum_reference_defect_norm=float(np.max(np.linalg.norm(defect@T.T,axis=1))),maximum_delivered_action_forcing_norm=float(np.max(np.linalg.norm(forcing@T.T,axis=1))),maximum_native_remainder_norm=float(np.max(np.linalg.norm(remainder@T.T,axis=1))),maximum_log10_induced_product_amplification=float(max(logs)),terminal_log10_induced_product_amplification=float(logs[-1]),maximum_raw_one_step_spectral_radius=float(max(rhos)),minimum_raw_one_step_spectral_radius=float(min(rhos)),maximum_physical_basis_spectral_radius=float(np.max(np.abs(peigs))),maximum_basis_spectral_radius_difference=float(np.max(np.abs(np.max(np.abs(eigs),axis=1)-np.max(np.abs(peigs),axis=1)))),saturated_ticks=int(np.sum(np.abs(command)>1)),maximum_tracking_gain_norm=float(np.max(np.linalg.norm(K,axis=1))),derivative_sensitivity=sensitivity)
   arrays=out/f"{case['tag']}.npz";np.savez_compressed(arrays,step_indices=np.arange(first,first+N),reference_states=nom,actual_states=x,nominal_controls=u[first:first+N],delivered_nominal_controls=center,actual_actions=actions,feedback_gains=K,metric_transform=T,A=As,B=Bs,A_half=Ahalf,B_half=Bhalf,half_increment_mask=mask,closed_loop=G,physical_closed_loop=physG,nominal_native_predictions=pred,actual_native_predictions=actual,delta=delta,tracking_action=track,unclipped_command=command,clipped_command=clipped,delivery_residual=delivery,linear_response=linear,reference_defect=defect,delivered_action_forcing=forcing,rounding_forcing=round_term,clipping_forcing=clip_term,nominal_centering_forcing=center_term,native_remainder=remainder,reconstruction_residual=residual,eigenvalues_raw=eigs,eigenvalues_physical=peigs,normalized_products=np.array(products),product_log10_norm=np.array(logs));summary['arrays']=file_metadata(arrays);d['records'].append(summary);dump_json(d,out/'result.progress.json');print(json.dumps(summary),flush=True)
  assert sum(q['total_native_transition_calls'] for q in d['records'])==counter[0]/4;d['status']='finished'
 except BaseException as e:d.update(status='failed',error=f'{type(e).__name__}: {e}');raise
 finally:
  mujoco.mj_step=original;d.update(total_native_transition_calls=counter[0]/4,native_physics_substeps=counter[0],partial_transition_substeps=counter[0]%4,finished_at=utc_timestamp(),wall_seconds=time.monotonic()-start);dump_json(d,out/'result.json');print(json.dumps(dict(status=d['status'],nativecalls=d['total_native_transition_calls'])),flush=True)
if __name__=='__main__':main()
