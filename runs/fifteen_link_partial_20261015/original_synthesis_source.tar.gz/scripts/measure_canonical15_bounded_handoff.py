"""Finite delivered-action reachability screen at actual fifteen arrivals."""
import argparse,json
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.angles import wrap_angle
from scripts.search_capture_sequence import fixed_state_cfg

def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--out',required=True);a=p.parse_args();m=json.loads(Path(a.manifest).read_text());out=Path(a.out);out.mkdir(exist_ok=False);r=json.loads(Path(m['source']['path']).read_text());base=json.loads(Path(r['source']['path']).read_text());cfg=fixed_state_cfg(load_config(r['config']['path']),base['selected_state'],30.)
 env=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);env.reset(seed=20265100);native=MujocoTransition(env,np.eye(32),continuous_angles=True);rows=[];tapes=[]
 try:
  for case in m['cases']:
   assert case['tape']==file_metadata(case['tape']['path'])
   with np.load(case['tape']['path']) as z:state=z['states'][case['step']].copy()
   nextstates=[];actions=np.linspace(-1,1,m['grid_points']).astype(np.float32).astype(float)
   for u in actions:
    x=native(state,float(u));nextstates.append(x);angles=np.abs(wrap_angle(np.cumsum(x[1:16])));rows.append(dict(label=case['label'],step=case['step'],action=float(u),force_N=80*float(u),maximum_angle=float(max(angles)),upright=bool(max(angles)<.15),maximum_absolute_rate=float(max(abs(np.cumsum(x[17:])))),cart=float(x[0])))
   path=out/(case['label']+'.npz');np.savez_compressed(path,initial_state=state,actions=actions,states=np.asarray(nextstates));tapes.append(file_metadata(path))
  summaries=[]
  for case in m['cases']:
   group=[x for x in rows if x['label']==case['label']];best=min(group,key=lambda x:x['maximum_angle']);summaries.append(dict(label=case['label'],step=case['step'],grid_count=len(group),upright_next_tick_count=sum(x['upright'] for x in group),best_next_tick_maximum_angle=best['maximum_angle'],best_action=best['action'],worst_next_tick_maximum_angle=max(x['maximum_angle'] for x in group),angle_response_span=max(x['maximum_angle'] for x in group)-best['maximum_angle']))
  dump_json(dict(generated_at=utc_timestamp(),status='finished',script=file_metadata(__file__),manifest=file_metadata(a.manifest),records=rows,summaries=summaries,tapes=tapes,total_native_transition_calls=native.evaluations,actual_hanging_start_episode_steps=0,not_solution=True,canonical_release_evidence=False,scope='41point finite F32force grid at five recordedactual states; nativeone-step forecast only, not proof over continuous inputrange or closedloop solution.'),out/'result.json');print(summaries,flush=True)
 finally:env.close()
if __name__=='__main__':main()
