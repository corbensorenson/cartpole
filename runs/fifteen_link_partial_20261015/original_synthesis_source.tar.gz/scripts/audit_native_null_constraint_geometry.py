"""Compare real and rounded minimax proposals under nested response cancellations."""
import argparse,json,time
from collections import Counter
from itertools import islice
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.native_action_lattice import affine_action_lattice
from gcartpole.native_sparse_stream import fixed_span_supports
from gcartpole.native_null_minimax import coupled_null_minimax,rounded_nonzero_offsets
from gcartpole.native_task_derivatives import physical_task_residual,chained_physical_task_jacobian
from gcartpole.native_bound_objective import bound_diagnostics,native_bound_score
from scripts.search_capture_sequence import fixed_state_cfg


def source_support_spans(source):
    """Recover frozen span settings when an older integer export omitted them."""
    spans=source['parameters'].get('support_spans')
    if spans is None:
        ref=source['geometry']
        if file_metadata(ref['path'])!=ref:raise ValueError('bound predecessor geometry changed')
        geometry=json.loads(Path(ref['path']).read_text())
        if geometry['source']!=source['repaired_from']:raise ValueError('geometry and repaired predecessor differ')
        spans=sorted({r['span_ticks'] for r in geometry['records']})
    if (not spans or any(not isinstance(s,int) or s<4 for s in spans)
            or spans!=sorted(set(spans)) or max(spans)>=len(source['last_finite_center'])):
        raise ValueError('ordered unique five-input temporal spans required')
    return spans


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('source','directory'):p.add_argument('--'+key,required=True)
    p.add_argument('--supports-per-span',type=int,default=80)
    p.add_argument('--solver-seconds',type=float,default=.2)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    if args.supports_per_span<1 or not np.isfinite(args.solver_seconds) or args.solver_seconds<=0:raise ValueError('positive finite component budgets required')
    began=time.monotonic();source=json.loads(Path(args.source).read_text());params=source['parameters']
    if source['feasible_sequence_found'] or not source['live_state_unchanged']:raise ValueError('verified failing center required')
    spans=source_support_spans(source)
    original=json.loads(Path(source['source']['path']).read_text());growth=original;ancestry=[];seen=set()
    if file_metadata(source['source']['path'])!=source['source']:raise ValueError('growth source changed')
    while not all(k in original for k in ('config','teacher','parameters')):
        ref=original['source']
        if ref['path'] in seen or len(ancestry)>=8 or file_metadata(ref['path'])!=ref:raise ValueError('changed/cyclic physical ancestry')
        seen.add(ref['path']);ancestry.append(ref);original=json.loads(Path(ref['path']).read_text())
    for key in ('source','config','teacher'):
        if file_metadata(original[key]['path'])!=original[key]:raise ValueError('physical input changed')
    cfg=load_config(original['config']['path']);n=cfg['env']['n_links'];nx=2*(n+1)
    base=json.loads(Path(original['source']['path']).read_text());step=original['parameters']['start_step'];rate=original['parameters']['rate_residual_weight']
    center=np.asarray(source['last_finite_center']);h=len(center);limit=params['forecast_angle_limit']
    ref=np.asarray(base['controller']['controls'][step:step+h],np.float32).astype(float)
    if len(ref)!=h:raise ValueError('unpadded physical reference required')
    spacing,lower,upper=affine_action_lattice(center,4096)
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True);local=FourthOrderMujocoTransition(env,np.eye(nx),continuous_angles=True)
    untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
    try:
        state=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
        for row in base['result']['trajectory'][:step]:
            state=native(state,float(np.float32(row['action'])))
            if state.tobytes()!=np.asarray(row['qpos']+row['qvel']).tobytes():raise ValueError('cold prefix changed')
        def forecast(actions):
            current=state.copy();states=[]
            for u in actions:current=native(current,float(u));states.append(current.copy())
            return np.asarray(states)
        known=forecast(np.asarray(growth['last_valid_plan']))
        if known.tobytes()!=np.asarray(growth['last_valid_forecast_states']).tobytes():raise ValueError('known plan changed')
        states=forecast(center);diagnostics=bound_diagnostics(states,n,limit,env.rail_limit)
        residual=physical_task_residual(states,n,rate,.1);cost=float(residual@residual+1e-4*np.sum((center-ref)**2))
        if (states.tobytes()!=np.asarray(source['last_finite_states']).tobytes()
                or list(native_bound_score(diagnostics,cost,params['bound_objective']))!=source['last_finite_score']):raise ValueError('final native states/score changed')
        jac=chained_physical_task_jacobian(local,state,center,states,n_links=n,rate_weight=rate,
            state_epsilon=base['controller']['state_epsilon'],action_epsilon=base['controller']['action_epsilon'],angle_band=0.)
        scaled=jac*spacing[None,:];_,singular,right=np.linalg.svd(scaled,full_matrices=False)
        if singular[2]<=singular[0]*1e-12:raise ValueError('three resolved global responses required')
        active=np.flatnonzero(np.linalg.norm(scaled,axis=0)>1e-12)
        phi=wrap_angle(np.cumsum(states[:,1:n+1],axis=1))
        values=np.r_[phi.ravel()/limit,states[:,0]/env.rail_limit]
        response=np.vstack([scaled[:n*h]*(.15*np.sqrt(n*h)/limit),
            scaled[2*n*h:2*n*h+h]*(1.5*np.sqrt(h)/.1/env.rail_limit)])
        records=[];nested_violations=0
        for span in spans:
            for support in islice(fixed_span_supports(active,5,span),args.supports_per_span):
                outcomes={}
                for rank in (3,2):
                    rows=right[:rank].copy();rows/=np.max(np.abs(rows),axis=1)[:,None]
                    offsets,d=coupled_null_minimax(rows[:,support],response[:,support],values,
                        lower[list(support)],upper[list(support)],solver_seconds=args.solver_seconds)
                    record=dict(span_ticks=int(span),indices=list(map(int,support)),cancelled_rank=rank,diagnostic=d)
                    if offsets is not None:
                        predictions=values+response[:,support]@offsets
                        record.update(real_offsets=offsets.tolist(),
                            real_predicted_maximum_angle=float(np.max(np.abs(predictions[:n*h]))*limit),
                            real_model_bound_pass=bool(np.max(np.abs(predictions[:n*h]))<1 and np.max(np.abs(predictions[n*h:]))<=1))
                        best=None;count=0
                        for fraction in (1.,.5,.25,.125,.0625):
                            for integer in rounded_nonzero_offsets(offsets*fraction,lower[list(support)],upper[list(support)]):
                                count+=1;prediction=values+response[:,support]@np.asarray(integer)
                                peak=float(np.max(np.abs(prediction)));angle=float(np.max(np.abs(prediction[:n*h]))*limit)
                                key=(peak,angle,integer)
                                if best is None or key<best[0]:best=(key,fraction,integer)
                        if best is not None:
                            record.update(rounded_candidates=count,best_rounded_predicted_normalized_peak=best[0][0],
                                best_rounded_predicted_maximum_angle=best[0][1],
                                best_rounded_offsets=list(best[2]),best_rounded_fraction=best[1])
                        outcomes[rank]=d['predicted_maximum_normalized_bound']
                    records.append(record)
                if len(outcomes)==2 and outcomes[2]>outcomes[3]+1e-7:nested_violations+=1
        summaries=[]
        for rank in (3,2):
            group=[r for r in records if r['cancelled_rank']==rank];solved=[r for r in group if 'real_offsets' in r]
            summaries.append(dict(cancelled_rank=rank,real_null_dimension=5-rank,tested_supports=len(group),
                statuses=dict(Counter(r['diagnostic']['status'] for r in group)),
                real_model_bound_pass_count=sum(r['real_model_bound_pass'] for r in solved),
                minimum_real_predicted_maximum_angle=min((r['real_predicted_maximum_angle'] for r in solved),default=None),
                minimum_rounded_predicted_maximum_angle=min((r['best_rounded_predicted_maximum_angle'] for r in solved if 'best_rounded_offsets' in r),default=None)))
        if forecast(center).tobytes()!=states.tobytes():raise ValueError('independent final tape replay changed')
        if untouched.tobytes()!=np.r_[env.data.qpos,env.data.qvel].tobytes():raise ValueError('audit changed live state')
        bad=np.argwhere(np.abs(phi)>=limit)
        data=dict(parameters=vars(args),support_spans=spans,source=file_metadata(args.source),input_ancestry=ancestry,
            records=records,summaries=summaries,nested_real_model_tolerance_violations=nested_violations,
            violating_angles=[dict(forecast_tick=int(k)+1,link=int(i)+1,angle=float(phi[k,i])) for k,i in bad],
            initial_bound_diagnostics=diagnostics,final_native_states_and_score_exact=True,known_plan_byte_identical=True,live_state_unchanged=True,
            scaled_singular_values=singular.tolist(),native_forecast_transition_calls=native.evaluations,
            native_local_derivative_transition_calls=local.evaluations,total_native_transition_calls=native.evaluations+local.evaluations,
            actual_episode_steps=0,optimizer_transition_calls=0,reserved_seeds_used=False,noisy_development_seeds_used=False,
            not_solution=True,canonical_release_evidence=False,runtime=runtime_metadata(),wall_seconds=time.monotonic()-began,
            scope='Cold-replay completed failing center and known plan;fresh native4/MP100 derivative model compares nested rank3/rank2 real null spaces on identical bounded temporal supports,with nonzero rounded contractions. Real/rounded predicted floors are model-only;no native candidate checks,actual episode,global feasibility or physical limit claim.')
        dump_json(data,out/'result.json');print(json.dumps(dict(summaries=summaries,nested_violations=nested_violations,native_calls=data['total_native_transition_calls'])))
    finally:env.close()


if __name__=='__main__':main()
