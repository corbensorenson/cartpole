"""Repair a failing native forecast using sparse integer worst-bound proposals."""
import argparse,json,time
from collections import Counter
from itertools import islice
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.native_action_lattice import affine_action_lattice
from gcartpole.native_sparse_stream import fixed_span_supports
from gcartpole.native_sparse_integer import sparse_integer_minimax
from gcartpole.simulation import SimulationError
from gcartpole.native_task_derivatives import physical_task_residual,chained_physical_task_jacobian
from gcartpole.native_bound_objective import bound_diagnostics,native_bound_score
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.audit_native_null_constraint_geometry import source_support_spans


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('source','directory'):p.add_argument('--'+key,required=True)
    p.add_argument('--geometry',required=True)
    p.add_argument('--max-supports',type=int,default=80)
    p.add_argument('--planning-transition-budget',type=int,default=65000)
    p.add_argument('--solver-seconds',type=float,default=1.)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    if min(args.max_supports,args.planning_transition_budget)<1 or not np.isfinite(args.solver_seconds) or args.solver_seconds<=0:raise ValueError('positive finite component budgets required')
    began=time.monotonic();source=json.loads(Path(args.source).read_text());params=source['parameters']
    if source['feasible_sequence_found'] or not source['live_state_unchanged']:raise ValueError('verified failing center required')
    spans=source_support_spans(source)
    geometry=json.loads(Path(args.geometry).read_text())
    if geometry['source']!=file_metadata(args.source) or not geometry['final_native_states_and_score_exact']:raise ValueError('source-aligned geometry required')
    if params['bound_objective']!='maximum':raise ValueError('verified maximum-objective source required')
    original=json.loads(Path(source['source']['path']).read_text());growth=original;ancestry=[];seen=set()
    if file_metadata(source['source']['path'])!=source['source']:raise ValueError('growth source changed')
    while not all(k in original for k in ('config','teacher','parameters')):
        ref=original['source']
        if ref['path'] in seen or len(ancestry)>=8 or file_metadata(ref['path'])!=ref:raise ValueError('changed/cyclic physical ancestry')
        seen.add(ref['path']);ancestry.append(ref);original=json.loads(Path(ref['path']).read_text())
    for key in ('source','config','teacher'):
        if file_metadata(original[key]['path'])!=original[key]:raise ValueError('physical input changed')
    cfg=load_config(original['config']['path']);n=cfg['env']['n_links'];nx=2*(n+1)
    base=json.loads(Path(original['source']['path']).read_text());step=original['parameters']['start_step'];rate=original['parameters']['rate_residual_weight']
    center=np.asarray(source['last_finite_center']);h=len(center);limit=params['forecast_angle_limit']
    ref=np.asarray(base['controller']['controls'][step:step+h],np.float32).astype(float)
    if len(ref)!=h:raise ValueError('unpadded physical reference required')
    spacing,lower,upper=affine_action_lattice(center,4096)
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True);local=FourthOrderMujocoTransition(env,np.eye(nx),continuous_angles=True)
    untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
    try:
        state=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
        for row in base['result']['trajectory'][:step]:
            state=native(state,float(np.float32(row['action'])))
            if state.tobytes()!=np.asarray(row['qpos']+row['qvel']).tobytes():raise ValueError('cold prefix changed')
        def forecast(actions):
            current=state.copy();states=[]
            for u in actions:current=native(current,float(u));states.append(current.copy())
            return np.asarray(states)
        known=forecast(np.asarray(growth['last_valid_plan']))
        if known.tobytes()!=np.asarray(growth['last_valid_forecast_states']).tobytes():raise ValueError('known plan changed')
        states=forecast(center);diagnostics=bound_diagnostics(states,n,limit,env.rail_limit)
        residual=physical_task_residual(states,n,rate,.1);cost=float(residual@residual+1e-4*np.sum((center-ref)**2))
        if (states.tobytes()!=np.asarray(source['last_finite_states']).tobytes()
                or list(native_bound_score(diagnostics,cost,params['bound_objective']))!=source['last_finite_score']):raise ValueError('final native states/score changed')
        jac=chained_physical_task_jacobian(local,state,center,states,n_links=n,rate_weight=rate,
            state_epsilon=base['controller']['state_epsilon'],action_epsilon=base['controller']['action_epsilon'],angle_band=0.)
        scaled=jac*spacing[None,:];_,singular,right=np.linalg.svd(scaled,full_matrices=False)
        if singular[2]<=singular[0]*1e-12:raise ValueError('three resolved global responses required')
        active=np.flatnonzero(np.linalg.norm(scaled,axis=0)>1e-12)
        phi=wrap_angle(np.cumsum(states[:,1:n+1],axis=1))
        values=np.r_[phi.ravel()/limit,states[:,0]/env.rail_limit]
        response=np.vstack([scaled[:n*h]*(.15*np.sqrt(n*h)/limit),
            scaled[2*n*h:2*n*h+h]*(1.5*np.sqrt(h)/.1/env.rail_limit)])
        if np.asarray(geometry['scaled_singular_values']).tobytes()!=singular.tobytes():raise ValueError('geometry derivative singular values changed')
        supports=[];seen_supports=set()
        def add(indices):
            indices=tuple(sorted(map(int,indices)))
            if len(indices)!=5 or len(set(indices))!=5 or min(indices)<0 or max(indices)>=h:return
            if indices not in seen_supports:supports.append(indices);seen_supports.add(indices)
        for metric in ('real_predicted_maximum_angle','best_rounded_predicted_maximum_angle'):
            ranked=[]
            for rank in (3,2):
                ranked.append(sorted((r for r in geometry['records'] if r['cancelled_rank']==rank and metric in r),key=lambda r:(r[metric],r['indices']))[:8])
            for index in range(8):
                for group in ranked:
                    if index<len(group):add(group[index]['indices'])
        first_move=growth['stages'][0]['rounds'][0]['selected_proposal']['indices']
        if len(first_move)!=4:raise ValueError('bound four-input predecessor required')
        for extra in (0,1,2,7,10,16,20,31):add([*first_move,extra])
        distributed=[]
        for span in spans:
            starts=np.rint(np.linspace(0,h-span-1,8)).astype(int)
            offsets=np.rint(np.linspace(0,span,5)).astype(int)
            distributed.append([tuple(start+offsets) for start in starts])
        for index in range(8):
            for group in distributed:add(group[index])
        supports=supports[:args.max_supports];records=[];score=tuple(source['last_finite_score'])
        selected=center.copy();selected_states=states.copy();found=False;cache={center.tobytes()};planning_before=native.evaluations
        def measure(candidate,actions):
            d=bound_diagnostics(candidate,n,limit,env.rail_limit);r=physical_task_residual(candidate,n,rate,.1)
            return native_bound_score(d,float(r@r+1e-4*np.sum((actions-ref)**2)),'maximum'),d
        for support in supports:
            started=time.monotonic()
            offsets,diagnostic=sparse_integer_minimax(response[:,support],values,lower[list(support)],upper[list(support)],solver_seconds=args.solver_seconds)
            record=dict(indices=list(support),model=diagnostic,solver_wall_seconds=time.monotonic()-started,native_trials=[])
            records.append(record)
            if offsets is None:continue
            for exponent in range(10):
                integers=np.rint(offsets*2.**(-exponent)).astype(int);actions=center.copy();actions[list(support)]+=spacing[list(support)]*integers
                key=actions.tobytes()
                if key in cache:continue
                if np.any(abs(actions)>1) or key!=actions.astype(np.float32).astype(float).tobytes():raise ValueError('MILP proposal not delivered force-bounded F32')
                if native.evaluations-planning_before+h>args.planning_transition_budget:break
                cache.add(key);trial=dict(fraction=2.**(-exponent),offsets=integers.tolist(),changed_inputs=int(np.count_nonzero(integers)))
                record['native_trials'].append(trial)
                prediction=values+response[:,support]@integers
                trial['predicted_normalized_peak']=float(np.max(np.abs(prediction)))
                try:
                    candidate=forecast(actions);new_score,d=measure(candidate,actions)
                    trial.update(native_score=list(new_score),native_bound_diagnostics=d)
                    if new_score<score:score=new_score;selected=actions.copy();selected_states=candidate.copy()
                    if d['feasible']:found=True;break
                except SimulationError as error:trial['invalid_forecast']=str(error)
            if found or native.evaluations-planning_before+h>args.planning_transition_budget:break
        planning_calls=native.evaluations-planning_before
        checked=forecast(selected)
        if checked.tobytes()!=selected_states.tobytes() or measure(checked,selected)[0]!=score:raise ValueError('independent final finite tape/score changed')
        if untouched.tobytes()!=np.r_[env.data.qpos,env.data.qvel].tobytes():raise ValueError('integer search changed live state')
        data=dict(parameters=dict(**vars(args),forecast_angle_limit=limit,bound_objective='maximum',move_arity=5,support_spans=spans),
            source=source['source'],repaired_from=file_metadata(args.source),geometry=file_metadata(args.geometry),input_ancestry=ancestry,
            records=records,declared_supports=[list(s) for s in supports],horizon_steps=h,
            initial_sequence=center.tolist(),initial_score=source['last_finite_score'],
            last_finite_center=selected.tolist(),last_finite_states=selected_states.tolist(),last_finite_score=list(score),
            feasible_sequence_found=found,selected_sequence=selected.tolist() if found else None,selected_states=selected_states.tolist() if found else None,
            final_bound_diagnostics=measure(checked,selected)[1],source_final_states_and_score_exact=True,
            known_plan_byte_identical=True,live_state_unchanged=True,independent_final_plan_replay_byte_identical=True,
            native_prefix_and_initial_forecast_transition_calls=planning_before,native_planning_transition_calls=planning_calls,
            independent_last_finite_plan_replay_transition_calls=h,native_forecast_transition_calls=native.evaluations,
            native_local_derivative_transition_calls=local.evaluations,total_native_transition_calls=native.evaluations+local.evaluations,
            actual_episode_steps=0,optimizer_transition_calls=0,reserved_seeds_used=False,noisy_development_seeds_used=False,
            not_solution=True,canonical_release_evidence=False,runtime=runtime_metadata(),wall_seconds=time.monotonic()-began,
            scope='Cold-replay failed H63center/known plan;fresh native4/MP100 model proposes at most five nonzero delivered offsets by direct integer all-node angle/rail minimax. Geometry-ranked,predecessor and distributed supports are finite. MILP status/prediction never accepts physical feasibility;native scores and final whole-tape proof do. No actual episode,global infeasibility or record.')
        dump_json(data,out/'result.json');print(json.dumps(dict(found=found,score=list(score),maximum_angle=data['final_bound_diagnostics']['maximum_angle'],native_calls=data['total_native_transition_calls'],tested_supports=len(records))))
    finally:env.close()


if __name__=='__main__':main()
