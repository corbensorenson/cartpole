"""High-precision finite-horizon checks of fixed F64 affine models; no physics."""
import argparse,json,time
from pathlib import Path
import numpy as np,mujoco,mpmath as mp
from gcartpole.angles import wrap_angle
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata
read=lambda p:json.loads(Path(p).read_text())
def propagate(A,B,du,dx,delivered,digits):
 ctx=mp.mp.clone();ctx.dps=digits;nx=A.shape[1];zero=ctx.zeros(nx,1);xi=zero.copy();xr=zero.copy();error=zero.copy();ideal=[xi.copy()];quant=[xr.copy()];residuals=[];error_tape=[error.copy()];closure=ctx.mpf(0)
 for t in range(len(du)):
  aa=ctx.matrix(A[t].tolist());bb=ctx.matrix(B[t,:,0].tolist());before=ctx.matrix(dx[t].tolist());after=ctx.matrix(dx[t+1].tolist());q=ctx.mpf(float(du[t]));d=ctx.mpf(float(delivered[t]));res=after-aa*before-bb*q;xi=aa*xi+bb*q;xr=aa*xr+bb*d;error=aa*error-res
  closure=max(closure,max(abs((xi-after)[j]-error[j]) for j in range(nx)));ideal.append(xi.copy());quant.append(xr.copy());residuals.append(res.copy());error_tape.append(error.copy())
 def strings(rows):return np.asarray([[ctx.nstr(v,digits) for v in row] for row in rows])
 def floating(rows):return np.asarray([[float(v) for v in row] for row in rows])
 return dict(ideal_increment_decimal=strings(ideal),delivered_increment_decimal=strings(quant),exact_row_residual_decimal=strings(residuals),error_from_residual_decimal=strings(error_tape),ideal_increment=floating(ideal),delivered_increment=floating(quant),exact_row_residual=floating(residuals),error_from_residual=floating(error_tape),residual_propagation_closure=str(ctx.nstr(closure,digits)))
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--directory',required=True);a=p.parse_args();root=Path(a.root);out=Path(a.directory);out.mkdir(exist_ok=False);m=read(root/'manifest.json');s=read(root/'core_validation/diagnostic/result.json');assert read(root/'core_validation/execution.json')['returncode']==0 and s['passed'];calls=0
 def forbidden(*args,**kw):
  nonlocal calls;calls+=1;raise AssertionError('Native integration forbidden in precision audit')
 mujoco.mj_step=forbidden;began=time.monotonic()
 with np.load(m['native_design']['path']) as z:X=z['states'];U=z['actions'];A=z['A'];B=z['B']
 C=np.zeros((15,32));C[:,1:16]=np.tril(np.ones((15,15)));rows=[]
 for case in s['cases']:
  start=case['active_start'];h=len(U)-start;R=np.r_[np.full(16,case['pose_radius']),np.full(16,10*case['pose_radius'])]
  for selection,row in case['selections'].items():
   if not row.get('solution'):continue
   assert row['solution']==file_metadata(row['solution']['path'])
   with np.load(row['solution']['path']) as z:du=z['action_step'];dx=z['state_step']
   delivered=np.asarray(U[start:]+du,np.float32).astype(float)-U[start:];precision=[];previous=None
   for digits in (80,100):
    result=propagate(A[start:],B[start:],du,dx,delivered,digits);path=out/f'case{case["index"]:02d}_{selection}_mp{digits}.npz';np.savez_compressed(path,**result);ideal=result['ideal_increment'];actual=result['delivered_increment'];mismatch=float(np.max(abs(ideal-dx)/R));scaledmax=float(np.max(abs(ideal)/R));rowres=float(np.max(abs(result['exact_row_residual'])/R));localcap=max(0,m['capture_offset']-start);angles=wrap_angle(X[start:]@C.T);idealpeak=float(np.max(abs((angles[localcap+1:]+ideal[localcap+1:]@C.T)/m['angle_limit'])));deliveredpeak=float(np.max(abs((angles[localcap+1:]+actual[localcap+1:]@C.T)/m['angle_limit'])));relative=None if previous is None else float(np.max(abs(ideal-previous)/np.maximum(1.,abs(ideal))));closure=float(result['residual_propagation_closure']);relative_closure=closure/max(1.,float(np.max(abs(ideal-dx))));assert relative is None or relative<1e-50;assert relative_closure<1e-60
    precision.append(dict(digits=digits,tape=file_metadata(path),maximum_scaled_exact_row_residual=rowres,maximum_scaled_recurrence_mismatch=mismatch,maximum_scaled_recurrence_increment=scaledmax,unwrapped_affine_capture_peak=idealpeak,delivered_unwrapped_affine_capture_peak=deliveredpeak,relative_ideal_agreement_with_previous_precision=relative,residual_propagation_relative_closure=relative_closure));previous=ideal
   q=dict(case_index=case['index'],active_start=start,selection=selection,pose_radius=case['pose_radius'],solution=row['solution'],reported_epigraph=row['diagnostics'].get('epigraph'),changed_delivered_inputs=int(np.count_nonzero(delivered)),maximum_actual_normalized_action_change=float(np.max(abs(delivered))),maximum_ideal_normalized_action_change=float(np.max(abs(du))),precision=precision);rows.append(q);print(q,flush=True)
 assert calls==0;dump_json(dict(passed=True,native_calls=0,manifest=file_metadata(root/'manifest.json'),affine_screen=file_metadata(root/'core_validation/diagnostic/result.json'),script=file_metadata(__file__),rows=rows,wall_seconds=time.monotonic()-began,scope='Fixed saved F64 A/B coefficients promoted exactly into MP80/100 recurrences. Checked controls/startzero imply a unique affine state trajectory; approximate state-variable LP residuals are propagated separately. Agreement validates arithmetic on these matrices, not derivatives or nonlinear feasibility. Linearized global angles intentionally unwrapped even outside local trust; not interpreted as physical trajectories.'),out/'result.json')
if __name__=='__main__':main()
