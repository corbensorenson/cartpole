#!/usr/bin/env python
"""Compare native secants with independently differentiated MP planar RK4.

Component-only: the independent model is never substituted for the executed
MuJoCo plant, and the derivative of smooth held force does not differentiate
the float32 action quantizer. Parameter promotion and arithmetic differences
remain. Neither comparison is a nonlinear robustness certificate.
"""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.planar_mechanics import PlanarMechanics
from gcartpole.evidence import file_metadata,runtime_metadata,utc_timestamp


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--config',required=True)
    p.add_argument('--steps',type=int,nargs='+',required=True);p.add_argument('--decimal-digits',type=int,default=100);p.add_argument('--out',required=True)
    args=p.parse_args();out=Path(args.out)
    if out.exists():raise FileExistsError(out)
    data=json.loads(Path(args.source).read_text());controller=data['controller'];nx=len(controller['coordinate_transform'])
    if (not controller['continuous_angles'] or controller['phase_adaptive'] or not np.array_equal(controller['coordinate_transform'],np.eye(nx))):raise ValueError('fixed-time physical coordinates required')
    env=NLinkCartPoleEnv(load_config(args.config),progress=1.,seed=data['seed']);env.reset(seed=data['seed']);start=time.monotonic()
    try:
        model=PlanarMechanics(env,decimal_digits=args.decimal_digits);c=model.ctx
        transition=FourthOrderMujocoTransition(env,np.eye(nx),continuous_angles=True)
        x=np.asarray(data['search']['nominal_coordinate_states']);u=np.asarray(controller['controls']);k=np.asarray(controller['feedback_gains']);rows=[]
        for step in args.steps:
            if not 0<=step<min(len(u)-1,len(data['result']['trajectory'])):raise ValueError('interior executed step required')
            before=data['selected_state'] if step==0 else data['result']['trajectory'][step-1]
            actual=np.r_[before['qpos'],before['qvel']];error=actual-x[step]
            action=float(np.float32(u[step]));value,a,b=model.transition(x[step],action,derivatives=True)
            native=transition(x[step],action);fd_a,fd_b=transition.linearize(x[step],action,state_epsilon=controller['state_epsilon'],action_epsilon=controller['action_epsilon'])
            da=c.matrix(fd_a.tolist())-a;db=c.matrix(fd_b.tolist())-b;next_gain=c.matrix(k[step+1].tolist()).T
            discrepancy=c.matrix([c.mpf(float(v)) for v in native])-value
            projected_a=next_gain*da; projected_b=next_gain*db
            finite_error=c.matrix([c.mpf(float(v)) for v in error])
            r=dict(step=step,time_seconds=step*env.dt,maximum_native_minus_independent_next_state=float(max(abs(v) for v in discrepancy)),
                maximum_native_secant_minus_independent_A=float(max(abs(v) for v in da)),maximum_native_secant_minus_independent_B=float(max(abs(v) for v in db)),
                next_gain_projected_transition_discrepancy=float((next_gain*discrepancy)[0]),
                maximum_next_gain_projected_A_discrepancy=float(max(abs(v) for v in projected_a)),
                next_gain_projected_B_discrepancy=float(projected_b[0]),
                next_gain_projected_A_discrepancy_on_recorded_error=float((projected_a*finite_error)[0]),
                recorded_error_maximum=float(np.max(np.abs(error))),
                independent_A=[[str(v) for v in row] for row in a.tolist()],independent_B=[[str(v) for v in row] for row in b.tolist()],
                native_secant_A=fd_a.tolist(),native_secant_B=fd_b.tolist())
            rows.append(r);print(json.dumps({key:value for key,value in r.items() if not isinstance(value,list)}),flush=True)
        dump_json(dict(not_solution=True,benchmark_evidence=False,generated_at=utc_timestamp(),runtime=runtime_metadata(),parameters=vars(args),
            source=file_metadata(args.source),config=file_metadata(args.config),wall_seconds=time.monotonic()-start,rows=rows,
            native_model_unmodified=True,simulation_precision_unchanged=True,reserved_seeds_used=False,
            scope=__doc__),out)
    finally:env.close()

if __name__=='__main__':main()
