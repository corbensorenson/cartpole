#!/usr/bin/env python
"""Compare a successful pair with each input change alone in native physics."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    pair=json.loads(Path(args.source).read_text())
    if not pair['feasible_sequence_found'] or len(pair['rounds'])!=1:raise ValueError('one-round independently verified pair required')
    cursor=pair;ancestry=[]
    while not all(k in cursor for k in ('config','teacher','parameters')):
        metadata=cursor['source']
        if len(ancestry)>=8 or file_metadata(metadata['path'])!=metadata:raise ValueError('ancestry changed')
        ancestry.append(metadata);cursor=json.loads(Path(metadata['path']).read_text())
    for key in ('source','config','teacher'):
        if file_metadata(cursor[key]['path'])!=cursor[key]:raise ValueError('physical source changed')
    base=json.loads(Path(cursor['source']['path']).read_text());cfg=load_config(cursor['config']['path'])
    n=cfg['env']['n_links'];step=cursor['parameters']['start_step'];dt=cfg['env']['timestep']*cfg['env']['frame_skip']
    initial=np.asarray(pair['initial_sequence'],np.float32).astype(float);selected=np.asarray(pair['selected_sequence'],np.float32).astype(float)
    proposal=pair['rounds'][0]['selected_proposal'];model=pair['rounds'][0]['proposal_model'];indices=proposal['indices']
    delta=np.asarray(model['spacing'])[indices]*proposal['offsets_ulps'];both=initial.copy();both[indices]+=delta
    if both.tobytes()!=selected.tobytes():raise ValueError('successful pair does not reconstruct exactly')
    first=initial.copy();first[indices[0]]+=delta[0];second=initial.copy();second[indices[1]]+=delta[1]
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(2*(n+1)),continuous_angles=True);untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()];began=time.monotonic()
    result=dict(not_solution=True,canonical_release_evidence=False,source=file_metadata(args.source),input_ancestry=ancestry,
        parameters=vars(args),runtime=runtime_metadata(),records=[],actual_episode_steps=0,optimizer_transition_calls=0,
        native_local_derivative_transition_calls=0,reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Matched native forecasts at the same actual cold-source state:unchanged failed center,first input change alone,second alone,and both together. Model leading-mode projections are descriptive;each native response is measured. No actual episode,capture basin or accepted record is inferred.')
    try:
        state=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
        for row in base['result']['trajectory'][:step]:
            state=native(state,float(np.float32(row['action'])))
            if state.tobytes()!=np.asarray(row['qpos']+row['qvel']).tobytes():raise ValueError('cold prefix changed')
        for label,actions in [('center',initial),('first_only',first),('second_only',second),('paired',both)]:
            if actions.tobytes()!=actions.astype(np.float32).astype(float).tobytes():raise ValueError('non-delivered variant')
            current=state.copy();states=[]
            for u in actions:current=native(current,float(u));states.append(current.copy())
            states=np.asarray(states);phi=np.abs(wrap_angle(np.cumsum(states[:,1:n+1],axis=1)))
            cart=np.abs(states[:,0]);admissible=bool(np.max(phi)<.14 and np.max(cart)<=env.rail_limit)
            if label=='paired' and (not admissible or states.tobytes()!=np.asarray(pair['selected_states']).tobytes()):raise ValueError('paired forecast no longer verifies every byte')
            result['records'].append(dict(variant=label,actions=actions.tolist(),states=states.tolist(),
                maximum_angle=float(np.max(phi)),terminal_maximum_angle=float(np.max(phi[-1])),
                maximum_cart=float(np.max(cart)),native_forecast_admissible=admissible,
                maximum_angle_series=np.max(phi,axis=1).tolist()))
        if untouched.tobytes()!=np.r_[env.data.qpos,env.data.qvel].tobytes():raise ValueError('diagnostic changed live state')
        coefficients=np.asarray(model['leading_scaled_coefficients'])[indices]*proposal['offsets_ulps']
        result.update(source_prefix_byte_identical=True,paired_forecast_byte_identical=True,live_state_unchanged=True,
            selected_indices=indices,selected_offsets_ulps=proposal['offsets_ulps'],delivered_action_changes=delta.tolist(),
            model_leading_components=coefficients.tolist(),model_leading_component_sum=float(np.sum(coefficients)),
            model_projection_scope='Leading scaled binary64 task singular response;not an actual native mode.',
            nominal_times_seconds=(step*dt+np.arange(1,len(initial)+1)*dt).tolist(),
            native_forecast_transition_calls=native.evaluations,total_native_transition_calls=native.evaluations,wall_seconds=time.monotonic()-began)
        dump_json(result,out/'result.json')
        print(json.dumps(dict(variants=[{k:r[k] for k in ('variant','maximum_angle','maximum_cart','native_forecast_admissible')} for r in result['records']])),flush=True)
    finally:env.close()


if __name__=='__main__':main()
