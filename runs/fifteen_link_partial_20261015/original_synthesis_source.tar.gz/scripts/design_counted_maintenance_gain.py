"""Design the shared maintenance gain with inclusive native accounting."""
import argparse,json
from pathlib import Path
import mujoco
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from scripts.search_swingup_capture import lqr_gain
from scripts.evaluate_fddp_two_expert import load_controller


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--config',required=True);p.add_argument('--source',required=True);p.add_argument('--directory',required=True);a=p.parse_args()
    out=Path(a.directory);out.mkdir(parents=True,exist_ok=False);cfg=load_config(a.config);c=load_controller(Path(a.source),14,load_config('benchmarks/p1_capture_envelope.yaml'));calls=[0];original=mujoco.mj_step
    def count(model,data,*args,**kwargs):
        n=int(kwargs.get('nstep',args[0] if args else 1));calls[0]+=n
        if calls[0]>4000:raise RuntimeError('native design ceiling')
        return original(model,data,*args,**kwargs)
    d=dict(generated_at=utc_timestamp(),status='running',script=file_metadata(__file__),config=file_metadata(a.config),source=file_metadata(a.source),native_transition_ceiling=1000,actual_hanging_start_episode_steps=0,not_solution=True,canonical_release_evidence=False)
    mujoco.mj_step=count
    try:
        gain=lqr_gain(cfg,progress=1.,fd_eps=1e-7,control_cost=c['lqr_control_cost'],q_weights=c['lqr_weights'],decimal_digits=100);d.update(status='finished',gain=gain.tolist())
    except BaseException as e:d.update(status='failed',error=f'{type(e).__name__}: {e}');raise
    finally:
        mujoco.mj_step=original;d.update(total_native_transition_calls=calls[0]/4,native_physics_substeps=calls[0],partial_transition_substeps=calls[0]%4);dump_json(d,out/'result.json')

if __name__=='__main__':main()
