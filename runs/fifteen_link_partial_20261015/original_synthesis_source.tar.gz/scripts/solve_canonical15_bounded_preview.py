"""Bounded native one-step / sampled preview feedback from an actual prefix."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.simulation import SimulationError
from gcartpole.angles import wrap_angle
from gcartpole.native_task_derivatives import physical_task_residual
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix

def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--directory',required=True);a=p.parse_args();m=json.loads(Path(a.manifest).read_text());out=Path(a.directory);out.mkdir(exist_ok=False);(out/'private').mkdir();s=json.loads(Path(m['source']['path']).read_text());base=json.loads(Path(s['source']['path']).read_text());initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in s['result']['trajectory']]]);U=np.asarray([q['action'] for q in s['result']['trajectory']],float);start=m['start_step'];cfg=fixed_state_cfg(load_config(s['config']['path']),base['selected_state'],30.);env=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);env.reset(seed=20265100);native=MujocoTransition(env,np.eye(32),continuous_angles=True);payload=dict(generated_at=utc_timestamp(),status='running',manifest=file_metadata(a.manifest),script=file_metadata(__file__),runtime=runtime_metadata(),records=[],private_batches=[],actual_hanging_start_episode_steps=0,total_native_transition_calls=0,canonical_release_evidence=False,not_solution=True,reserved_seeds_used=False,noisy_development_seeds_used=False);batchnumber=0;allactual=0;began=time.monotonic()
 def rank(states,horizon):
  if not len(states):return (-0,1e100)
  angles=np.abs(wrap_angle(np.cumsum(states[:,1:16],axis=1)));okay=(np.max(angles,axis=1)<.149)&(np.abs(states[:,0])<=3);bad=np.flatnonzero(~okay);prefix=int(bad[0]) if len(bad) else len(states)
  if len(states)<horizon:return (-prefix,1e90)
  residual=physical_task_residual(states,15,m['rate_weight'],.05);excess=np.maximum(angles-.149,0)/.149;rail=np.maximum(np.abs(states[:,0])-2.85,0)/.15
  return (-prefix,float(residual@residual+100*np.sum(excess**2)+100*np.sum(rail**2)))
 def batch(state,commands,label,tick,iteration):
  nonlocal batchnumber
  horizon=commands.shape[1];commands=np.clip(commands,-1,1).astype(np.float32).astype(float);predictions=np.full((len(commands),horizon+1,32),np.nan);lengths=np.zeros(len(commands),int);errors=[];scores=[]
  for index,seq in enumerate(commands):
   current=state.copy();predictions[index,0]=current;error=None
   try:
    for j,u in enumerate(seq):current=native(current,float(u));predictions[index,j+1]=current;lengths[index]+=1
   except SimulationError as e:error=f'SimulationError: {e}'
   errors.append(error);scores.append(rank(predictions[index,1:lengths[index]+1],horizon))
  batchnumber+=1;path=out/'private'/f'batch_{batchnumber:05d}.npz';np.savez_compressed(path,states=predictions,actions=commands,lengths=lengths,scores=np.asarray(scores));payload['private_batches'].append(dict(label=label,tick=tick,iteration=iteration,tape=file_metadata(path),errors=errors,horizon=horizon,candidates=len(commands)));return scores,predictions,lengths,commands
 try:
  for i in range(start):assert native(X[i],float(U[i])).tobytes()==X[i+1].tobytes()
  for arm in m['arms']:
   label,horizon=arm['label'],arm['horizon'];rng=np.random.default_rng(m['search_random_seed']);actual=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);actual.reset(seed=20265100);xs=[initial.copy()];us=[];streak=longest=0;maximumcart=0.;decisions=[];warm=None;before=native.evaluations;reason=None;info=None
   try:
    for tick in range(actual.max_steps):
     state=np.r_[actual.data.qpos,actual.data.qvel]
     if tick<start:action=float(U[tick]);decision=None
     else:
      if horizon==1:
       scores,pred,lengths,commands=batch(state,np.linspace(-1,1,41)[:,None],label,tick,0);best=min(range(len(scores)),key=lambda i:scores[i]);selected=commands[best];selectedstates=pred[best,1:];selectedscore=scores[best]
      else:
       basis=interpolation_matrix(m['knots'],horizon)
       if warm is None:warm=U[tick:tick+horizon].copy() if tick+horizon<=len(U) else np.zeros(horizon)
       knotlocations=np.linspace(0,horizon-1,m['knots']);mean=np.interp(knotlocations,np.arange(horizon),warm);std=np.full(m['knots'],m['initial_std']);bestseq=None;selectedscore=(0,1e100)
       for iteration in range(m['cem_iterations']):
        knots=rng.normal(mean,std,size=(m['candidates'],m['knots']));knots[0]=mean;knots[1]=0;knots[2]=-1;knots[3]=1
        commands=np.clip(knots@basis.T,-1,1);commands[4]=warm
        if tick+horizon<=len(U):commands[5]=U[tick:tick+horizon]
        scores,pred,lengths,commands=batch(state,commands,label,tick,iteration);order=sorted(range(len(scores)),key=lambda i:scores[i]);idx=order[0]
        if bestseq is None or scores[idx]<selectedscore:bestseq=commands[idx].copy();selectedstates=pred[idx,1:].copy();selectedscore=scores[idx]
        elite=np.clip(knots[order[:m['elite_count']]],-1,1);mean=np.mean(elite,axis=0);std=np.maximum(np.std(elite,axis=0),m['minimum_std'])
       selected=bestseq;warm=np.r_[selected[1:],selected[-1]]
      action=float(selected[0]);decision=dict(tick=tick,selected_sequence=selected.tolist(),selected_forecast=selectedstates.tolist(),score=list(selectedscore));decisions.append(decision)
     _,_,terminated,truncated,info=actual.step([action]);allactual+=1;state=np.r_[actual.data.qpos,actual.data.qvel];xs.append(state.copy());us.append(action)
     if tick<start:assert state.tobytes()==X[tick+1].tobytes()
     elif decision is not None:assert state.tobytes()==np.asarray(decision['selected_forecast'][0]).tobytes()
     angle=float(max(abs(wrap_angle(np.cumsum(state[1:16])))));streak=streak+1 if angle<.15 else 0;longest=max(longest,streak);maximumcart=max(maximumcart,abs(float(state[0])))
     if tick%25==0 and tick>=start:print(json.dumps(dict(arm=label,tick=tick,hold=longest*.02,angle=angle,calls=native.evaluations+allactual)),flush=True)
     if terminated or truncated:reason=info['termination_reason'];break
   finally:
    actual.close();tape=out/(label+'.npz');np.savez_compressed(tape,states=np.asarray(xs),actions=np.asarray(us));dump_json(dict(label=label,decisions=decisions,tape=file_metadata(tape)),out/(label+'_decisions.json'))
   for i,u in enumerate(us):assert native(xs[i],float(u)).tobytes()==xs[i+1].tobytes()
   passed=len(us)==1500 and longest*.02>=5 and reason=='time_limit' and maximumcart<=3 and not info['simulation_error']
   row=dict(label=label,horizon=horizon,actual_hanging_start_episode_steps=len(us),hold_seconds=longest*.02,maximum_cart=maximumcart,termination_reason=reason,full_nominal_gate_passed=passed,tape=file_metadata(tape),decisions=file_metadata(out/(label+'_decisions.json')),native_forecast_and_proof_attempts=native.evaluations-before,actual_prefix_byte_exact=True,selected_first_native_prediction_byte_exact=True,independent_whole_tape_byte_exact=True);payload['records'].append(row);payload.update(total_native_transition_calls=native.evaluations+allactual,actual_hanging_start_episode_steps=allactual);dump_json(payload,out/'result.progress.json');print(row,flush=True)
  payload.update(status='finished',wall_seconds=time.monotonic()-began,total_native_transition_calls=native.evaluations+allactual,actual_hanging_start_episode_steps=allactual,scope='Two uninterrupted canonical15 hanging episodes use exactsource420prefix then boundedphysicalnative feedback:41gridone-step versus16step48candidate/3round sixknotCEM. F32actions,allprivateforecastbatches includingfailedpartialcalls saved. Wholeactualtapes nativeproved. Finiteadaptiveexploratorycontroller comparison; no heldoutgeneralization or acceptedrecord untilgates.');dump_json(payload,out/'result.json')
 except BaseException as e:
  payload.update(status='failed',error=f'{type(e).__name__}: {e}',total_native_transition_calls=native.evaluations+allactual,actual_hanging_start_episode_steps=allactual);dump_json(payload,out/'result.failed.json');raise
 finally:env.close()
if __name__=='__main__':main()
