"""Scientific fixed-K native bias comparison from audited actual tapes."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import wrap_angle
from gcartpole.config import dump_json
root=Path('runs/fixed_gain_affine_20261004');a=json.loads((root/'verified.json').read_text());assert a['passed'];out=root/'figures';out.mkdir(exist_ok=True)
fig,axes=plt.subplots(3,2,figsize=(10.2,9.3),sharex=True);colors=['#596a83','#d27b28','#167c68'];records=[]
for row,tag in enumerate(['legacy','rotated0','weighted0.01']):
 for scale,color in zip([0,.25,1],colors):
  rr=next(r for r in a['records'] if r['tag']==tag and r['offset_scale']==scale and r['handoff_seconds']==9);t=np.load(rr['tape']['path']);x=t['states'];ts=np.arange(len(x))*.02;angle=np.max(abs(wrap_angle(np.cumsum(x[:,1:15],axis=1))),axis=1);axes[row,0].semilogy(ts,np.maximum(angle,1e-5),color=color,label=f'Bias strength {scale:g}');axes[row,1].plot(ts,x[:,0],color=color);records.append(rr['tape'])
 axes[row,0].axhline(.15,color='black',ls='--',lw=1);axes[row,0].set_ylim(1e-5,4);axes[row,0].set_ylabel('Maximum absolute angle (rad)');axes[row,1].axhline(3,color='black',ls='--',lw=1);axes[row,1].axhline(-3,color='black',ls='--',lw=1);axes[row,1].set_ylim(-3.2,3.2);axes[row,1].set_ylabel('Cart position (m)')
 name={'legacy':'Legacy metric','rotated0':'Rotation-only metric','weighted0.01':'Directional weight 0.01'}[tag]
 for ax in axes[row]:
  ax.axvspan(0,8,color='#dce2e9',alpha=.6);ax.axvline(9,color='#65707c',ls=':',lw=1);ax.set_title(name);ax.grid(alpha=.16);ax.set_xlim(0,30)
axes[0,0].legend(loc='lower left',fontsize=8)
for ax in axes[-1]:ax.set_xlabel('Actual episode time (s)')
fig.suptitle('Native trajectory bias with original feedback gains held fixed\nAltered fourteen-link plant (armature factor 0.95), nine-second handoff',fontsize=12)
fig.text(.5,.01,'Shading: identical first eight seconds. Dashed lines: angle/rail bounds. Dotted line: maintenance handoff.\nAngles below 1e-5 rad are shown at the plot floor; each line is one exact-start native episode.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.05,1,.94));paths=[]
for ext in ['png','pdf']:
 p=out/f'fixed_gain_native_affine.{ext}';fig.savefig(p,dpi=180);paths.append(file_metadata(p))
plt.close(fig);dump_json(dict(generated_at=utc_timestamp(),script=file_metadata(__file__),audit=file_metadata(root/'verified.json'),sources=records,figures=paths,native_transition_calls=0),out/'figures.json')
