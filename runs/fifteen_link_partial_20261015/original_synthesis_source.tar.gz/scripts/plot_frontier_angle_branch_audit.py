#!/usr/bin/env python
"""Plot a completed native angle-branch comparison with quantized action evidence."""
import argparse,json
from pathlib import Path
import mpmath
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();source=Path(args.source);out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    audit=json.loads(source.read_text())
    if not audit['original_replay_bit_identical']:raise ValueError('Original replay not verified')
    loaded={r['label']:json.loads(Path(r['result']['path']).read_text()) for r in audit['records']}
    if not all(r['declared_reset_branch_verified'] for r in loaded.values()):
        raise ValueError('A declared reset branch was not independently verified')
    a=loaded['original']['result']['trajectory'];b=loaded['positive_winding']['result']['trajectory']
    reflected=loaded['reflected']['result']['trajectory']
    if len(reflected)!=len(a) or not all(
            np.array_equal(np.asarray(x['qpos']+x['qvel']),-np.asarray(y['qpos']+y['qvel']))
            and np.float32(x['action'])==-np.float32(y['action']) for x,y in zip(reflected,a)):
        raise ValueError('Reflected native state/action symmetry not exact')
    ctx=mpmath.mp.clone();ctx.dps=80;shift=ctx.mpf(float(2*np.pi))
    errors=[]
    for x,y in zip(a,b):
        e=[ctx.mpf(float(v))-ctx.mpf(float(u)) for u,v in zip(x['qpos']+x['qvel'],y['qpos']+y['qvel'])]
        e[1]-=shift;errors.append(float(max(abs(v) for v in e)))
    action_differences=[i+1 for i,(x,y) in enumerate(zip(a,b)) if np.float32(x['action'])!=np.float32(y['action'])]
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    fig,axes=plt.subplots(3,1,figsize=(8,7.5),sharex=True,layout='constrained')
    for label,color in [('original','#243a50'),('positive_winding','#bb4053')]:
        rows=loaded[label]['result']['trajectory'];t=np.array([x['time_seconds'] for x in rows])
        axes[0].plot(t,[x['max_abs_angle'] for x in rows],color=color,lw=1.6,
            label='Original −π → 0 (reflection identical)' if label=='original' else 'Shifted +π → 2π')
        axes[1].plot(t,np.asarray([x['action'] for x in rows],dtype=np.float32),color=color,lw=1.,alpha=.85)
    axes[0].axhline(.15,color='#7b838b',ls=':',lw=1.2,label='Upright threshold 0.15 rad')
    axes[0].set(ylabel='Maximum absolute angle (rad)',ylim=(0,3.4))
    axes[0].legend(loc='upper right',fontsize=9)
    axes[1].set(ylabel='Applied normalized force',ylim=(-1.12,1.12))
    axes[2].semilogy([x['time_seconds'] for x in b[:len(errors)]],errors,color='#bb4053',lw=1.6)
    axes[2].set(ylabel='Maximum coordinate discrepancy',xlabel='Native episode time (s)',xlim=(0,10))
    if action_differences:
        for ax in axes:ax.axvline(action_differences[0]*.02,color='#9a8b76',lw=.8,ls='--')
        axes[2].annotate('First different float32 action\n3.46 s',xy=(action_differences[0]*.02,1e-6),
            xytext=(.4,1e-2),arrowprops={'arrowstyle':'-','color':'#9a8b76'},fontsize=9)
    for ax in axes:ax.grid(axis='y',alpha=.16)
    fig.suptitle('15-link native feedback is sensitive to equivalent angle branches',fontsize=13)
    fig.supxlabel('Exact-start auxiliary episodes; every branch fails the full physical gate.',fontsize=9)
    out.mkdir(parents=True,exist_ok=True)
    outputs=[]
    for suffix in ('png','pdf','svg'):
        path=out/('comparison.'+suffix);fig.savefig(path,dpi=180);outputs.append(file_metadata(path))
    plt.close(fig)
    dump_json(dict(not_solution=True,benchmark_evidence=False,source=file_metadata(source),outputs=outputs,
        reflected_states_and_quantized_actions_exactly_negated=True,
        first_different_float32_action_tick=action_differences[0] if action_differences else None,
        first_mp_coordinate_difference_above_1e_4_tick=next((i+1 for i,v in enumerate(errors) if v>1e-4),None),
        discrepancy_arithmetic='80-digit subtraction of represented native state values and declared binary64 2pi reference shift',
        quantized_action_scope='Native float32 clipping/cast of recorded bounded policy actions; action residual disabled.',
        coordinate_norm_scope='Maximum raw qpos/qvel component discrepancy after constant q1 shift; units differ and this is not a Lyapunov contraction norm.',
        native_transition_calls=0,reserved_seeds_used=False),out/'result.json')
    print(json.dumps(dict(outputs=outputs,first_different_float32_action_tick=action_differences[0] if action_differences else None)))
if __name__=='__main__':main()
