"""Compare complete link-mode decay shaping on matched native capture screens.

Model poles and transient metrics are diagnostics. Native local resets remain
separate from hanging-start synthesis and canonical release evaluation.
"""
import argparse
import json
from pathlib import Path
import time

import mpmath
import numpy as np

from gcartpole.config import load_config, dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, runtime_metadata, utc_timestamp
from gcartpole.lqr_design import _precision_eigenvalues
from gcartpole.pole_design import high_precision_siso_pole_gain
from gcartpole.upright_mechanics import upright_rk4_matrices
from scripts.audit_nonlinear_capture_compatibility import screen


FAMILY = [
    ('preserved_stable_control', 1., 1., 0.),
    ('slower_unstable_control', .5, 1., 0.),
    ('stable_slower_half', 1., .5, 0.),
    ('stable_slower_three_quarters', 1., .75, 0.),
    ('stable_faster_three_halves', 1., 1.5, 0.),
    ('stable_faster_double', 1., 2., 0.),
    ('both_slower_half', .5, .5, 0.),
    ('separated_decay', .5, 2., 0.),
    ('moderately_separated_decay', .75, 1.5, 0.),
    ('stable_slower_low_mode_emphasis', 1., .5, -.5),
    ('stable_slower_high_mode_emphasis', 1., .5, .5),
]


def model_transient(a, b, gain, directions, n, *, ticks=100, digits=100):
    """Unbounded exact-model perturbation response; no native predictor calls."""
    ctx = mpmath.mp.clone(); ctx.dps = digits
    am, bm = ctx.matrix(a.tolist()), ctx.matrix(b.tolist())
    k = ctx.matrix([np.asarray(gain).ravel().tolist()])
    closed = am-bm*k
    columns = np.zeros((2*(n+1), len(directions)))
    columns[1:n+1] = directions[:, :n].T
    columns[n+2:] = directions[:, n:].T
    states = ctx.matrix(columns.tolist())
    maximum_angle = maximum_rate = maximum_action = ctx.mpf(0)
    for _ in range(ticks):
        requests = k*states
        maximum_action = max(maximum_action, max(abs(v) for v in requests))
        states = closed*states
        for column in range(states.cols):
            angle = rate = ctx.mpf(0)
            for i in range(n):
                angle += states[1+i, column]
                rate += states[n+2+i, column]
                maximum_angle = max(maximum_angle, abs(angle))
                maximum_rate = max(maximum_rate, abs(rate))
    return dict(arithmetic_digits=digits, ticks=ticks, duration_seconds=ticks*.02,
        maximum_absolute_angle_per_unit_initial_direction=str(maximum_angle),
        maximum_absolute_rate_per_unit_initial_direction=str(maximum_rate),
        maximum_raw_action_per_unit_initial_direction=str(maximum_action),
        predicted_angle_at1em12=float(maximum_angle*ctx.mpf('1e-12')),
        predicted_rate_at1em12=float(maximum_rate*ctx.mpf('1e-12')),
        predicted_action_at1em12=float(maximum_action*ctx.mpf('1e-12')),
        scope='Unbounded linear MP100 model from declared normalized relative angle/rate directions; rounded gain promoted exactly, no nonlinear/F32 disturbance certificate.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', required=True)
    parser.add_argument('--directory', required=True)
    args = parser.parse_args()
    out = Path(args.directory)
    if out.exists():
        raise FileExistsError(out)
    out.mkdir(parents=True)
    baseline = json.loads(Path(args.baseline).read_text())
    assert baseline['not_solution'] and baseline['gain_norms']['n15'] > 1e9
    assert not baseline['reserved_seeds_used'] and not baseline['noisy_development_seeds_used']
    directions = np.asarray(baseline['directions15'])
    assert directions.shape == (4, 30)
    assert np.allclose(np.linalg.norm(directions, axis=1), 1., rtol=0., atol=1e-15)
    cfg = load_config('configs/swingup15_uniform.yaml')
    env = NLinkCartPoleEnv(cfg, progress=1., seed=0)
    env.reset(seed=0)
    a, b, mechanics = upright_rk4_matrices(env, decimal_digits=100)
    dt = env.dt
    env.close()
    assert dt == .02
    ctx = mpmath.mp.clone(); ctx.dps = 100
    roots = _precision_eigenvalues(ctx.matrix(a.tolist()), ctx)
    assert all(abs(ctx.im(z)) < ctx.mpf('1e-80') and ctx.re(z) > 0 for z in roots)
    roots = sorted(ctx.re(z) for z in roots)
    unstable = sorted(z for z in roots if z > 1+ctx.mpf('1e-60'))
    stable_links = [z for z in roots if z < ctx.exp(-ctx.mpf('.5')*ctx.mpf(dt))]
    assert len(unstable) == len(stable_links) == 15
    centers = {k:np.asarray(v) for k,v in baseline['centers15'].items()}
    payload = dict(generated_at=utc_timestamp(), parameters=vars(args),
        config=file_metadata('configs/swingup15_uniform.yaml'), baseline=file_metadata(args.baseline),
        code=[file_metadata(__file__), file_metadata('src/gcartpole/pole_design.py'),
              file_metadata('scripts/audit_nonlinear_capture_compatibility.py')],
        runtime=runtime_metadata(), mechanics=mechanics, open_loop_roots=[str(z) for z in roots],
        family=[dict(label=l, unstable_exponent=u, stable_link_exponent=s, unstable_log_decay_skew=k)
                for l,u,s,k in FAMILY], baseline_native_summaries=baseline['summary'],
        directions=directions.tolist(), centers15={k:v.tolist() for k,v in centers.items()},
        records=[], native_transition_calls=0, optimizer_transition_calls=0,
        actual_hanging_start_episode_steps=0, reserved_seeds_used=False,
        noisy_development_seeds_used=False, not_solution=True, canonical_release_evidence=False,
        scope='MP100 full link-spectrum pole shaping changes stable link decay as well as unstable replacement. Weak stable cart mode retained; neutral translation pole set exp(-0.5dt). Same frozen mixed-coordinate signed directions/centers as review baseline, delivered native F32 bounded local30s screens. Linear poles/transients are not capture or release certificates.')
    cache_ref = next(v for v in baseline['sources'] if v['path'].endswith('capture_cache.json'))
    assert file_metadata(cache_ref['path']) == cache_ref
    cache = json.loads(Path(cache_ref['path']).read_text())
    payload['baseline_linear_transient'] = model_transient(a, b, cache['gain'], directions, 15)
    began = time.monotonic()
    for label, alpha, beta, skew in FAMILY:
        row = dict(label=label, unstable_exponent=alpha, stable_link_exponent=beta,
                   unstable_log_decay_skew=skew, screens=[], status='designing')
        payload['records'].append(row)
        dump_json(payload, out/'result.progress.json')
        started = time.monotonic()
        targets = []
        for z in roots:
            if abs(z-1) < ctx.mpf('1e-60'):
                target = ctx.exp(-ctx.mpf('.5')*ctx.mpf(dt))
            elif z > 1:
                rank = unstable.index(z)
                modulation = 1+ctx.mpf(skew)*(ctx.mpf(rank)/14-ctx.mpf('.5'))
                target = z**(-ctx.mpf(alpha)*modulation)
            elif z in stable_links:
                target = z**ctx.mpf(beta)
            else:
                target = z
            targets.append(target)
        try:
            gain, diagnostics = high_precision_siso_pole_gain(a.tolist(), b.tolist(), targets, decimal_digits=100)
            gain = gain.ravel()
            row.update(gain=gain.tolist(), design_diagnostics=diagnostics,
                design_wall_seconds=time.monotonic()-started,
                linear_transient=model_transient(a, b, gain, directions, 15))
            # Retain native outcomes even if rounded-gain input-model stability fails.
            for amplitude in (0., 1e-14, 1e-12, 1e-10):
                trials = directions[:1] if amplitude == 0 else directions
                for index, direction in enumerate(trials):
                    for sign in ((1,) if amplitude == 0 else (1, -1)):
                        initial = centers['upright_origin'].copy()
                        initial[1:16] += sign*amplitude*direction[:15]
                        initial[17:] += sign*amplitude*direction[15:]
                        result = screen(cfg, initial, gain, 30.)
                        row['screens'].append(dict(center='upright_origin', amplitude=amplitude,
                                                   direction=index, sign=sign, result=result))
                        payload['native_transition_calls'] += result['native_transition_calls']
            for name in ('transferred14_quiet_endpoint', 'verified15_h64_endpoint'):
                result = screen(cfg, centers[name], gain, 30.)
                row['screens'].append(dict(center=name, amplitude=0., result=result))
                payload['native_transition_calls'] += result['native_transition_calls']
            row['summaries'] = [dict(amplitude=amplitude, episodes=len(trials),
                local_gate_passes=sum(r['local_gate_pass'] for r in trials),
                all_samples_upright=sum(r['all_samples_upright'] for r in trials),
                minimum_hold_seconds=min(r['physical_hold_seconds'] for r in trials))
                for amplitude in (0., 1e-14, 1e-12, 1e-10)
                for trials in [[s['result'] for s in row['screens']
                                if s['center']=='upright_origin' and s['amplitude']==amplitude]]]
            row['status'] = 'finished'
        except (ValueError, ZeroDivisionError, np.linalg.LinAlgError) as error:
            row.update(status='design_failed', error=f'{type(error).__name__}: {error}')
        row['wall_seconds'] = time.monotonic()-started
        payload['wall_seconds'] = time.monotonic()-began
        dump_json(payload, out/'result.progress.json')
        print(json.dumps(dict(label=label, status=row['status'],
            gain_norm=row.get('design_diagnostics',{}).get('gain_norm'), summaries=row.get('summaries'),
            total_native_transition_calls=payload['native_transition_calls'])), flush=True)
    payload['wall_seconds'] = time.monotonic()-began
    dump_json(payload, out/'result.json')


if __name__ == '__main__':
    main()
