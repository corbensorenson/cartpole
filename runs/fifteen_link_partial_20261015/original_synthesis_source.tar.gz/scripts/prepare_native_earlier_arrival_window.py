#!/usr/bin/env python
"""Extend a checked plan backward through its actual, admissible arrival prefix."""
import argparse,json
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg


def earliest_admissible_suffix(states,n_links,angle_limit,rail_limit):
    states=np.asarray(states,float)
    if states.ndim!=2 or states.shape[1]!=2*(n_links+1) or not np.all(np.isfinite(states)):
        raise ValueError('finite aligned physical states required')
    allowed=(np.max(np.abs(wrap_angle(np.cumsum(states[:,1:n_links+1],axis=1))),axis=1)<angle_limit)&(np.abs(states[:,0])<=rail_limit)
    invalid=np.flatnonzero(~allowed)
    return int(invalid[-1]+1) if len(invalid) else 0


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    p.add_argument('--angle-limit',type=float,default=.149)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    if not .1<args.angle_limit<.15:raise ValueError('planner margin required')
    plan=json.loads(Path(args.source).read_text())
    if not plan['feasible_sequence_found'] or not plan['known_plan_byte_identical'] or not plan['live_state_unchanged']:
        raise ValueError('verified native plan required')
    cursor=plan;ancestry=[file_metadata(args.source)];seen={args.source}
    while not all(k in cursor for k in ('config','teacher','parameters')):
        ref=cursor['source']
        if ref['path'] in seen or len(ancestry)>=9 or file_metadata(ref['path'])!=ref:raise ValueError('changed or cyclic ancestry')
        seen.add(ref['path']);ancestry.append(ref);cursor=json.loads(Path(ref['path']).read_text())
    for k in ('source','config','teacher'):
        if file_metadata(cursor[k]['path'])!=cursor[k]:raise ValueError('changed physical source')
    cfg=load_config(cursor['config']['path']);n=cfg['env']['n_links'];nx=2*(n+1)
    if cfg['env']['frame_skip']!=4:raise ValueError('canonical cadence required')
    base=json.loads(Path(cursor['source']['path']).read_text());old_step=cursor['parameters']['start_step']
    prefix=base['result']['trajectory'][:old_step]
    prefix_states=np.asarray([r['qpos']+r['qvel'] for r in prefix])
    start=earliest_admissible_suffix(prefix_states,n,args.angle_limit,cfg['env']['rail_limit'])
    if start>=old_step:raise ValueError('no earlier admissible arrival prefix')
    actions=np.r_[np.asarray([r['action'] for r in prefix[start:]],np.float32).astype(float),
                  np.asarray(plan['selected_sequence'],np.float32).astype(float)]
    expected=np.vstack([prefix_states[start:],np.asarray(plan['selected_states'])])
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True)
    untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
    state=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
    try:
        for row in prefix[:start]:
            state=native(state,float(np.float32(row['action'])))
            if state.tobytes()!=np.asarray(row['qpos']+row['qvel']).tobytes():raise ValueError('cold prefix changed')
        verified=[]
        for action,boundary in zip(actions,expected):
            state=native(state,float(action));verified.append(state.copy())
            if state.tobytes()!=boundary.tobytes():raise ValueError('extended native arrival boundary changed')
        if earliest_admissible_suffix(verified,n,args.angle_limit,env.rail_limit)!=0:
            raise ValueError('extended arrival exceeds physical planner bound')
        if untouched.tobytes()!=np.r_[env.data.qpos,env.data.qvel].tobytes():raise ValueError('planner changed live state')
        result=dict(not_solution=True,canonical_release_evidence=False,original_plan=file_metadata(args.source),
            input_ancestry=ancestry,source=cursor['source'],config=cursor['config'],teacher=cursor['teacher'],
            parameters=dict(start_step=start,rate_residual_weight=cursor['parameters']['rate_residual_weight']),
            preparation_parameters=vars(args),old_start_step=old_step,new_start_step=start,
            control_dt=env.dt,horizon_steps=len(actions),native_transition_calls=native.evaluations,
            native_physics_steps=native.evaluations*env.frame_skip,actual_episode_steps=0,optimizer_transition_calls=0,
            known_plan_byte_identical=True,feasible_sequence_found=True,live_state_unchanged=True,
            selected_sequence=actions.tolist(),selected_states=expected.tolist(),runtime=runtime_metadata(),
            reserved_seeds_used=False,noisy_development_seeds_used=False,
            scope='Canonical planning-window extension through earlier actual arrival inputs;original cold prefix and full longer tape independently reproduce bytes. No new control changes or actual episode. Earlier window search must retain every angle/rail bound,then pass actual full replay before any release gate.')
        dump_json(result,out/'result.json')
        print(json.dumps({k:result[k] for k in ['old_start_step','new_start_step','horizon_steps','native_transition_calls']}),flush=True)
    finally:env.close()


if __name__=='__main__':main()
