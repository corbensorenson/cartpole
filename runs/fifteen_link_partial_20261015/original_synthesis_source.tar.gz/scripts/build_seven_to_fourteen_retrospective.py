"""Read archived evaluations and bind the retrospective to their exact bytes.

This audit does not execute controllers, resynthesize routes, or use new seeds.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORDS = ['seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen']
OUT = ROOT / 'runs/seven_to_fourteen_retrospective'


def metadata(path):
    path = Path(path)
    data = (ROOT / path).read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def checked_reference(reference):
    if isinstance(reference, str):
        return metadata(reference)
    actual = metadata(reference['path'])
    for key in ('bytes', 'sha256'):
        if key in reference:
            assert actual[key] == reference[key], (actual['path'], key)
    return actual


def cohort(reference):
    ref = checked_reference(reference)
    report = json.loads((ROOT / ref['path']).read_text())
    episodes = report['episode_results']
    assert len(episodes) == report['episodes']
    assert all(e['success'] and e.get('length', 1500) == 1500 and
               e['termination_reason'] == 'time_limit' and
               e['max_upright_streak_seconds'] >= 5 and
               e['max_cart_excursion'] <= 3 for e in episodes), ref['path']
    return {'source': ref, 'episodes': len(episodes),
            'successes': sum(bool(e['success']) for e in episodes),
            'seed_start': report['seed_start'],
            'seeds': [e['seed'] for e in episodes],
            'minimum_hold_seconds': min(e['max_upright_streak_seconds'] for e in episodes),
            'maximum_cart_excursion_m': max(e['max_cart_excursion'] for e in episodes),
            'all_full_episode': True,
            'completion_basis': 'explicit 1500-step length and time_limit' if
                all('length' in e for e in episodes) else
                'historical time_limit reports; explicit per-episode lengths absent',
            'park_seconds': report.get('park_seconds', report.get('prelude_seconds')),
            'route_seconds': report.get('route_seconds'),
            'tracking_gain_scale': report['tracking_gain_scale']}


def fifteen_prediction_evidence():
    """Extract completed development comparisons without replaying the plant."""
    prefix = 'runs/frontier_campaign_20261001/'
    names = [
        'n15_native_h57_pairs_matched_total_budget_continuation',
        'n15_native_h57_triples_matched_total_budget_continuation',
        'n15_native_h57_feasible_arrival_weight5_triple_polish',
        'n15_native_h57_feasible_arrival_weight100_triple_polish',
        'n15_native_h57_arrival_weight5_plan_then_baseline_full30',
        'n15_native_h57_arrival_weight100_plan_then_baseline_full30',
        'n15_native_h57_arrival_directional_capture_audit',
        'n15_inherited_physical_tail_value0_full20',
        'n15_inherited_physical_tail_value1_full20',
        'n15_native_h141_earlier_directional100_plan_then_baseline_full30',
        'n15_native_h57_quadruples_matched_physics_budget_continuation',
        'n15_native_quadruple_plan62_then_baseline_full30',
        'n15_native_h58_quadruple_subset_audit',
        'n15_native_h63_three_response_quadruple_restoration',
        'n15_native_h63_stream_arity4_matched_restoration',
        'n15_native_h63_stream_arity5_matched_restoration',
        'n15_native_h63_temporal_strata_arity4_restoration',
        'n15_native_h63_temporal_strata_arity5_restoration',
        'n15_native_h63_five_input_rank3_comparison',
        'n15_native_h63_five_input_rank4_comparison',
        'n15_native_h63_rank3_round2_verified_center',
        'n15_native_h63_rank3_maximum_objective_comparison',
        'n15_native_h63_rank3_sum_objective_comparison',
        'n15_native_h63_coupled_null_minimax_comparison',
        'n15_native_h63_uncoupled_null_minimax_control',
        'n15_native_h63_nested_rank_constraint_geometry',
        'n15_native_h63_direct_sparse_integer_minimax',
        'n15_native_h63_sparse_integer_refined_geometry_bound_spans',
        'n15_native_h63_refined_geometry_candidates',
        'n15_native_sparse_integer_plan63_then_baseline_full30',
        'n15_native_h64_integer_growth_comparison',
        'n15_native_h64_rounded_null_growth_control',
        'n15_native_h64_all_input_real_reachability',
        'n15_native_h64_frozen_model_suffix_reachability',
        'n15_native_h64_frozen_model_physical_suffix_boxes',
        'n15_native_h64_fresh_physical_suffix_round1',
        'n15_native_h64_fresh_physical_suffix_round2',
        'n15_native_fresh_suffix_plan64_then_baseline_full30',
        'n15_native_h65_fresh_physical_suffix_growth_bound_record_schemas',
        'n15_native_h65_prefix28_32_physical_domain_comparison',
        'n15_native_h65_derivative_scale_0p25',
        'n15_native_h65_derivative_scale_0p5',
        'n15_native_h65_derivative_scale_1',
        'n15_native_h65_derivative_scale_2',
    ]
    records = []
    for name in names:
        ref = metadata(prefix + name + '/result.json')
        data = json.loads((ROOT / ref['path']).read_text())
        metrics = {key: data[key] for key in (
            'last_valid_horizon_steps', 'total_native_transition_calls',
            'initial_endpoint', 'final_endpoint', 'final_maximum_angle',
            'known_plan_byte_identical', 'actual_plan_states_byte_identical_to_forecast',
            'actual_episode_steps', 'full_development_episode_passed',
            'horizon_steps', 'feasible_sequence_found', 'initial_score', 'last_finite_score',
            'source_initial_score_exact', 'source_final_tape_and_score_exact',
            'selected_round_score_and_angle_exact', 'independent_selected_round_replay_bytes_exact',
            'new_valid_plan_found', 'initial_known_horizon_steps', 'selected_plan_score',
            'derivative_action_epsilon', 'derivative_state_epsilon',
        ) if key in data}
        if 'bound_objective' in data.get('parameters', {}):
            metrics['bound_objective'] = data['parameters']['bound_objective']
        if 'last_finite_states' in data:
            import numpy as np
            states = np.asarray(data['last_finite_states'])
            n = states.shape[1] // 2 - 1
            phi = (np.cumsum(states[:, 1:n+1], axis=1) + np.pi) % (2*np.pi) - np.pi
            metrics['last_finite_maximum_angle'] = float(np.max(np.abs(phi)))
            metrics['native_restoration_rounds'] = [
                {key: row[key] for key in ('round', 'improved', 'maximum_angle',
                                           'tested_candidates', 'native_planning_transition_calls')}
                for row in data.get('rounds', [])]
            metrics['selected_temporal_spans_ticks'] = [
                None if row['selected_proposal'] is None else
                row['selected_proposal']['indices'][-1]-row['selected_proposal']['indices'][0]
                for row in data.get('rounds', [])]
            metrics['selected_null_direction_families'] = [
                None if row['selected_proposal'] is None else
                row['selected_proposal'].get('null_direction_family', 'legacy_signed_minors')
                for row in data.get('rounds', [])]
        if 'stages' in data:
            metrics['last_stage'] = {key: data['stages'][-1][key] for key in (
                'horizon_steps', 'feasible_sequence_found', 'maximum_angle', 'status')
                if key in data['stages'][-1]}
            if 'new_valid_plan_found' in data:
                metrics['growth_proposal_family'] = data['parameters']['proposal_family']
                metrics['last_attempt_rounds'] = [{key: row[key] for key in (
                    'round', 'improved', 'maximum_angle', 'tested_candidates',
                    'native_planning_transition_calls', 'native_local_derivative_transition_calls')}
                    for row in data['stages'][-1]['rounds']]
        state_key = 'last_finite_states' if 'last_finite_states' in data else 'selected_states'
        if state_key in data:
            import numpy as np
            endpoint = np.asarray(data[state_key], dtype=float)[-1]
            n = len(endpoint)//2-1
            angles = (np.cumsum(endpoint[1:n+1])+np.pi) % (2*np.pi)-np.pi
            rates = np.cumsum(endpoint[n+2:])
            largest = np.argsort(-np.abs(angles), kind='stable')[:5]
            metrics['endpoint_physical_motion'] = dict(
                state_source_field=state_key, cart_position=float(endpoint[0]),
                cart_velocity=float(endpoint[n+1]),
                maximum_absolute_link_rate=float(np.max(np.abs(rates))),
                largest_angles=[dict(link=int(i+1),angle=float(angles[i]),
                                     absolute_rate=float(rates[i])) for i in largest])
        if 'result' in data:
            metrics['actual'] = {key: data['result'][key] for key in (
                'length', 'success', 'max_upright_streak_seconds',
                'max_cart_excursion', 'termination_reason', 'trajectory_integrity')}
            # A nominal development pass still cannot establish a released count.
        if 'records' in data:
            if 'summaries' in data:
                metrics['constraint_geometry'] = data['summaries']
                metrics['nested_tolerance_violations'] = data['nested_real_model_tolerance_violations']
                metrics['violating_angles'] = data['violating_angles']
            elif 'final_bound_diagnostics' in data:
                metrics['real_all_input_trials' if 'affine_bound_model' in data else 'sparse_integer_trials'] = data['records']
                metrics['final_bound_diagnostics'] = data['final_bound_diagnostics']
                if 'affine_bound_model' in data:
                    metrics['affine_bound_model'] = checked_reference(data['affine_bound_model'])
            else:
                key = 'directional_audit' if 'binary64_saved_capture_value' in data['records'][0] else 'subset_ablation'
                metrics[key] = data['records']
        records.append({'name': name, 'source': ref, 'metrics': metrics})
    for value in (0, 1):
        directory = prefix + f'n15_inherited_physical_tail_value{value}_conditional_followup/'
        journal_ref = metadata(directory + 'followup.json')
        journal = json.loads((ROOT / journal_ref['path']).read_text())
        assert journal['status'] == 'finished_negative', journal_ref['path']
        screen_ref = checked_reference(journal['physical_screen'])
        screen = json.loads((ROOT / screen_ref['path']).read_text())
        assert screen['status'] == 'finished_negative'
        handoffs = []
        for row in screen['handoff_results']:
            ref = checked_reference(row['result'])
            actual = json.loads((ROOT / ref['path']).read_text())['result']
            assert not row['full_physical_pass'] and not actual['success']
            handoffs.append({'seconds': row['seconds'], 'source': ref,
                'actual': {key: actual[key] for key in (
                    'length', 'success', 'max_upright_streak_seconds',
                    'max_cart_excursion', 'termination_reason')}})
        records.append({'name': f'physical_tail_value{value}_conditional_followup',
                        'source': journal_ref, 'screen': screen_ref,
                        'metrics': {'handoffs': handoffs}})
    coverage = metadata(prefix + 'n15_native_stream_support_coverage.json')
    records.append({'name': 'bounded_stream_temporal_coverage', 'source': coverage,
                    'metrics': json.loads((ROOT / coverage['path']).read_text())['records']})
    retention = metadata(prefix + 'n15_native_coupled_minimax_first_round_retention_audit/result.json')
    retained = json.loads((ROOT / retention['path']).read_text())
    assert retained['initial_native_states_and_score_exact'] and retained['live_state_unchanged']
    records.append({'name': 'coupled_minimax_first_round_retention', 'source': retention,
                    'metrics': {'records': retained['records'],
                                'total_native_transition_calls': retained['total_native_transition_calls']}})
    review_ref = metadata('tmp/deep_review_fifteen_20261003/analysis.json')
    review = json.loads((ROOT / review_ref['path']).read_text())
    for ref in review['sources']:
        checked_reference(ref)
    for key in ('linear_arithmetic_comparison', 'independent_mp60_nonlinear_comparison',
                'nonlinear_remainder_projection'):
        checked_reference(review[key])
    records.append({'name': 'received_deeper_capture_review', 'source': review_ref,
                    'metrics': {key: review[key] for key in (
                        'geometry', 'accepted_handoffs', 'adjacent_endpoint_transfer',
                        'local_capture_perturbations', 'principal_new_findings')}})
    compatibility_ref = metadata('runs/frontier_campaign_20261001/n15_review_nonlinear_capture_compatibility/result.json')
    compatibility = json.loads((ROOT / compatibility_ref['path']).read_text())
    assert compatibility['records'][0]['result']['expected_native_states_byte_identical']
    assert all(row['reproduced_review'] for row in compatibility['records'][1:5])
    records.append({'name': 'review_reproduction_and_target15_capture_screens',
                    'source': compatibility_ref, 'metrics': {key: compatibility[key] for key in (
                        'summary', 'gain_norms', 'verified_review_references',
                        'native_transition_calls', 'perturbation_definition')}})
    transient_ref = metadata('runs/frontier_campaign_20261001/n15_transient_shaped_capture_component/diagnostic/result.json')
    transient = json.loads((ROOT / transient_ref['path']).read_text())
    records.append({'name': 'full_link_spectrum_transient_shaping', 'source': transient_ref,
        'metrics': dict(native_transition_calls=transient['native_transition_calls'],
            baseline_linear_transient=transient['baseline_linear_transient'],
            records=[{key:row[key] for key in ('label', 'status', 'design_diagnostics',
                'linear_transient', 'summaries', 'screens') if key in row}
                for row in transient['records']])})
    pilot_ref = metadata('runs/frontier_campaign_20261001/n15_projected_remainder_capture_pilot/diagnostic/result.json')
    pilot = json.loads((ROOT / pilot_ref['path']).read_text())
    records.append({'name': 'native_projected_remainder_capture_pilot', 'source': pilot_ref,
        'metrics': dict(total_native_transition_calls=pilot['total_native_transition_calls'],
            records=[dict(gain_label=row['gain_label'], amplitude=row['amplitude'], sign=row['sign'],
                result={key:row['result'][key] for key in (
                    'steps', 'physical_hold_seconds', 'local_gate_pass', 'first_angle_failure_seconds',
                    'maximum_angle', 'maximum_absolute_rate', 'maximum_cart', 'maximum_delivered_action',
                    'changed_delivered_actions', 'delivered_at_bound_steps', 'planning_transition_calls',
                    'every_selected_forecast_matches_live_state_bytes',
                    'independent_actual_tape_replay_bytes_exact')}) for row in pilot['records']])})
    delayed_ref = metadata('runs/frontier_campaign_20261001/n15_projected_remainder_capture_pilot/diagnostic/delayed_projection_audit.json')
    records.append({'name': 'projected_remainder_delayed_error_audit', 'source': delayed_ref,
                    'metrics': json.loads((ROOT / delayed_ref['path']).read_text())['records']})
    for name in ('n15_joint_projected_capture_pilot', 'n15_joint_force_aware_capture_pilot',
                 'n15_joint_constraint_capture_pilot', 'n15_joint_constraint_horizon_pilot',
                 'n15_joint_capture_continuity_pilot'):
        result_path = ROOT / prefix / name / 'diagnostic/result.json'
        if not result_path.exists():
            continue  # Completed comparisons only; running pilots are not results.
        ref = metadata(prefix + name + '/diagnostic/result.json')
        data = json.loads(result_path.read_text())
        records.append({'name': name, 'source': ref, 'metrics': dict(
            total_native_transition_calls=data['total_native_transition_calls'],
            planning_transition_calls=data['planning_transition_calls'],
            actual_local_episode_steps=data['actual_local_episode_steps'],
            records=[dict(label=row['label'], gain_label=row['gain_label'],
                horizon=row['horizon'], projection_delays=row['projection_delays'],
                commit_steps=row['commit_steps'],controller_options=row.get('controller_options',{}),
                result={key:row['result'][key] for key in (
                    'steps','physical_hold_seconds','local_gate_pass','first_angle_failure_seconds',
                    'maximum_angle','maximum_absolute_rate','maximum_cart','maximum_delivered_action',
                    'every_committed_forecast_matches_live_bytes','independent_actual_tape_replay_bytes_exact')})
                for row in data['records']])})
    force_ref = metadata(prefix + 'n15_joint_projected_capture_pilot/diagnostic/terminal_force_audit.json')
    records.append({'name':'joint_projection_omitted_future_force_audit', 'source':force_ref,
                    'metrics':json.loads((ROOT / force_ref['path']).read_text())['records']})
    selection_ref = metadata(prefix + 'n15_joint_force_aware_capture_pilot/diagnostic/selection_audit.json')
    records.append({'name':'joint_capture_selection_audit', 'source':selection_ref,
                    'metrics':json.loads((ROOT / selection_ref['path']).read_text())['records']})
    for name in ('n15_joint_constraint_capture_pilot', 'n15_joint_constraint_horizon_pilot',
                 'n15_joint_capture_continuity_pilot'):
        path=prefix + name + '/diagnostic/constraint_audit.json'
        if not (ROOT/path).is_file():
            continue
        ref=metadata(path)
        records.append({'name':name+'_constraint_audit','source':ref,
                        'metrics':json.loads((ROOT/path).read_text())['records']})
    prediction_ref=metadata(prefix+'n15_joint_constraint_capture_pilot/diagnostic/prediction_audit.json')
    prediction=json.loads((ROOT/prediction_ref['path']).read_text())
    records.append({'name':'joint_constraint_affine_f32_native_prediction_audit','source':prediction_ref,
                    'metrics':dict(native_transition_calls=prediction['native_transition_calls'],records=prediction['records'])})
    for name, filename in (
        ('n15_mode_aligned_capture_component', 'result.progress.json'),
        ('n15_mode_aligned_capture_zero_normalized', 'result.json'),
        ('n15_mode_capture_geometry_component', 'result.json'),
    ):
        ref = metadata(prefix + name + '/diagnostic/' + filename)
        data = json.loads((ROOT / ref['path']).read_text())
        execution = metadata(prefix + name + '/execution.json')
        journal = json.loads((ROOT / execution['path']).read_text())
        assert journal['status'] == ('failed' if filename == 'result.progress.json' else 'finished')
        assert journal['returncode'] == (1 if filename == 'result.progress.json' else 0)
        # Every saved episode is bound to its complete raw physical tape.
        for row in data['records']:
            checked_reference(row['result']['tape'])
        records.append({'name': name, 'source': ref, 'execution': execution,
            'metrics': {key: data[key] for key in (
                'scope', 'designs', 'amplitudes', 'coefficients', 'coefficient_seed',
                'physical_directions', 'zero_initialization_convention',
                'actual_local_episode_steps', 'independent_tape_replay_calls',
                'total_native_transition_calls', 'native_transition_ceiling', 'records') if key in data},
            'status': journal['status'], 'canonical_release_evidence': False})
    for name in ('n15_native_modal_arrival_comparison',
                 'n15_native_modal_arrival_f32_contractions',
                 'n15_native_arrival_probe_scale_component'):
        path=prefix+name+'/diagnostic/result.json'
        ref=metadata(path);data=json.loads((ROOT/path).read_text())
        execution=metadata(prefix+name+'/execution.json')
        journal=json.loads((ROOT/execution['path']).read_text())
        assert journal['status']=='finished' and journal['returncode']==0
        for row in data['records']:
            if 'tape' in row:checked_reference(row['tape'])
        records.append({'name':name,'source':ref,'execution':execution,
            'metrics':{key:data[key] for key in ('scope','parameters','metric',
                'setup_native_transition_calls','total_native_transition_calls',
                'actual_hanging_start_episode_steps','records') if key in data},
            'canonical_release_evidence':False})
    ref=metadata(prefix+'n15_native_modal_arrival_results_audit.json')
    records.append({'name':'native_modal_arrival_intervention_and_probe_audit','source':ref,
                    'metrics':json.loads((ROOT/ref['path']).read_text())})
    return {'scope': 'Completed fifteen-link development evidence only; '
                     'no new simulation, noisy cohorts, reserved seeds or accepted record. '
                     'Hanging-start follow-ups remain negative; modal local maintenance passes '
                     'do not establish reachability. Interrupted signed-zero run retained separately.',
            'highest_accepted_count': 14, 'active_count': 15, 'records': records}


def harmonic_reconnaissance_evidence():
    """Refresh only the new supplement without replacing earlier study bindings."""
    prefix = 'runs/harmonics_reconnaissance_20261003_phase_accounting/'
    audit_path = prefix+'verified.json'
    audit = json.loads((ROOT/audit_path).read_text())
    assert audit['passed'] and audit['total_new_native_transition_calls'] == 0
    result = json.loads((ROOT/(prefix+'diagnostic/result.json')).read_text())
    supplement = dict(
        scope='22 stored native tapes and16 hanging base-acceleration mode plants; descriptive spectra/phase, not causal resonance or a new canonical solve.',
        verification=metadata(audit_path),result=metadata(prefix+'diagnostic/result.json'),
        metrics=metadata(prefix+'diagnostic/phase_metrics.csv'),
        figures=metadata(prefix+'diagnostic/figures/figures.json'),
        prospective_memo=metadata('research/memos/2026-10-03_harmonics_reconnaissance_plan.json'),
        clarification_memo=metadata('research/memos/2026-10-03_harmonics_phase_accounting_amendment.json'),
        results_memo=metadata('research/memos/2026-10-03_harmonics_results.json'),
        trace_count=audit['trace_count'],mode_plant_count=audit['mode_plant_count'],
        same_swing_different_outcome=result['same_swing_different_outcome'],
        total_new_native_transition_calls=0,canonical_release_evidence=False,
        protocol=metadata('docs/research_recording.md'))
    (OUT/'harmonics_evidence.json').write_text(json.dumps(supplement,indent=2)+'\n')
    return supplement


def armature_increment_evidence():
    """Refresh the physical-prefix continuation supplement without old rebuilds."""
    prefix='runs/armature_route_increment_20261003/'
    audit=json.loads((ROOT/(prefix+'verified_fixed_prefix.json')).read_text())
    assert audit['passed'] and audit['combined_turn_native_transition_calls']==3079312
    supplement=dict(scope='Exact altered14armature0.98physicalcontinuation;failedfull-route/smallerstep/MPcomparisonsretained;canonical15unsolved.',
        audits=[metadata(prefix+p) for p in ('verified.json','verified_step_iterations.json','verified_fixed_prefix.json')],
        figures=metadata(prefix+'fixed_prefix_figures/figures.json'),passing_physical_initializer=audit['passing_physical_initializer'],
        total_new_native_transition_calls=audit['combined_turn_native_transition_calls'],
        actual_hanging_start_episode_steps=audit['combined_turn_actual_hanging_start_episode_steps'],
        full_passing_handoffs=audit['full_passing_handoffs'],canonical_release_evidence=False,
        protocol=metadata('docs/research_recording.md'))
    (OUT/'armature_increment_evidence.json').write_text(json.dumps(supplement,indent=2)+'\n')
    return supplement


def adaptive_armature_evidence():
    """Refresh only the declared adaptive-recipe supplement after its audit."""
    prefix='runs/armature_adaptive_continuation_20261004/'
    audit=json.loads((ROOT/(prefix+'verified.json')).read_text());assert audit['passed']
    supplement=dict(scope='Declared shared native swing/capture procedure on exact altered14 plants; target factors0.97/0.95 from passing0.98 source. No canonical count promotion or noisy robustness.',
        verification=metadata(prefix+'verified.json'),figures=metadata(prefix+'figures/figures.json'),
        prospective_memo=metadata('research/memos/2026-10-04_adaptive_armature_continuation_plan.json'),
        results_memo=metadata('research/memos/2026-10-04_adaptive_armature_continuation_results.json'),
        pipelines=audit['pipelines'],total_new_native_transition_calls=audit['total_new_native_transition_calls'],
        actual_hanging_start_episode_steps=audit['actual_hanging_start_episode_steps'],
        budget_scope=audit['budget_scope'],canonical_release_evidence=False,protocol=metadata('docs/research_recording.md'))
    (OUT/'adaptive_armature_evidence.json').write_text(json.dumps(supplement,indent=2)+'\n')
    return supplement


def closer_source_armature_evidence():
    """Refresh closer-source supplement, retaining earlier plant comparisons."""
    prefix='runs/armature_closer_source_20261004/'
    audit=json.loads((ROOT/(prefix+'verified.json')).read_text());assert audit['passed']
    supplement=dict(scope='Declared matched continuation from physical0.97to0.96/0.95 on altered14; both stopwithoutarrival. No targetplant impossibility orcanonical promotion.',
        verification=metadata(prefix+'verified.json'),figures=metadata(prefix+'figures/figures.json'),
        prospective_memo=metadata('research/memos/2026-10-04_closer_source_continuation_plan.json'),
        results_memo=metadata('research/memos/2026-10-04_closer_source_continuation_results.json'),
        pipelines=audit['pipelines'],total_new_native_transition_calls=audit['total_new_native_transition_calls'],
        actual_hanging_start_episode_steps=audit['actual_hanging_start_episode_steps'],budget_scope=audit['budget_scope'],
        canonical_release_evidence=False,protocol=metadata('docs/research_recording.md'))
    (OUT/'closer_source_armature_evidence.json').write_text(json.dumps(supplement,indent=2)+'\n')
    return supplement


def harmonic_window_sensitivity_evidence():
    """Zero-physics window sensitivity supplement from independently checked PSDs."""
    prefix='runs/harmonic_window_sensitivity_20261004/'
    audit=json.loads((ROOT/(prefix+'verified.json')).read_text());assert audit['passed']
    result=json.loads((ROOT/(prefix+'diagnostic/result.json')).read_text());assert result['status']=='finished'
    supplement=dict(scope=result['scope'],verification=metadata(prefix+'verified.json'),
        result=metadata(prefix+'diagnostic/result.json'),figures=metadata(prefix+'figures/figures.json'),
        prospective_memo=metadata('research/memos/2026-10-04_harmonic_window_sensitivity_plan.json'),
        results_memo=metadata('research/memos/2026-10-04_harmonic_window_sensitivity_results.json'),
        trace_count=22,phase_window_domains=264,available_domains=166,unavailable_domains=98,
        independent_fft_spectra_checked=2203,maximum_fft_peak_scaled_residual=result['maximum_fft_relative_peak_scaled_residual'],
        canonical_whole_force_peaks_hz=result['canonical_whole_force_peak_hz_by_window'],
        total_new_native_transition_calls=0,canonical_release_evidence=False,protocol=metadata('docs/research_recording.md'))
    (OUT/'harmonic_window_sensitivity_evidence.json').write_text(json.dumps(supplement,indent=2)+'\n')
    return supplement


def short_swing_continuation_evidence():
    """Retain preflight invalidations and corrected finite negative controls."""
    prefix='runs/short_swing_continuation_20261004/'
    audit=json.loads((ROOT/(prefix+'verified.json')).read_text());assert audit['passed']
    supplement=dict(scope='Exact altered14 shortened6/8s tasks on0.95 from0.97; retained invalidpreflights and corrected negativecontrols. Horizon/capturetiming confounded; no canonical promotion.',
        verification=metadata(prefix+'verified.json'),figures=metadata(prefix+'figures/figures.json'),
        prospective_memo=metadata('research/memos/2026-10-04_short_swing_continuation_plan.json'),
        correction_memo=metadata('research/memos/2026-10-04_short_swing_preflight_correction.json'),
        results_memo=metadata('research/memos/2026-10-04_short_swing_continuation_results.json'),
        setup_failures=metadata(prefix+'setup_failures.json'),pipelines=audit['pipelines'],
        total_new_native_transition_calls=audit['total_new_native_transition_calls'],
        actual_hanging_start_episode_steps=audit['actual_hanging_start_episode_steps'],
        budget_scope=audit['budget_scope'],canonical_release_evidence=False,protocol=metadata('docs/research_recording.md'))
    (OUT/'short_swing_continuation_evidence.json').write_text(json.dumps(supplement,indent=2)+'\n')
    return supplement


def preserved_gain_followup_evidence():
    """Nine failed frozen-reference gain controls and independent action checks."""
    prefix='runs/preserved_gain_followup_20261004/'
    audit=json.loads((ROOT/(prefix+'verified.json')).read_text());assert audit['passed']
    supplement=dict(scope='Sameplant0.95 frozen14/6/8references, oldsourcegains1/.25/0; all9zero-hold. Nativeactions independently reconstructed. Cross-horizon timingconfounded.',
        verification=metadata(prefix+'verified.json'),result=metadata(prefix+'execution/diagnostic/result.json'),
        figures=metadata('runs/short_swing_continuation_20261004/figures/figures.json'),
        prospective_memo=metadata('research/memos/2026-10-04_preserved_gain_followup_plan.json'),
        results_memo=metadata('research/memos/2026-10-04_preserved_gain_followup_results.json'),
        total_new_native_transition_calls=audit['total_new_native_transition_calls'],
        actual_hanging_start_episode_steps=audit['actual_hanging_start_episode_steps'],
        canonical_release_evidence=False,protocol=metadata('docs/research_recording.md'))
    (OUT/'preserved_gain_followup_evidence.json').write_text(json.dumps(supplement,indent=2)+'\n')
    return supplement


def earlier_physical_capture_evidence():
    """Matched earlier-prefix interventions and bit-exact eight-second control."""
    prefix='runs/earlier_physical_capture_20261004/'
    audit=json.loads((ROOT/(prefix+'verified.json')).read_text());assert audit['passed']
    supplement=dict(scope='Same altered14plant/source, six/seven/eight-second actualprefixes and8+8capture-only repair; all fail, no canonical promotion.',
        verification=metadata(prefix+'verified.json'),figures=metadata(prefix+'figures/figures.json'),
        prospective_memo=metadata('research/memos/2026-10-04_earlier_physical_capture_plan.json'),
        results_memo=metadata('research/memos/2026-10-04_earlier_physical_capture_results.json'),
        pipelines=audit['pipelines'],control_reproduction=audit['control_reproduction'],
        total_new_native_transition_calls=audit['total_new_native_transition_calls'],
        actual_hanging_start_episode_steps=audit['actual_hanging_start_episode_steps'],
        budget_scope=audit['budget_scope'],canonical_release_evidence=False,protocol=metadata('docs/research_recording.md'))
    (OUT/'earlier_physical_capture_evidence.json').write_text(json.dumps(supplement,indent=2)+'\n')
    return supplement


def dense_capture_handoffs_evidence():
    """Every available native-tick handoff on the fixed best failed reference."""
    prefix='runs/dense_capture_handoffs_20261004/'
    audit=json.loads((ROOT/(prefix+'verified.json')).read_text());assert audit['passed']
    supplement=dict(scope=audit['scope'],verification=metadata(prefix+'verified.json'),
        result=metadata(prefix+'execution/diagnostic/result.json'),figures=metadata(prefix+'figures/figures.json'),
        prospective_memo=metadata('research/memos/2026-10-04_dense_capture_handoffs_plan.json'),
        results_memo=metadata('research/memos/2026-10-04_dense_capture_handoffs_results.json'),
        native_tick_cases=80,passing_handoff_seconds=audit['passing_handoff_seconds'],
        independent_reconstructed_tracking_ticks=audit['independent_reconstructed_tracking_ticks'],
        total_new_native_transition_calls=audit['total_new_native_transition_calls'],
        actual_hanging_start_episode_steps=audit['actual_hanging_start_episode_steps'],
        canonical_release_evidence=False,protocol=metadata('docs/research_recording.md'))
    (OUT/'dense_capture_handoffs_evidence.json').write_text(json.dumps(supplement,indent=2)+'\n')
    return supplement


def _directional_supplement(name, scope, extra):
    prefix = f'runs/{name}_20261004/'
    audit = json.loads((ROOT/(prefix+'verified.json')).read_text())
    assert audit['passed']
    supplement = dict(scope=scope, verification=metadata(prefix+'verified.json'),
        figures=metadata(prefix+'figures/figures.json'),
        prospective_memo=metadata(f'research/memos/2026-10-04_{name}_plan.json'),
        results_memo=metadata(f'research/memos/2026-10-04_{name}_results.json'),
        total_new_native_transition_calls=audit['total_new_native_transition_calls'],
        actual_hanging_start_episode_steps=audit['actual_hanging_start_episode_steps'],
        canonical_release_evidence=False, protocol=metadata('docs/research_recording.md'), **extra)
    (OUT/f'{name}_evidence.json').write_text(json.dumps(supplement,indent=2)+'\n')
    return supplement


def moving_capture_forcing_evidence():
    """Native moving-reference diagnostics, with arithmetic sensitivity retained."""
    prefix='runs/moving_capture_forcing_20261004/'
    audit=json.loads((ROOT/(prefix+'verified.json')).read_text())
    return _directional_supplement('moving_capture_forcing',audit['scope'],dict(
        result=audit['result'], manifest=audit['manifest'], records=audit['records'],
        processed_stored_actual_ticks=296, unavailable_requested_ticks=104,
        new_closed_loop_episodes=0, primary_binary64_products_numerically_certified=False,
        initial_elementwise_audit=metadata(prefix+'audit_initial_elementwise.py'),
        successful9second_prefix_byte_exact=audit['successful9second_prefix_byte_exact']))


def directional_capture_metric_evidence():
    """Four fixed-metric controls; failed QPs and optimization confounds retained."""
    prefix='runs/directional_capture_metric_20261004/'
    audit=json.loads((ROOT/(prefix+'verified.json')).read_text())
    return _directional_supplement('directional_capture_metric',audit['budget_scope'],dict(
        manifest=audit['manifest'], outcomes=audit['outcomes'], pipelines=audit['pipelines'],
        primitive_executions=8, nonadditive_pipeline_parents=4, new_closed_loop_episodes=14,
        default_factor_byte_identical=True, current_shared_suite_passed=733,
        no_new_passing_initializer=True))


def directional_dense_handoffs_evidence():
    """Complete finite preterminal timing grids on the four new repaired references."""
    prefix='runs/directional_dense_handoffs_20261004/'
    audit=json.loads((ROOT/(prefix+'verified.json')).read_text())
    return _directional_supplement('directional_dense_handoffs',audit['budget_scope'],dict(
        outcomes=audit['outcomes'], complete_available_handoff_ticks=377,
        new_closed_loop_episodes=377, no_new_passing_initializer=True,
        repeated_integer_control_tapes_byte_exact=audit['repeated_integer_control_tapes_byte_exact'],
        independent_reconstructed_tracking_ticks=audit['independent_reconstructed_tracking_ticks'],
        tracking_actions_independently_reconstructed_byte_exact=True))


def fixed_gain_affine_evidence():
    """Fixed runtime-gain bias comparison and normalized actual-prefix validation."""
    prefix='runs/fixed_gain_affine_20261004/'
    audit=json.loads((ROOT/(prefix+'verified.json')).read_text())
    normalized=json.loads((ROOT/(prefix+'initializer_verified.json')).read_text())
    assert audit['passed'] and normalized['passed']
    supplement=dict(scope=audit['scope'],verification=metadata(prefix+'verified.json'),
        initializer_verification=metadata(prefix+'initializer_verified.json'),
        figures=metadata(prefix+'figures/figures.json'),
        memos=[metadata(f'research/memos/2026-10-04_fixed_gain_affine{suffix}.json')
               for suffix in ('_plan','_results','_initializer_plan','_initializer_results')],
        outcomes=audit['outcomes'], full_component_passes=4,
        passing_physical_initializer=normalized['passing_physical_initializer'],
        previous_passing_physical_initializer=metadata('runs/armature_adaptive_continuation_20261004/target0.97/diagnostic/passing_physical_initializer.json'),
        total_new_native_transition_calls=157770, actual_hanging_start_episode_steps=21135,
        primitive_executions=2, new_actual_episodes=29, nonadditive_pipeline_parents=0,
        baseline_full_tapes_byte_exact=9, normalized_full_tapes_byte_exact=2,
        mp80_maximum_offset_residual=audit['mp80_maximum_offset_residual'],
        canonical_release_evidence=False, protocol=metadata('docs/research_recording.md'))
    (OUT/'fixed_gain_affine_evidence.json').write_text(json.dumps(supplement,indent=2)+'\n')
    return supplement


def native_affine_transfer_evidence():
    """Finite failed full-swing transfers, preserving native forcing and clipping."""
    prefix='runs/native_affine_transfer_20261004/'
    a=json.loads((ROOT/(prefix+'verified.json')).read_text());assert a['passed']
    supplement=dict(scope=a['scope'],verification=metadata(prefix+'verified.json'),
        figures=metadata(prefix+'figures/figures.json'),
        memos=[metadata(f'research/memos/2026-10-04_native_affine_transfer_{n}.json') for n in ('plan','results')],
        outcomes=a['outcomes'],total_new_native_transition_calls=181088,
        actual_hanging_start_episode_steps=1582,new_actual_episodes=8,
        distinct_preterminal_trajectories=4,mp80_maximum_offset_residual=a['mp80_maximum_offset_residual'],
        canonical_release_evidence=False,protocol=metadata('docs/research_recording.md'))
    (OUT/'native_affine_transfer_evidence.json').write_text(json.dumps(supplement,indent=2)+'\n')
    return supplement


def shared_native_bias_evidence():
    """General shared-entry equivalence and explicit zero-physics correction."""
    prefix='runs/shared_native_bias_20261004/'
    a=json.loads((ROOT/(prefix+'verified.json')).read_text());assert a['passed']
    supplement=dict(scope=a['scope'],verification=metadata(prefix+'verified.json'),
        figures=metadata(prefix+'figures/figures.json'),
        memos=[metadata(f'research/memos/2026-10-04_shared_native_bias_{n}.json') for n in ('plan','results','baseline_correction')],
        historical_code_binding_registry=metadata('research/sources/code_reference_relocations.json'),
        historical_code_binding_memo=metadata('research/memos/2026-10-04_historical_code_binding_relocation.json'),
        complete_actual_tapes_byte_exact_to_R24=6,shared_native_offsets_and_bias_design_gains_byte_exact=True,
        full_component_passes=2,deterministic_repeat_not_new_robustness=True,
        total_new_native_transition_calls=51682,actual_hanging_start_episode_steps=5267,
        new_actual_episodes=6,zero_physics_preflight_rejections=1,
        canonical_release_evidence=False,protocol=metadata('docs/research_recording.md'))
    (OUT/'shared_native_bias_evidence.json').write_text(json.dumps(supplement,indent=2)+'\n')
    return supplement


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for n, word in zip(range(7, 15), WORDS):
        folder = f'runs/swingup{n}_uniform' if n == 7 or n >= 11 else 'runs/generalized_solver'
        manifest_path = f'{folder}/{word}_link_swingup_manifest.json'
        manifest = json.loads((ROOT / manifest_path).read_text())
        ev = manifest['evaluation']
        a, b = ('gate20', 'gate100') if n >= 11 else ('twenty_episode', 'hundred_episode')
        gates = {'noisy20': cohort(ev[a]), 'noisy100': cohort(ev[b])}
        assert set(gates['noisy20']['seeds']).isdisjoint(gates['noisy100']['seeds'])
        if n >= 8:
            exact_key = 'exact20' if n >= 11 else 'exact_twenty_episode'
            gates['exact20'] = cohort(ev[exact_key])
        if n >= 11:
            gates['video_episode'] = cohort(ev['video_episode'])
            assert gates['video_episode']['seeds'][0] not in (
                gates['noisy20']['seeds'] + gates['noisy100']['seeds'])
            for name, key in [('noisy20', 'gate20'), ('noisy100', 'gate100'),
                              ('exact20', 'exact20'), ('video_episode', 'video_episode')]:
                saved = manifest['metrics'][key]
                measured = gates[name]
                assert saved['successes'] == measured['successes']
                assert saved['minimum_hold'] == measured['minimum_hold_seconds']
                assert saved['maximum_cart_excursion'] == measured['maximum_cart_excursion_m']
            policy_ref = checked_reference(manifest['policy'])
            policy = json.loads((ROOT / policy_ref['path']).read_text())
            controller = checked_reference(policy['controller'])
            video = checked_reference(manifest['video'])
        else:
            policy_ref = None
            controller = checked_reference(manifest['controller'])
            video = checked_reference(ev['video'])
        rows.append({'n_links': n, 'manifest': metadata(manifest_path),
                     'paper': metadata(f'docs/{word}_link_swingup_paper.md'),
                     'policy': policy_ref, 'controller': controller, 'video': video,
                     'cohorts': gates,
                     'rail_margin_m': 3 - gates['noisy100']['maximum_cart_excursion_m']})
    result = {'schema_version': 1,
              'scope': 'Retrospective of stored release evidence; no new physical episodes. '
                       '7-10 historical evidence and 11-14 frozen-source reserved gates retain '
                       'their original provenance; this audit does not upgrade historical provenance.',
              'records': rows,
              'noisy_successes': sum(r['cohorts']['noisy20']['successes'] +
                                     r['cohorts']['noisy100']['successes'] for r in rows),
              'exact_successes': sum(r['cohorts'].get('exact20', {}).get('successes', 0) for r in rows),
              'interpretation': 'Counts use different controllers. Totals are accounting only, '
                                'not an estimate of universal-solver success probability.'}
    (OUT / 'evidence.json').write_text(json.dumps(result, indent=2) + '\n')
    (OUT / 'fifteen_prediction_evidence.json').write_text(
        json.dumps(fifteen_prediction_evidence(), indent=2) + '\n')
    parameter_audit='runs/solved_chain_parameter_map_20261003_int_normalized/parameter_studies_verified.json'
    parameter_data=json.loads((ROOT/parameter_audit).read_text())
    assert parameter_data['passed'] and parameter_data['native_transition_calls']==0
    (OUT/'parameter_studies_evidence.json').write_text(json.dumps(dict(
        scope='Completed auxiliary geometry studies: transfer on7--14 and selected local gain redesign on7/10/14/15. No count promotion or route-resynthesis claim.',
        verification=metadata(parameter_audit),studies=parameter_data['studies'],
        retained_failure=parameter_data['retained_failure'],
        total_native_transition_calls=parameter_data['total_geometry_study_transition_calls'],
        protocol=metadata('docs/solved_chain_parameter_map.md')),indent=2)+'\n')
    route_audit='runs/armature_route_continuation_20261003/verified.json'
    route_data=json.loads((ROOT/route_audit).read_text())
    assert route_data['passed'] and route_data['native_transition_calls_for_this_audit']==0
    (OUT/'parameter_route_evidence.json').write_text(json.dumps(dict(
        scope='Completed small-armature fourteen full-route repairs and paired native defect correction/handoff screens. Exact unparked altered-plant evidence only; canonical fifteen unsolved.',
        verification=metadata(route_audit),studies=route_data['studies'],
        passing_physical_initializer=route_data['passing_physical_initializer'],
        total_new_native_transition_calls=route_data['total_new_native_transition_calls'],
        actual_hanging_start_episode_steps=route_data['actual_hanging_start_episode_steps'],
        figures=metadata('runs/armature_route_continuation_20261003/figures/figures.json'),
        protocol=metadata('docs/solved_chain_parameter_map.md')),indent=2)+'\n')
    spectral_audit='runs/parameter_eigenstructure_20261003_verified/parameter_spectral_results_verified.json'
    spectral_data=json.loads((ROOT/spectral_audit).read_text())
    assert spectral_data['passed'] and spectral_data['native_transition_calls_for_this_audit']==0
    (OUT/'parameter_spectral_evidence.json').write_text(json.dumps(dict(
        scope='129 high-precision upright spectra, 24 shared-cost feedback transients and 32 paired local native armature/cadence episodes. Raw zero condition summaries are invalid; corrected spectra are authoritative. Local altered-plant evidence only; canonical fifteen remains unsolved.',
        verification=metadata(spectral_audit),studies=spectral_data['studies'],
        figures=spectral_data['figures'],
        total_new_native_transition_calls=spectral_data['total_new_native_transition_calls'],
        protocol=metadata('docs/solved_chain_parameter_map.md')),indent=2)+'\n')
    if (ROOT/'runs/harmonics_reconnaissance_20261003_phase_accounting/verified.json').exists():
        harmonic_reconnaissance_evidence()
    if (ROOT/'runs/armature_route_increment_20261003/verified_fixed_prefix.json').exists():
        armature_increment_evidence()
    for r in rows:
        b = r['cohorts']['noisy100']
        print(f"n={r['n_links']} hold_min={b['minimum_hold_seconds']:.2f}s "
              f"cart_max={b['maximum_cart_excursion_m']:.6f}m "
              f"rail_margin={r['rail_margin_m']:.6f}m")
    print(f"Stored cohorts verified: {result['noisy_successes']} noisy successes, "
          f"{result['exact_successes']} exact successes; manifest references match.")


if __name__ == '__main__':
    main()
