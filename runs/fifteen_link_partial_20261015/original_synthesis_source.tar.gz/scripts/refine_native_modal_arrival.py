"""Matched native arrival refinement toward a demonstrated target-count quiet start.

No state decision variables or live resets inside the episode. Source prefix,
whole arrival segment, short bounded feedback tail and full hanging-start replay
are all native, using delivered float32 controls. Local target is not a record.
"""
import argparse
import json
from pathlib import Path
import time
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config, dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, runtime_metadata, utc_timestamp
from gcartpole.ilqr import MujocoTransition
from gcartpole.modal_arrival import empirical_modal_factor, regularized_qr_step
from gcartpole.simulation import SimulationError
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix, scale_step_to_trust_region
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.solve_frontier_capture_increment import validate_development_seeds


def represented_state(x, n):
    """Choose the zero-upright absolute branch for search residuals only."""
    y = np.asarray(x, dtype=float).copy()
    y[1:n+1] = wrap_angle(y[1:n+1])
    absolute = np.cumsum(y[1:n+1])
    if np.any(np.abs(absolute)>=np.pi):
        y[1:n+1] = np.diff(np.r_[0., wrap_angle(absolute)])
    return y


def raw_feedback(gain, state, n):
    physical = state.copy(); physical[1:n+1] = wrap_angle(physical[1:n+1])
    return -float(gain@physical)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', required=True)
    p.add_argument('--aligned', required=True)
    p.add_argument('--geometry', required=True)
    p.add_argument('--directory', required=True)
    p.add_argument('--start-step', type=int, default=291)
    p.add_argument('--arrival-step', type=int, default=439)
    p.add_argument('--iterations', type=int, default=6)
    p.add_argument('--knots', type=int, default=48)
    p.add_argument('--epsilon', type=float, default=1e-5)
    p.add_argument('--trust', type=float, default=.01)
    p.add_argument('--regularization', type=float, default=1e-6)
    p.add_argument('--arm-budget', type=int, default=400000)
    p.add_argument('--contraction-powers', type=int, default=8)
    p.add_argument('--verify-initial-comparison')
    args = p.parse_args();out = Path(args.directory)
    if out.exists():raise FileExistsError(out)
    if not 0 <= args.start_step < args.arrival_step or not 2 <= args.knots <= args.arrival_step-args.start_step:
        raise ValueError('bounded whole-arrival input basis required')
    if min(args.iterations,args.epsilon,args.trust,args.regularization,args.arm_budget)<=0:
        raise ValueError('positive finite search parameters required')
    if not 8 <= args.contraction_powers <= 32:
        raise ValueError('declared eight to32 contraction powers required')
    prior = None if not args.verify_initial_comparison else json.loads(Path(args.verify_initial_comparison).read_text())
    out.mkdir(parents=True);(out/'tapes').mkdir()
    saved=json.loads(Path(args.source).read_text())
    for k in ('source','config','plan_source','capture_cache'):
        assert saved[k]==file_metadata(saved[k]['path'])
    assert saved['inherited_prefix_states_and_actions_byte_identical'] and saved['actual_plan_states_byte_identical_to_forecast']
    base=json.loads(Path(saved['source']['path']).read_text())
    cfg=load_config(saved['config']['path']);n=cfg['env']['n_links'];nx=2*(n+1)
    validate_development_seeds(n,base['seed'])
    assert n==15 and cfg['env']['timestep']==.005 and cfg['env']['frame_skip']==4
    assert base['seed']==20265100
    aligned=json.loads(Path(args.aligned).read_text());geometry=json.loads(Path(args.geometry).read_text())
    assert geometry['aligned']==file_metadata(args.aligned)
    gain_label='moderately_separated_decay'
    gain=np.asarray(aligned['gains'][gain_label])
    design=next(d for d in aligned['designs'] if d['gain_label']==gain_label)
    target_row=next(r for r in geometry['records'] if r['gain_label']==gain_label and
        r['kind']=='modal_mixture' and r['amplitude']==1e-4 and r['direction']==0 and r['sign']==1)
    assert target_row['result']['local_gate_pass'] and target_row['result']['all_samples_upright']
    assert target_row['result']['tape']==file_metadata(target_row['result']['tape']['path'])
    target=np.asarray(target_row['result']['initial_state'])
    ctx,modal,w,metric=empirical_modal_factor([d['rounded_direction'] for d in design['directions']],
        n_links=n,time_scale=design['normalization']['time_scale_seconds'])
    initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
    local_cfg=fixed_state_cfg(cfg,base['selected_state'],30.)
    env=NLinkCartPoleEnv(local_cfg,progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    assert np.r_[env.data.qpos,env.data.qvel].tobytes()==initial.tobytes()
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True)
    untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
    controls=np.asarray([r['action'] for r in saved['result']['trajectory'][:args.arrival_step]],np.float32).astype(float)
    expected=np.asarray([r['qpos']+r['qvel'] for r in saved['result']['trajectory'][:args.arrival_step]])
    assert len(controls)==args.arrival_step
    interpolation=interpolation_matrix(args.knots,args.arrival_step-args.start_step)
    tail_steps=16;sample_offsets=(0,3,7,15);records=[]
    payload=dict(generated_at=utc_timestamp(),parameters=vars(args),runtime=runtime_metadata(),
        script=file_metadata(__file__),geometry_code=file_metadata('src/gcartpole/modal_arrival.py'),
        source=file_metadata(args.source),aligned=file_metadata(args.aligned),geometry=file_metadata(args.geometry),
        config=saved['config'],gain_label=gain_label,gain=gain.tolist(),target=target.tolist(),
        demonstrated_target_tape=target_row['result']['tape'],metric=metric,
        native_transition_ceiling=2*args.arm_budget+args.arrival_step+tail_steps,
        records=records,total_native_transition_calls=0,actual_hanging_start_episode_steps=0,
        reserved_seeds_used=False,noisy_development_seeds_used=False,canonical_release_evidence=False,not_solution=True,
        scope='Two matched arrival objectives on one actual hanging-start branch. Fixed prefix then distributed whole-arrival corrections; same quiet demonstrated target, frozen improved gain and16-step bounded native feedback tail. MP100 factored metric/QR without normal equations; every candidate F32/native checked. Selected full30s hanging-start episode and independent full tape proof. No new local robustness gate, noisy or reserved seeds.')
    began=time.monotonic()
    def forecast(state,tape):
        result=[];current=state.copy()
        for u in tape:current=native(current,float(u));result.append(current.copy())
        return np.asarray(result)
    def tail(state):
        states=[];raws=[];actions=[];current=state.copy()
        for _ in range(tail_steps):
            raw=raw_feedback(gain,current,n);u=float(np.float32(np.clip(raw,-1,1)))
            current=native(current,u);states.append(current.copy());raws.append(raw);actions.append(u)
        return np.asarray(states),np.asarray(raws),np.asarray(actions)
    try:
        known=forecast(initial,controls)
        assert known.tobytes()==expected.tobytes()
        prefix_state=initial if args.start_step==0 else known[args.start_step-1]
        source_arrival=controls[args.start_step:].copy();source_states=known[args.start_step:].copy()
        source_tail,source_raw,source_tail_actions=tail(source_states[-1])
        setup_calls=native.evaluations
        assert setup_calls==args.arrival_step+tail_steps
        tail_scale=max(ctx.mpf(1),ctx.sqrt(ctx.fsum(ctx.norm(w*ctx.matrix(represented_state(s,n).tolist()))**2 for s in source_tail[list(sample_offsets)])))
        raw_scale=max(1.,float(np.sqrt(np.mean(source_raw[list(sample_offsets)]**2))))
        payload.update(setup_native_transition_calls=setup_calls,source_full_arrival_byte_exact=True,
            initial_prefix_hold_source='Stored physical hanging-start tape, independently reproduced through arrival-step',
            frozen_tail_physical_scale=str(tail_scale),frozen_tail_raw_scale=raw_scale)
        target_mp=ctx.matrix(target.tolist())
        def target_error_at(state):
            return ctx.matrix(represented_state(state,n).tolist())-target_mp
        for label,factor in (('physical',w),('modal_factored',modal)):
            arm_before=native.evaluations;arm_actual=0;center=source_arrival.copy();states=source_states.copy()
            target_error=target_error_at(states[-1])
            endpoint_scale=max(ctx.mpf(1),ctx.norm(factor*target_error))
            scale_factor=factor/endpoint_scale
            def residual(predictions,feedback_states,raws):
                endpoint=scale_factor*target_error_at(predictions[-1])
                values=list(endpoint)
                for idx in sample_offsets:
                    physical=w*ctx.matrix(represented_state(feedback_states[idx],n).tolist())
                    values.extend(ctx.mpf('.1')*v/tail_scale for v in physical)
                    values.append(ctx.mpf('.1')*ctx.mpf(float(raws[idx]))/ctx.mpf(float(raw_scale))/2)
                return ctx.matrix(values)
            def score(predictions,feedback_states,raws,res):
                angle=np.abs(wrap_angle(np.cumsum(predictions[:,1:n+1],axis=1)))
                cart=np.abs(predictions[:,0]);excess=np.maximum(angle-.149,0)/.149
                violation=float(np.sum(excess**2)+np.sum((np.maximum(cart-3.,0)/3.)**2))
                feasible=bool(np.all(angle<.149) and np.all(cart<=3.))
                return (0 if feasible else 1,violation,float(ctx.norm(res)**2))
            feedback=source_tail.copy();raws=source_raw.copy();res=residual(states,feedback,raws)
            center_score=score(states,feedback,raws,res);rounds=[]
            initial_score=center_score;initial_physical=np.asarray((w*target_error).tolist(),float).ravel()
            status='iteration_limit'
            def affordable(calls):
                # Reserve final arrival proof, up to1500 actual steps and1500 whole-tape proof.
                return native.evaluations-arm_before+arm_actual+calls+(args.arrival_step-args.start_step)+3000<=args.arm_budget
            for iteration in range(args.iterations):
                before=native.evaluations
                if not affordable(4*args.knots*(len(center)+tail_steps)+args.contraction_powers*(len(center)+tail_steps)):
                    status='inclusive_native_budget';break
                jac=ctx.zeros(res.rows,args.knots)
                derivative_failed=None;probe_summaries=[]
                try:
                    for column in range(args.knots):
                        samples=[]
                        for multiple in (1,-1,2,-2):
                            trial=np.asarray(np.clip(center+multiple*args.epsilon*interpolation[:,column],-1,1),np.float32).astype(float)
                            predicted=forecast(prefix_state,trial);ts,tr,_=tail(predicted[-1])
                            samples.append(residual(predicted,ts,tr))
                            probe_summaries.append(dict(column=column,multiple=multiple,
                                maximum_angle=float(np.max(np.abs(wrap_angle(np.cumsum(predicted[:,1:n+1],axis=1))))),
                                endpoint_physical_difference_norm=str(ctx.norm(w*ctx.matrix((represented_state(predicted[-1],n)-represented_state(states[-1],n)).tolist())))))
                        for row in range(res.rows):
                            jac[row,column]=(8*(samples[0][row]-samples[1][row])-(samples[2][row]-samples[3][row]))/(12*ctx.mpf(float(args.epsilon)))
                except (SimulationError,ValueError) as error:
                    derivative_failed=f'{type(error).__name__}: {error}'
                derivative_calls=native.evaluations-before
                if derivative_failed:
                    rounds.append(dict(iteration=iteration,derivative_failed=derivative_failed,native_derivative_calls=derivative_calls));status='native_derivative_failed';break
                step,qr_error=regularized_qr_step(ctx,jac,res,args.regularization)
                step=scale_step_to_trust_region(step,args.trust)
                proposals=[];best=None;search_before=native.evaluations
                no_op_divisors=[]
                for power in range(args.contraction_powers):
                    divisor=2**power
                    trial=np.asarray(np.clip(center+interpolation@(step/divisor),-1,1),np.float32).astype(float)
                    if trial.tobytes()==center.tobytes():
                        no_op_divisors.append(divisor);continue
                    try:
                        predicted=forecast(prefix_state,trial);ts,tr,_=tail(predicted[-1]);rr=residual(predicted,ts,tr)
                        ss=score(predicted,ts,tr,rr)
                        model=res+jac*ctx.matrix((step/divisor).tolist())
                        row_error=ctx.norm(rr-model)/max(ctx.mpf(1),ctx.norm(model))
                        proposals.append(dict(divisor=divisor,score=list(ss),maximum_angle=float(np.max(np.abs(wrap_angle(np.cumsum(predicted[:,1:n+1],axis=1))))),
                            maximum_cart=float(np.max(np.abs(predicted[:,0]))),affine_residual_norm=str(ctx.norm(model)),
                            native_residual_norm=str(ctx.norm(rr)),relative_model_disagreement=str(row_error)))
                        changed=np.flatnonzero(trial!=center)
                        proposals[-1].update(changed_input_count=len(changed),
                            first_changed_absolute_step=int(args.start_step+changed[0]),
                            last_changed_absolute_step=int(args.start_step+changed[-1]),
                            maximum_delivered_action_change=float(np.max(np.abs(trial-center))))
                        if ss<center_score and (best is None or ss<best[0]):best=(ss,trial,predicted,ts,tr,rr,divisor)
                    except SimulationError as error:proposals.append(dict(divisor=divisor,error=str(error)))
                improved=best is not None
                matched_prefix=None
                if prior is not None and iteration==0:
                    old=next(r for r in prior['records'] if r['label']==label)
                    assert old['initial_score']==list(initial_score)
                    previous=old['rounds'][0]['proposals']
                    matched_prefix=all(all(a[k]==b[k] for k in a) for a,b in zip(previous,proposals[:len(previous)]))
                    assert len(proposals)>=len(previous) and matched_prefix
                if improved:center_score,center,states,feedback,raws,res,selected=best
                rounds.append(dict(iteration=iteration,improved=improved,score=list(center_score),
                    selected_divisor=selected if improved else None,qr_error=qr_error,
                    native_derivative_calls=derivative_calls,native_candidate_calls=native.evaluations-search_before,
                    proposals=proposals,maximum_knot_step=float(np.max(np.abs(step))),
                    no_op_divisors=no_op_divisors,derivative_probes=probe_summaries,
                    previous_initial_eight_contractions_exact=matched_prefix))
                print(json.dumps(dict(arm=label,iteration=iteration,improved=improved,score=list(center_score),calls=native.evaluations-arm_before)),flush=True)
                dump_json({**payload,'running_arm':label,'running_rounds':rounds,
                    'total_native_transition_calls':native.evaluations+sum(r['actual_hanging_start_episode_steps'] for r in records)},out/'result.progress.json')
                if not improved:status='no_improving_tested_contraction';break
            proof=forecast(prefix_state,center)
            assert proof.tobytes()==states.tobytes()
            delivered=np.r_[controls[:args.start_step],center]
            actual=NLinkCartPoleEnv(local_cfg,progress=1.,seed=base['seed']);actual.reset(seed=base['seed'])
            actual_states=[initial.copy()];actual_actions=[];streak=longest=0;maxcart=0.;termination=None
            try:
                for tick in range(actual.max_steps):
                    state=np.r_[actual.data.qpos,actual.data.qvel]
                    u=float(delivered[tick]) if tick<len(delivered) else float(np.float32(np.clip(raw_feedback(gain,state,n),-1,1)))
                    _,_,terminated,truncated,info=actual.step([u]);arm_actual+=1
                    x=np.r_[actual.data.qpos,actual.data.qvel];actual_states.append(x.copy());actual_actions.append(u)
                    if tick<args.start_step:assert x.tobytes()==known[tick].tobytes()
                    elif tick<len(delivered):assert x.tobytes()==states[tick-args.start_step].tobytes()
                    phi=np.max(np.abs(wrap_angle(np.cumsum(x[1:n+1]))))
                    streak=streak+1 if phi<.15 else 0;longest=max(longest,streak);maxcart=max(maxcart,abs(float(x[0])))
                    if terminated or truncated:termination=info['termination_reason'];break
            finally:actual.close()
            whole_before=native.evaluations
            for index,u in enumerate(actual_actions):assert native(actual_states[index],u).tobytes()==actual_states[index+1].tobytes()
            whole_proof=native.evaluations-whole_before
            assert whole_proof==arm_actual
            tape=out/'tapes'/f'{label}.npz';np.savez_compressed(tape,states=np.asarray(actual_states),actions=np.asarray(actual_actions))
            passed=arm_actual==1500 and longest*.02>=5 and termination=='time_limit' and not info['simulation_error'] and maxcart<=3
            physical_error=w*target_error_at(states[-1])
            row=dict(label=label,status=status,rounds=rounds,endpoint_scale=str(endpoint_scale),
                initial_score=list(initial_score),final_score=list(center_score),
                initial_physical_error_norm=float(np.linalg.norm(initial_physical)),final_physical_error_norm=str(ctx.norm(physical_error)),
                selected_controls=center.tolist(),selected_states=states.tolist(),
                endpoint_maximum_angle=float(np.max(np.abs(wrap_angle(np.cumsum(states[-1,1:n+1]))))),
                endpoint_absolute_rate_rms=float(np.sqrt(np.mean(np.cumsum(states[-1,n+2:])**2))),
                endpoint_raw_feedback_action=raw_feedback(gain,states[-1],n),
                selected_whole_arrival_byte_exact=True,actual_prefix_and_selected_arrival_byte_exact=True,
                independent_whole_actual_tape_byte_exact=True,
                actual_hanging_start_episode_steps=arm_actual,actual_hold_seconds=longest*.02,
                actual_maximum_cart=maxcart,actual_termination_reason=termination,full_nominal_gate_passed=passed,
                tape=file_metadata(tape),private_native_transition_calls=native.evaluations-arm_before,
                actual_tape_proof_calls=whole_proof,total_native_transition_calls=native.evaluations-arm_before+arm_actual,
                native_transition_ceiling=args.arm_budget)
            assert row['total_native_transition_calls']<=args.arm_budget
            records.append(row)
            payload.update(total_native_transition_calls=native.evaluations+sum(r['actual_hanging_start_episode_steps'] for r in records),
                actual_hanging_start_episode_steps=sum(r['actual_hanging_start_episode_steps'] for r in records))
            dump_json(payload,out/'result.progress.json')
            print(json.dumps(dict(arm=label,hold=row['actual_hold_seconds'],full_pass=passed,steps=arm_actual,calls=row['total_native_transition_calls'])),flush=True)
        assert np.r_[env.data.qpos,env.data.qvel].tobytes()==untouched.tobytes()
        assert payload['total_native_transition_calls']<=payload['native_transition_ceiling']
        assert payload['total_native_transition_calls']==setup_calls+sum(r['total_native_transition_calls'] for r in records)
        payload.update(live_forecast_environment_unchanged=True,wall_seconds=time.monotonic()-began)
        dump_json(payload,out/'result.json')
    finally:env.close()


if __name__=='__main__':main()
