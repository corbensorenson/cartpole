"""Native paired armature/cadence interaction test guided by the spectral map."""
import argparse,copy,json,time
from pathlib import Path
import mpmath
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,utc_timestamp,runtime_metadata
from gcartpole.lqr_design import high_precision_discrete_lqr
from gcartpole.modal_arrival import physical_factor
from gcartpole.spectral_geometry import upright_spectrum
from gcartpole.upright_mechanics import upright_rk4_matrices
from scripts.make_lqr_checkpoint import absolute_angle_cost
from scripts.map_parameter_capture_redesign import local_episode,WEIGHTS


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();out=Path(args.directory);out.mkdir(parents=True,exist_ok=False);(out/'tapes').mkdir();(out/'configs').mkdir()
    source=json.loads(Path(args.source).read_text());ctx=mpmath.mp.clone();ctx.dps=100;tau=ctx.sqrt(ctx.mpf(3)/ctx.mpf('9.81'))
    payload=dict(source=file_metadata(args.source),script=file_metadata(__file__),helper_code=file_metadata('scripts/map_parameter_capture_redesign.py'),
        spectral_code=file_metadata('src/gcartpole/spectral_geometry.py'),runtime=runtime_metadata(),generated_at=utc_timestamp(),
        counts=[14,15],armature_factors=[1.,.5],frame_skips=[4,1],amplitudes=[1e-13,1e-14],weights=WEIGHTS,
        control_cost=1000.,records=[],native_transition_ceiling=240000,total_native_transition_calls=0,
        actual_local_episode_steps=0,independent_tape_replay_transition_calls=0,actual_hanging_start_episode_steps=0,
        not_solution=True,canonical_release_evidence=False,reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Spectral-map-guided2x2 armature/cadence interaction,14and15,nohub original length/mass/damping/rail/force/timestep. Half scalar armature changes both cart and hinges; frame4/1 means50/200Hz. Shared MP100 plant-specific gain design,rounded gain/MP100 dot/native F32. Two frozen physical directions each at1e-13/1e-14,32local30s episodes plus byte proofs. Original50Hz1e-13prefixes must reproduce source tapes exactly. Inherited helper has a1500step gate; retain that flag separately and independently derive the cadence-aware physical full30s/5s/inrail gate from the tape. Not a hanging-start solve or canonical count promotion.')
    began=time.monotonic()
    for n in (14,15):
        prior=next(r for r in source['records'] if r['n_links']==n and (r['length_scale'],r['hub_diameter_m'])==(1.,0.))
        assert prior['config']==file_metadata(prior['config']['path']);base=load_config(prior['config']['path']);directions=np.asarray(prior['paired_directions'])
        for frame in (4,1):
            for factor in (1.,.5):
                cfg=copy.deepcopy(base);cfg['env']['joint_armature']*=factor;cfg['env']['frame_skip']=frame
                tag=f'n{n}_frame{frame}_arm{factor}';cp=out/'configs'/f'{tag}.json';dump_json(cfg,cp)
                env=NLinkCartPoleEnv(cfg,progress=1.,seed=0);env.reset(seed=0)
                try:
                    a,b,_=upright_rk4_matrices(env,decimal_digits=100)
                    gain,_,diag=high_precision_discrete_lqr(a.tolist(),b.tolist(),absolute_angle_cost(n,WEIGHTS),[[1000.]],decimal_digits=100,preserve_input_precision=True)
                    spectrum=upright_spectrum(a,b,physical_factor(ctx,n,tau),dt=env.dt,decimal_digits=100)
                finally:env.close()
                if frame==4 and factor==1.:assert gain.ravel().tobytes()==np.asarray(prior['gain']).tobytes()
                row=dict(n_links=n,armature_factor=factor,frame_skip=frame,control_hz=1/(.005*frame),
                    config=file_metadata(cp),gain=gain.ravel().tolist(),design_diagnostics=diag,spectrum=spectrum,episodes=[])
                payload['records'].append(row)
                for amplitude in payload['amplitudes']:
                    for i,v in enumerate(directions):
                        e=local_episode(cfg,gain.ravel(),v,amplitude,out/'tapes'/f'{tag}_a{amplitude}_v{i}.npz')
                        with np.load(e['tape']['path']) as tape:
                            states=tape['states'];actions=tape['actions'];maximum=streak=0
                            for upright in np.max(np.abs(wrap_angle(np.cumsum(states[1:,1:n+1],axis=1))),axis=1)<.15:
                                streak=streak+1 if upright else 0;maximum=max(maximum,streak)
                            passed=bool(e['steps']==round(30/(.005*frame)) and e['termination_reason']=='time_limit'
                                and maximum*.005*frame>=5 and np.max(np.abs(states[:,0]))<=3
                                and np.all(np.isfinite(states)) and np.all(np.isfinite(actions)))
                            if frame==4 and factor==1. and amplitude==1e-13:
                                before=next(e0 for e0 in prior['episodes'] if e0['amplitude']==amplitude and e0['direction_index']==i)
                                assert before['tape']==file_metadata(before['tape']['path'])
                                with np.load(before['tape']['path']) as old:
                                    assert states.tobytes()==old['states'].tobytes() and actions.tobytes()==old['actions'].tobytes()
                                e['original_baseline_states_actions_and_call_counts_byte_exact']=True
                        e.update(amplitude=amplitude,direction_index=i,legacy_1500_step_gate_flag=e['local_full_episode_gate_passed'],
                            local_full_episode_gate_passed=passed,sampled_physical_hold_seconds=maximum*.005*frame,
                            full_duration_required_steps=round(30/(.005*frame)))
                        row['episodes'].append(e)
                        for key in ('actual_local_episode_steps','independent_tape_replay_transition_calls','total_native_transition_calls'):payload[key]+=e[key]
                        assert payload['total_native_transition_calls']<=payload['native_transition_ceiling']
                        dump_json(payload,out/'result.progress.json')
                print(json.dumps(dict(n=n,armature=factor,hz=row['control_hz'],gain_norm=diag['gain_norm'],
                    gram_condition=spectrum['normalized_backward_gram_condition'],
                    passes=[e['local_full_episode_gate_passed'] for e in row['episodes']],
                    holds=[e['sampled_physical_hold_seconds'] for e in row['episodes']],calls=payload['total_native_transition_calls'])),flush=True)
    payload['wall_seconds']=time.monotonic()-began;dump_json(payload,out/'result.json')


if __name__=='__main__':main()
