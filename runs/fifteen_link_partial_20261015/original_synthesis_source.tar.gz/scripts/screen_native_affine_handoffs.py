"""Test prefix-preserving earlier handoffs on a native defect-corrected route."""
import argparse,json,copy
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from scripts.evaluate_fddp_two_expert import load_controller
from scripts.evaluate_fddp_parked_route import run_episode
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    p.add_argument('--handoff-seconds',type=float,nargs='+',default=[6.,7.,8.,9.,10.,11.,12.,13.])
    args=p.parse_args();d=json.loads(Path(args.source).read_text());out=Path(args.directory);out.mkdir(parents=True,exist_ok=False)
    assert d['status']=='finished' and d['config']==file_metadata(d['config']['path']) and d['reference']==file_metadata(d['reference']['path'])
    cfg=load_config(d['config']['path']);prior=json.loads(Path(d['source']['path']).read_text());n=cfg['env']['n_links'];assert n==14
    controller=load_controller(Path(d['source']['path']),n,load_config('benchmarks/p1_capture_envelope.yaml'))
    with np.load(d['reference']['path']) as r:
        gains=r['feedback_gains'].copy();states=r['states'].copy();controls=np.clip(r['controls']+r['feedforward_offsets'],-1.,1.)
    full=next(e for e in d['records'] if e['affine']);assert full['tape']==file_metadata(full['tape']['path'])
    with np.load(full['tape']['path']) as tape:prefix_states=tape['states'].copy();prefix_actions=tape['actions'].copy()
    if not args.handoff_seconds or len(set(args.handoff_seconds))!=len(args.handoff_seconds):
        raise ValueError('provide distinct handoff times')
    for seconds in args.handoff_seconds:
        steps=round(seconds/.02)
        if not np.isfinite(seconds) or seconds<=0 or abs(steps*.02-seconds)>1e-10 or steps>len(prefix_actions):
            raise ValueError('handoff must be on a positive control tick inside the saved actual prefix')
    ecfg=fixed_state_cfg(cfg,prior['selected_state'],30.);rows=[];calls=0
    for seconds in args.handoff_seconds:
        steps=round(seconds/.02);c=copy.deepcopy(controller);c.update(controls=controls[:steps],feedback_gains=gains[:steps],nominal_states=states[:steps+1])
        result=run_episode(ecfg,c,np.asarray(d['gain']),np.zeros(30),seed=0,park_seconds=0.,cart_target=0.,
            tracking_gain_scale=1.,phase_adaptive=False,phase_window=12,include_trace=True)
        actions=np.asarray([r['action'] for r in result['trajectory']],np.float32).astype(float)
        actual=np.vstack([prior['selected_state']['qpos']+prior['selected_state']['qvel'],[r['qpos']+r['qvel'] for r in result['trajectory']]])
        assert actual[:steps+1].tobytes()==prefix_states[:steps+1].tobytes() and actions[:steps].tobytes()==prefix_actions[:steps].tobytes()
        env=NLinkCartPoleEnv(ecfg,progress=1.,seed=0);env.reset(seed=0);native=MujocoTransition(env,np.eye(30),continuous_angles=True)
        try:
            for i,u in enumerate(actions):assert native(actual[i],float(u)).tobytes()==actual[i+1].tobytes()
        finally:env.close()
        assert native.evaluations==len(actions)
        path=out/f'handoff{seconds}.npz';np.savez_compressed(path,states=actual,actions=actions)
        passed=bool(result['success'] and len(actions)==1500 and result['termination_reason']=='time_limit'
            and result['max_upright_streak_seconds']>=5 and result['max_cart_excursion']<=3 and not result['final_info'].get('simulation_error'))
        row=dict(handoff_seconds=seconds,actual_hanging_start_episode_steps=len(actions),independent_tape_replay_transition_calls=len(actions),
            total_native_transition_calls=2*len(actions),tape=file_metadata(path),independent_whole_actual_tape_bytes_exact=True,
            prefix_actual_states_and_actions_byte_identical=True,full_nominal_component_gate_passed=passed,
            result={k:v for k,v in result.items() if not isinstance(v,(dict,list))})
        rows.append(row);calls+=2*len(actions);print(json.dumps(row),flush=True)
    assert calls<=24000
    payload=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),source=file_metadata(args.source),config=d['config'],
        records=rows,handoff_seconds=args.handoff_seconds,total_native_transition_calls=calls,native_transition_ceiling=24000,
        actual_hanging_start_episode_steps=sum(r['actual_hanging_start_episode_steps'] for r in rows),
        not_solution=True,canonical_release_evidence=False,reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Declared unchanged native affine route prefixes with the same plant-specific maintenance gain. All actual prefix states/actions equal prior full route byte-for-byte and all full actual tapes independently replay. Saved gains only; no design transitions. Exact unparked14altered-plant development;no15or release evidence.')
    dump_json(payload,out/'result.json')


if __name__=='__main__':main()
