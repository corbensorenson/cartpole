"""Test modal mixtures, directional width and coordinate conditioning."""
import argparse
import json
from pathlib import Path
import mpmath
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata,utc_timestamp
from gcartpole.ilqr import MujocoTransition
from scripts.audit_mode_aligned_capture import screen


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--aligned',required=True);parser.add_argument('--baseline',required=True)
    parser.add_argument('--directory',required=True)
    args=parser.parse_args();out=Path(args.directory)
    if out.exists():raise FileExistsError(out)
    out.mkdir(parents=True);(out/'tapes').mkdir()
    aligned=json.loads(Path(args.aligned).read_text());baseline=json.loads(Path(args.baseline).read_text())
    assert len(aligned['records'])==642 and all(r['result']['local_gate_pass'] for r in aligned['records'])
    assert aligned['baseline']==file_metadata(args.baseline)
    coefficients=np.random.default_rng(20261026).normal(size=(4,32))
    coefficients/=np.linalg.norm(coefficients,axis=1)[:,None]
    physical_directions=np.asarray(baseline['directions15'])
    cfg=load_config('configs/swingup15_uniform.yaml')
    env=NLinkCartPoleEnv(cfg,progress=1.,seed=0);env.reset(seed=0)
    predictor=MujocoTransition(env,np.eye(32),continuous_angles=True)
    ctx=mpmath.mp.clone();ctx.dps=100
    payload=dict(generated_at=utc_timestamp(),runtime=runtime_metadata(),parameters=vars(args),
        script=file_metadata(__file__),screen_code=file_metadata('scripts/audit_mode_aligned_capture.py'),
        aligned=file_metadata(args.aligned),baseline=file_metadata(args.baseline),
        coefficient_seed=20261026,coefficients=coefficients.tolist(),physical_directions=physical_directions.tolist(),
        designs=[],records=[],actual_local_episode_steps=0,independent_tape_replay_calls=0,
        total_native_transition_calls=0,native_transition_ceiling=384000,
        actual_hanging_start_episode_steps=0,reserved_seeds_used=False,noisy_development_seeds_used=False,
        canonical_release_evidence=False,not_solution=True,
        scope='Prospective4fixed modal coefficient directions and both signs at1e-4/1e-3/1e-2/1e-1. '
              'Paired width screens around origin and first mixture at1e-4, using original relative-angle/rate '
              'directions at1e-14/1e-12. Two frozen gains,128local30s episodes and independent tape proof. '
              'Basis conditioning is coordinate-dependent, not nonlinear controllability or a certified basin.')
    try:
        for design in aligned['designs']:
            label=design['gain_label'];gain=np.asarray(aligned['gains'][label])
            basis=ctx.matrix(np.column_stack([d['rounded_direction'] for d in design['directions']]).tolist())
            assert basis.rows==basis.cols==32
            weighted=ctx.zeros(32,32);tau=ctx.mpf(design['normalization']['time_scale_seconds'])
            for column in range(32):
                weighted[0,column]=basis[0,column]/3;weighted[16,column]=tau*basis[16,column]/3
                angle=rate=ctx.mpf(0)
                for i in range(15):
                    angle+=basis[i+1,column];rate+=basis[i+17,column]
                    weighted[i+1,column]=angle/ctx.mpf('.15')
                    weighted[i+17,column]=tau*rate/ctx.mpf('.15')
            singular=ctx.svd_r(weighted,compute_uv=False)
            inverse=ctx.inverse(basis)
            residual=ctx.norm(inverse*basis-ctx.eye(32))/ctx.norm(ctx.eye(32))
            assert residual<ctx.mpf('1e-70') and min(singular)>0
            rounded_singular=np.linalg.svd(np.asarray(weighted.tolist(),float),compute_uv=False)
            payload['designs'].append(dict(gain_label=label,normalization=design['normalization'],
                weighted_singular_values=[str(v) for v in singular],
                weighted_basis_condition=str(max(singular)/min(singular)),
                binary64_weighted_basis_condition=float(max(rounded_singular)/min(rounded_singular)),
                inverse_residual=str(residual),inverse_modal_factor=[[str(v) for v in row] for row in inverse.tolist()],
                factor_scope='MP100 inverse of promoted rounded right-mode directions; maps whole physical state to modal coefficients. '
                             'Experimental terminal-shaping candidate only; no certified capture metric.'))
            def mixture(amplitude,index,sign):
                state=basis*ctx.matrix(coefficients[index].tolist())*ctx.mpf(float(sign*amplitude))
                value=np.array(list(state),dtype=float);value[value==0]=0.
                return value
            cases=[]
            for amplitude in (1e-4,1e-3,1e-2,1e-1):
                for index in range(4):
                    for sign in (1,-1):
                        cases.append(dict(kind='modal_mixture',amplitude=amplitude,direction=index,sign=sign,
                                          initial=mixture(amplitude,index,sign)))
            for name,center in (('origin',np.zeros(32)),('first_mixture1em4',mixture(1e-4,0,1))):
                for amplitude in (1e-14,1e-12):
                    for index,direction in enumerate(physical_directions):
                        for sign in (1,-1):
                            initial=center.copy()
                            initial[1:16]+=sign*amplitude*direction[:15]
                            initial[17:]+=sign*amplitude*direction[15:]
                            initial[initial==0]=0.
                            cases.append(dict(kind='off_mode_width',center=name,amplitude=amplitude,
                                              direction=index,sign=sign,initial=initial))
            for case in cases:
                initial=case.pop('initial');tape=out/'tapes'/f'{label}_{len(payload["records"]):04d}.npz'
                result=screen(cfg,initial,gain,predictor,tape)
                payload['records'].append(dict(gain_label=label,**case,result=result))
                for key in ('actual_local_episode_steps','independent_tape_replay_calls','total_native_transition_calls'):
                    payload[key]+=result[key]
                assert payload['total_native_transition_calls']<=payload['native_transition_ceiling']
                dump_json(payload,out/'result.progress.json')
                print(json.dumps(dict(gain=label,**case,pass30=result['local_gate_pass'],hold=result['physical_hold_seconds'],
                                     completed=len(payload['records']),calls=payload['total_native_transition_calls'])),flush=True)
        assert len(payload['records'])==128
        dump_json(payload,out/'result.json')
    finally:env.close()


if __name__=='__main__':main()
