#!/usr/bin/env python
"""Execute a checked native plan after the same cold prefix, then baseline control."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.search_ilqr_capture import execute_controller
from scripts.search_fddp_capture import warm_start_diagnostics
from scripts.solve_frontier_capture_increment import validate_development_seeds,physical_replay_passed


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('plan-source','capture-cache','directory'):p.add_argument('--'+key,required=True)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    plan_source=json.loads(Path(args.plan_source).read_text())
    if not plan_source['feasible_sequence_found'] or not plan_source['live_state_unchanged']:raise ValueError('native verified plan required')
    cursor=plan_source;ancestry=[]
    while not all(k in cursor for k in ('config','teacher','parameters')):
        metadata=cursor['source']
        if len(ancestry)>=8 or file_metadata(metadata['path'])!=metadata:raise ValueError('plan ancestry changed')
        ancestry.append(metadata);cursor=json.loads(Path(metadata['path']).read_text())
    for key in ('source','config','teacher'):
        if file_metadata(cursor[key]['path'])!=cursor[key]:raise ValueError('bound physical inputs changed')
    base=json.loads(Path(cursor['source']['path']).read_text());cache=json.loads(Path(args.capture_cache).read_text())
    if cache['source']!=cursor['source'] or cache['config']!=cursor['config']:raise ValueError('source aligned maintenance cache required')
    cfg=load_config(cursor['config']['path']);n=cfg['env']['n_links'];nx=2*(n+1);dt=cfg['env']['timestep']*cfg['env']['frame_skip']
    c=base['controller'];start=cursor['parameters']['start_step'];steps=round(30/dt)
    validate_development_seeds(n,base['seed'])
    if not c['continuous_angles'] or c['phase_adaptive'] or not np.array_equal(c['coordinate_transform'],np.eye(nx)):raise ValueError('physical source with frozen phase required')
    plan=np.asarray(plan_source['selected_sequence'],np.float32).astype(float);predictions=np.asarray(plan_source['selected_states'])
    if predictions.shape!=(len(plan),nx) or start+len(plan)>steps:raise ValueError('aligned plan must fit episode')
    controls=np.asarray(c['controls']);nodes=np.asarray(base['search']['nominal_coordinate_states']);gains=np.asarray(c['feedback_gains'])
    if len(controls)<steps:
        controls=np.r_[controls,np.zeros(steps-len(controls))];nodes=np.vstack([nodes,np.zeros((steps+1-len(nodes),nx))]);gains=np.vstack([gains,np.zeros((steps-len(gains),nx))])
    else:controls=controls[:steps];nodes=nodes[:steps+1];gains=gains[:steps]
    cfg=fixed_state_cfg(cfg,base['selected_state'],30.);factor=np.asarray(base['lyapunov']['factor']);delivered=0;began=time.monotonic()
    def selector(step,state,baseline):
        nonlocal delivered
        if start<=step<start+len(plan):
            offset=step-start
            expected=np.asarray(base['result']['trajectory'][start-1]['qpos']+base['result']['trajectory'][start-1]['qvel']) if offset==0 else predictions[offset-1]
            if state.tobytes()!=expected.tobytes():raise ValueError('actual state differs from checked plan;never overwrite actual state')
            delivered+=1
            return float(plan[offset]),dict(verified_native_plan_offset=offset,actual_preinput_state_byte_identical=True)
        return baseline,None
    result=execute_controller(cfg,progress=1.,seed=base['seed'],controls=controls,nominal_states=nodes,feedback_gains=gains,
        gain=np.asarray(cache['gain']),lqr_scale=c['lqr_scale'],transform=np.eye(nx),lyapunov=factor.T@factor,lyapunov_factor=factor,
        handoff_lyapunov=c['handoff_lyapunov'],handoff_cart_abs=c['handoff_cart_abs'],handoff_angle_abs=c['handoff_angle_abs'],
        handoff_cart_velocity_abs=c['handoff_cart_velocity_abs'],handoff_hinge_velocity_rms=c['handoff_hinge_velocity_rms'],
        defer_handoff_until_horizon=True,continuous_angles=True,tracking_mode='verified_native_plan_then_source_baseline',tracking_action_selector=selector)
    rows=result['trajectory'];prior=base['result']['trajectory']
    if delivered!=len(plan) or len(rows)<start+len(plan):raise ValueError('verified plan was not completely executed')
    if any(np.asarray(a['qpos']+a['qvel']).tobytes()!=np.asarray(b['qpos']+b['qvel']).tobytes()
        or np.float32(a['action']).tobytes()!=np.float32(b['action']).tobytes() for a,b in zip(rows[:start],prior[:start])):raise ValueError('actual prefix changed')
    if np.asarray([r['qpos']+r['qvel'] for r in rows[start:start+len(plan)]]).tobytes()!=predictions.tobytes():raise ValueError('actual plan states differ from native forecast')
    initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);states=np.vstack([initial,[r['qpos']+r['qvel'] for r in rows]])
    actions=np.asarray([r['action'] for r in rows],np.float32).astype(float)
    env=NLinkCartPoleEnv(cfg,progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    try:
        native=MujocoTransition(env,np.eye(nx),continuous_angles=True);physical=warm_start_diagnostics(native,initial,actions,states)
        if physical['maximum_dynamics_defect']!=0. or not physical['is_exactly_feasible'] or native.evaluations!=len(rows):raise ValueError('actual complete tape fails independent exact replay')
    finally:env.close()
    dump_json(dict(not_solution=True,canonical_release_evidence=False,parameters=vars(args),runtime=runtime_metadata(),
        source=cursor['source'],config=cursor['config'],plan_source=file_metadata(args.plan_source),capture_cache=file_metadata(args.capture_cache),
        input_ancestry=ancestry,result=result,full_development_episode_passed=physical_replay_passed(result,cfg),
        inherited_prefix_states_and_actions_byte_identical=True,actual_plan_states_byte_identical_to_forecast=True,
        delivered_verified_plan_actions=delivered,physical_tape_diagnostics=physical,actual_episode_steps=len(rows),
        actual_tape_validation_transition_calls=native.evaluations,optimizer_transition_calls=0,reserved_seeds_used=False,noisy_development_seeds_used=False,
        wall_seconds=time.monotonic()-began,
        scope='Uninterrupted exact hanging-start episode. Original source prefix,then bounded delivered F32 checked plan,then source baseline;every planned preinput and postinput actual state verifies byte for byte. Entire actual tape independently replays. Nominal pass alone would still require original noisy/frozen/reserved/video/publication gates.'),out/'result.json')
    print(json.dumps(dict(hold=result['max_upright_streak_seconds'],length=result['length'],full_pass=physical_replay_passed(result,cfg))),flush=True)


if __name__=='__main__':main()
