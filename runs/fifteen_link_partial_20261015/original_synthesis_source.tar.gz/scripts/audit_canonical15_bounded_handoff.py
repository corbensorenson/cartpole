import argparse,json
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.angles import wrap_angle
from scripts.search_capture_sequence import fixed_state_cfg

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(a.root);out=Path(a.out);out.mkdir(exist_ok=False);r=json.loads((root/'execution/diagnostic/result.json').read_text());m=json.loads((root/'manifest.json').read_text());s=json.loads(Path(m['source']['path']).read_text());base=json.loads(Path(s['source']['path']).read_text());env=NLinkCartPoleEnv(fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.),progress=1.,seed=20265100);env.reset(seed=20265100);native=MujocoTransition(env,np.eye(32),continuous_angles=True)
 try:
  for case,meta in zip(m['cases'],r['tapes']):
   assert meta==file_metadata(meta['path']);z=np.load(meta['path']);original=np.load(case['tape']['path'])['states'][case['step']];assert z['initial_state'].tobytes()==original.tobytes();rows=[q for q in r['records'] if q['label']==case['label']]
   for i,u in enumerate(z['actions']):
    assert native(original,float(u)).tobytes()==z['states'][i].tobytes();x=z['states'][i];angle=float(max(abs(wrap_angle(np.cumsum(x[1:16])))));q=rows[i];assert q['maximum_angle']==angle and q['upright']==(angle<.15) and q['action']==u
  assert native.evaluations==205;dump_json(dict(generated_at=utc_timestamp(),status='finished',passed=True,source_result=file_metadata(root/'execution/diagnostic/result.json'),script=file_metadata(__file__),total_native_transition_calls=205,actual_hanging_start_episode_steps=0,summaries=r['summaries'],scope='205finitegrid nextstates/actions/angles independently byteexact; no continuous-input impossibilitycertificate.'),out/'result.json')
 finally:env.close()
if __name__=='__main__':main()
