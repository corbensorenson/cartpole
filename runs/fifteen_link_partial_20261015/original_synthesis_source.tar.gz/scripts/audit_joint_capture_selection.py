"""Read-only audit of completed joint capture pilots and their selection rules."""
import json
from pathlib import Path
from gcartpole.evidence import file_metadata, utc_timestamp


def main():
    root = Path('runs/frontier_campaign_20261001')
    records = []
    sources = []
    for name in ('n15_joint_projected_capture_pilot', 'n15_joint_force_aware_capture_pilot'):
        path = root / name / 'diagnostic/result.json'
        data = json.loads(path.read_text())
        sources.append(file_metadata(path))
        for row in data['records']:
            result = row['result']
            plans = result['plans']
            first_bad = next((p for p in plans if not p['diagnostics']['selected_preview_feasible']), None)
            early = plans[:10]
            rounds = [r for p in early for r in p['diagnostics']['rounds']]
            failure = None
            if first_bad is not None:
                step = first_bad['start_step']
                failure = dict(start_step=step, seconds=step*.02,
                    measured_state=result['states'][step],
                    maximum_violation=first_bad['diagnostics']['selected_maximum_violation'],
                    maximum_model_feedback_request=first_bad['diagnostics'].get('selected_maximum_model_feedback_request'))
            records.append(dict(pilot=name, label=row['label'], gain_label=row['gain_label'],
                steps=result['steps'], physical_hold_seconds=result['physical_hold_seconds'],
                local_gate_pass=result['local_gate_pass'],
                preview_feasible_plans=sum(p['diagnostics']['selected_preview_feasible'] for p in plans),
                total_plans=len(plans), first_preview_failure=failure,
                first_ten_plans=len(early),
                first_ten_actions_differ_from_baseline=sum(p['actions'] != p['diagnostics']['baseline_actions'] for p in early),
                first_ten_rounds=len(rounds),
                first_ten_improved_rounds=sum(r.get('improved', False) for r in rounds),
                first_ten_rank_failures=sum(r['status'] == 'projected_jacobian_rank_failure' for r in rounds),
                every_committed_forecast_matches_live_bytes=result['every_committed_forecast_matches_live_bytes'],
                independent_actual_tape_replay_bytes_exact=result['independent_actual_tape_replay_bytes_exact']))
    output = dict(generated_at=utc_timestamp(), script=file_metadata(__file__), sources=sources,
        native_transition_calls=0, records=records,
        scope='Read-only saved-plan audit. An improved lexicographic score is not sustained capture. '
              'Force-aware violations report infeasibility rather than guaranteeing a feasible plan. '
              'The current Newton subproblem differentiates terminal projected residuals; intermediate '
              'and terminal force violations rank native candidates but are not explicit subproblem constraints. '
              'This limits the interpretation of the negative pilots; it does not prove bounded nonlinear '
              'capture impossible. No new local or hanging-start physics, development or reserved seeds.')
    path = root / 'n15_joint_force_aware_capture_pilot/diagnostic/selection_audit.json'
    path.write_text(json.dumps(output, indent=2, sort_keys=True)+'\n')
    print(json.dumps(dict(path=str(path), records=len(records), native_transition_calls=0,
                         early_rank_failures=sum(r['first_ten_rank_failures'] for r in records))))


if __name__ == '__main__':
    main()
