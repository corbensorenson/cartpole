"""Summarize completed constraint pilots without executing additional dynamics."""
import argparse
from collections import Counter
import json
from pathlib import Path
from gcartpole.evidence import file_metadata, utc_timestamp


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--result', required=True)
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    data = json.loads(Path(args.result).read_text())
    records = []
    for row in data['records']:
        result = row['result']
        plans = result['plans']
        rounds = [r for p in plans for r in p['diagnostics']['rounds']]
        subproblems = [r['constraint_subproblem'] for r in rounds if r.get('constraint_subproblem')]
        first_bad = next((p for p in plans if not p['diagnostics']['selected_preview_feasible']), None)
        agreements=[r['best_trial_agreement'] for r in rounds if r.get('best_trial_agreement')]
        records.append(dict(label=row['label'], gain_label=row['gain_label'], horizon=row['horizon'],
            projection_delays=row['projection_delays'], controller_options=row['controller_options'],
            local_gate_pass=result['local_gate_pass'], steps=result['steps'],
            physical_hold_seconds=result['physical_hold_seconds'],
            first_angle_failure_seconds=result['first_angle_failure_seconds'],
            preview_feasible_plans=sum(p['diagnostics']['selected_preview_feasible'] for p in plans),
            total_plans=len(plans), improved_rounds=sum(r.get('improved', False) for r in rounds),
            total_rounds=len(rounds), constraint_subproblem_statuses=dict(Counter(r['status'] for r in subproblems)),
            trust_actions=dict(Counter(r.get('trust_action','unrecorded') for r in rounds)),
            minimum_recorded_trust_radius=min((r['trust_after'] for r in rounds if 'trust_after' in r),default=None),
            poor_native_agreements=sum(a['poor'] for a in agreements),
            good_native_agreements=sum(a['good'] for a in agreements),
            warm_candidate_plans=sum(p['diagnostics'].get('warm_candidate_used',False) for p in plans),
            warm_candidate_feasible_plans=sum(p['diagnostics'].get('warm_candidate_preview_feasible') is True for p in plans),
            warm_candidate_reasons=dict(Counter(p['diagnostics'].get('warm_candidate_reason','unrecorded') for p in plans)),
            maximum_original_mp_epigraph_error=max((float(r.get('original_mp_epigraph_error', 0)) for r in subproblems), default=0.),
            first_infeasible_preview_seconds=None if first_bad is None else first_bad['start_step']*.02,
            first_infeasible_constraint_peak=None if first_bad is None else first_bad['diagnostics']['selected_constraint_peak'],
            previous_baseline_byte_exact=result.get('previous_force_scaled_baseline_actions_states_and_call_counts_byte_exact'),
            previous_reserve_byte_exact=result.get('previous_minimax_reserve_actions_states_and_call_counts_byte_exact'),
            native_transition_calls=result['total_native_transition_calls'],
            planning_transition_calls=result['planning_transition_calls'],
            every_committed_forecast_matches_live_bytes=result['every_committed_forecast_matches_live_bytes'],
            independent_actual_tape_replay_bytes_exact=result['independent_actual_tape_replay_bytes_exact']))
    output = dict(generated_at=utc_timestamp(), script=file_metadata(__file__), source=file_metadata(args.result),
        native_transition_calls=0, records=records,
        scope='Read-only completed local-pilot counters and saved subproblem/preview statuses. '
              'Accepted derivative-model proposals are independently checked candidates, not nonlinear '
              'certificates or actual future-policy force demands. No new canonical or local dynamics.')
    Path(args.out).write_text(json.dumps(output, indent=2, sort_keys=True)+'\n')
    print(json.dumps(dict(records=len(records), path=args.out, native_transition_calls=0)))


if __name__ == '__main__':
    main()
