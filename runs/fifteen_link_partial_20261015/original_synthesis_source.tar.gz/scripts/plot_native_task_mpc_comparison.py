#!/usr/bin/env python
"""Plot native MPC actual traces and explicitly separate their forecasts."""
import argparse, json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', required=True, nargs='+')
    p.add_argument('--directory', required=True)
    args = p.parse_args(); out = Path(args.directory)
    if (out/'result.json').exists(): raise FileExistsError(out)
    plt.rcParams.update({'font.size':10, 'axes.spines.top':False,
        'axes.spines.right':False, 'svg.fonttype':'none'})
    fig, axes = plt.subplots(3, 1, figsize=(8,7.4), sharex=True, layout='constrained')
    sources = []
    for path, color in zip(args.source, ('#243a50','#b04752','#43816a')):
        data = json.loads(Path(path).read_text()); policy = data['executed_policy']
        if (not data['inherited_prefix_states_and_actions_bit_identical']
                or not data['physical_tape_diagnostics']['is_exactly_feasible']):
            raise ValueError('Verified native actual traces required')
        rows = data['result']['trajectory']; sources.append(file_metadata(path))
        commit = policy.get('plan_commit_steps',1)
        label = 'Replan every tick' if commit == 1 else f'Commit {commit} planned inputs'
        time = np.asarray([r['time_seconds'] for r in rows])
        angles = np.asarray([r['max_abs_angle'] for r in rows])
        rates = np.asarray([np.max(np.abs(np.cumsum(r['qvel'][1:]))) for r in rows])
        axes[0].plot(time, angles, color=color, lw=1.6, label=label)
        axes[1].plot(time, rates, color=color, lw=1.6)
        forecasts = [r for r in rows if 'maximum_predicted_absolute_angle' in r.get('tracking_preview',{})]
        starts = np.asarray([r['time_seconds']-.02 for r in forecasts])
        for ax, key in zip(axes[:2], ('maximum_predicted_absolute_angle','maximum_predicted_absolute_rate')):
            ax.plot(starts,[r['tracking_preview'][key] for r in forecasts],color=color,ls='none',marker='.',ms=4 if commit==1 else 7)
        axes[2].plot(starts,[r['tracking_preview']['minimum_observed_physical_task_cost'] for r in forecasts],color=color,lw=1.5)
    axes[0].axhline(.15,color='#727b84',ls='--',lw=1,label='Canonical angle threshold')
    axes[0].plot([],[],color='#727b84',ls='none',marker='.',label='Native H16 forecast maximum')
    axes[0].set(ylabel='Worst link angle (rad)',ylim=(0,.6))
    axes[0].legend(loc='upper left',fontsize=9)
    axes[1].set(ylabel='Worst link angular speed (rad/s)',ylim=(0,9))
    axes[2].set(ylabel='Native forecast task cost',yscale='log',xlabel='Simulation time (s)',xlim=(7.4,8.3))
    for ax in axes: ax.grid(axis='y',alpha=.16)
    fig.suptitle('A straight-looking chain can still lose its planned continuation',fontsize=13)
    fig.supxlabel('Solid: executed native state. Markers: worst H16 forecast, plotted at its planning time.\n15-link exact-start research; neither policy completes the canonical episode.',fontsize=9)
    out.mkdir(parents=True,exist_ok=True); outputs=[]
    for suffix in ('png','pdf','svg'):
        q=out/f'comparison.{suffix}';fig.savefig(q,dpi=180);outputs.append(file_metadata(q))
    plt.close(fig)
    dump_json(dict(not_solution=True,benchmark_evidence=False,sources=sources,outputs=outputs,
        native_transition_calls=0,scope='Verified actual traces and their explicitly labeled native forecasts. No new simulation, noisy validation or success claim.'),out/'result.json')

if __name__ == '__main__': main()
