"""Window sensitivity on canonical whole-episode force; scientific PNG/PDF."""
import argparse,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.config import dump_json

def main():
 p=argparse.ArgumentParser();p.add_argument('--directory',required=True);a=p.parse_args();root=Path(a.directory);audit=json.loads((root/'verified.json').read_text());assert audit['passed'];r=json.loads((root/'diagnostic/result.json').read_text());out=root/'figures';out.mkdir(exist_ok=True)
 plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42});fig,axes=plt.subplots(2,4,figsize=(12.5,6.4),sharex=True,sharey=True);refs=[]
 for n,ax in zip(range(7,15),axes.flat):
  tag=f'canonical{n}';t=next(t for t in r['traces'] if t['tag']==tag);ref=t['spectra'];refs.append(ref);arrays=np.load(ref['path'])
  for seconds,color in zip((2,4,8),('#205493','#bd6536','#287b61')):
   f=arrays[f'whole_w{seconds}_frequency_hz'];P=arrays[f'whole_w{seconds}_psd'][:,0];density=P/(np.sum(P)*(1/seconds));ax.plot(f,density,label=f'{seconds}s window',color=color,lw=1.3)
  ax.set(title=f'{n} links',xlim=(0,5),ylim=(1e-4,10),yscale='log');ax.grid(alpha=.15);ax.set_xticks(range(6))
 handles,labels=axes.flat[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,.925),ncol=3,frameon=False);fig.suptitle('Whole-episode force peaks depend partly on analysis window',fontsize=15,y=.99);fig.supxlabel('Frequency (Hz)',y=.085);fig.supylabel('Normalized force spectral density (Hz$^{-1}$)',x=.012)
 fig.text(.5,.014,'Same saved 50Hz traces; Hann windows, 50% overlap, constant detrending, no zero padding. Each density normalized by its spectral integral.\nSix peaks stay at 0.5Hz; seven shifts to 0.625Hz; ten shifts from 4Hz to 0.5Hz. Descriptive spectra; no fundamental or causal-resonance claim.',ha='center',fontsize=8.8);fig.tight_layout(rect=(.02,.10,1,.86))
 paths=[out/'canonical_force_window_sensitivity.png',out/'canonical_force_window_sensitivity.pdf']
 for path in paths:fig.savefig(path,dpi=180)
 plt.close(fig);dump_json(dict(generated_at=utc_timestamp(),script=file_metadata(__file__),verification=file_metadata(root/'verified.json'),sources=refs,artifacts=[file_metadata(p) for p in paths],native_transition_calls=0,scope='Normalized whole-episode force Welch density versus window; canonical7--14 stored traces, no causal inference.'),out/'figures.json');print(paths[0])
if __name__=='__main__':main()
