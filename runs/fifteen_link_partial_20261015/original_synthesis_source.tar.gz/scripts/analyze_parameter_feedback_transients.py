"""Compare stable model poles, transient amplification and existing native tapes."""
import argparse,json,time
from pathlib import Path
import mpmath
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,utc_timestamp,runtime_metadata
from gcartpole.modal_arrival import physical_factor
from gcartpole.upright_mechanics import upright_rk4_matrices


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();out=Path(args.directory);out.mkdir(parents=True,exist_ok=False)
    old=json.loads(Path(args.source).read_text());assert len(old['records'])==24
    # Match the original precision-input model assembly, not just its filename.
    olddir=Path(args.source).parents[1]
    assert file_metadata(olddir/'snapshot/src/gcartpole/upright_mechanics.py')['sha256']==file_metadata('src/gcartpole/upright_mechanics.py')['sha256']
    ctx=mpmath.mp.clone();ctx.dps=100;tau=ctx.sqrt(ctx.mpf(3)/ctx.mpf('9.81'));began=time.monotonic()
    result=dict(source=file_metadata(args.source),script=file_metadata(__file__),runtime=runtime_metadata(),generated_at=utc_timestamp(),
        records=[],ticks=[1,5,25,100,400],native_transition_calls=0,actual_episode_steps=0,
        not_solution=True,canonical_release_evidence=False,reserved_seeds_used=False,noisy_development_seeds_used=False,
        state_scaling_time_seconds=str(tau),maximum_decomposition_ticks=25,decomposition_angle_limit=.05,
        scope='Read-only MP100 unbounded local linear closed-loop transients plus decomposition of24plant144existing native tapes. Stable model poles do not bound transient gain or native nonlinear response. Largest singular value computed in binary64 ONLY after MP100 propagation; Frobenius bounds retained. State scaling fixed across all plants. Model-remainder forcing includes nonlinear physics and numerical arithmetic; action forcing includes F32/clipping/wrapped feedback. The algebraic decomposition is not a causal separation of those mechanisms or a hanging-start solve.')
    for source in old['records']:
        assert source['config']==file_metadata(source['config']['path']);cfg=load_config(source['config']['path']);n=cfg['env']['n_links']
        env=NLinkCartPoleEnv(cfg,progress=1.,seed=0);env.reset(seed=0)
        try:
            a,b,_=upright_rk4_matrices(env,decimal_digits=100)
            assert __import__('hashlib').sha256(env.xml.encode()).hexdigest()==source['mechanics']['xml_sha256']
        finally:env.close()
        a=ctx.matrix(a.tolist());b=ctx.matrix(b.tolist());k=ctx.matrix([source['gain']]);closed=a-b*k
        w=physical_factor(ctx,n,tau);wi=ctx.inverse(w)
        row=dict(n_links=n,length_scale=source['length_scale'],hub_diameter_m=source['hub_diameter_m'],config=source['config'],
            gain_norm=source['design_diagnostics']['gain_norm'],
            rounded_gain_model_spectral_radius=source['design_diagnostics']['rounded_gain_high_precision_spectral_radius'],
            transient=[],episodes=[])
        assert ctx.mpf(row['rounded_gain_model_spectral_radius'])<1
        for ticks in result['ticks']:
            mapping=w*(closed**ticks)*wi;frobenius=ctx.norm(mapping)
            sigma=float(np.linalg.svd(np.asarray(mapping.tolist(),float),compute_uv=False)[0])
            assert float(frobenius/ctx.sqrt(mapping.rows))<=sigma*(1+1e-12)<=float(frobenius)*(1+2e-12)
            row['transient'].append(dict(ticks=ticks,seconds=ticks*.02,
                maximum_state_amplification_largest_singular_value=sigma,
                frobenius_upper_bound=str(frobenius),frobenius_lower_bound=str(frobenius/ctx.sqrt(mapping.rows))))
        for e in source['episodes']:
            assert e['tape']==file_metadata(e['tape']['path'])
            with np.load(e['tape']['path']) as tape:states=tape['states'].copy();actions=tape['actions'].copy()
            linear=ctx.matrix(states[0].tolist());action_error=ctx.zeros(2*(n+1),1);model_error=action_error.copy()
            history=[]
            for i in range(min(25,len(actions))):
                x=ctx.matrix(states[i].tolist());following=ctx.matrix(states[i+1].tolist())
                # Stop while the current state remains within the stated local angle window.
                angles=np.cumsum(states[i,1:n+1])
                if np.max(np.abs(angles))>.05:break
                u=ctx.mpf(float(actions[i]));action_delta=u+(k*x)[0]
                remainder=following-a*x-b*u
                linear=closed*linear;action_error=closed*action_error+b*action_delta;model_error=closed*model_error+remainder
                identity_error=ctx.norm(w*(following-linear-action_error-model_error))
                assert identity_error<=ctx.mpf('1e-75')*max(ctx.norm(w*following),ctx.mpf(1))
                history.append(dict(tick=i+1,native_state_norm=str(ctx.norm(w*following)),
                    ideal_unbounded_model_state_norm=str(ctx.norm(w*linear)),
                    propagated_action_forcing_norm=str(ctx.norm(w*action_error)),
                    propagated_model_remainder_norm=str(ctx.norm(w*model_error)),
                    one_step_model_remainder_norm=str(ctx.norm(w*remainder)),
                    raw_feedback_from_one_step_model_remainder=str(abs((k*remainder)[0])),
                    action_minus_unwrapped_linear_feedback=str(action_delta),
                    decomposition_identity_error=str(identity_error)))
            row['episodes'].append(dict(amplitude=e['amplitude'],direction_index=e['direction_index'],tape=e['tape'],
                local_gate_passed=e['local_full_episode_gate_passed'],hold_seconds=e['hold_seconds'],
                native_steps=e['steps'],history=history,independent_native_tape_replay_previously_passed=e['independent_tape_replay_bytes_exact']))
        result['records'].append(row);dump_json(result,out/'result.progress.json')
        print(json.dumps(dict(n=n,length_scale=row['length_scale'],diameter=row['hub_diameter_m'],
            spectral_radius=row['rounded_gain_model_spectral_radius'],
            maximum_sampled_amplification=max(t['maximum_state_amplification_largest_singular_value'] for t in row['transient']),
            records=len(result['records']))),flush=True)
    result['wall_seconds']=time.monotonic()-began;dump_json(result,out/'result.json')


if __name__=='__main__':main()
