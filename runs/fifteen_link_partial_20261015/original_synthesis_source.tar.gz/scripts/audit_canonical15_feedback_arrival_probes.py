"""Independent native proof and action/locality audit of R29 private tapes."""
import argparse
from pathlib import Path
import mujoco,numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import dump_json,load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.ilqr import MujocoTransition
from scripts.audit_armature_route_increment import checked,journal,read
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix
from scripts.search_capture_sequence import fixed_state_cfg

def main():
 p=argparse.ArgumentParser();p.add_argument('--directory',required=True);p.add_argument('--out',required=True);args=p.parse_args()
 root=Path(args.directory);out=Path(args.out);out.mkdir(exist_ok=False)
 m=read(root/'manifest.json');r=read(root/'execution/diagnostic/result.json');j=journal(root/'execution');assert r['status']=='finished'
 for key in ('source','controller_source','config','previous_open_loop'):checked(m[key])
 saved=read(m['source']['path']);base=read(m['controller_source']['path']);old=read(m['previous_open_loop']['path'])
 assert r['manifest']==file_metadata(root/'manifest.json') and len(r['records'])==960
 start,end,knots=m['start_step'],m['arrival_step'],m['knots'];basis=interpolation_matrix(knots,end-start)
 K=np.asarray(base['controller']['feedback_gains']);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
 U=np.asarray([q['action'] for q in saved['result']['trajectory'][:end]],np.float32).astype(float)
 X=np.vstack([initial,[q['qpos']+q['qvel'] for q in saved['result']['trajectory'][:end]]])
 cfg=load_config(m['config']['path']);cfg=fixed_state_cfg(cfg,base['selected_state'],30.)
 count=[0];original=mujoco.mj_step;env=None;ceiling=int(r['total_native_transition_calls']);summaries=[]
 def counted(model,data,*a,**kw):
  n=int(kw.get('nstep',a[0] if a else 1))
  if count[0]+n>4*ceiling:raise RuntimeError('independent audit ceiling')
  count[0]+=n;return original(model,data,*a,**kw)
 payload=dict(generated_at=utc_timestamp(),status='running',script=file_metadata(__file__),source_result=file_metadata(root/'execution/diagnostic/result.json'),
  source_execution=j,manifest=file_metadata(root/'manifest.json'),native_transition_ceiling=ceiling,actual_hanging_start_episode_steps=0,not_solution=True,canonical_release_evidence=False)
 mujoco.mj_step=counted
 try:
  env=NLinkCartPoleEnv(cfg,progress=1.,seed=base['seed']);env.reset(seed=base['seed']);native=MujocoTransition(env,np.eye(32),continuous_angles=True)
  for i,u in enumerate(U):assert native(X[i],float(u)).tobytes()==X[i+1].tobytes()
  checked(r['baseline'])
  with np.load(r['baseline']['path']) as a:
   assert a['states'].tobytes()==X[start:end+1].tobytes() and a['actions'].tobytes()==U[start:end].tobytes()
   for i,u in enumerate(a['actions']):assert native(a['states'][i],float(u)).tobytes()==a['states'][i+1].tobytes()
  prior={(q['amplitude'],q['column'],q['sign']):q for q in old['records']};seen=set();nonzero=0
  for q in r['records']:
   key=(q['feedback_scale'],q['amplitude'],q['column'],q['sign']);assert key not in seen;seen.add(key)
   scale,amp,column,sign=key;bias=sign*amp*basis[:,column]
   shifted=np.clip(U[start:end]+bias,-1,1).astype(np.float32).astype(float);changed=np.flatnonzero(shifted!=U[start:end])
   assert q['changed_input_count']==len(changed) and q['no_op_after_f32']==(not len(changed))
   if not len(changed):assert q['native_transition_calls']==0
   else:
    checked(q['tape']);nonzero+=1;first=int(changed[0]);assert q['first_changed_absolute_step']==start+first
    with np.load(q['tape']['path']) as a:
     x,u=a['states'],a['actions'];assert len(u)==end-start-first==q['native_transition_calls']
     assert x.shape==(len(u)+1,32) and x[0].tobytes()==X[start+first].tobytes()
     commands=np.asarray([np.float32(np.clip(U[start+first+i]+bias[first+i]+scale*(K[start+first+i]@(x[i]-X[start+first+i])),-1,1)) for i in range(len(u))],dtype=float)
     assert commands.tobytes()==u.tobytes()
     for i,v in enumerate(u):assert native(x[i],float(v)).tobytes()==x[i+1].tobytes()
     post=np.vstack([X[start+1:start+first+1],x[1:]]);angle=np.abs(wrap_angle(np.cumsum(post[:,1:16],axis=1)))
     local=bool(np.all(angle<.149) and np.all(abs(post[:,0])<=3))
     assert local==q['arrival_bounds_passed'] and np.max(angle)==q['maximum_arrival_angle'] and np.max(abs(post[:,0]))==q['maximum_arrival_cart']
     assert np.linalg.norm(x[-1]-X[end])==q['endpoint_state_difference_norm']
   if scale==0:
    for k,v in prior[(amp,column,sign)].items():assert q[k]==v
  assert count[0]/4==ceiling==587+sum(q['native_transition_calls'] for q in r['records']) and nonzero==576
  for scale in m['feedback_scales']:
   for amp in m['amplitudes']:
    group=[q for q in r['records'] if q['feedback_scale']==scale and q['amplitude']==amp];local=[q for q in group if q.get('arrival_bounds_passed')]
    summaries.append(dict(feedback_scale=scale,amplitude=amp,potential_probes=len(group),noops=sum(q['no_op_after_f32'] for q in group),
     nonzero_local=len(local),earliest_local_changed_step=min((q['first_changed_absolute_step'] for q in local),default=None)))
  payload.update(status='finished',passed=True,summaries=summaries,independent_native_tapes_byte_exact=576,
   cold439_source_and_zero148_reference_byte_exact=True,archived_openloop480_summaries_exact=True,
   total_combined_native_transition_calls=2*ceiling,full_nominal_passes=0,
   scope='960potential probes,576nonzero completeprivate native tapes independently byte replayed and all feedback actions/locality metrics recomputed. Existingfullgain feedback local1 vsopenloop52 on sampled directions; no new actualepisode or optimization/noisy/reserved/canonicalgate. Reject only this frozenK/localbasis, not all feedback parameterizations.')
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}');raise
 finally:
  if env is not None:env.close()
  mujoco.mj_step=original;payload.update(total_native_transition_calls=count[0]/4,native_physics_substeps=count[0],partial_transition_substeps=count[0]%4,finished_at=utc_timestamp());dump_json(payload,out/'result.json');print(payload,flush=True)

if __name__=='__main__':main()
