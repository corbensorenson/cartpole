"""Prove preserved failed baseline and its endpoint scoring defect."""
import argparse,json
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.native_minimax import bounded_affine_minimax
from scripts.audit_canonical15_native_minimax import lp_gap
from scripts.search_capture_sequence import fixed_state_cfg
read=lambda p:json.loads(Path(p).read_text())
def same(a,b):assert np.asarray(a).tobytes()==np.asarray(b).tobytes()
def fullfeature(xs,m):return np.r_[(wrap_angle(np.cumsum(xs[m['capture_offset']:,1:16],axis=1))/m['angle_limit']).ravel(),xs[:,0]/3]
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);args=p.parse_args();root=Path(args.root);out=Path(args.out);out.mkdir(exist_ok=False);m=read(root/'manifest.json');r=read(root/'execution/diagnostic/result.failed.json');j=read(root/'execution/execution.json');acc=read(root/'execution/inclusive_accounting.json');assert j['status']=='failed' and j['returncode']==1 and r['error']=='AssertionError: ' and r['status']=='failed';assert len(r['private_forecasts'])==len(r['reference_contexts'])==len(r['force_projections'])==1 and not r['arms'] and not r['actual_records'];base=read(read(m['source']['path'])['source']['path']);h=m['horizon']
 with np.load(m['center_tape']['path']) as z:X=z['states'][:h+1].copy();U=z['actions'][:h].copy()
 cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);env=NLinkCartPoleEnv(cfg,progress=1.,seed=m['nominal_seed']);env.reset(seed=m['nominal_seed']);native=MujocoTransition(env,np.eye(32),continuous_angles=True)
 try:
  for i,u in enumerate(U):same(native(X[i],float(u)),X[i+1])
  context=r['reference_contexts'][0];assert context['gain_scale']==0 and context['parent_forecast'] is None and context['tape']==file_metadata(context['tape']['path'])
  with np.load(context['tape']['path']) as z:same(z['states'],X);same(z['actions'],U)
  forecast=r['private_forecasts'][0];assert forecast['tape']==file_metadata(forecast['tape']['path'])
  with np.load(forecast['tape']['path']) as z:xs=z['states'];us=z['actions'];ff=z['feedforward'];raws=z['raw_actions'];assert np.isnan(z['failed_post_state']).all() and np.isnan(z['failed_time'])
  same(xs[:-1],X[:-1]);same(us[:-1],U[:-1]);same(ff[:-1],U[:-1]);same(raws,ff)
  for i,u in enumerate(us):assert float(np.float32(np.clip(raws[i],-1,1)))==u;same(native(xs[i],float(u)),xs[i+1])
  row=r['force_projections'][0];assert row['tape']==file_metadata(row['tape']['path']) and all(e is None for e in row['errors'])
  with np.load(row['tape']['path']) as z:pairs=z['states'];actions=z['actions'];commands=z['raw_actions'];assert np.isnan(z['failed_post_states']).all() and np.isnan(z['failed_times']).all()
  for pair,u,raw in zip(pairs,actions,commands,strict=True):same(pair[0],X[-2]);assert float(np.float32(np.clip(raw,-1,1)))==u;same(native(pair[0],float(u)),pair[1])
  def peak(i):return float(abs(pairs[i,1,0])/3)
  grid=np.unique(np.r_[np.linspace(-1,1,m['inner_grid_points']).astype(np.float32).astype(float),np.float32(row['input_last_hint']).astype(float)]);same(grid,row['grid_actions']);ids=row['grid_candidate_ids'];assert ids==list(range(len(grid)));same(actions[ids],grid);minus=int(np.flatnonzero(grid==-1)[0]);plus=int(np.flatnonzero(grid==1)[0]);fm,fp=np.asarray([pairs[minus,1,0]/3]),np.asarray([pairs[plus,1,0]/3]);proposal=bounded_affine_minimax(fm,fp);assert proposal==row['affine_proposal'] and commands[len(grid)]==proposal;assert lp_gap(fm,fp,proposal)<1e-7
  best=min(range(len(grid)),key=lambda i:peak(i));left=float(grid[max(0,best-1)]);right=float(grid[min(len(grid)-1,best+1)]);assert row['initial_bracket']==[left,right];ratio=(np.sqrt(5)-1)/2;c=right-ratio*(right-left);d=left+ratio*(right-left);ci,di=row['golden_initial_ids'];assert [ci,di]==[len(grid)+1,len(grid)+2] and commands[ci]==c and commands[di]==d
  for i,history in enumerate(row['golden_history']):
   if peak(ci)<=peak(di):right,d,di=d,c,ci;c=right-ratio*(right-left);ci=len(grid)+3+i;branch='left';new=ci;assert commands[new]==c
   else:left,c,ci=c,d,di;d=left+ratio*(right-left);di=len(grid)+3+i;branch='right';new=di;assert commands[new]==d
   assert history==dict(iteration=i,branch=branch,left=left,right=right,c=c,d=d,candidate_c=ci,candidate_d=di,new_candidate=new)
  winner=min(range(len(pairs)),key=lambda i:(peak(i),abs(actions[i]),i));assert winner==row['winner_index'] and row['selected_next_peak']==peak(winner);same(pairs[winner,1],xs[-1]);assert actions[winner]==us[-1]==ff[-1]
  originalpeak=float(np.max(abs(fullfeature(X[1:],m))));failedpeak=float(np.max(abs(fullfeature(xs[1:],m))));assert failedpeak==forecast['score'][2] and failedpeak>originalpeak;assert native.evaluations-1==r['total_native_transition_calls']==acc['total_native_transition_calls']==906 and acc['native_physics_substeps']==3624
  dump_json(dict(status='finished',passed=True,generated_at=utc_timestamp(),scope='Failed original906-call baseline/projection andassertion independentlyproved. Endpointfeaturelostanglesbecausecaptureoffset291appliedtoone-nodearray; cart-onlyforcechoice worsenedwholecapturepeak. Failure/stoppingdata preserved, not aphysicallimit oroptimizationresult.',native_queries_proved=906,projection_queries_proved=len(pairs),complete_forecast_proved=True,failed_score=failedpeak,source_score=originalpeak,total_native_transition_calls=native.evaluations,actual_hanging_start_episode_steps=0,not_solution=True,canonical_release_evidence=False),out/'result.json');print(dict(passed=True,calls=native.evaluations,failedpeak=failedpeak,sourcepeak=originalpeak),flush=True)
 finally:env.close()
if __name__=='__main__':main()
