"""Screen native gain-projected nonlinear correction on frozen local15 states."""
import argparse
import json
from pathlib import Path
import time

import numpy as np

from gcartpole.angles import wrap_angle
from gcartpole.config import load_config, dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, runtime_metadata, utc_timestamp
from gcartpole.ilqr import MujocoTransition
from gcartpole.projected_remainder_control import ProjectedRemainderController
from gcartpole.upright_mechanics import upright_rk4_matrices
from scripts.search_capture_sequence import fixed_state_cfg


def episode(cfg, initial, gain, a, b):
    n = cfg['env']['n_links']; nx = len(initial)
    local = fixed_state_cfg(cfg, dict(qpos=initial[:n+1].tolist(), qvel=initial[n+1:].tolist()), 30.)
    for key in ('init_qpos_scale_start', 'init_qpos_scale_end'):
        local['env'].pop(key, None)
    env = NLinkCartPoleEnv(local, progress=1., seed=0); env.reset(seed=0)
    forecast = NLinkCartPoleEnv(cfg, progress=1., seed=0); forecast.reset(seed=0)
    predictor = MujocoTransition(forecast, np.eye(nx), continuous_angles=True)
    assert predictor.data is not env.data
    policy = ProjectedRemainderController(predictor, a, b, gain, n_links=n)
    states = [np.r_[env.data.qpos, env.data.qvel]]
    assert states[0].tobytes() == initial.tobytes()
    actions = []; diagnostics = []
    streak = longest = corrections = 0
    max_angle = max_rate = max_cart = max_baseline_raw = 0.
    first_angle_failure = None
    began = time.monotonic()
    try:
        for step in range(env.max_steps):
            state = np.r_[env.data.qpos, env.data.qvel]
            action, predicted, diagnostic = policy.select(state)
            assert predictor.evaluations-sum(v['predictor_evaluations'] for v in diagnostics) == diagnostic['predictor_evaluations']
            assert action == float(np.float32(action)) and abs(action) <= 1
            corrections += diagnostic['changed_delivered_action']
            max_baseline_raw = max(max_baseline_raw, abs(diagnostic['baseline_raw_action']))
            _, _, terminated, truncated, info = env.step([action])
            current = np.r_[env.data.qpos, env.data.qvel]
            assert current.tobytes() == predicted.tobytes(), step
            states.append(current); actions.append(action); diagnostics.append(diagnostic)
            angle = float(np.max(np.abs(wrap_angle(np.cumsum(env.data.qpos[1:n+1])))))
            max_angle = max(max_angle, angle)
            max_rate = max(max_rate, float(np.max(np.abs(np.cumsum(env.data.qvel[1:])))))
            max_cart = max(max_cart, abs(float(env.data.qpos[0])))
            streak = streak+1 if angle < .15 else 0
            longest = max(longest, streak)
            if angle >= .15 and first_angle_failure is None:
                first_angle_failure = (step+1)*env.dt
            if terminated or truncated:
                break
        before_replay = predictor.evaluations
        for index, action in enumerate(actions):
            assert predictor(states[index], action).tobytes() == states[index+1].tobytes()
        replay = predictor.evaluations-before_replay
        assert replay == len(actions)
        return dict(steps=len(actions), physical_hold_seconds=longest*env.dt,
            first_angle_failure_seconds=first_angle_failure,
            local_gate_pass=len(actions)==env.max_steps and info['termination_reason']=='time_limit'
                and longest*env.dt>=5 and not info['simulation_error'],
            all_samples_upright=first_angle_failure is None,
            maximum_angle=max_angle, maximum_absolute_rate=max_rate, maximum_cart=max_cart,
            maximum_baseline_raw_action=max_baseline_raw,
            maximum_delivered_action=max(abs(v) for v in actions),
            delivered_at_bound_steps=sum(abs(v)==1 for v in actions),
            changed_delivered_actions=corrections, termination_reason=info['termination_reason'],
            actual_local_episode_steps=len(actions), planning_transition_calls=before_replay,
            independent_actual_tape_replay_transition_calls=replay,
            total_native_transition_calls=before_replay+2*len(actions),
            every_selected_forecast_matches_live_state_bytes=True,
            independent_actual_tape_replay_bytes_exact=True,
            initial_state=initial.tolist(), actions=actions, states=[v.tolist() for v in states],
            action_diagnostics=diagnostics, wall_seconds=time.monotonic()-began)
    finally:
        env.close(); forecast.close()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--baseline', required=True)
    p.add_argument('--spectral-component', required=True)
    p.add_argument('--directory', required=True)
    args = p.parse_args(); out = Path(args.directory)
    if out.exists():
        raise FileExistsError(out)
    out.mkdir(parents=True)
    baseline = json.loads(Path(args.baseline).read_text())
    spectral = json.loads(Path(args.spectral_component).read_text())
    assert spectral['baseline'] == file_metadata(args.baseline)
    cache_ref = next(r for r in baseline['sources'] if r['path'].endswith('capture_cache.json'))
    assert cache_ref == file_metadata(cache_ref['path'])
    cache = json.loads(Path(cache_ref['path']).read_text())
    selected = next(r for r in spectral['records'] if r['label']=='moderately_separated_decay')
    assert selected['status']=='finished'
    gains = dict(saved_baseline=np.asarray(cache['gain']), moderately_separated_decay=np.asarray(selected['gain']))
    directions = np.asarray(baseline['directions15'])
    cfg = load_config('configs/swingup15_uniform.yaml')
    env = NLinkCartPoleEnv(cfg, progress=1., seed=0); env.reset(seed=0)
    a, b, mechanics = upright_rk4_matrices(env, decimal_digits=100); env.close()
    payload = dict(generated_at=utc_timestamp(), runtime=runtime_metadata(), parameters=vars(args),
        script=file_metadata(__file__), policy_code=file_metadata('src/gcartpole/projected_remainder_control.py'),
        baseline=file_metadata(args.baseline), spectral_component=file_metadata(args.spectral_component),
        config=file_metadata('configs/swingup15_uniform.yaml'), mechanics=mechanics,
        gains={k:v.tolist() for k,v in gains.items()}, direction=directions[0].tolist(),
        records=[], total_native_transition_calls=0, actual_local_episode_steps=0,
        planning_transition_calls=0, independent_actual_tape_replay_transition_calls=0,
        native_transition_ceiling=228000, actual_hanging_start_episode_steps=0,
        optimizer_transition_calls=0, reserved_seeds_used=False, noisy_development_seeds_used=False,
        canonical_release_evidence=False, not_solution=True,
        scope='Eight local target15 pilot episodes:two frozen gains,first frozen direction/bothsigns at1e-14/1e-12. Native single-action gain-projected remainder correction;MP100 mechanical next-feedback target,12secant proposals plus adjacent F32 checks;baselinealwayscandidate. Predictor/live and independent whole-tape byte equality mandatory. No reset-free hanging-start or real-time feasibility claim.')
    began = time.monotonic()
    for label, gain in gains.items():
        for amplitude in (1e-14, 1e-12):
            for sign in (1, -1):
                initial = np.zeros(32)
                initial[1:16] += sign*amplitude*directions[0, :15]
                initial[17:] += sign*amplitude*directions[0, 15:]
                result = episode(cfg, initial, gain, a, b)
                payload['records'].append(dict(gain_label=label, amplitude=amplitude, sign=sign, result=result))
                for key in ('total_native_transition_calls', 'actual_local_episode_steps',
                            'planning_transition_calls', 'independent_actual_tape_replay_transition_calls'):
                    payload[key] += result[key]
                assert payload['total_native_transition_calls'] <= payload['native_transition_ceiling']
                payload['wall_seconds'] = time.monotonic()-began
                dump_json(payload, out/'result.progress.json')
                print(json.dumps(dict(gain=label, amplitude=amplitude, sign=sign,
                    steps=result['steps'], hold=result['physical_hold_seconds'], pass30=result['local_gate_pass'],
                    changed=result['changed_delivered_actions'], calls=result['total_native_transition_calls'])), flush=True)
    payload['wall_seconds'] = time.monotonic()-began
    dump_json(payload, out/'result.json')


if __name__=='__main__':
    main()
