"""Native scalar last-force projection at three actual reachable arrivals."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.native_trust_minimax import affine_trust_proposal
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix
from scripts.solve_canonical15_native_minimax import features,gain_raw,first_proposals
from gcartpole.native_minimax import bounded_affine_minimax
read=lambda p:json.loads(Path(p).read_text())
def physical_features(states,m):
 angles=wrap_angle(np.cumsum(states[:,1:16],axis=1))/m['angle_limit'];return np.r_[angles.reshape(-1),states[:,0]/m['rail_limit']]
def score(states,raws,h,m):
 if len(states)!=h:return (1,1,1e100,1e100,0)
 f=physical_features(states,m);safe=(np.max(abs(wrap_angle(np.cumsum(states[:,1:16],axis=1))),axis=1)<m['angle_limit'])&(abs(states[:,0])<=m['rail_limit']);bad=np.flatnonzero(~safe);prefix=int(bad[0]) if len(bad) else h;excess=np.maximum(abs(f)-1,0)
 return (0,0 if np.all(safe) else 1,float(np.max(abs(f))),float(excess@excess),-prefix)
def basis_for(h,m):
 first=m['tracking_steps'];tail=h-first;basis=np.zeros((h,m['tracking_knots']+tail));basis[:first,:m['tracking_knots']]=interpolation_matrix(m['tracking_knots'],first);basis[first:,m['tracking_knots']:]=np.eye(tail);return basis

def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--directory',required=True);a=p.parse_args();m=read(a.manifest);out=Path(a.directory);out.mkdir(exist_ok=False);(out/'private').mkdir();s=read(m['source']['path']);base=read(s['source']['path']);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in s['result']['trajectory']]]);U=np.asarray([q['action'] for q in s['result']['trajectory']],np.float32).astype(float);start=m['start_step'];track=m['tracking_steps'];gain=np.asarray(read(m['gain_source']['path'])['gain'])
 for key in ('source','config','tracking_array','tracking_audit','source_audit','gain_source','center_tape'):assert m[key]==file_metadata(m[key]['path'])
 assert read(m['tracking_audit']['path'])['passed'] and read(m['source_audit']['path'])['passed']
 with np.load(m['tracking_array']['path']) as z:K=z['gains'][m['tracking_variant_index']];assert z['states'].tobytes()==X[start:start+track+1].tobytes()
 cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);env=NLinkCartPoleEnv(cfg,progress=1.,seed=m['nominal_seed']);env.reset(seed=m['nominal_seed']);native=MujocoTransition(env,np.eye(32),continuous_angles=True);actual_ticks=0;began=time.monotonic();payload=dict(status='running',generated_at=utc_timestamp(),manifest=file_metadata(a.manifest),script=file_metadata(__file__),helper=file_metadata('src/gcartpole/native_trust_minimax.py'),runtime=runtime_metadata(),private_forecasts=[],tail_screens=[],stages=[],actual_records=[],maintenance_decisions=[],not_solution=True,canonical_release_evidence=False,noisy_development_seeds_used=False,reserved_seeds_used=False)
 def forecast(ff,label,kind):
  xs=[X[start].copy()];us=[];raws=[];err=None;failed_post_state=np.full(32,np.nan);failed_time=np.nan
  try:
   for i,value in enumerate(ff):
    raw=float(value)+float(K[i]@(xs[-1]-X[start+i])) if i<track else float(value);u=float(np.float32(np.clip(raw,-1,1)));us.append(u);raws.append(raw);xs.append(native(xs[-1],u))
  except SimulationError as e:err=f'SimulationError: {e}';failed_post_state=np.r_[native.data.qpos,native.data.qvel].copy();failed_time=float(native.data.time)
  tape=out/'private'/f'forecast_{len(payload["private_forecasts"]):05d}.npz';np.savez_compressed(tape,states=np.asarray(xs),actions=np.asarray(us),raw_actions=np.asarray(raws),feedforward=np.asarray(ff),failed_post_state=failed_post_state,failed_time=np.asarray(failed_time));row=dict(index=len(payload['private_forecasts']),label=label,kind=kind,tape=file_metadata(tape),error=err,attempted_steps=len(us),completed_steps=len(xs)-1,score=list(score(np.asarray(xs)[1:],np.asarray(raws),len(ff),m)));payload['private_forecasts'].append(row);return dict(row=row,states=np.asarray(xs),raws=np.asarray(raws),actions=np.asarray(us),ff=np.asarray(ff).copy(),score=tuple(row['score']))
 def maintenance(state,tick,last,label):
  om=m['maintenance'];pairs=[];calls=[];errors=[]
  def evaluate(x,raw,role):
   u=float(np.float32(np.clip(raw,-1,1)));pair=np.full((2,32),np.nan);pair[0]=x;error=None
   try:pair[1]=native(x,u)
   except SimulationError as e:error=f'SimulationError: {e}'
   index=len(calls);calls.append((pair,u,float(raw),role));errors.append(error);return index,pair[1] if error is None else None
  mi,minus=evaluate(state,-1.,'first_minus');pi,plus=evaluate(state,1.,'first_plus')
  if minus is None or plus is None:raise RuntimeError('Maintenance anchor failed; preserve new failed evidence')
  proposal=bounded_affine_minimax(features(minus,0.,om),features(plus,0.,om));raw=gain_raw(gain,state);source=float(U[tick]) if tick<len(U) else 0.;commands,pr=first_proposals(raw,proposal,source,last,om)
  for i,u in enumerate(commands):
   fi,first=evaluate(state,float(u),f'first_{i}');row=dict(index=i,first_id=fi,second_minus_id=None,second_plus_id=None,second_id=None,second_raw=None,score=[1,1e100,abs(float(u))])
   if first is not None:
    sm,minus=evaluate(first,-1.,f'second_minus_{i}');sp,plus=evaluate(first,1.,f'second_plus_{i}');row.update(second_minus_id=sm,second_plus_id=sp)
    if minus is not None and plus is not None:
     raw2=bounded_affine_minimax(features(minus,0.,om),features(plus,0.,om));si,second=evaluate(first,raw2,f'second_selected_{i}');row.update(second_id=si,second_raw=raw2)
     if second is not None:row['score']=[0,float(max(np.max(abs(features(first,0.,om))),np.max(abs(features(second,0.,om))))),abs(float(u))]
   pairs.append(row)
  winner=min(range(len(pairs)),key=lambda i:tuple(pairs[i]['score']));tape=out/'private'/f'maintenance_{len(payload["maintenance_decisions"]):05d}.npz';np.savez_compressed(tape,states=np.asarray([c[0] for c in calls]),actions=np.asarray([c[1] for c in calls]),raw_actions=np.asarray([c[2] for c in calls]),roles=np.asarray([c[3] for c in calls]),candidate_actions=commands,candidate_raw_proposals=pr);d=dict(label=label,tick=tick,tape=file_metadata(tape),errors=errors,first_minus_id=mi,first_plus_id=pi,proposal=proposal,gain_raw=raw,source_action=source,last_action=last,candidates=pairs,winner_index=winner);payload['maintenance_decisions'].append(d)
  if pairs[winner]['score'][0]:raise RuntimeError('No complete maintenance forecast')
  return float(commands[winner]),calls[pairs[winner]['first_id']][0][1]
 def actual_episode(label,selected,h):
  nonlocal actual_ticks
  actual=NLinkCartPoleEnv(cfg,progress=1.,seed=m['nominal_seed']);actual.reset(seed=m['nominal_seed']);xs=[initial.copy()];us=[];raws=[];info=None;reason=None
  try:
   for tick in range(actual.max_steps):
    state=np.r_[actual.data.qpos,actual.data.qvel]
    if tick<start:raw=float(U[tick]);u=raw
    elif tick<start+h:
     i=tick-start;raw=float(selected['ff'][i])+float(K[i]@(state-X[tick])) if i<track else float(selected['ff'][i]);u=float(np.float32(np.clip(raw,-1,1)))
    else:u,prediction=maintenance(state,tick,float(us[-1]),label);raw=u
    _,_,terminated,truncated,info=actual.step([u]);actual_ticks+=1;x=np.r_[actual.data.qpos,actual.data.qvel];xs.append(x.copy());us.append(u);raws.append(raw)
    if tick<start:assert x.tobytes()==X[tick+1].tobytes()
    elif tick<start+h:assert x.tobytes()==selected['states'][tick-start+1].tobytes()
    else:assert x.tobytes()==prediction.tobytes()
    if terminated or truncated:reason=info['termination_reason'];break
  finally:
   actual.close();tape=out/(label+'_actual.npz');np.savez_compressed(tape,states=np.asarray(xs),actions=np.asarray(us),raw_actions=np.asarray(raws))
  for tick,u in enumerate(us):assert native(xs[tick],float(u)).tobytes()==xs[tick+1].tobytes()
  safe=np.max(abs(wrap_angle(np.cumsum(np.asarray(xs)[1:,1:16],axis=1))),axis=1)<.15;streak=longest=0
  for ok in safe:streak=streak+1 if ok else 0;longest=max(longest,streak)
  maxcart=float(np.max(abs(np.asarray(xs)[:,0])));passed=len(us)==1500 and longest>=250 and maxcart<=3 and reason=='time_limit' and not info['simulation_error'];row=dict(label=label,horizon=h,selected_forecast=selected['row']['tape'],selected_forecast_index=selected['row']['index'],tape=file_metadata(tape),actual_hanging_start_episode_steps=len(us),hold_seconds=longest*.02,maximum_cart=maxcart,termination_reason=reason,simulation_error=info['simulation_error'],full_nominal_gate_passed=passed);payload['actual_records'].append(row);print(row,flush=True)
 try:
  for tick in range(start+track):assert native(X[tick],float(U[tick])).tobytes()==X[tick+1].tobytes()
  h=149
  for case in m['cases']:
   assert case['tape']==file_metadata(case['tape']['path'])
   with np.load(case['tape']['path']) as z:ff=z['feedforward'].copy();expected=z['states'].copy()
   center=forecast(ff,case['label'],'case_baseline');assert center['states'].tobytes()==expected.tobytes();state=center['states'][-2].copy();pairs=[];controls=[];raws=[];roles=[];errors=[];failed_states=[];failed_times=[]
   def query(raw,role):
    u=float(np.float32(np.clip(raw,-1,1)));pair=np.full((2,32),np.nan);pair[0]=state;err=None;failed_state=np.full(32,np.nan);failed_time=np.nan
    try:pair[1]=native(state,u)
    except SimulationError as e:err=f'SimulationError: {e}';failed_state=np.r_[native.data.qpos,native.data.qvel].copy();failed_time=float(native.data.time)
    index=len(pairs);pairs.append(pair);controls.append(u);raws.append(float(raw));roles.append(role);errors.append(err);failed_states.append(failed_state);failed_times.append(failed_time);return index
   def peak(index):return float(np.max(abs(physical_features(pairs[index][1:2],m)))) if errors[index] is None else 1e100
   grid=np.unique(np.r_[np.linspace(-1,1,m['grid_points']).astype(np.float32).astype(float),np.float32(ff[-1]).astype(float)]);ids=[query(float(u),'coarse_grid') for u in grid];minus=ids[int(np.flatnonzero(grid==-1)[0])];plus=ids[int(np.flatnonzero(grid==1)[0])];proposal=bounded_affine_minimax(physical_features(pairs[minus][1:2],m),physical_features(pairs[plus][1:2],m));proposal_id=query(proposal,'affine_minimax');best=min(range(len(ids)),key=lambda i:peak(ids[i]));left=float(grid[max(0,best-1)]);right=float(grid[min(len(grid)-1,best+1)]);bracket=[left,right];ratio=(np.sqrt(5)-1)/2;c=right-ratio*(right-left);d=left+ratio*(right-left);ci=query(c,'golden_initial_c');di=query(d,'golden_initial_d');history=[]
   for iteration in range(m['golden_iterations']):
    if peak(ci)<=peak(di):right,d,di=d,c,ci;c=right-ratio*(right-left);ci=query(c,'golden_c');branch='left';new=ci
    else:left,c,ci=c,d,di;d=left+ratio*(right-left);di=query(d,'golden_d');branch='right';new=di
    history.append(dict(iteration=iteration,branch=branch,left=left,right=right,c=c,d=d,candidate_c=ci,candidate_d=di,new_candidate=new))
   winner=min(range(len(pairs)),key=lambda i:(peak(i),abs(controls[i]),i));tape=out/'private'/(case['label']+'_tail_oracles.npz');np.savez_compressed(tape,states=np.asarray(pairs),actions=np.asarray(controls),raw_actions=np.asarray(raws),roles=np.asarray(roles),failed_post_states=np.asarray(failed_states),failed_times=np.asarray(failed_times));selectedff=ff.copy();selectedff[-1]=controls[winner];selected=forecast(selectedff,case['label'],'projected_last_force');assert selected['states'][:-1].tobytes()==center['states'][:-1].tobytes();assert selected['states'][-1].tobytes()==pairs[winner][1].tobytes();row=dict(label=case['label'],case=case,baseline_forecast=center['row']['index'],selected_forecast=selected['row']['index'],tape=file_metadata(tape),errors=errors,grid_actions=grid.tolist(),grid_candidate_ids=ids,affine_proposal=proposal,affine_candidate_id=proposal_id,initial_bracket=bracket,golden_initial_ids=[len(ids)+1,len(ids)+2],golden_history=history,winner_index=winner,original_last_action=float(center['actions'][-1]),selected_last_action=float(controls[winner]),original_next_peak=float(np.max(abs(physical_features(center['states'][-1:],m)))),selected_next_peak=peak(winner),selected_plan_score=list(selected['score']),sampled_tail_149safe_count=sum(peak(i)<1 for i in ids));payload['tail_screens'].append(row);print({k:row[k] for k in ('label','original_last_action','selected_last_action','original_next_peak','selected_next_peak','sampled_tail_149safe_count')},flush=True)
   if case['execute']:actual_episode(case['label']+'_projected_h149',selected,h)
   dump_json(payload,out/'result.progress.json')
  payload.update(status='finished',total_native_transition_calls=native.evaluations+actual_ticks,actual_hanging_start_episode_steps=actual_ticks,wall_seconds=time.monotonic()-began);assert payload['total_native_transition_calls']<=m['execution_native_transition_ceiling'];dump_json(payload,out/'result.json')
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}',total_native_transition_calls=native.evaluations+actual_ticks,actual_hanging_start_episode_steps=actual_ticks);dump_json(payload,out/'result.failed.json');raise
 finally:env.close()
if __name__=='__main__':main()
