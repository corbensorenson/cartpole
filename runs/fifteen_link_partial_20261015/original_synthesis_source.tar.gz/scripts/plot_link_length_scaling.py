#!/usr/bin/env python
"""Show measured geometry scalings without treating them as solve evidence."""
import argparse,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    data=json.loads(Path(args.source).read_text());records=data['geometry_records']
    canonical=[r for r in records if abs(r['total_length_m']-3)<1e-12]
    longer=[canonical[0]]+[r for r in records if r['total_length_m']>3]
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    fig,axes=plt.subplots(3,1,figsize=(7.8,7.4),sharex=True,layout='constrained')
    for group,label,color in [(canonical,'Fixed total length: 3 m','#243a50'),(longer,'Fixed link length: 21.4 cm','#43816a')]:
        group=sorted(group,key=lambda r:r['n_links']);counts=[r['n_links'] for r in group]
        axes[0].plot(counts,[100*r['lengths_m'][0] for r in group],'-o',color=color,label=label,lw=1.6,ms=5)
        axes[1].plot(counts,[r['armature_to_body_own_hinge_inertia'][0] for r in group],'-o',color=color,lw=1.6,ms=5)
        axes[2].plot(counts,[r['fastest_hanging_frequency_hz'] for r in group],'-o',color=color,lw=1.6,ms=5)
    axes[0].set(ylabel='Individual link length (cm)',ylim=(13,24));axes[0].legend(fontsize=9)
    axes[1].set(ylabel='Armature / own-link\nhinge inertia',ylim=(.25,1.35))
    axes[1].axhline(1,color='#7b838b',ls=':',lw=1)
    axes[1].text(14.05,1.04,'Equal own-link hinge and armature inertia',color='#65707b',fontsize=9)
    axes[2].set(ylabel='Fastest hanging mode (Hz)',xlabel='Number of links',ylim=(4.45,5.02),xticks=(14,15,20))
    for ax in axes:ax.grid(axis='y',alpha=.16)
    fig.suptitle('Increasing link count changes physical proportions',fontsize=13)
    fig.supxlabel('Native compiled geometry; total chain mass 1 kg, fixed radius and joint armature.\nOwn-link ratios exclude descendant bodies. Markers are measured cases; lines guide the eye.\nGeometry diagnostics do not establish hanging-start control or a new chain record.',fontsize=9)
    out.mkdir(parents=True,exist_ok=True);outputs=[]
    for suffix in ('png','pdf','svg'):
        path=out/f'comparison.{suffix}';fig.savefig(path,dpi=180);outputs.append(file_metadata(path))
    plt.close(fig)
    dump_json(dict(not_solution=True,canonical_release_evidence=False,source=file_metadata(args.source),outputs=outputs,native_transition_calls=0,scope='Plot of five measured native geometry cases. No new simulation or record.'),out/'result.json')

if __name__=='__main__':main()
