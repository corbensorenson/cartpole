"""Metric and complete finite timing comparisons, scientific PNG/PDF."""
import argparse,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp

def main():
 p=argparse.ArgumentParser();p.add_argument('--directory',required=True);a=p.parse_args();root=Path(a.directory);r=json.loads((root/'verified.json').read_text());dense_root=Path('runs/directional_dense_handoffs_20261004');dense=json.loads((dense_root/'verified.json').read_text());assert r['passed'] and dense['passed'];out=root/'figures';out.mkdir(exist_ok=True);plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42});fig,ax=plt.subplots(1,2,figsize=(10.8,4.8));x=np.arange(4);raw=[q['hold_seconds'] for q in r['outcomes']];best=[q['maximum_hold_seconds'] for q in dense['outcomes']];v=[abs(q['first_free_native_defect_next_tracking_action']) for q in r['outcomes']];labels=['Legacy','Rotation only','Weight0.001','Weight0.01'];ax[0].bar(x-.16,raw,.32,label='Raw tracking',color='#205493');ax[0].bar(x+.16,best,.32,label='Best dense handoff',color='#477f64');ax[0].axhline(5,color='#a14848',ls='--',lw=1);ax[0].set(xticks=x,xticklabels=labels,ylim=(0,5.5),ylabel='Longest actual upright hold (s)');ax[0].legend(frameon=False,fontsize=8);ax[1].bar(x,v,color=['#205493','#bd713f','#9c4f65','#477f64']);ax[1].set(xticks=x,xticklabels=labels,yscale='log',ylabel='Absolute first feedback correction');
 for i,val in enumerate(v):ax[1].text(i,val*1.15,f'{val:.2e}',ha='center',fontsize=8)
 ax[1].set_ylim(min(v)*.4,max(v)*2.5)
 for axis in ax:axis.grid(axis='y',alpha=.15);axis.tick_params(axis='x',labelsize=9)
 fig.suptitle('Reducing the first correction did not deliver capture',fontsize=14);fig.text(.5,.023,'Same altered 14-link plant, armature factor 0.95, frozen 8s actual prefix, shared costs and native 50Hz/F32.\nAll four repairs and all 377 available 20ms handoffs fail. Optimization changes reference and gains together.',ha='center',fontsize=8.5);fig.tight_layout(rect=(0,.13,1,.94));artifacts=[]
 for ext in ['png','pdf']:
  path=out/f'directional_metric_capture.{ext}';fig.savefig(path,dpi=180);artifacts.append(file_metadata(path))
 plt.close(fig);dump_json(dict(generated_at=utc_timestamp(),script=file_metadata(__file__),audits=[file_metadata(root/'verified.json'),file_metadata(dense_root/'verified.json')],artifacts=artifacts,native_transition_calls=0,scope='Actualraw/denseholds andfirstnative feedbackcorrection; finiteweights/handoffdomains, allfailedgates.'),out/'figures.json')
 out=dense_root/'figures';out.mkdir(exist_ok=True);fig,axis=plt.subplots(figsize=(9.8,4.6))
 for row,label,col in zip(dense['studies'],labels,['#205493','#bd713f','#9c4f65','#477f64']):axis.plot([q['handoff_seconds'] for q in row['records']],[q['result']['max_upright_streak_seconds'] for q in row['records']],'.-',label=label,color=col,ms=2.5)
 axis.axhline(5,color='#a14848',ls='--',lw=1);axis.set(xlabel='Maintenance handoff time (s)',ylabel='Longest actual upright hold (s)',ylim=(0,5.5));axis.legend(frameon=False,fontsize=9);axis.grid(axis='y',alpha=.15);fig.suptitle('Every available handoff fails on all four new references',fontsize=14);fig.text(.5,.025,'98/116/52/111 preterminal ticks tested; unequal available domains are explicit. Ten integer controls reproduce byte-for-byte.\nSame exact seed and plant; complete timing grids for these references, not a plant impossibility certificate.',ha='center',fontsize=8.5);fig.tight_layout(rect=(0,.13,1,.94));artifacts=[]
 for ext in ['png','pdf']:
  path=out/f'directional_dense_handoffs.{ext}';fig.savefig(path,dpi=180);artifacts.append(file_metadata(path))
 plt.close(fig);dump_json(dict(generated_at=utc_timestamp(),script=file_metadata(__file__),audit=file_metadata(dense_root/'verified.json'),artifacts=artifacts,native_transition_calls=0,scope='All377native-tickhandoffs onfourfrozenmetricreferences; no newoptimization/physics forplot.'),out/'figures.json');print(out/'directional_dense_handoffs.png')
if __name__=='__main__':main()
