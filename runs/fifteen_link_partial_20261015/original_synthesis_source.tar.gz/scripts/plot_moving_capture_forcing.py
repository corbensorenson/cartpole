"""Traceable moving-reference capture diagnostics; approximate matrix estimates labelled."""
import argparse,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp

def main():
 p=argparse.ArgumentParser();p.add_argument('--directory',required=True);a=p.parse_args();root=Path(a.directory);audit=json.loads((root/'verified.json').read_text());assert audit['passed'];r=json.loads((root/'execution/diagnostic/result.json').read_text());out=root/'figures';out.mkdir(exist_ok=True);plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42});fig,ax=plt.subplots(1,2,figsize=(11,4.9));colors=['#205493','#bd713f','#9c4f65','#477f64'];artifacts=[]
 for q,col in zip(r['records'],colors):
  z=np.load(q['arrays']['path']);t=np.arange(q['processed_steps']+1)*.02;label=q['tag'].replace('fail0.95_prefix','0.95, prefix ').replace('success0.97_prefix','0.97, prefix ')+'s';e=np.linalg.norm(z['delta']@z['metric_transform'].T,axis=1);ax[0].plot(t[1:],e[1:],label=label,color=col);cmd=z['unclipped_command'];ax[1].plot(t[:-1],np.abs(cmd),color=col);sat=np.flatnonzero(abs(cmd)>1)
  if len(sat):i=int(sat[0]);ax[1].plot(t[i],abs(cmd[i]),'o',color=col,ms=5)
 ax[0].set(yscale='log',xlabel='Time after preserved prefix (s)',ylabel='Error norm in scaled physical coordinates');ax[1].set(yscale='log',xlabel='Time after preserved prefix (s)',ylabel='Absolute requested normalized action');ax[1].axhline(1,color='#a14848',ls='--',lw=1);ax[1].text(.03,1.5,'Actuator bound',color='#a14848',fontsize=8);ax[0].legend(frameon=False,fontsize=8)
 for axis in ax:axis.grid(axis='y',alpha=.15)
 fig.suptitle('Failed captures amplify reference errors and saturate feedback',fontsize=14);fig.text(.5,.025,'Stored exact-seed altered 14-link tapes, native 50Hz/F32. Reference, plant and gains differ across arms.\nNorm scales: cart 3m, absolute angles 0.15rad, cart speed 0.5m/s, absolute rates 0.75rad/s. No new control episodes.',ha='center',fontsize=8.5);fig.tight_layout(rect=(0,.13,1,.94))
 for ext in ['png','pdf']:
  path=out/f'capture_error_and_saturation.{ext}';fig.savefig(path,dpi=180);artifacts.append(file_metadata(path))
 plt.close(fig);fig,axes=plt.subplots(2,2,figsize=(10.7,7.2),sharex=False)
 for q,axis,col in zip(r['records'],axes.flat,colors):
  z=np.load(q['arrays']['path']);T=z['metric_transform'];P=np.eye(30);log=0;logs=[0.]
  for gg in z['closed_loop']:
   P=(T@gg@np.linalg.inv(T))@P;s=np.linalg.norm(P,2);P/=s;log+=np.log10(s);logs.append(log)
  t=np.arange(len(logs))*.02;axis.plot(t,z['product_log10_norm'],color=col,label='Batched contraction');axis.plot(t,logs,'--',color='#585858',label='Sequential matrix products');axis.set(title=q['tag'],xlabel='Time after preserved prefix (s)',ylabel='Log10 induced product norm');axis.grid(axis='y',alpha=.15)
 axes[0,0].legend(frameon=False,fontsize=8);fig.suptitle('Equivalent binary64 calculations give different amplification estimates',fontsize=13);fig.text(.5,.014,'Approximate local products are numerically sensitive and are not stability or capture certificates.\nCoordinate matrices differ only about 1e-16 relative to their largest entries; operation order changes log estimates by up to 0.626.',ha='center',fontsize=8.5);fig.tight_layout(rect=(0,.08,1,.94))
 for ext in ['png','pdf']:
  path=out/f'capture_product_rounding_sensitivity.{ext}';fig.savefig(path,dpi=180);artifacts.append(file_metadata(path))
 plt.close(fig);dump_json(dict(generated_at=utc_timestamp(),script=file_metadata(__file__),audit=file_metadata(root/'verified.json'),result=file_metadata(root/'execution/diagnostic/result.json'),artifacts=artifacts,native_transition_calls=0,scope='Storedactualerror/command comparisons and explicitly noncertified binary64product sensitivity. Unequalfinitecoverage disclosed.'),out/'figures.json');print(out/'capture_error_and_saturation.png')
if __name__=='__main__':main()
