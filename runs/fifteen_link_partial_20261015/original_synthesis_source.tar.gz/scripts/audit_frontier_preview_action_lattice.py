#!/usr/bin/env python
"""Inspect native float32 action neighbors on an executed preview trace.

These are isolated forecasts of saved states, never live state corrections.
"""
import argparse,json,time
from pathlib import Path
import mpmath
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.ilqr import MujocoTransition
from gcartpole.route_value_inputs import verified_route_value_inputs
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.solve_frontier_capture_increment import validate_development_seeds


def action_neighbors(action,radius):
    center=np.float32(action);items=[float(center)]
    for direction in [np.float32(-np.inf),np.float32(np.inf)]:
        current=center
        for _ in range(radius):
            current=np.nextafter(current,direction)
            if abs(current)<=1:items.append(float(current))
    return np.asarray(sorted(set(items)))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--episode',required=True);p.add_argument('--directory',required=True)
    p.add_argument('--steps',nargs='+',type=int,required=True)
    p.add_argument('--neighbor-radius',type=int,default=128)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    if args.neighbor_radius<1 or len(set(args.steps))!=len(args.steps):raise ValueError('positive radius and unique steps required')
    episode=json.loads(Path(args.episode).read_text());params=episode['parameters']
    if not params['exact_reference_subtraction']:raise ValueError('requires exact reference subtraction')
    source,values,provenance=verified_route_value_inputs(params['source'],params['value_factors'],params['config'])
    cfg=load_config(params['config']);validate_development_seeds(cfg['env']['n_links'],source['seed'])
    cfg=fixed_state_cfg(cfg,source['selected_state'],30.)
    transform=np.asarray(source['controller']['coordinate_transform']);nodes=np.asarray(source['search']['nominal_coordinate_states'])
    controls=np.asarray(source['controller']['controls']);roots=np.asarray(values['value_factors']);rows=episode['result']['trajectory']
    if any(step<1 or step>=min(len(rows),len(controls)) for step in args.steps):raise ValueError('interior executed steps required')
    ctx=mpmath.mp.clone();ctx.dps=params['decimal_digits'];effort=ctx.mpf(values['control_cost']+values['regularization'])
    env=NLinkCartPoleEnv(cfg,progress=1.,seed=source['seed']);env.reset(seed=source['seed'])
    predictor=MujocoTransition(env,transform,continuous_angles=True);records=[];begun=time.monotonic()
    try:
        for step in args.steps:
            state=transform@np.asarray(rows[step-1]['qpos']+rows[step-1]['qvel']);row=rows[step]
            root=ctx.matrix(roots[step+1].tolist());reference=ctx.matrix(nodes[step+1].tolist());u_ref=ctx.mpf(float(controls[step]))
            delivered=float(np.float32(row['action']));candidates=action_neighbors(delivered,args.neighbor_radius)
            costs=[];predictions={}
            for action in candidates:
                predicted=predictor(state,float(action));predictions[float(action)]=predicted
                residual=root*(ctx.matrix(predicted.tolist())-reference)
                costs.append((residual.T*residual)[0]+effort*(ctx.mpf(float(action))-u_ref)**2)
            base_index=int(np.flatnonzero(candidates==delivered)[0]);base=costs[base_index];best=min(range(len(costs)),key=costs.__getitem__)
            actual=transform@np.asarray(row['qpos']+row['qvel'])
            if not np.array_equal(predictions[delivered],actual):raise ValueError('native forecast does not exactly reproduce executed state')
            saved=row['tracking_preview']['predicted_value']
            if float(base)!=saved:raise ValueError('recomputed selected-action value differs from trace')
            record=dict(step=step,time_seconds=step*env.dt,selected_action=delivered,
                selected_value=float(base),best_neighbor_action=float(candidates[best]),best_neighbor_value=float(costs[best]),
                better_neighbor_count=sum(value<base for value in costs),
                best_neighbor_value_ratio=float(costs[best]/base) if base else None,
                native_executed_next_state_reproduced_exactly=True,
                actions=candidates.tolist(),values=[float(value) for value in costs],
                centered_values=[float(value-base) for value in costs])
            records.append(record);print(json.dumps({k:v for k,v in record.items() if not isinstance(v,list)}),flush=True)
    finally:env.close()
    dump_json(dict(not_solution=True,benchmark_evidence=False,reserved_seeds_used=False,
        source_episode=file_metadata(args.episode),value_provenance=provenance,parameters=vars(args),runtime=runtime_metadata(),
        records=records,predictor_transition_calls=predictor.evaluations,wall_seconds=time.monotonic()-begun,
        scope='Saved actual states, isolated native forecasts, adjacent float32 actions. Pointwise lower next-step value does not establish a better full episode or stability.'),out/'result.json')
if __name__=='__main__':main()
