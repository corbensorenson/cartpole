#!/usr/bin/env python
"""Compare virtual capture initialization with inherited executed maintenance."""
import argparse,json,time
from pathlib import Path
import mpmath,numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.evidence import file_metadata,runtime_metadata
from scripts.transfer_physical_capture_route import transfer_physical_nodes
from scripts.synthesize_inverse_increment import exact_candidate_passed
from scripts.solve_frontier_capture_increment import validate_development_seeds

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for key in ('source','source-config','config','stationary-metric-source','directory'):p.add_argument('--'+key,required=True)
 p.add_argument('--seed',type=int,default=20265100);args=p.parse_args();out=Path(args.directory)
 if (out/'result.json').exists():raise FileExistsError(out)
 source=json.loads(Path(args.source).read_text());sourcecfg=load_config(args.source_config);cfg=load_config(args.config);metric=json.loads(Path(args.stationary_metric_source).read_text());n=cfg['env']['n_links'];dt=cfg['env']['timestep']*cfg['env']['frame_skip'];prefix=len(source['controller']['controls']);tail=round(5/dt)
 validate_development_seeds(n,args.seed)
 if sourcecfg['env']['n_links']+1!=n or not exact_candidate_passed(source,sourcecfg) or dt!=sourcecfg['env']['timestep']*sourcecfg['env']['frame_skip'] or len(metric['selected_state']['qpos'])!=n+1 or len(source['result']['trajectory'])<prefix+tail:raise ValueError('passed adjacent complete physical maintenance source required')
 transform=np.asarray(source['controller']['coordinate_transform']);initial=np.linalg.solve(transform,np.asarray(source['search']['nominal_coordinate_states'])[0]);rows=source['result']['trajectory'][:prefix+tail]
 states=np.vstack([initial,[r['qpos']+r['qvel'] for r in rows]]);actions=np.asarray([r['action'] for r in rows],dtype=np.float32).astype(float)
 if not np.array_equal(actions[:prefix],np.asarray(source['controller']['controls'],dtype=np.float32).astype(float)):raise ValueError('source prefix controls differ from executed actions')
 physical=transfer_physical_nodes(states,n);target=np.zeros(2*(n+1));target[1:n+1]=2*np.pi*np.round(physical[prefix,1:n+1]/(2*np.pi));virtual=np.vstack([physical[:prefix+1],np.repeat(target[None],tail,axis=0)]);virtual_actions=np.r_[actions[:prefix],np.zeros(tail)]
 env=NLinkCartPoleEnv(cfg,progress=1.,seed=args.seed);env.reset(seed=args.seed);predictor=MujocoTransition(env,np.eye(2*(n+1)),continuous_angles=True);ctx=mpmath.mp.clone();ctx.dps=100;factor=ctx.matrix(metric['lyapunov']['factor']);records=[];began=time.monotonic()
 try:
  for label,nodes,u in [('virtual_zero',virtual,virtual_actions),('inherited_physical',physical,actions)]:
   rows=[]
   for step in range(prefix,prefix+tail):
    nxt=predictor(nodes[step],u[step]);gap=ctx.matrix(nxt.tolist())-ctx.matrix(nodes[step+1].tolist());phi=np.cumsum(nodes[step+1,1:n+1]);velocity=np.cumsum(nodes[step+1,n+2:])
    rows.append(dict(step=step,time_seconds=step*dt,physical_maximum_gap=float(max(abs(z) for z in gap)),stationary_weighted_gap_norm=float(ctx.norm(factor*gap)),maximum_absolute_angle=float(np.max(np.abs((phi+np.pi)%(2*np.pi)-np.pi))),absolute_angular_velocity_rms=float(np.sqrt(np.mean(velocity**2))),action=float(u[step])))
   records.append(dict(label=label,rows=rows,maximum_tail_gap=max(r['physical_maximum_gap'] for r in rows),maximum_stationary_weighted_gap_norm=max(r['stationary_weighted_gap_norm'] for r in rows),maximum_absolute_angle=max(r['maximum_absolute_angle'] for r in rows),maximum_absolute_action=max(abs(r['action']) for r in rows)))
 finally:env.close()
 proposal=out/'physical_tail_initializer.json';dump_json(dict(not_solution=True,initialization_only=True,selected_state=dict(qpos=physical[0,:n+1].tolist(),qvel=physical[0,n+1:].tolist()),seed=args.seed,source=file_metadata(args.source),source_config=file_metadata(args.source_config),config=file_metadata(args.config),source_count=n-1,n_links=n,controller=dict(type='adjacent_material_physical_route_and_executed_capture_tail',continuous_angles=True,physical_shooting=True,coordinate_transform=np.eye(2*(n+1)).tolist(),controls=actions.tolist(),feedback_gains=np.zeros_like(physical[:-1]).tolist(),feedback_placeholder=True,capture_start_seconds=prefix*dt,capture_tail_seconds=tail*dt,angle_branch_terminal_target=target.tolist()),search=dict(nominal_coordinate_states=physical.tolist()),scope='All source states/actions are actually executed, including maintenance. Target dynamics feasibility is not inherited; offline variables only, never live state projection.'),proposal)
 dump_json(dict(not_solution=True,benchmark_evidence=False,reserved_seeds_used=False,noisy_development_seeds_used=False,parameters=vars(args),source=file_metadata(args.source),stationary_metric_source=file_metadata(args.stationary_metric_source),runtime=runtime_metadata(),records=records,physical_tail_initializer=file_metadata(proposal),prefix_nodes_and_actions_identical=True,prefix_steps=prefix,tail_steps=tail,native_transition_calls=predictor.evaluations,wall_seconds=time.monotonic()-began,scope='Offline target-count tail defect comparisons on native transitions. Stationary weighting is not a moving capture certificate; no full physical episode or synthesis.'),out/'result.json')
 print(json.dumps([{k:v for k,v in r.items() if k!='rows'} for r in records]),flush=True)
if __name__=='__main__':main()
