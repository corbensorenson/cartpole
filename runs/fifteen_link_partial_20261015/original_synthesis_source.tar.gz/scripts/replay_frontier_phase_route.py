#!/usr/bin/env python
"""Change only route-index selection on a saved frontier tracking controller."""
import argparse
import json
import subprocess
import sys
from pathlib import Path

import numpy as np

from gcartpole.config import dump_json, load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata
from gcartpole.ilqr import MujocoTransition
from gcartpole.route_feedback import inherited_tracking_replay_command
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.search_fddp_capture import warm_start_diagnostics
from scripts.solve_frontier_capture_increment import physical_replay_passed, validate_development_seeds


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('source', 'config', 'directory'):
        parser.add_argument('--' + key, required=True)
    parser.add_argument('--phase-window', type=int, default=12)
    args = parser.parse_args()
    source, out = Path(args.source), Path(args.directory)
    if (out / 'result.json').exists():
        raise FileExistsError(out)
    prior = json.loads(source.read_text())
    cfg = load_config(args.config)
    c = prior['controller']
    validate_development_seeds(cfg['env']['n_links'], prior['seed'])
    if (args.phase_window < 1 or c['phase_adaptive'] or not c['continuous_angles']
            or len(prior['selected_state']['qpos']) != cfg['env']['n_links'] + 1
            or not np.array_equal(c['coordinate_transform'], np.eye(2 * (cfg['env']['n_links'] + 1)))):
        raise ValueError('Requires a physical-coordinate fixed-time source and positive phase window')
    execution = source.parent / 'synthesis/execution.json'
    if not execution.exists():
        execution = source.parent / 'execution.json'
    primitive = json.loads(execution.read_text())
    if primitive['status'] != 'finished' or primitive['returncode'] != 0:
        raise ValueError('Source must be completed')
    command = inherited_tracking_replay_command(primitive['command'])

    def set_arg(flag, value):
        if flag in command:
            command[command.index(flag) + 1] = str(value)
        else:
            command.extend([flag, str(value)])

    for flag, value in [('--config', args.config), ('--state-json', source),
        ('--initial-controller', source), ('--optimizer', 'sqrt-ilqr'),
        ('--out', out / 'synthesis/result.json'), ('--optimize-suffix-start-seconds', 0),
        ('--phase-window', args.phase_window)]:
        set_arg(flag, value)
    for flag, arity in [('--sparse-capture-angle-limit', 1), ('--enforce-rail-during-search', 0),
        ('--recompute-tracking-feedback', 0), ('--export-tracking-value-factors', 1),
        ('--capture-start-seconds', 1), ('--capture-stage-weight', 1), ('--capture-value-weight', 1)]:
        if flag in command:
            index = command.index(flag)
            del command[index:index + arity + 1]
    for flag in ('--replay-only', '--phase-adaptive'):
        if flag not in command:
            command.append(flag)
    subprocess.run([sys.executable, 'scripts/run_frontier_experiment.py', '--directory', str(out / 'synthesis'),
        '--input', str(source), '--input', str(execution), '--input', args.config, '--', *command], check=True)
    data = json.loads((out / 'synthesis/result.json').read_text())
    for key in ('controls', 'feedback_gains', 'coordinate_transform'):
        if not np.array_equal(data['controller'][key], c[key]):
            raise ValueError('Phase-only replay changed inherited ' + key)
    if not np.array_equal(data['search']['nominal_coordinate_states'], prior['search']['nominal_coordinate_states']):
        raise ValueError('Phase-only replay changed reference nodes')
    rows = data['result']['trajectory']
    initial = np.asarray(prior['selected_state']['qpos'] + prior['selected_state']['qvel'])
    env = NLinkCartPoleEnv(fixed_state_cfg(cfg, prior['selected_state'], 30.), progress=1., seed=prior['seed'])
    try:
        env.reset(seed=prior['seed'])
        predictor = MujocoTransition(env, np.eye(initial.size), continuous_angles=True)
        states = np.vstack([initial, [r['qpos'] + r['qvel'] for r in rows]])
        actions = np.asarray([r['action'] for r in rows], dtype=np.float32).astype(float)
        diagnostics = warm_start_diagnostics(predictor, initial, actions, states)
        if not diagnostics['is_exactly_feasible']:
            raise ValueError('Actual phase-policy tape did not reproduce exactly')
    finally:
        env.close()
    data['phase_only_comparison'] = dict(source=file_metadata(source), config=file_metadata(args.config),
        source_execution=file_metadata(execution), fixed_time_baseline_hold_seconds=prior['result']['max_upright_streak_seconds'],
        inherited_controls_and_gains_and_nodes_bit_identical=True, phase_adaptive=True,
        phase_window=args.phase_window, actual_tape_diagnostics=diagnostics,
        native_actual_tape_validation_transition_calls=len(rows),
        full_development_episode_passed=physical_replay_passed(data['result'], cfg),
        no_runtime_state_projection=True, reserved_seeds_used=False, noisy_development_seeds_used=False,
        scope='Only reference-index selection changes. Actual native physics stays uninterrupted. The accepted release protocol currently requires fixed-time tracking, so a phase-policy pass would require further physical materialization and the original canonical gates.')
    dump_json(data, out / 'result.json')
    print(json.dumps(dict(hold=data['result']['max_upright_streak_seconds'], length=data['result']['length'],
        full_pass=data['phase_only_comparison']['full_development_episode_passed'])))


if __name__ == '__main__':
    main()
