#!/usr/bin/env python
"""Native one-step probes in saved moving-value sensitive directions."""
import argparse,json,time
from pathlib import Path
import mpmath,numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,runtime_metadata,data_sha256
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for key in ('source','values','forcing-audit','config','directory'):p.add_argument('--'+key,required=True)
 args=p.parse_args();out=Path(args.directory)
 if (out/'result.json').exists():raise FileExistsError(out)
 source=json.loads(Path(args.source).read_text());values=json.loads(Path(args.values).read_text());audit=json.loads(Path(args.forcing_audit).read_text());nodes=np.asarray(source['search']['nominal_coordinate_states']);u=np.asarray(source['controller']['controls']);gains=np.asarray(source['controller']['feedback_gains'])
 if values['controls_sha256']!=data_sha256(u.tolist()) or values['nominal_states_sha256']!=data_sha256(nodes.tolist()) or values['config']!=file_metadata(args.config) or values['decimal_digits']!=100 or values['derivative_order']!=4 or values['known_defect_feedforward']:raise ValueError('value/source provenance mismatch')
 if source['controller']['tracking_feedback_design']['value_factor_export']!=file_metadata(args.values):raise ValueError('source does not bind exported factors')
 records=[];cfg=load_config(args.config);env=NLinkCartPoleEnv(cfg,progress=1.,seed=source['seed']);env.reset(seed=source['seed']);predictor=FourthOrderMujocoTransition(env,np.eye(nodes.shape[1]),continuous_angles=True);ctx=mpmath.mp.clone();ctx.dps=100;began=time.monotonic()
 norm=lambda x:ctx.norm(x)
 try:
  for step in (375,381):
   row=next(r for r in audit['records'] if r['step']==step);a,b=ctx.matrix(row['A']),ctx.matrix(row['B']);k=ctx.matrix(gains[step].tolist()).T;current=ctx.matrix(values['value_factors'][step]);future=ctx.matrix(values['value_factors'][step+1]);inverse=current**-1
   closed=future*(a+b*k)*inverse;_,singular,vh=np.linalg.svd(np.asarray(closed.tolist(),dtype=float));direction=inverse*ctx.matrix(vh[0].tolist());direction/=max(abs(x) for x in direction);physical=np.asarray(list(direction),dtype=float)
   native_a,native_b=predictor.linearize(nodes[step],float(np.float32(u[step])),state_epsilon=values['state_epsilon'],action_epsilon=values['action_epsilon']);native_a,native_b=ctx.matrix(native_a.tolist()),ctx.matrix(native_b.tolist());base=predictor(nodes[step],float(np.float32(u[step])))
   for amplitude in (1e-11,1e-9,1e-7,1e-5):
    for sign in (-1,1):
     x=nodes[step]+sign*amplitude*physical;error=ctx.matrix(x.tolist())-ctx.matrix(nodes[step].tolist());raw=float(u[step]+gains[step]@(x-nodes[step]));action=float(np.float32(np.clip(raw,-1.,1.)));delta=ctx.mpf(action)-ctx.mpf(float(np.float32(u[step])));next_state=predictor(x,action);increment=ctx.matrix(next_state.tolist())-ctx.matrix(base.tolist());analytic=a*error+b*delta;native=native_a*error+native_b*delta;incoming=norm(current*error)
     record=dict(step=step,time_seconds=step*env.dt,requested_physical_amplitude=amplitude,sign=sign,realized_physical_error=float(max(abs(z) for z in error)),incoming_value_norm=float(incoming),native_increment_value_norm=float(norm(future*increment)),analytic_prediction_value_norm=float(norm(future*analytic)),native_fd_prediction_value_norm=float(norm(future*native)),native_gain=float(norm(future*increment)/incoming),analytic_gain=float(norm(future*analytic)/incoming),native_fd_gain=float(norm(future*native)/incoming),analytic_remainder_value_norm=float(norm(future*(increment-analytic))),native_fd_remainder_value_norm=float(norm(future*(increment-native))),raw_action=raw,delivered_action=action,nominal_delivered_action=float(np.float32(u[step])),clipped=abs(raw)>1.,feedback_arithmetic_and_quantization_error=float(delta-(k*error)[0]),analytic_worst_singular_value=float(singular[0]),physical_direction=physical.tolist(),realized_error=[str(z) for z in error],native_increment=[str(z) for z in increment])
     records.append(record);print(json.dumps({k:v for k,v in record.items() if not isinstance(v,list)}),flush=True)
 finally:env.close()
 dump_json(dict(not_solution=True,benchmark_evidence=False,source=file_metadata(args.source),values=file_metadata(args.values),forcing_audit=file_metadata(args.forcing_audit),config=file_metadata(args.config),parameters=vars(args),runtime=runtime_metadata(),records=records,native_transition_calls=predictor.evaluations,wall_seconds=time.monotonic()-began,scope='Isolated native one-step increments. Nominal native forcing removed by paired subtraction. Direction selected from analytic model; finite-difference comparison is separately measured. No full episode, robustness guarantee or independent noise cohort.'),out/'result.json')
if __name__=='__main__':main()
