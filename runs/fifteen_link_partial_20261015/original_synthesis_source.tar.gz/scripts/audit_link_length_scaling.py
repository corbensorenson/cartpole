#!/usr/bin/env python
"""Separate link count from individual length in native geometry/capture audits."""
import argparse, json, time
from pathlib import Path
import mujoco
import numpy as np
from gcartpole.config import load_config, dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, runtime_metadata, utc_timestamp
from gcartpole.generalized_modes import chain_normal_modes
from gcartpole.lqr_design import high_precision_discrete_lqr
from gcartpole.upright_mechanics import upright_rk4_matrices
from scripts.audit_link_count_frontier import WEIGHTS, exact_capture
from scripts.make_lqr_checkpoint import absolute_angle_cost


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--configs',required=True,nargs='+')
    p.add_argument('--design-counts',type=int,nargs='+',default=[15])
    p.add_argument('--directory',required=True)
    p.add_argument('--study', choices=('link-length', 'joint-hub'), default='link-length')
    p.add_argument('--hub-mass-policy', choices=('fixed-total', 'constant-density'), default='fixed-total')
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    started=time.monotonic(); records=[]; designs=[]
    payload=dict(not_solution=True,canonical_release_evidence=False,
        generated_at=utc_timestamp(),parameters=vars(args),runtime=runtime_metadata(),
        geometry_records=records,local_designs=designs,actual_local_episode_steps=0,
        reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope=('Diagnostic geometry and local upright components. Only total length changes in paired same-count configurations.' if args.study == 'link-length' else 'Physical proximal disks attached rigidly to child links; rods and hinge spacing unchanged. ' + ('Fixed added hub mass across radius variants; the no-hub baseline has lower total mass.' if args.hub_mass_policy == 'fixed-total' else 'Hub mass scales with radius squared at fixed thickness and density within each link count; rod mass remains 1 kg. Radius and mass change together.')) + ' No hanging-start or canonical count promotion is inferred.',
        references=['https://mujoco.readthedocs.io/en/3.3.5/XMLreference.html#body-joint-armature'])
    matrices={}
    for cfgpath in args.configs:
        cfg=load_config(cfgpath);n=cfg['env']['n_links']
        env=NLinkCartPoleEnv(cfg,progress=1.,seed=0);env.reset(seed=0)
        try:
            modes=chain_normal_modes(env)
            a,b,mechanics=upright_rk4_matrices(env,decimal_digits=100)
            inertia=[]
            for quat,principal in zip(env.model.body_iquat[2:],env.model.body_inertia[2:]):
                rotation=np.zeros(9);mujoco.mju_quat2Mat(rotation,quat)
                inertia.append(float(np.sum(rotation.reshape(3,3)[1]**2*principal)))
            inertia=np.asarray(inertia);mass=env.model.body_mass[2:]
            local_hinge=inertia+mass*np.sum(env.model.body_ipos[2:][:,[0,2]]**2,axis=1)
            armature=env.model.dof_armature[1:]
            record=dict(config=file_metadata(cfgpath),n_links=n,total_length_m=float(env.morphology.total_length),
                lengths_m=env.morphology.lengths.tolist(),total_chain_mass_kg=float(np.sum(mass)),
                link_masses_kg=mass.tolist(),link_radius_m=float(cfg['env']['link_radius']),
                joint_hub_radius_m=float(cfg['env'].get('joint_hub_radius',0.)),
                joint_hub_mass_kg=float(cfg['env'].get('joint_hub_mass',0.)),
                total_added_hub_mass_kg=n*float(cfg['env'].get('joint_hub_mass',0.)),
                joint_hub_half_width_m=float(cfg['env'].get('joint_hub_half_width',.0125)),
                cylinder_hinge_axis_inertia_kg_m2=.5*float(cfg['env'].get('joint_hub_mass',0.))*float(cfg['env'].get('joint_hub_radius',0.))**2,
                compiled_body_com_z_m=env.model.body_ipos[2:,2].tolist(),
                native_xml_sha256=__import__('hashlib').sha256(env.xml.encode()).hexdigest(),
                diameter_to_link_length=(2*cfg['env']['link_radius']/env.morphology.lengths).tolist(),
                hinge_armature=armature.tolist(),body_com_inertia_about_hinge_axis=inertia.tolist(),
                body_own_inertia_about_proximal_hinge=local_hinge.tolist(),
                armature_to_body_com_inertia=(armature/inertia).tolist(),
                armature_to_body_own_hinge_inertia=(armature/local_hinge).tolist(),
                ratio_scope='Own-body ratios only; a joint also moves descendant bodies. These are geometry diagnostics, not whole-chain inertia or causal difficulty measures.',
                fastest_hanging_frequency_hz=float(np.max(modes.angular_frequencies)/(2*np.pi)),
                smallest_hanging_normalized_input_coupling=float(np.min(np.abs(modes.normalized_coupling))),
                hanging_joint_mass_condition=float(np.linalg.cond(modes.joint_mass_matrix)),
                upright_per_control_tick_growth=float(np.max(np.abs(np.linalg.eigvals(np.asarray(a.tolist(),float))))),
                control_hz=1/env.dt,mechanics=mechanics)
            records.append(record);matrices[cfgpath]=(a,b,cfg)
            print(json.dumps({k:record[k] for k in ('n_links','total_length_m','fastest_hanging_frequency_hz','upright_per_control_tick_growth')}),flush=True)
        finally:env.close()
        dump_json(payload,out/'result.progress.json')
    for cfgpath,(a,b,cfg) in matrices.items():
        n=cfg['env']['n_links']
        if n not in args.design_counts:continue
        case=dict(config=file_metadata(cfgpath),n_links=n,total_length_m=cfg['env']['total_length'],
            component_episode_seconds=30.,physical_perturbation_coordinates='Paired relative hinge angles and relative hinge velocities; no reset noise cohort.',local_capture={})
        designs.append(case);design_started=time.monotonic()
        try:
            q=absolute_angle_cost(n,WEIGHTS);r=np.array([[1000.]])
            gain,_,diagnostics=high_precision_discrete_lqr(a.tolist(),b.tolist(),q,r,
                decimal_digits=100,preserve_input_precision=True)
            case.update(gain=gain.ravel().tolist(),design_diagnostics=diagnostics,
                design_wall_seconds=time.monotonic()-design_started)
            directions=np.random.default_rng(20265500+n).uniform(-1,1,(4,2*n))
            case['paired_directions']=directions.tolist()
            for amplitude in (1e-5,1e-9,1e-13):
                episodes=[exact_capture(cfg,dict(qpos=np.r_[0.,amplitude*v[:n]].tolist(),
                    qvel=np.r_[0.,amplitude*v[n:]].tolist()),gain.ravel(),seconds=30.) for v in directions]
                case['local_capture'][str(amplitude)]=dict(successes=sum(x['success'] and x['termination_reason']=='time_limit' and x['steps']==1500 and x['trajectory_clean'] and x['max_hold_seconds']>=5 and x['max_cart_excursion']<=3 for x in episodes),episodes=episodes)
                payload['actual_local_episode_steps']+=sum(x['steps'] for x in episodes)
        except (ValueError,np.linalg.LinAlgError,ZeroDivisionError) as error:
            case.update(error=f'{type(error).__name__}: {error}',design_wall_seconds=time.monotonic()-design_started)
        dump_json(payload,out/'result.progress.json')
        print(json.dumps(dict(n_links=n,total_length_m=case['total_length_m'],gain_norm=case.get('design_diagnostics',{}).get('gain_norm'),error=case.get('error'),successes={k:v['successes'] for k,v in case['local_capture'].items()})),flush=True)
    payload['wall_seconds']=time.monotonic()-started
    dump_json(payload,out/'result.json')

if __name__=='__main__':main()
