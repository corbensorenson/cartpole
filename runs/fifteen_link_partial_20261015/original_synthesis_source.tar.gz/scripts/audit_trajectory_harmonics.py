"""Read-only provenance and numerical consistency audit for trajectory spectra."""
import argparse,json
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.trajectory_spectra import (welch_summary,projected_modal_rates,
    first_sustained_upright_tick)

def read(p):return json.loads(Path(p).read_text())
def checked(r):assert file_metadata(r['path'])==r,r['path']
def refs(v):
    if isinstance(v,dict):
        if all(k in v for k in ('path','bytes','sha256')):yield v
        else:
            for x in v.values():yield from refs(x)
    elif isinstance(v,list):
        for x in v:yield from refs(x)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',required=True);args=p.parse_args()
    root=Path(args.directory);d=read(root/'diagnostic/result.json');j=read(root/'execution.json')
    assert j['status']=='finished' and j['returncode']==0
    for r in j['frozen_inputs']:assert file_metadata(root/'snapshot'/r['path'])['sha256']==r['sha256']
    for r in refs(d):checked(r)
    assert d['total_native_transition_calls']==d['native_transition_ceiling']==0
    source=read(d['source']['path']);route=read(d['route_audit']['path'])
    allowed={r['path']:r for r in refs(source)}
    for study in route['studies']:
        for r in refs(read(study['result']['path'])):allowed[r['path']]=r
    mode_rows={r['tag']:r for r in d['mode_catalog']};rows=[]
    for r in d['mode_catalog']:
        V=np.array(r['modes']['relative_shapes']);M=np.array(r['modes']['joint_mass_matrix']);K=np.array(r['modes']['stiffness_matrix'])
        squared=np.array(r['modes']['squared_frequencies'])
        assert np.all(squared>0) and np.allclose(V.T@M@V,np.eye(r['n_links']),atol=1e-11)
        assert np.linalg.norm(K@V-(M@V)*squared)/np.linalg.norm(K@V)<1e-11
        assert np.array_equal(np.sqrt(squared)/(2*np.pi),np.array(r['frequencies_hz']))
    for r in d['traces']:
        assert allowed[r['tape']['path']]==r['tape']
        tape=np.load(r['tape']['path']);states=tape['states'];actions=tape['actions'];sp=np.load(r['spectra']['path'])
        mode=mode_rows[r['basis_tag']]['modes'];projector=np.array(mode['relative_shapes']).T@np.array(mode['joint_mass_matrix'])
        assert np.array_equal(sp['force_N'],actions*80.)
        assert np.array_equal(sp['modal_rates'],projected_modal_rates(states[:-1],r['n_links'],projector))
        begin=first_sustained_upright_tick(states,r['n_links'],50.)
        assert r['first_sustained_upright_start_seconds']==(None if begin is None else begin/50.)
        gate=bool(len(actions)==1500 and begin is not None and np.max(np.abs(states[:,0]))<=3.)
        assert gate==r['full_episode_gate_passed']
        for phase in r['phases']:
            if not phase['estimated']:continue
            lo,hi=phase['start_tick'],phase['end_tick'];spec=welch_summary(actions[lo:hi]*80.,50.)
            assert np.array_equal(sp[phase['label']+'_force_psd'],spec['psd'])
            assert phase['force']['covered_samples']+phase['force']['unused_tail_samples']==hi-lo
            for i in range(r['n_links']):
                ms=welch_summary(sp['modal_rates'][lo:hi,i],50.)
                assert np.array_equal(sp[phase['label']+'_modal_rate_psd'][i],ms['psd'])
                if phase['force']['segments']<3:assert not phase['modes'][i]['force_motion_coherence']['estimated']
        rows.append(dict(tag=r['tag'],tape=r['tape'],spectra=r['spectra'],full_episode_gate_passed=gate,steps=len(actions)))
    raw_path=Path('runs/harmonics_reconnaissance_20261003/diagnostic/result.json');raw=read(raw_path)
    for a,b in zip(raw['traces'],d['traces']):
        assert a['tag']==b['tag'];x=np.load(a['spectra']['path']);y=np.load(b['spectra']['path'])
        for key in x.files:
            translated=key.replace('balance_','post_capture_')
            assert np.array_equal(x[key],y[translated])
    figures=root/'diagnostic/figures/figures.json'
    for ref in refs(read(figures)):checked(ref)
    a=next(r for r in d['traces'] if r['tag']=='armature0.99_affine14')
    b=next(r for r in d['traces'] if r['tag']=='armature0.99_handoff9')
    x=np.load(a['tape']['path']);y=np.load(b['tape']['path'])
    assert x['states'][:451].tobytes()==y['states'][:451].tobytes() and x['actions'][:450].tobytes()==y['actions'][:450].tobytes()
    verified=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),passed=True,
        execution=file_metadata(root/'execution.json'),result=file_metadata(root/'diagnostic/result.json'),
        original_analysis=file_metadata(raw_path),figure_metadata=file_metadata(figures),
        frozen_inputs_checked=len(j['frozen_inputs']),trace_count=len(rows),mode_plant_count=len(mode_rows),
        rows=rows,corrected_spectral_arrays_byte_identical_to_original=True,
        all_tapes_bound_to_independently_replayed_source_results=True,
        canonical_release_evidence=False,not_solution=True,native_transition_calls_for_this_audit=0,
        total_new_native_transition_calls=0)
    dump_json(verified,root/'verified.json');print(json.dumps(dict(passed=True,traces=len(rows),mode_plants=len(mode_rows),native_calls=0)))

if __name__=='__main__':main()
