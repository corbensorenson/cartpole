#!/usr/bin/env python
"""Test frozen upright gains after the same uninterrupted native cold prefix."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.search_ilqr_capture import execute_controller
from scripts.search_fddp_capture import warm_start_diagnostics
from scripts.solve_frontier_capture_increment import validate_development_seeds,physical_replay_passed


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ('source','config','capture-cache','pole-component','directory'):parser.add_argument('--'+key,required=True)
    parser.add_argument('--start-seconds',type=float,default=7.5)
    args=parser.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    source=json.loads(Path(args.source).read_text());cache=json.loads(Path(args.capture_cache).read_text())
    component=json.loads(Path(args.pole_component).read_text());cfg=load_config(args.config)
    n=cfg['env']['n_links'];nx=2*(n+1);dt=cfg['env']['timestep']*cfg['env']['frame_skip']
    start=round(args.start_seconds/dt);steps=round(30/dt);c=source['controller']
    validate_development_seeds(n,source['seed'])
    if (cache['source']!=file_metadata(args.source) or cache['config']!=file_metadata(args.config)
            or not 0<start<len(c['controls']) or not np.isclose(start*dt,args.start_seconds)
            or not c['continuous_angles'] or c['phase_adaptive'] or not np.array_equal(c['coordinate_transform'],np.eye(nx))):
        raise ValueError('source-aligned physical coordinates and on-grid prefix required')
    controls=np.asarray(c['controls']);nodes=np.asarray(source['search']['nominal_coordinate_states']);gains=np.asarray(c['feedback_gains'])
    if len(controls)<steps:
        controls=np.r_[controls,np.zeros(steps-len(controls))]
        nodes=np.vstack([nodes,np.zeros((steps+1-len(nodes),nx))])
        gains=np.vstack([gains,np.zeros((steps-len(gains),nx))])
    else:controls=controls[:steps];nodes=nodes[:steps+1];gains=gains[:steps]
    cfg=fixed_state_cfg(cfg,source['selected_state'],30.);factor=np.asarray(source['lyapunov']['factor'])
    began=time.monotonic();payload=dict(not_solution=True,canonical_release_evidence=False,parameters=vars(args),
        source=file_metadata(args.source),config=file_metadata(args.config),capture_cache=file_metadata(args.capture_cache),
        pole_component=file_metadata(args.pole_component),runtime=runtime_metadata(),records=[],
        optimizer_transition_calls=0,actual_episode_steps=0,actual_tape_validation_transition_calls=0,
        reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Same exact hanging-start source prefix,then frozen rounded upright gain at the declared switch,continuing native F32 saturated control to30s or physical termination. Input-model-unstable rounded gains skipped explicitly. No live state edits or resets during episodes. Nominal physical pass alone is not an accepted record.')
    for design in component['records']:
        if design['n_links']!=n:continue
        record=dict(method=design['method'],decay_factor=design['decay_factor']);payload['records'].append(record)
        if 'error' in design:record['skipped']=design['error'];continue
        if float(design['design_diagnostics']['rounded_gain_high_precision_spectral_radius'])>=1:
            record['skipped']='rounded runtime gain does not stabilize its input model';continue
        if design['resolved_config']!=load_config(args.config):raise ValueError('pole design configuration differs from actual plant')
        gain=np.asarray(design['gain'])
        def selector(step,state,baseline):
            if step<start:return baseline,None
            physical=state.copy();physical[1:n+1]=wrap_angle(physical[1:n+1])
            raw=float(-gain@physical)
            return float(np.clip(raw,-1,1)),dict(frozen_pole_capture=True,raw_action=raw)
        result=execute_controller(cfg,progress=1.,seed=source['seed'],controls=controls,
            nominal_states=nodes,feedback_gains=gains,gain=np.asarray(cache['gain']),lqr_scale=c['lqr_scale'],
            transform=np.eye(nx),lyapunov=factor.T@factor,lyapunov_factor=factor,
            handoff_lyapunov=c['handoff_lyapunov'],handoff_cart_abs=c['handoff_cart_abs'],
            handoff_angle_abs=c['handoff_angle_abs'],handoff_cart_velocity_abs=c['handoff_cart_velocity_abs'],
            handoff_hinge_velocity_rms=c['handoff_hinge_velocity_rms'],defer_handoff_until_horizon=True,
            continuous_angles=True,tracking_mode='frozen_pole_capture',tracking_action_selector=selector)
        rows=result['trajectory'];prior=source['result']['trajectory']
        if len(rows)<start or any(np.asarray(a['qpos']+a['qvel']).tobytes()!=np.asarray(b['qpos']+b['qvel']).tobytes()
                or np.float32(a['action']).tobytes()!=np.float32(b['action']).tobytes() for a,b in zip(rows[:start],prior[:start])):
            raise ValueError('actual cold prefix differs byte for byte')
        initial=np.asarray(source['selected_state']['qpos']+source['selected_state']['qvel'])
        states=np.vstack([initial,[r['qpos']+r['qvel'] for r in rows]])
        actions=np.asarray([r['action'] for r in rows],np.float32).astype(float)
        env=NLinkCartPoleEnv(cfg,progress=1.,seed=source['seed']);env.reset(seed=source['seed'])
        try:
            native=MujocoTransition(env,np.eye(nx),continuous_angles=True)
            physical=warm_start_diagnostics(native,initial,actions,states)
            if not physical['is_exactly_feasible'] or physical['maximum_dynamics_defect']!=0:
                raise ValueError('actual pole policy tape failed exact independent replay')
            if native.evaluations!=len(rows):raise ValueError('native tape replay budget mismatch')
        finally:env.close()
        record.update(result=result,physical_tape_diagnostics=physical,full_development_episode_passed=physical_replay_passed(result,cfg),
            inherited_prefix_states_and_actions_byte_identical=True,actual_tape_validation_transition_calls=len(rows))
        payload['actual_episode_steps']+=len(rows);payload['actual_tape_validation_transition_calls']+=len(rows)
        payload['wall_seconds']=time.monotonic()-began;dump_json(payload,out/'result.progress.json')
        print(json.dumps(dict(factor=design['decay_factor'],hold=result['max_upright_streak_seconds'],
            length=result['length'],full_pass=record['full_development_episode_passed'])),flush=True)
    payload['wall_seconds']=time.monotonic()-began;dump_json(payload,out/'result.json')


if __name__=='__main__':main()
