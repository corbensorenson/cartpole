"""Scientific figure from audited actual tapes; no new native transitions."""
import argparse,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.config import dump_json


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',required=True);a=p.parse_args();root=Path(a.directory)
    audit=json.loads((root/'verified.json').read_text());assert audit['passed'];out=root/'figures';out.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    fig,axes=plt.subplots(2,2,figsize=(11.2,7.1));sources=[]
    base=audit['studies'][0];bt=np.load(base['tape']['path'])
    for column,ratio in enumerate((.97,.95)):
        rows=[r for r in audit['studies'] if f'/target{ratio}/' in r['directory']]
        ax=axes[0,column];ax.plot(np.arange(len(bt['states']))*.02,bt['states'][:,0],color='black',alpha=.5,lw=1.2,label='0.98 unchanged passing source')
        episodes=[]
        for r in rows:
            iteration='8+8' if '16' in r['name'] else '8'
            if r['name']=='capture_suffix8':iteration='suffix 8'
            if 'tape' in r:episodes.append((f'{iteration}: saved solver',r))
            episodes.extend((f'{iteration}: MP affine',rr) for rr in r.get('records',[]) if rr.get('affine'))
            episodes.extend((f"Handoff {rr['handoff_seconds']:g}s",rr) for rr in r.get('records',[]) if rr.get('handoff_seconds') in (8.,9.))
        colors=plt.cm.tab10(np.arange(len(episodes))%10)
        for color,(label,r) in zip(colors,episodes):
            sources.append(r['tape']);tt=np.load(r['tape']['path']);x=tt['states'];t=np.arange(len(x))*.02
            ax.plot(t,x[:,0],color=color,lw=1.3,label=label)
            angle=np.max(abs(wrap_angle(np.cumsum(x[:,1:15],axis=1))),axis=1)
            axes[1,column].plot(t,angle,color=color,lw=1.1)
        ax.axhline(3,color='#a33838',ls='--',lw=.8);ax.axhline(-3,color='#a33838',ls='--',lw=.8)
        ax.set(title=f'Target armature factor {ratio}',ylabel='Actual cart position (m)',xlim=(0,15),ylim=(-3.25,3.25))
        bx=axes[1,column];bx.axhline(.15,color='#a33838',ls='--',lw=.8);bx.set(xlabel='Actual native time (s)',ylabel='Maximum absolute angle (rad)',xlim=(0,15),ylim=(0,3.3))
        for aa in (ax,bx):aa.grid(alpha=.15)
    fig.suptitle('A preserved physical swing supports another armature step',fontsize=15,y=.99)
    handles,labels=axes[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,.945),ncol=4,fontsize=8.5,frameon=False)
    fig.text(.5,.018,'Exact hanging start; 14 links; 50 Hz; F32 actions. First 15s shown; failed curves end. 8+8 means restarted repairs.\n0.97 handoffs 9--13s pass full 30s; 0.95 handoffs 8/9s fail. Altered components; canonical fifteen remains unsolved.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.065,1,.87));png=out/'adaptive_native_swing.png';pdf=out/'adaptive_native_swing.pdf';fig.savefig(png,dpi=180);fig.savefig(pdf);plt.close(fig)
    dump_json(dict(generated_at=utc_timestamp(),script=file_metadata(__file__),audit=file_metadata(root/'verified.json'),sources=[base['tape'],*sources],artifacts=[file_metadata(png),file_metadata(pdf)],native_transition_calls=0,scope='Actual native trajectories and sampled rails/upright threshold; no spectral or causal conclusion.'),out/'figures.json')
    print(png)

if __name__=='__main__':main()
