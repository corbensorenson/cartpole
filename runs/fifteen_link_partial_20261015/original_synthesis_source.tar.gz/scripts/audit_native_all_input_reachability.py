"""Diagnose all-input real affine reachability and delivered/native model agreement."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.native_action_lattice import affine_action_lattice
from gcartpole.native_integer_continuation import normalized_bound_model,source_known_tape
from gcartpole.native_real_minimax import bounded_real_minimax,checked_affine_prediction,quantized_box_trial,checked_bound_model
from gcartpole.native_bound_objective import bound_diagnostics,native_bound_score
from gcartpole.native_task_derivatives import physical_task_residual,chained_physical_task_jacobian
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('source','directory'):p.add_argument('--'+key,required=True)
    p.add_argument('--physical-halfwidths',nargs='+',type=float,default=[1e-4,1e-3,1e-2])
    p.add_argument('--solver-seconds',type=float,default=10.)
    p.add_argument('--frozen-model-source')
    p.add_argument('--fixed-prefixes',nargs='+',type=int)
    p.add_argument('--suffix-physical-boxes',action='store_true')
    p.add_argument('--complete-model-comparison',action='store_true')
    p.add_argument('--derivative-scale',type=float,default=1.)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    if (not args.physical_halfwidths or args.physical_halfwidths!=sorted(set(args.physical_halfwidths))
            or any(not np.isfinite(v) or not 0<v<=.1 for v in args.physical_halfwidths)
            or not np.isfinite(args.solver_seconds) or args.solver_seconds<=0):raise ValueError('ordered finite bounded physical boxes required')
    if not np.isfinite(args.derivative_scale) or not .125<=args.derivative_scale<=4:raise ValueError('bounded finite derivative scale required')
    began=time.monotonic();source=json.loads(Path(args.source).read_text());root=source;root_ref=file_metadata(args.source);ancestry=[];seen=set()
    if not source['live_state_unchanged'] or source['parameters']['bound_objective']!='maximum':raise ValueError('verified maximum-bound source required')
    while not all(k in root for k in ('config','teacher','parameters')):
        metadata=root['source']
        if metadata['path'] in seen or len(ancestry)>=8 or file_metadata(metadata['path'])!=metadata:raise ValueError('changed/cyclic root')
        seen.add(metadata['path']);ancestry.append(metadata);root_ref=metadata;root=json.loads(Path(metadata['path']).read_text())
    for key in ('source','config','teacher'):
        if file_metadata(root[key]['path'])!=root[key]:raise ValueError('physical input changed')
    base=json.loads(Path(root['source']['path']).read_text());cfg=load_config(root['config']['path'])
    state_epsilon=base['controller']['state_epsilon']*args.derivative_scale
    action_epsilon=base['controller']['action_epsilon']*args.derivative_scale
    n=cfg['env']['n_links'];nx=2*(n+1);start=root['parameters']['start_step'];rate=root['parameters']['rate_residual_weight']
    limit=source['parameters']['forecast_angle_limit'];center=np.asarray(source['last_finite_center'],float);h=len(center)
    parent=None
    if source.get('selected_sequence') is None and 'known_plan_score' not in source:
        metadata=source['repaired_from']
        if file_metadata(metadata['path'])!=metadata:raise ValueError('known-plan score parent changed')
        parent=json.loads(Path(metadata['path']).read_text())
    known,known_states,known_score=source_known_tape(source,parent)
    if not len(known)<h or cfg['env']['timestep']!=.005 or cfg['env']['frame_skip']!=4:
        raise ValueError('known shorter valid tape and canonical50Hz source required')
    spacing,lower,upper=affine_action_lattice(center,4096)
    frozen=None
    if args.frozen_model_source and not args.fixed_prefixes:raise ValueError('frozen model requires declared fixed prefixes')
    if args.suffix_physical_boxes and not args.fixed_prefixes:raise ValueError('physical suffix boxes require fixed prefixes')
    if args.fixed_prefixes and (args.fixed_prefixes!=sorted(set(args.fixed_prefixes)) or any(not 0<k<h for k in args.fixed_prefixes)):
        raise ValueError('ordered nonempty suffix domains required')
    if args.frozen_model_source:
        frozen=json.loads(Path(args.frozen_model_source).read_text())
        if (frozen['repaired_from']!=file_metadata(args.source) or not frozen['source_final_states_and_score_exact']
                or not frozen['known_source_score_exact'] or not frozen['live_state_unchanged']
                or args.fixed_prefixes!=sorted(set(args.fixed_prefixes)) or any(not 0<k<h for k in args.fixed_prefixes)
                or frozen['parameters'].get('derivative_scale',1.)!=args.derivative_scale
                or file_metadata(frozen['affine_bound_model']['path'])!=frozen['affine_bound_model']):
            raise ValueError('exact source-aligned frozen model and ordered suffix domains required')
    reference=np.asarray(base['controller']['controls'][start:start+h],np.float32).astype(float)
    if len(reference)!=h:raise ValueError('reference cannot be padded')
    boxes=[dict(label='all_input_f32_radius4096',lower=spacing*lower,upper=spacing*upper)]
    for width in args.physical_halfwidths:
        boxes.append(dict(label=f'all_input_physical_halfwidth_{width:g}',physical_halfwidth=width,
            lower=np.maximum(-width,-1-center),upper=np.minimum(width,1-center)))
    if not args.fixed_prefixes:
        for previous,following in zip(boxes,boxes[1:]):
            if np.any(following['lower']>previous['lower']) or np.any(following['upper']<previous['upper']):raise ValueError('declared physical boxes must be nested')
    if args.fixed_prefixes:
        if args.suffix_physical_boxes:
            boxes=[dict(label=f'physical_halfwidth_{width:g}_fixed_prefix_{k}',
                lower=np.maximum(-width,-1-center),upper=np.minimum(width,1-center),fixed_prefix=k)
                for k in args.fixed_prefixes for width in args.physical_halfwidths]
        else:
            boxes=[dict(label=f'all_input_f32_radius4096_fixed_prefix_{k}',lower=spacing*lower,upper=spacing*upper,
                        fixed_prefix=k) for k in args.fixed_prefixes]
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True);local=FourthOrderMujocoTransition(env,np.eye(nx),continuous_angles=True)
    untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
    try:
        state=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
        for row in base['result']['trajectory'][:start]:
            state=native(state,float(np.float32(row['action'])))
            if state.tobytes()!=np.asarray(row['qpos']+row['qvel']).tobytes():raise ValueError('cold prefix changed')
        def forecast(actions):
            current=state.copy();states=[]
            for u in actions:current=native(current,float(u));states.append(current.copy())
            return np.asarray(states)
        def measure(states,actions):
            d=bound_diagnostics(states,n,limit,env.rail_limit);r=physical_task_residual(states,n,rate,.1)
            return native_bound_score(d,float(r@r+1e-4*np.sum((actions-reference[:len(actions)])**2)),'maximum'),d
        replay=forecast(known)
        if replay.tobytes()!=known_states.tobytes() or list(measure(replay,known)[0])!=known_score or not measure(replay,known)[1]['feasible']:
            raise ValueError('known source plan/state/score changed')
        states=forecast(center);score,initial=measure(states,center)
        if states.tobytes()!=np.asarray(source['last_finite_states']).tobytes() or list(score)!=source['last_finite_score']:
            raise ValueError('failed longer source tape/score changed')
        prefix_calls=native.evaluations
        if frozen is None:
            jac=chained_physical_task_jacobian(local,state,center,states,n_links=n,rate_weight=rate,
                state_epsilon=state_epsilon,action_epsilon=action_epsilon,angle_band=0.)
            if local.evaluations!=(4*nx+6)*h:raise ValueError('native derivative accounting changed')
            values,response=normalized_bound_model(states,jac,np.ones(h),n,limit,env.rail_limit)
            out.mkdir(parents=True,exist_ok=True);model_path=out/'affine_bound_model.npz'
            np.savez_compressed(model_path,values=values,response=response,task_jacobian=jac,
                center=center,states=states,prefix_state=state,spacing=spacing,lattice_lower=lower,lattice_upper=upper)
        else:
            model_path=Path(frozen['affine_bound_model']['path'])
            with np.load(model_path,allow_pickle=False) as model:
                values,response=checked_bound_model(model,center,states,state,n,limit,env.rail_limit)
        records=[];best=center.copy();best_states=states.copy();found=False;visited={center.tobytes()}
        def solved_boxes():
            for box in boxes:
                active=np.arange(box.get('fixed_prefix',0),h)
                before=time.monotonic();partial,diagnostic=bounded_real_minimax(response[:,active],values,box['lower'][active],box['upper'][active],solver_seconds=args.solver_seconds)
                record=dict(label=box['label'],lower=box['lower'].tolist(),upper=box['upper'].tolist(),
                    active_inputs=active.tolist(),fixed_prefix=box.get('fixed_prefix',0),
                    model=diagnostic,solver_and_check_wall_seconds=time.monotonic()-before,native_trials=[])
                records.append(record)
                if partial is not None:
                    full=np.zeros(h);full[active]=partial
                    record.update(real_control_delta=full.tolist(),real_model_margin_pass=diagnostic['checked_normalized_peak']<1)
                yield box,active,partial,record
        models=list(solved_boxes()) if args.complete_model_comparison else solved_boxes()
        for box,active,partial,record in models:
            diagnostic=record['model']
            if partial is None:continue
            delta=np.zeros(h);delta[active]=partial
            record.update(real_control_delta=delta.tolist(),real_model_margin_pass=diagnostic['checked_normalized_peak']<1)
            for exponent in range(10):
                fraction=2.**(-exponent);actions=quantized_box_trial(center,delta,box['lower'],box['upper'],fraction)
                fixed=box.get('fixed_prefix',0)
                if actions[:fixed].tobytes()!=center[:fixed].tobytes():raise ValueError('fixed early inputs changed')
                if actions.tobytes() in visited:continue
                visited.add(actions.tobytes());prediction=checked_affine_prediction(response,values,actions-center)
                trial=dict(fraction=fraction,sequence=actions.tolist(),changed_inputs=int(np.count_nonzero(actions!=center)),
                    maximum_control_change=float(np.max(np.abs(actions-center))),
                    delivered_predicted_normalized_peak=float(np.max(np.abs(prediction))),
                    delivered_predicted_maximum_angle=float(np.max(np.abs(prediction[:n*h]))*limit),
                    quantization_maximum_error=float(np.max(np.abs(actions-(center+delta*fraction)))))
                record['native_trials'].append(trial)
                try:
                    candidate=forecast(actions);new_score,d=measure(candidate,actions)
                    trial.update(native_score=list(new_score),native_bound_diagnostics=d)
                    if new_score<score:score=new_score;best=actions.copy();best_states=candidate.copy()
                    if d['feasible']:found=True;break
                except SimulationError as error:trial['invalid_forecast']=str(error)
            print(json.dumps(dict(box=box['label'],model=diagnostic,found=found)),flush=True)
            if found:break
        planning_calls=native.evaluations-prefix_calls;checked=forecast(best)
        if checked.tobytes()!=best_states.tobytes() or measure(checked,best)[0]!=score:raise ValueError('final finite tape/state/score proof changed')
        if untouched.tobytes()!=np.r_[env.data.qpos,env.data.qvel].tobytes():raise ValueError('diagnostic changed live state')
        fixed=min(args.fixed_prefixes) if args.fixed_prefixes else 0
        if best[:fixed].tobytes()!=center[:fixed].tobytes():raise ValueError('exported early inputs changed')
        ceiling=start+len(known)+h+local.evaluations+(len(boxes)*10+1)*h
        if native.evaluations+local.evaluations>ceiling:raise ValueError('frozen total native budget exceeded')
        data=dict(parameters=dict(**vars(args),forecast_angle_limit=limit,bound_objective='maximum'),source=root_ref,
            repaired_from=file_metadata(args.source),input_ancestry=ancestry,affine_bound_model=file_metadata(model_path),
            frozen_affine_model_source=file_metadata(args.frozen_model_source) if frozen else None,
            derivative_state_epsilon=state_epsilon,derivative_action_epsilon=action_epsilon,
            records=records,horizon_steps=h,known_plan=known.tolist(),known_plan_states=known_states.tolist(),known_plan_score=list(known_score),
            initial_sequence=center.tolist(),initial_score=source['last_finite_score'],initial_bound_diagnostics=initial,
            last_finite_center=best.tolist(),last_finite_states=best_states.tolist(),last_finite_score=list(score),
            feasible_sequence_found=found,selected_sequence=best.tolist() if found else None,selected_states=best_states.tolist() if found else None,
            final_bound_diagnostics=measure(checked,best)[1],source_final_states_and_score_exact=True,
            fixed_early_input_count=fixed,fixed_early_inputs_byte_identical=True,
            known_plan_byte_identical=True,known_source_score_exact=True,live_state_unchanged=True,independent_final_plan_replay_byte_identical=True,
            native_prefix_and_initial_forecast_transition_calls=prefix_calls,native_planning_transition_calls=planning_calls,
            independent_last_finite_plan_replay_transition_calls=h,native_forecast_transition_calls=native.evaluations,
            native_local_derivative_transition_calls=local.evaluations,total_native_transition_calls=native.evaluations+local.evaluations,
            total_native_transition_ceiling=ceiling,actual_episode_steps=0,optimizer_transition_calls=0,
            reserved_seeds_used=False,noisy_development_seeds_used=False,not_solution=True,canonical_release_evidence=False,
            runtime=runtime_metadata(),wall_seconds=time.monotonic()-began,
            scope=(f'Cold-reproduce knownH{len(known)}/finiteH{h}states and scores. '+
                (('Hash-bound native4/MP100 model reused with exact context/physical rows;fixed early prefix,physical suffix-box widening,no new derivatives. ' if args.suffix_physical_boxes else
                  'Hash-bound native4/MP100 model reused with exact context/physical rows;fixed early prefix and progressively smaller active suffixes in same F32 boxes,no new derivatives. ') if frozen else
                 ('One fresh native4/MP100 physical model;fixed early prefix,real physical suffix trust boxes. ' if args.suffix_physical_boxes else
                  'One fresh native4/MP100 physical model;all-input real minimax in nested lattice/physical boxes. '))+
                'MP100 independently checks affine epigraph;bounded delivered F32 contractions and native full tapes decide validity. All finite candidates/model statuses retained;floating LP status is not rigorous global lower bound,nonlinear feasibility or record. Stop on new native margin pass for required actual cold full30.'))
        dump_json(data,out/'result.json');print(json.dumps(dict(found=found,maximum_angle=data['final_bound_diagnostics']['maximum_angle'],native_calls=data['total_native_transition_calls'])))
    finally:env.close()


if __name__=='__main__':main()
