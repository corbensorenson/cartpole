"""Read-only intervention coverage and probe-locality audit of completed comparisons."""
import argparse
import json
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--comparison',action='append',required=True)
    p.add_argument('--probe',required=True);p.add_argument('--output',required=True)
    args=p.parse_args();records=[]
    for path in args.comparison:
        data=json.loads(Path(path).read_text());source=json.loads(Path(data['source']['path']).read_text())
        start=data['parameters']['start_step'];end=data['parameters']['arrival_step']
        original=np.asarray([r['action'] for r in source['result']['trajectory'][start:end]],np.float32).astype(float)
        for row in data['records']:
            selected=np.asarray(row['selected_controls']);changed=np.flatnonzero(selected!=original)+start
            assert row['tape']==file_metadata(row['tape']['path'])
            rounds=[]
            for rr in row['rounds']:
                rounds.append(dict(iteration=rr['iteration'],improved=rr['improved'],
                    selected_divisor=rr['selected_divisor'],native_derivative_calls=rr['native_derivative_calls'],
                    native_candidate_calls=rr['native_candidate_calls'],
                    nonlocal_derivative_probes=sum(r['maximum_angle']>=.149 for r in rr.get('derivative_probes',[])),
                    recorded_derivative_probes=len(rr.get('derivative_probes',[])),
                    no_op_contractions=len(rr.get('no_op_divisors',[]))))
            records.append(dict(source=file_metadata(path),label=row['label'],
                changed_absolute_steps=changed.tolist(),changed_delivered_input_count=len(changed),
                first_changed_seconds=None if not len(changed) else float(changed[0]*.02),
                last_changed_seconds=None if not len(changed) else float(changed[-1]*.02),
                actual_hold_seconds=row['actual_hold_seconds'],full_nominal_gate_passed=row['full_nominal_gate_passed'],
                initial_score=row['initial_score'],final_score=row['final_score'],
                rounds=rounds,tape=row['tape'],total_native_transition_calls=row['total_native_transition_calls']))
    probe=json.loads(Path(args.probe).read_text());groups=[]
    for amplitude in probe['amplitudes']:
        rr=[r for r in probe['records'] if r['amplitude']==amplitude]
        nonzero=[r for r in rr if not r['no_op_after_f32']]
        passing=[r for r in nonzero if r['arrival_bounds_passed']]
        groups.append(dict(amplitude=amplitude,potential_probes=len(rr),no_op_probes=len(rr)-len(nonzero),
            executed_nonzero_probes=len(nonzero),bounds_passing_nonzero_probes=len(passing),
            passing_columns=sorted({r['column'] for r in passing}),
            earliest_passing_first_changed_step=min([r['first_changed_absolute_step'] for r in passing],default=None)))
    dump_json(dict(generated_at=utc_timestamp(),script=file_metadata(__file__),
        records=records,probe=file_metadata(args.probe),probe_groups=groups,native_transition_calls=0,
        actual_episode_steps=0,scope='Read-only full delivered intervention coverage and sampled whole-arrival probe locality. Earlier smooth independent probes fail or become F32 no-ops; no physical impossibility claim. Affine diagnostics in comparisons use ideal knot changes and include delivery/derivative/nonlinearity discrepancies.'),args.output)


if __name__=='__main__':main()
