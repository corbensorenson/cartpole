#!/usr/bin/env python
"""Compare linear proposals with their native physical-task forecast costs."""
import argparse,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',required=True);parser.add_argument('--directory',required=True)
    args=parser.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    data=json.loads(Path(args.source).read_text())
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    fig,axes=plt.subplots(1,len(data['records']),figsize=(10,4.7),layout='constrained')
    for ax,row in zip(axes,data['records']):
        points=sorted(row['secants'],key=lambda s:s['epsilon'],reverse=True)
        x=[p['epsilon'] for p in points]
        ax.loglog(x,[p['native_candidate_physical_cost'] for p in points],'-o',color='#243a50',label='Native proposal forecast')
        ax.loglog(x,[p['linear_predicted_physical_cost'] for p in points],'--s',color='#b65739',label='Linear prediction')
        ax.axhline(row['baseline_physical_cost'],color='#43816a',ls=':',lw=1.6,label='Retained plan')
        ax.set(title=f"Actual state at {row['controller_time_seconds']:.2f} s",
            xlabel='Requested F32 action secant',xticks=[1e-3,1e-5,1e-7])
        ax.invert_xaxis();ax.grid(axis='y',alpha=.15)
    axes[0].set_ylabel('Physical forecast task cost');axes[0].legend(fontsize=8,loc='best')
    fig.suptitle('Long-horizon linear proposals need native validation',fontsize=14)
    fig.supxlabel('H32 / rate1: bounded linear proposals evaluated from three fixed actual states.\nMarkers are measured secants; lines guide the eye. Forecast costs do not establish episode success.',fontsize=9)
    out.mkdir(parents=True,exist_ok=True);outputs=[]
    for suffix in ('png','pdf','svg'):
        p=out/f'comparison.{suffix}';fig.savefig(p,dpi=180);outputs.append(file_metadata(p))
    plt.close(fig)
    dump_json(dict(not_solution=True,canonical_release_evidence=False,source=file_metadata(args.source),outputs=outputs,
        native_transition_calls=0,scope='Source-bound plotting; no new physics or controller pass.'),out/'result.json')


if __name__=='__main__':main()
