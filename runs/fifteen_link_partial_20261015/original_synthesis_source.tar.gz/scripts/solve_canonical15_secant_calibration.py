"""Matched native secant/trust calibration, then physical continuation refinement."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.native_trust_minimax import affine_trust_proposal
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix
from scripts.solve_canonical15_native_minimax import features,gain_raw,first_proposals
from gcartpole.native_minimax import bounded_affine_minimax
read=lambda p:json.loads(Path(p).read_text())
def physical_features(states,m):
 angles=wrap_angle(np.cumsum(states[:,1:16],axis=1))/m['angle_limit'];return np.r_[angles.reshape(-1),states[:,0]/m['rail_limit']]
def score(states,raws,h,m):
 if len(states)!=h:return (1,1,1e100,1e100,0)
 f=physical_features(states,m);safe=(np.max(abs(wrap_angle(np.cumsum(states[:,1:16],axis=1))),axis=1)<m['angle_limit'])&(abs(states[:,0])<=m['rail_limit']);bad=np.flatnonzero(~safe);prefix=int(bad[0]) if len(bad) else h;excess=np.maximum(abs(f)-1,0)
 return (0,0 if np.all(safe) else 1,float(np.max(abs(f))),float(excess@excess),-prefix)
def basis_for(h,m):
 first=m['tracking_steps'];tail=h-first;basis=np.zeros((h,m['tracking_knots']+tail));basis[:first,:m['tracking_knots']]=interpolation_matrix(m['tracking_knots'],first);basis[first:,m['tracking_knots']:]=np.eye(tail);return basis

def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--directory',required=True);a=p.parse_args();m=read(a.manifest);out=Path(a.directory);out.mkdir(exist_ok=False);(out/'private').mkdir();s=read(m['source']['path']);base=read(s['source']['path']);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in s['result']['trajectory']]]);U=np.asarray([q['action'] for q in s['result']['trajectory']],np.float32).astype(float);start=m['start_step'];track=m['tracking_steps'];gain=np.asarray(read(m['gain_source']['path'])['gain'])
 for key in ('source','config','tracking_array','tracking_audit','source_audit','gain_source','center_tape'):assert m[key]==file_metadata(m[key]['path'])
 assert read(m['tracking_audit']['path'])['passed'] and read(m['source_audit']['path'])['passed']
 with np.load(m['tracking_array']['path']) as z:K=z['gains'][m['tracking_variant_index']];assert z['states'].tobytes()==X[start:start+track+1].tobytes()
 cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);env=NLinkCartPoleEnv(cfg,progress=1.,seed=m['nominal_seed']);env.reset(seed=m['nominal_seed']);native=MujocoTransition(env,np.eye(32),continuous_angles=True);actual_ticks=0;began=time.monotonic();payload=dict(status='running',generated_at=utc_timestamp(),manifest=file_metadata(a.manifest),script=file_metadata(__file__),helper=file_metadata('src/gcartpole/native_trust_minimax.py'),runtime=runtime_metadata(),private_forecasts=[],calibrations=[],refinement=[],stages=[],actual_records=[],maintenance_decisions=[],not_solution=True,canonical_release_evidence=False,noisy_development_seeds_used=False,reserved_seeds_used=False)
 def forecast(ff,label,kind):
  xs=[X[start].copy()];us=[];raws=[];err=None;failed_post_state=np.full(32,np.nan);failed_time=np.nan
  try:
   for i,value in enumerate(ff):
    raw=float(value)+float(K[i]@(xs[-1]-X[start+i])) if i<track else float(value);u=float(np.float32(np.clip(raw,-1,1)));us.append(u);raws.append(raw);xs.append(native(xs[-1],u))
  except SimulationError as e:err=f'SimulationError: {e}';failed_post_state=np.r_[native.data.qpos,native.data.qvel].copy();failed_time=float(native.data.time)
  tape=out/'private'/f'forecast_{len(payload["private_forecasts"]):05d}.npz';np.savez_compressed(tape,states=np.asarray(xs),actions=np.asarray(us),raw_actions=np.asarray(raws),feedforward=np.asarray(ff),failed_post_state=failed_post_state,failed_time=np.asarray(failed_time));row=dict(index=len(payload['private_forecasts']),label=label,kind=kind,tape=file_metadata(tape),error=err,attempted_steps=len(us),completed_steps=len(xs)-1,score=list(score(np.asarray(xs)[1:],np.asarray(raws),len(ff),m)));payload['private_forecasts'].append(row);return dict(row=row,states=np.asarray(xs),raws=np.asarray(raws),actions=np.asarray(us),ff=np.asarray(ff).copy(),score=tuple(row['score']))
 def maintenance(state,tick,last,label):
  om=m['maintenance'];pairs=[];calls=[];errors=[]
  def evaluate(x,raw,role):
   u=float(np.float32(np.clip(raw,-1,1)));pair=np.full((2,32),np.nan);pair[0]=x;error=None
   try:pair[1]=native(x,u)
   except SimulationError as e:error=f'SimulationError: {e}'
   index=len(calls);calls.append((pair,u,float(raw),role));errors.append(error);return index,pair[1] if error is None else None
  mi,minus=evaluate(state,-1.,'first_minus');pi,plus=evaluate(state,1.,'first_plus')
  if minus is None or plus is None:raise RuntimeError('Maintenance anchor failed; preserve new failed evidence')
  proposal=bounded_affine_minimax(features(minus,0.,om),features(plus,0.,om));raw=gain_raw(gain,state);source=float(U[tick]) if tick<len(U) else 0.;commands,pr=first_proposals(raw,proposal,source,last,om)
  for i,u in enumerate(commands):
   fi,first=evaluate(state,float(u),f'first_{i}');row=dict(index=i,first_id=fi,second_minus_id=None,second_plus_id=None,second_id=None,second_raw=None,score=[1,1e100,abs(float(u))])
   if first is not None:
    sm,minus=evaluate(first,-1.,f'second_minus_{i}');sp,plus=evaluate(first,1.,f'second_plus_{i}');row.update(second_minus_id=sm,second_plus_id=sp)
    if minus is not None and plus is not None:
     raw2=bounded_affine_minimax(features(minus,0.,om),features(plus,0.,om));si,second=evaluate(first,raw2,f'second_selected_{i}');row.update(second_id=si,second_raw=raw2)
     if second is not None:row['score']=[0,float(max(np.max(abs(features(first,0.,om))),np.max(abs(features(second,0.,om))))),abs(float(u))]
   pairs.append(row)
  winner=min(range(len(pairs)),key=lambda i:tuple(pairs[i]['score']));tape=out/'private'/f'maintenance_{len(payload["maintenance_decisions"]):05d}.npz';np.savez_compressed(tape,states=np.asarray([c[0] for c in calls]),actions=np.asarray([c[1] for c in calls]),raw_actions=np.asarray([c[2] for c in calls]),roles=np.asarray([c[3] for c in calls]),candidate_actions=commands,candidate_raw_proposals=pr);d=dict(label=label,tick=tick,tape=file_metadata(tape),errors=errors,first_minus_id=mi,first_plus_id=pi,proposal=proposal,gain_raw=raw,source_action=source,last_action=last,candidates=pairs,winner_index=winner);payload['maintenance_decisions'].append(d)
  if pairs[winner]['score'][0]:raise RuntimeError('No complete maintenance forecast')
  return float(commands[winner]),calls[pairs[winner]['first_id']][0][1]
 def actual_episode(label,selected,h):
  nonlocal actual_ticks
  actual=NLinkCartPoleEnv(cfg,progress=1.,seed=m['nominal_seed']);actual.reset(seed=m['nominal_seed']);xs=[initial.copy()];us=[];raws=[];info=None;reason=None
  try:
   for tick in range(actual.max_steps):
    state=np.r_[actual.data.qpos,actual.data.qvel]
    if tick<start:raw=float(U[tick]);u=raw
    elif tick<start+h:
     i=tick-start;raw=float(selected['ff'][i])+float(K[i]@(state-X[tick])) if i<track else float(selected['ff'][i]);u=float(np.float32(np.clip(raw,-1,1)))
    else:u,prediction=maintenance(state,tick,float(us[-1]),label);raw=u
    _,_,terminated,truncated,info=actual.step([u]);actual_ticks+=1;x=np.r_[actual.data.qpos,actual.data.qvel];xs.append(x.copy());us.append(u);raws.append(raw)
    if tick<start:assert x.tobytes()==X[tick+1].tobytes()
    elif tick<start+h:assert x.tobytes()==selected['states'][tick-start+1].tobytes()
    else:assert x.tobytes()==prediction.tobytes()
    if terminated or truncated:reason=info['termination_reason'];break
  finally:
   actual.close();tape=out/(label+'_actual.npz');np.savez_compressed(tape,states=np.asarray(xs),actions=np.asarray(us),raw_actions=np.asarray(raws))
  for tick,u in enumerate(us):assert native(xs[tick],float(u)).tobytes()==xs[tick+1].tobytes()
  safe=np.max(abs(wrap_angle(np.cumsum(np.asarray(xs)[1:,1:16],axis=1))),axis=1)<.15;streak=longest=0
  for ok in safe:streak=streak+1 if ok else 0;longest=max(longest,streak)
  maxcart=float(np.max(abs(np.asarray(xs)[:,0])));passed=len(us)==1500 and longest>=250 and maxcart<=3 and reason=='time_limit' and not info['simulation_error'];row=dict(label=label,horizon=h,selected_forecast=selected['row']['tape'],selected_forecast_index=selected['row']['index'],tape=file_metadata(tape),actual_hanging_start_episode_steps=len(us),hold_seconds=longest*.02,maximum_cart=maxcart,termination_reason=reason,simulation_error=info['simulation_error'],full_nominal_gate_passed=passed);payload['actual_records'].append(row);print(row,flush=True)
 try:
  for tick in range(start+track):assert native(X[tick],float(U[tick])).tobytes()==X[tick+1].tobytes()
  h=m['calibration_horizon'];basis=basis_for(h,m)
  with np.load(m['center_tape']['path']) as z:initialff=z['feedforward'].copy();expected_center=z['states'].copy()
  center=forecast(initialff,'calibration_center','initial');assert center['states'].tobytes()==expected_center.tobytes();payload['initial_forecast']=center['row']['index'];best=center;best_case=None
  def model(center,basis,eps,label):
   columns=[];pairs=[];valid=True
   for k in range(basis.shape[1]):
    plus=forecast(center['ff']+eps[k]*basis[:,k],label,f'plus_{k}');minus=forecast(center['ff']-eps[k]*basis[:,k],label,f'minus_{k}');pairs.append([plus['row']['index'],minus['row']['index']])
    if plus['score'][0] or minus['score'][0]:valid=False
    elif valid:columns.append((physical_features(plus['states'][1:],m)-physical_features(minus['states'][1:],m))/(2*eps[k]))
   return np.column_stack(columns) if valid else None,pairs
  def propose(center,basis,eps,tracking_radius,jac,pairs,label):
   horizon=len(center['ff']);radii=np.r_[np.full(m['tracking_knots'],tracking_radius),np.full(horizon-track,m['tail_trust_radius'])];row=dict(label=label,center_before=center['row']['index'],derivative_pairs=pairs,derivative_epsilons=eps.tolist(),trust_radii=radii.tolist(),backtracks=[],accepted=None,parameter_step=None)
   if jac is None:row.update(status='incomplete_secant_forecasts',center_after=center['row']['index']);return center,row
   f=physical_features(center['states'][1:],m);delta,lp=affine_trust_proposal(f,jac,radii,action_values=center['ff'],action_basis=basis,solver_seconds=m['lp_seconds']);row['lp']=lp;row['parameter_step']=None if delta is None else delta.tolist();selected=center
   if delta is not None:
    for power in range(m['backtrack_powers']):
     candidate=forecast(center['ff']+basis@(delta/(2**power)),label,f'backtrack_{power}');bt=dict(power=power,forecast_index=candidate['row']['index'])
     if not candidate['score'][0]:
      pred=f+jac@(delta/(2**power));actual=physical_features(candidate['states'][1:],m);bt.update(predicted_physical_peak=float(np.max(abs(pred))),observed_physical_peak=float(np.max(abs(actual))),maximum_normalized_prediction_error=float(np.max(abs(pred-actual))))
     row['backtracks'].append(bt)
     if candidate['score']<center['score']:selected=candidate;row['accepted']=candidate['row']['index'];break
   row['center_after']=selected['row']['index'];return selected,row
  for epsilon in m['tracking_epsilons']:
   eps=np.r_[np.full(m['tracking_knots'],epsilon),np.full(h-track,m['tail_epsilon'])];jac,pairs=model(center,basis,eps,f'eps{epsilon:g}')
   for radius in m['tracking_trust_radii']:
    label=f'eps{epsilon:g}_trust{radius:g}';selected,row=propose(center,basis,eps,radius,jac,pairs,label);row.update(tracking_epsilon=epsilon,tracking_trust_radius=radius);payload['calibrations'].append(row)
    if selected['score']<best['score']:best=selected;best_case=len(payload['calibrations'])-1
    print(dict(calibration=label,selected_score=selected['score'],accepted=row['accepted'],calls=native.evaluations+actual_ticks),flush=True);dump_json(payload,out/'result.progress.json')
  payload['selected_calibration_case']=best_case
  if best_case is not None:
   chosen=payload['calibrations'][best_case];epsilon=chosen['tracking_epsilon'];radius=chosen['tracking_trust_radius']
   for iteration in range(m['refinement_iterations']):
    if best['score'][0] or best['score'][1]==0:break
    eps=np.r_[np.full(m['tracking_knots'],epsilon),np.full(h-track,m['tail_epsilon'])];jac,pairs=model(best,basis,eps,f'refine_{iteration}');selected,row=propose(best,basis,eps,radius,jac,pairs,f'refine_{iteration}');row['iteration']=iteration;payload['refinement'].append(row);best=selected
    print(dict(refinement=iteration,selected_score=best['score'],accepted=row['accepted'],calls=native.evaluations+actual_ticks),flush=True)
    if row['accepted'] is None:break
  payload['selected_forecast']=best['row']['index'];actual_episode('calibrated_h149',best,h)
  if best['score'][1]==0 and best_case is not None:
   for h in m['extension_horizons']:
    label=f'extension_h{h}';basis=basis_for(h,m);ff=U[start:start+h].copy();ff[:len(best['ff'])]=best['ff'];center=forecast(ff,label,'extension_initial');initial_index=center['row']['index'];history=[]
    for iteration in range(m['extension_iterations']):
     if center['score'][0] or center['score'][1]==0:break
     eps=np.r_[np.full(m['tracking_knots'],epsilon),np.full(h-track,m['tail_epsilon'])];jac,pairs=model(center,basis,eps,label+f'_round{iteration}');selected,row=propose(center,basis,eps,radius,jac,pairs,label+f'_round{iteration}');row['iteration']=iteration;history.append(row);center=selected
     if row['accepted'] is None:break
    payload['stages'].append(dict(label=label,horizon=h,initial_forecast=initial_index,selected_forecast=center['row']['index'],selected_score=list(center['score']),history=history));actual_episode(label,center,h);best=center;dump_json(payload,out/'result.progress.json')
    if best['score'][0] or best['score'][1]:break
  payload.update(status='finished',total_native_transition_calls=native.evaluations+actual_ticks,actual_hanging_start_episode_steps=actual_ticks,wall_seconds=time.monotonic()-began);assert payload['total_native_transition_calls']<=m['execution_native_transition_ceiling'];dump_json(payload,out/'result.json')
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}',total_native_transition_calls=native.evaluations+actual_ticks,actual_hanging_start_episode_steps=actual_ticks);dump_json(payload,out/'result.failed.json');raise
 finally:env.close()
if __name__=='__main__':main()
