"""Full hanging-start trials of native-verified two-step minimax control."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.native_minimax import bounded_affine_minimax
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg
read=lambda p:json.loads(Path(p).read_text())
def features(x,rate_weight,m):
    values=[wrap_angle(np.cumsum(x[1:16]))/m['angle_scale']]
    if rate_weight:values.append(rate_weight*np.cumsum(x[17:])/m['rate_scale'])
    values.append(np.asarray([x[0]/3,.1*x[16]/.5]));return np.concatenate(values)
def gain_raw(gain,x):
    physical=x.copy();physical[1:16]=wrap_angle(physical[1:16]);return -float(gain@physical)
def first_proposals(raw,proposal,source,last,m):
    nominal=float(np.clip(raw,-1,1));values=[proposal,-1.,1.,0.,source,last]+[proposal+(nominal-proposal)/(2**p) for p in range(m['backoff_powers'])];seen=set();commands=[];raws=[]
    for v in values:
        u=float(np.float32(np.clip(v,-1,1)));key=np.float32(u).tobytes()
        if key not in seen:seen.add(key);commands.append(u);raws.append(float(v))
    return np.asarray(commands),np.asarray(raws)
def main():
    p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--directory',required=True);a=p.parse_args();m=read(a.manifest);out=Path(a.directory);out.mkdir(exist_ok=False);(out/'private').mkdir();source=read(m['source']['path']);base=read(source['source']['path']);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in source['result']['trajectory']]]);U=np.asarray([q['action'] for q in source['result']['trajectory']],np.float32).astype(float);gain=np.asarray(read(m['gain_source']['path'])['gain'])
    for k in ('source','config','gain_source','source_audit'):assert m[k]==file_metadata(m[k]['path'])
    assert read(m['source_audit']['path'])['passed'];cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);assert cfg['env']['n_links']==15 and cfg['env']['timestep']==.005 and cfg['env']['frame_skip']==4 and base['seed']==20265100
    env=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);env.reset(seed=20265100);native=MujocoTransition(env,np.eye(32),continuous_angles=True);actual_ticks=0;began=time.monotonic();payload=dict(status='running',generated_at=utc_timestamp(),manifest=file_metadata(a.manifest),script=file_metadata(__file__),helper=file_metadata('src/gcartpole/native_minimax.py'),runtime=runtime_metadata(),decisions=[],records=[],actual_hanging_start_episode_steps=0,total_native_transition_calls=0,canonical_release_evidence=False,not_solution=True,noisy_development_seeds_used=False,reserved_seeds_used=False)
    try:
        for tick in range(m['start_step']):assert native(X[tick],float(U[tick])).tobytes()==X[tick+1].tobytes()
        for arm in m['arms']:
            label=arm['label'];rate_weight=arm['rate_weight'];actual=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);actual.reset(seed=20265100);xs=[initial.copy()];us=[];streak=longest=0;maxcart=0.;reason=None;info=None;arm_decisions=[]
            try:
                for tick in range(actual.max_steps):
                    state=np.r_[actual.data.qpos,actual.data.qvel]
                    if tick<m['start_step']:u=float(U[tick])
                    else:
                        if native.evaluations+actual_ticks+4*(m['backoff_powers']+6)+2+3500>m['execution_native_transition_ceiling']:reason='native_budget';break
                        oracle_states=[];oracle_actions=[];oracle_raws=[];oracle_completed=[];oracle_roles=[];errors=[]
                        def evaluate(x,raw,role):
                            u=float(np.float32(np.clip(raw,-1,1)));index=len(oracle_actions);oracle_actions.append(u);oracle_raws.append(float(raw));oracle_roles.append(role);prediction=np.full((2,32),np.nan);prediction[0]=x;error=None;completed=False
                            try:prediction[1]=native(x,u);completed=True
                            except SimulationError as e:error=f'SimulationError: {e}'
                            oracle_states.append(prediction);oracle_completed.append(completed);errors.append(error);return index,prediction[1] if completed else None
                        minus_id,minus=evaluate(state,-1.,'first_anchor_minus');plus_id,plus=evaluate(state,1.,'first_anchor_plus')
                        if minus is None or plus is None:
                            tape=out/'private'/f'{label}_{tick:04d}.npz';np.savez_compressed(tape,states=np.asarray(oracle_states),actions=np.asarray(oracle_actions),raw_actions=np.asarray(oracle_raws),completed=np.asarray(oracle_completed),roles=np.asarray(oracle_roles),candidate_actions=np.asarray([]),candidate_proposal_raws=np.asarray([]))
                            decision=dict(label=label,tick=tick,rate_weight=rate_weight,first_anchor_minus_id=minus_id,first_anchor_plus_id=plus_id,first_affine_proposal=None,candidates=[],winner_index=None,tape=file_metadata(tape),errors=errors,stopped_before_action=True);payload['decisions'].append(decision);arm_decisions.append(decision);reason='invalid_first_anchor';break
                        proposal=bounded_affine_minimax(features(minus,rate_weight,m),features(plus,rate_weight,m));raw=gain_raw(gain,state);reference=float(U[tick]) if tick<len(U) else 0.;last=float(us[-1]) if us else 0.;commands,proposal_raws=first_proposals(raw,proposal,reference,last,m);candidates=[]
                        for index,command in enumerate(commands):
                            first_id,first=evaluate(state,float(command),f'candidate_{index}_first');row=dict(index=index,first_action=float(command),first_id=first_id,second_minus_id=None,second_plus_id=None,second_id=None,second_raw=None,score=[1,1e100,abs(float(command))])
                            if first is not None:
                                sm_id,sm=evaluate(first,-1.,f'candidate_{index}_second_minus');sp_id,sp=evaluate(first,1.,f'candidate_{index}_second_plus');row.update(second_minus_id=sm_id,second_plus_id=sp_id)
                                if sm is not None and sp is not None:
                                    second_raw=bounded_affine_minimax(features(sm,rate_weight,m),features(sp,rate_weight,m));second_id,second=evaluate(first,second_raw,f'candidate_{index}_second_selected');row.update(second_id=second_id,second_raw=second_raw)
                                    if second is not None:row['score']=[0,float(max(np.max(abs(features(first,rate_weight,m))),np.max(abs(features(second,rate_weight,m))))),abs(float(command))]
                            candidates.append(row)
                        winner=min(range(len(candidates)),key=lambda i:tuple(candidates[i]['score']));selected=candidates[winner];tape=out/'private'/f'{label}_{tick:04d}.npz';np.savez_compressed(tape,states=np.asarray(oracle_states),actions=np.asarray(oracle_actions),raw_actions=np.asarray(oracle_raws),completed=np.asarray(oracle_completed),roles=np.asarray(oracle_roles),candidate_actions=commands,candidate_proposal_raws=proposal_raws)
                        decision=dict(label=label,tick=tick,rate_weight=rate_weight,first_anchor_minus_id=minus_id,first_anchor_plus_id=plus_id,first_affine_proposal=proposal,gain_raw_action=raw,source_proposal=reference,last_action=last,candidates=candidates,winner_index=winner,tape=file_metadata(tape),errors=errors);payload['decisions'].append(decision);arm_decisions.append(decision)
                        if selected['score'][0]:reason='no_complete_forecast';break
                        u=selected['first_action'];predicted=oracle_states[selected['first_id']][1]
                    _,_,terminated,truncated,info=actual.step([u]);actual_ticks+=1;x=np.r_[actual.data.qpos,actual.data.qvel];xs.append(x.copy());us.append(u)
                    if tick<m['start_step']:assert x.tobytes()==X[tick+1].tobytes()
                    else:assert x.tobytes()==predicted.tobytes()
                    angle=float(np.max(abs(wrap_angle(np.cumsum(x[1:16])))));streak=streak+1 if angle<.15 else 0;longest=max(longest,streak);maxcart=max(maxcart,abs(float(x[0])))
                    if tick>=m['start_step'] and tick%25==0:print(json.dumps(dict(label=label,tick=tick,hold_seconds=longest*.02,maximum_angle=angle,cart=x[0],calls=native.evaluations+actual_ticks)),flush=True)
                    if terminated or truncated:reason=info['termination_reason'];break
            finally:actual.close()
            tape=out/(label+'_actual.npz');np.savez_compressed(tape,states=np.asarray(xs),actions=np.asarray(us))
            for tick,u in enumerate(us):assert native(xs[tick],float(u)).tobytes()==xs[tick+1].tobytes()
            passed=len(us)==1500 and longest*.02>=5 and maxcart<=3 and reason=='time_limit' and not info['simulation_error'];row=dict(label=label,rate_weight=rate_weight,actual_hanging_start_episode_steps=len(us),hold_seconds=longest*.02,maximum_cart=maxcart,termination_reason=reason,full_nominal_gate_passed=passed,tape=file_metadata(tape),actual_prefix_and_first_prediction_byte_exact=True,whole_actual_tape_byte_exact=True,decisions=len(arm_decisions));payload['records'].append(row);payload.update(total_native_transition_calls=native.evaluations+actual_ticks,actual_hanging_start_episode_steps=actual_ticks);dump_json(payload,out/'result.progress.json');print(row,flush=True)
        payload.update(status='finished',total_native_transition_calls=native.evaluations+actual_ticks,actual_hanging_start_episode_steps=actual_ticks,wall_seconds=time.monotonic()-began);assert payload['total_native_transition_calls']<=m['execution_native_transition_ceiling'];dump_json(payload,out/'result.json')
    except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}',total_native_transition_calls=native.evaluations+actual_ticks,actual_hanging_start_episode_steps=actual_ticks);dump_json(payload,out/'result.failed.json');raise
    finally:env.close()
if __name__=='__main__':main()
