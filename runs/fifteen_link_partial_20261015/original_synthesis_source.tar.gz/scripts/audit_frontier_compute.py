#!/usr/bin/env python
"""Summarize retained search work without counting orchestration wrappers twice.

This reads completed development artifacts. Job times can overlap and backend
iteration counts have different meanings; neither is a serial speed benchmark.
"""
import argparse
from collections import Counter
import json
from pathlib import Path

from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata, utc_timestamp


def summarize(path):
    data = json.loads(path.read_text())
    execution_path = path.parent/'synthesis/execution.json'
    if not execution_path.is_file():
        execution_path = path.parent/'execution.json'
    execution = json.loads(execution_path.read_text())
    if execution.get('status') != 'finished' or execution.get('returncode') != 0:
        raise ValueError('compute summary requires a completed execution: '+str(path))
    if not any(Path(arg).name == 'search_fddp_capture.py' for arg in execution['command']):
        raise ValueError('expected a primitive search execution, not an orchestration wrapper')
    primitive_result = execution_path.parent/'result.json'
    original = json.loads(primitive_result.read_text())
    if any(data[key] != original[key] for key in ('controller','search','selected_state','result')):
        raise ValueError('wrapper result differs from its primitive search artifact')
    controller, search = data['controller'], data['search']
    history = search['optimizer_history']
    backends = {}
    for row in history:
        backend = row.get('qp_solver')
        if backend is None:
            continue
        record = backends.setdefault(backend, dict(history_rows=0,reported_native_iterations=0,
            missing_iteration_counts=0,native_accepted_rows=0,statuses=Counter(),residual_definitions=set(),
            maximum_variables=0,maximum_constraint_rows=0))
        record['history_rows'] += 1
        iterations = row.get('qp_iterations')
        if iterations is None:
            record['missing_iteration_counts'] += 1
        else:
            record['reported_native_iterations'] += int(iterations)
        record['native_accepted_rows'] += int(row.get('qp_native_accepted') is True)
        record['statuses'][str(row.get('qp_status'))] += 1
        record['residual_definitions'].add(row.get('qp_residual_definition'))
        record['maximum_variables'] = max(record['maximum_variables'],row.get('qp_variables',0))
        record['maximum_constraint_rows'] = max(record['maximum_constraint_rows'],row.get('qp_constraint_rows',0))
    for record in backends.values():
        record['statuses'] = dict(record['statuses'])
        record['residual_definitions'] = sorted(x for x in record['residual_definitions'] if x is not None)
    n = len(data['selected_state']['qpos'])-1
    return dict(source=file_metadata(path),primitive_result=file_metadata(primitive_result),
        primitive_execution=file_metadata(execution_path),
        n_links=n,optimizer=controller['optimizer'],requested_outer_iterations=controller['iterations'],
        reported_outer_iterations=search['iterations'],history_rows=len(history),
        accepted_history_rows=sum(row.get('accepted') is True for row in history),
        search_wall_seconds=search['wall_time_seconds'],primitive_job_wall_seconds=execution['wall_time_seconds'],
        horizon_steps=controller['horizon_steps'],horizon_seconds=controller['horizon_seconds'],
        initializer_capture_start_seconds=controller['capture_start_seconds'],
        transition_evaluation_budget=controller.get('transition_evaluation_budget'),qp_work_by_backend=backends,
        final_maximum_native_gap=controller['final_trajectory_diagnostics']['maximum_dynamics_defect'],
        actual_episode={key:data['result'][key] for key in ('length','termination_reason','success','max_upright_streak_seconds')})


def audit(paths):
    records, duplicates, seen = [], [], set()
    for path in paths:
        record = summarize(Path(path))
        key = record['primitive_execution']['sha256']
        if key in seen:
            duplicates.append(record['source'])
            continue
        seen.add(key);records.append(record)
    return dict(schema_version=1,generated_at=utc_timestamp(),not_solution=True,benchmark_promotion=False,
        records=records,duplicate_wrapper_results_not_counted=duplicates,
        totals=dict(unique_primitive_jobs=len(records),
            sum_search_job_seconds=sum(row['search_wall_seconds'] for row in records),
            sum_primitive_job_seconds=sum(row['primitive_job_wall_seconds'] for row in records),
            optimization_transition_calls=sum((row['transition_evaluation_budget'] or {}).get('optimization',0) for row in records),
            jobs_missing_transition_budget=sum(row['transition_evaluation_budget'] is None for row in records)),
        scope='Completed declared input artifacts only; not the total project search budget. Primitive execution identities deduplicate copied wrapper results. Search times cover optimization; primitive job times include its setup/replay. Concurrent job times are additive compute occupancy, not campaign elapsed time. Backend iteration totals remain separate and are only the iterations reported in saved histories. Native transition budget scope is retained per job; its physics-step upper bound is not an exact simulator-step count.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--result',action='append',required=True)
    parser.add_argument('--out',required=True)
    args = parser.parse_args()
    path = Path(args.out)
    if path.exists():
        raise FileExistsError(path)
    result = audit(args.result)
    dump_json(result,path)
    print(json.dumps(result['totals']))


if __name__ == '__main__':
    main()
