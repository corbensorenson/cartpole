"""Read completed pilot tapes and measure present versus delayed model projections."""
import argparse
import json
from pathlib import Path

import mpmath
import numpy as np

from gcartpole.angles import wrap_angle
from gcartpole.config import load_config, dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, runtime_metadata
from gcartpole.upright_mechanics import upright_rk4_matrices


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', required=True)
    p.add_argument('--out', required=True)
    args = p.parse_args()
    out = Path(args.out)
    if out.exists():
        raise FileExistsError(out)
    data = json.loads(Path(args.source).read_text())
    assert file_metadata(data['config']['path']) == data['config']
    cfg = load_config(data['config']['path'])
    env = NLinkCartPoleEnv(cfg, progress=1., seed=0); env.reset(seed=0)
    a, b, _ = upright_rk4_matrices(env, decimal_digits=100); env.close()
    ctx = mpmath.mp.clone(); ctx.dps = 100
    a, b = ctx.matrix(a.tolist()), ctx.matrix(b.tolist())
    records = []
    for row in data['records']:
        gain = data['gains'][row['gain_label']]
        k = ctx.matrix([gain]); closed = a-b*k
        following_output = k*closed
        result = row['result']; states = np.asarray(result['states'])
        assert result['every_selected_forecast_matches_live_state_bytes'] and result['independent_actual_tape_replay_bytes_exact']
        record = {key:row[key] for key in ('gain_label', 'amplitude', 'sign')}
        record['ticks'] = []
        for tick in range(min(20, result['steps'])):
            current, following = [states[tick+index].copy() for index in (0,1)]
            current[1:16] = wrap_angle(current[1:16])
            following[1:16] = wrap_angle(following[1:16])
            angle = float(np.max(np.abs(wrap_angle(np.cumsum(following[1:16])))))
            if angle >= .05:
                record['stopped_at_angle_guard'] = tick+1
                break
            x, y = ctx.matrix(current.tolist()), ctx.matrix(following.tolist())
            action = ctx.mpf(result['actions'][tick])
            ideal = closed*x
            remaining = y-ideal
            native_remainder = y-a*x-b*action
            control_change = b*(action+(k*x)[0])
            assert ctx.norm(remaining-native_remainder-control_change) < ctx.mpf('1e-80')
            present = -(k*remaining)[0]
            saved_error = ctx.mpf(result['action_diagnostics'][tick]['selected_projected_error'])
            assert abs(present-saved_error) < ctx.mpf('1e-65')
            record['ticks'].append(dict(tick=tick+1, time_seconds=(tick+1)*.02,
                maximum_angle=angle, delivered_action=float(action),
                present_projected_remaining_error=str(present),
                one_linear_step_delayed_remaining_error=str(-(following_output*remaining)[0]),
                present_projection_native_remainder=str(-(k*native_remainder)[0]),
                present_projection_control_correction=str(-(k*control_change)[0]),
                remaining_state_linf=str(max(abs(v) for v in remaining))))
        records.append(record)
    payload = dict(source=file_metadata(args.source), script=file_metadata(__file__),
        config=data['config'], runtime=runtime_metadata(), records=records,
        native_transition_calls=0, actual_episode_steps=0, canonical_release_evidence=False,
        scope='Read-only first20pilot ticks, stopping before next maxangle0.05rad. MP100 decomposition of recorded delivered transition versus unclipped linear closed-loop model. Remainder includes nonlinear/native arithmetic discrepancy; correction contribution separately retained. Delayed projection is hypothetical linear propagation of remaining vector, not an actual counterfactual or a causality proof.')
    dump_json(payload, out)
    for r in records:
        print(json.dumps(dict(gain=r['gain_label'], amplitude=r['amplitude'], sign=r['sign'], ticks=len(r['ticks']),
            present_peak=max((abs(float(v['present_projected_remaining_error'])) for v in r['ticks']), default=None),
            delayed_peak=max((abs(float(v['one_linear_step_delayed_remaining_error'])) for v in r['ticks']), default=None))), flush=True)


if __name__ == '__main__':
    main()
