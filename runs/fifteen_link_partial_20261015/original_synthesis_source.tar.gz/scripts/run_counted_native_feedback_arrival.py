"""Inclusive physics accounting even if the native arrival driver fails."""
import argparse,runpy,sys
from pathlib import Path
import mujoco
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv

def main():
 p=argparse.ArgumentParser();p.add_argument('--ceiling',type=int,required=True);p.add_argument('--accounting-file',required=True);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
 command=a.command[1:] if a.command[:1]==['--'] else a.command;assert command and a.ceiling>0
 original=mujoco.mj_step;original_env=NLinkCartPoleEnv.step;oldargv=sys.argv;counts=[0];actual=[0]
 record=dict(generated_at=utc_timestamp(),status='running',script=file_metadata(__file__),command=command,native_transition_ceiling=a.ceiling,not_solution=True,canonical_release_evidence=False)
 def counted(model,data,*args,**kw):
  n=int(kw.get('nstep',args[0] if args else 1))
  if counts[0]+n>4*a.ceiling:raise RuntimeError('inclusive native arrival ceiling reached')
  counts[0]+=n;return original(model,data,*args,**kw)
 def counted_env(env,action):actual[0]+=1;return original_env(env,action)
 mujoco.mj_step=counted;NLinkCartPoleEnv.step=counted_env
 try:sys.argv=command;runpy.run_path(command[0],run_name='__main__');record['status']='finished'
 except BaseException as e:record.update(status='failed',error=f'{type(e).__name__}: {e}');raise
 finally:
  mujoco.mj_step=original;NLinkCartPoleEnv.step=original_env;sys.argv=oldargv
  record.update(total_native_transition_calls=counts[0]/4,native_physics_substeps=counts[0],partial_transition_substeps=counts[0]%4,actual_hanging_start_episode_steps=actual[0],finished_at=utc_timestamp())
  dump_json(record,Path(a.accounting_file));print(record,flush=True)

if __name__=='__main__':main()
