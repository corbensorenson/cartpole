"""Native proof of every sampled forecast and full earlier-control episode."""
import argparse,json,re
from contextlib import contextmanager
_CACHE={}
@contextmanager
def load_cached(path):
 if path not in _CACHE:
  with np.load(path) as archive:_CACHE[path]={k:archive[k] for k in archive.files}
 yield _CACHE[path]

def arrays(path):
 if path not in _CACHE:
  with np.load(path) as archive:_CACHE[path]={k:archive[k] for k in archive.files}
 return _CACHE[path]
from pathlib import Path
import numpy as np,mujoco
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.angles import wrap_angle
from gcartpole.simulation import SimulationError
from gcartpole.native_task_derivatives import physical_task_residual
from scripts.search_capture_sequence import fixed_state_cfg

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(a.root);out=Path(a.out);out.mkdir(exist_ok=False);m=json.loads((root/'manifest.json').read_text());r=json.loads((root/'execution/diagnostic/result.json').read_text());acc=json.loads((root/'execution/inclusive_accounting.json').read_text());s=json.loads(Path(m['source']['path']).read_text());base=json.loads(Path(s['source']['path']).read_text());initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in s['result']['trajectory']]]);U=np.asarray([q['action'] for q in s['result']['trajectory']],float);cfg=fixed_state_cfg(load_config(s['config']['path']),base['selected_state'],30.);count=[0];old=mujoco.mj_step;env=None;attempts=0;failed=[];outcomes=[]
 payload=dict(generated_at=utc_timestamp(),status='running',script=file_metadata(__file__),source_result=file_metadata(root/'execution/diagnostic/result.json'),source_accounting=file_metadata(root/'execution/inclusive_accounting.json'),actual_hanging_start_episode_steps=0,native_transition_ceiling=145000,not_solution=True,canonical_release_evidence=False)
 def counted(model,data,*args,**kw):
  n=int(kw.get('nstep',args[0] if args else 1));assert count[0]+n<=580000;count[0]+=n;return old(model,data,*args,**kw)
 def rank(states,h):
  if not len(states):return (0,1e100)
  angles=np.abs(wrap_angle(np.cumsum(states[:,1:16],axis=1)));ok=(np.max(angles,axis=1)<.149)&(abs(states[:,0])<=3);bad=np.flatnonzero(~ok);prefix=int(bad[0]) if len(bad) else len(states)
  if len(states)<h:return (-prefix,1e90)
  rr=physical_task_residual(states,15,m['rate_weight'],.05);return (-prefix,float(rr@rr+100*np.sum((np.maximum(angles-.149,0)/.149)**2)+100*np.sum((np.maximum(abs(states[:,0])-2.85,0)/.15)**2)))
 mujoco.mj_step=counted
 try:
  env=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);env.reset(seed=20265100);native=MujocoTransition(env,np.eye(32),continuous_angles=True);actuals={}
  for q in r['records']:
   assert q['tape']==file_metadata(q['tape']['path']);z=arrays(q['tape']['path']);actuals[q['label']]=(z['states'].copy(),z['actions'].copy())
  candidatecount=0
  for q in r['private_batches']:
   assert q['tape']==file_metadata(q['tape']['path']);z=arrays(q['tape']['path']);xs,us=actuals[q['label']];tick=q['tick'];candidatecount+=q['candidates'];h=q['horizon']
   for i,actions in enumerate(z['actions']):
    assert z['states'][i,0].tobytes()==xs[tick].tobytes();steps=int(z['lengths'][i]);assert actions.tobytes()==actions.astype(np.float32).astype(float).tobytes();assert np.max(abs(actions))<=1
    for j in range(steps):attempts+=1;assert native(z['states'][i,j],float(actions[j])).tobytes()==z['states'][i,j+1].tobytes()
    error=q['errors'][i]
    if error:
     before=count[0];attempts+=1
     try:native(z['states'][i,steps],float(actions[steps]))
     except SimulationError as e:assert f'SimulationError: {e}'==error
     else:raise AssertionError('failedcandidate did not reproduce')
     failed.append(dict(batch=q['tape'],candidate=i,error=error,substeps=count[0]-before))
    else:assert steps==h
    assert tuple(z['scores'][i])==rank(z['states'][i,1:steps+1],h)
  for i in range(m['start_step']):attempts+=1;assert native(X[i],float(U[i])).tobytes()==X[i+1].tobytes()
  for q in r['records']:
   xs,us=actuals[q['label']];assert xs[:m['start_step']+1].tobytes()==X[:m['start_step']+1].tobytes();assert q['decisions']==file_metadata(q['decisions']['path']);decisions=json.loads(Path(q['decisions']['path']).read_text())['decisions'];assert len(decisions)==len(us)-m['start_step'];streak=longest=0
   for i,u in enumerate(us):
    attempts+=1;assert native(xs[i],float(u)).tobytes()==xs[i+1].tobytes();angle=float(max(abs(wrap_angle(np.cumsum(xs[i+1,1:16])))));streak=streak+1 if angle<.15 else 0;longest=max(longest,streak)
    if i>=m['start_step']:
     decision=decisions[i-m['start_step']];assert decision['tick']==i and decision['selected_sequence'][0]==u;assert np.asarray(decision['selected_forecast'][0]).tobytes()==xs[i+1].tobytes()
     group=[b for b in r['private_batches'] if b['label']==q['label'] and b['tick']==i];ranks=[];match=False
     for b in group:
      with load_cached(b['tape']['path']) as z:
       for j in range(b['candidates']):
        ranks.append(tuple(z['scores'][j]));match=match or (z['actions'][j].tobytes()==np.asarray(decision['selected_sequence']).tobytes() and z['states'][j,1:].tobytes()==np.asarray(decision['selected_forecast']).tobytes())
     assert match and tuple(decision['score'])==min(ranks)
   assert longest*.02==q['hold_seconds'] and len(us)==q['actual_hanging_start_episode_steps'];assert float(max(abs(xs[1:,0])))==q['maximum_cart'];assert abs(xs[-1,0])>3 and not q['full_nominal_gate_passed'];outcomes.append({k:q[k] for k in ('label','horizon','actual_hanging_start_episode_steps','hold_seconds','maximum_cart','termination_reason','full_nominal_gate_passed')})
  assert attempts+r['actual_hanging_start_episode_steps']==r['total_native_transition_calls'];assert count[0]+4*r['actual_hanging_start_episode_steps']==acc['native_physics_substeps'];payload.update(status='finished',passed=True,independent_native_candidate_forecasts=candidatecount,independent_private_batches=len(r['private_batches']),reproduced_failed_candidates=failed,outcomes=outcomes,source_total_native_transition_calls=acc['total_native_transition_calls'],scope='Allsampledprivatecompletedtransitions, candidatephysicalranks and selectedminranks/actualactions reproduce. Bothfullrecordedactualtapes/gates/375prefix independentlybyteproved. Searchpopulationgeneration RNG notindependentlyreimplemented. Negativefinitecontrollercomparison, no causalhorizon/generalization/releasecertificate.')
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}');raise
 finally:
  if env:env.close()
  mujoco.mj_step=old;payload.update(total_native_transition_calls=count[0]/4,native_physics_substeps=count[0],attempted_transition_calls=attempts,finished_at=utc_timestamp());dump_json(payload,out/'result.json');print({k:v for k,v in payload.items() if k not in ['reproduced_failed_candidates','outcomes']},flush=True)
if __name__=='__main__':main()
