#!/usr/bin/env python
"""Probe one-step continuation at endpoints of independently verified plans."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',required=True);parser.add_argument('--directory',required=True)
    args=parser.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    component=json.loads(Path(args.source).read_text());meta=component['plan_inputs']
    if file_metadata(meta['path'])!=meta:raise ValueError('Plan inputs changed')
    inputs=json.loads(Path(meta['path']).read_text());records=[];calls=0;began=time.monotonic()
    for case in component['records']:
        raw=next(x for x in inputs['cases'] if x['first_plan']['step']==case['start_step'])
        if file_metadata(case['source']['path'])!=case['source'] or file_metadata(case['config']['path'])!=case['config']:
            raise ValueError('Physical inputs changed')
        base=json.loads(Path(case['source']['path']).read_text());cfg=load_config(case['config']['path']);n=cfg['env']['n_links']
        env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
        native=MujocoTransition(env,np.eye(2*(n+1)),continuous_angles=True)
        untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
        start=case['start_step'];row=base['result']['trajectory'][start-1]
        state=np.asarray(row['qpos']+row['qvel'])
        for action in raw['first_plan']['diagnostic']['selected_sequence'][:16]:state=native(state,float(action))
        try:
            for method in case['methods']:
                if not method['feasible_sequence_found']:continue
                current=state.copy();states=[]
                for action in method['selected_sequence']:current=native(current,float(action));states.append(current.copy())
                if not np.array_equal(states,method['selected_states']):raise ValueError('Selected plan no longer exactly replays')
                tests=[]
                for action in np.linspace(-1.,1.,101).astype(np.float32).astype(float):
                    following=native(current.copy(),float(action))
                    angles=wrap_angle(np.cumsum(following[1:n+1]));rates=np.cumsum(following[n+2:])
                    tests.append(dict(action=float(action),absolute_angle_max=float(np.max(np.abs(angles))),
                        absolute_rate_max=float(np.max(np.abs(rates))),cart_position=float(following[0]),
                        canonical_angle_and_rail_admissible=bool(np.max(np.abs(angles))<.15 and abs(following[0])<=env.rail_limit),
                        planner_angle_and_rail_admissible=bool(np.max(np.abs(angles))<.14 and abs(following[0])<=env.rail_limit)))
                best=min(tests,key=lambda row:row['absolute_angle_max'])
                records.append(dict(start_step=start,method=method['method'],terminal_step=start+16+len(states),
                    terminal_native_state=current.tolist(),selected_plan_native_replay_bit_identical=True,
                    terminal_absolute_angle_max=float(np.max(np.abs(wrap_angle(np.cumsum(current[1:n+1]))))),
                    terminal_absolute_rate_max=float(np.max(np.abs(np.cumsum(current[n+2:])))),
                    one_step_grid=tests,best_tested_next_angle=best,
                    canonical_next_step_admissible_tested_actions=sum(x['canonical_angle_and_rail_admissible'] for x in tests),
                    planner_next_step_admissible_tested_actions=sum(x['planner_angle_and_rail_admissible'] for x in tests)))
            if not np.array_equal(untouched,np.r_[env.data.qpos,env.data.qvel]):raise ValueError('Forecast probes changed live state')
        finally:calls+=native.evaluations;env.close()
    dump_json(dict(not_solution=True,canonical_release_evidence=False,source=file_metadata(args.source),
        records=records,native_forecast_transition_calls=calls,total_native_transition_calls=calls,
        optimizer_transition_calls=0,actual_episode_steps=0,wall_seconds=time.monotonic()-began,runtime=runtime_metadata(),
        reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Independent native replay of recorded plans and101 delivered-F32 one-step input probes at each valid endpoint. Finite sampled controls do not establish global infeasibility or a viability certificate. No actual episode or live state replacement.'),out/'result.json')
    print(json.dumps(dict(native_calls=calls,records=[dict(method=x['method'],terminal_angle=x['terminal_absolute_angle_max'],
        terminal_rate=x['terminal_absolute_rate_max'],best_next_angle=x['best_tested_next_angle']['absolute_angle_max'],
        canonical_tested_admissible=x['canonical_next_step_admissible_tested_actions']) for x in records])),flush=True)


if __name__=='__main__':main()
