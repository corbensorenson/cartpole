#!/usr/bin/env python
"""Screen a declared auxiliary geometry without relaxing canonical release guards."""
import argparse, copy, json, math, subprocess, sys
from pathlib import Path
from gcartpole.config import dump_json, load_config
from gcartpole.evidence import file_metadata, utc_timestamp
from gcartpole.roadmap import validate_canonical_config
from scripts.screen_frontier_capture_candidate import validate_handoff_times
from scripts.solve_frontier_capture_increment import physical_replay_passed, validate_development_seeds
from scripts.verify_frontier_release import verify_manifest
from scripts.synthesize_inverse_increment import exact_candidate_passed


def validate_geometry_difference(cfg, canonical, study):
    comparable = copy.deepcopy(cfg['env'])
    if study == 'link-length':
        length = comparable['total_length']
        if not math.isfinite(length) or length <= canonical['env']['total_length']:
            raise ValueError('length-only diagnostic must increase total length')
        comparable['total_length'] = canonical['env']['total_length']
        difference = dict(total_length_m=length, canonical_total_length_m=canonical['env']['total_length'])
    elif study == 'joint-hub':
        values = {key: comparable.pop(key, None) for key in
                  ('joint_hub_radius', 'joint_hub_mass', 'joint_hub_half_width')}
        if any(value is None or not math.isfinite(value) or value <= 0 for value in values.values()):
            raise ValueError('physical hub diagnostic requires positive radius, mass and half width')
        difference = dict(**values, total_added_hub_mass_kg=cfg['env']['n_links'] * values['joint_hub_mass'])
    else:
        raise ValueError('unknown geometry study')
    if comparable != canonical['env'] or cfg['morphology'] != canonical['morphology']:
        raise ValueError('diagnostic changes fields outside its declared geometry')
    return difference


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('config','canonical-config','source','source-manifest','directory'):p.add_argument('--'+key,required=True)
    p.add_argument('--study', choices=('link-length', 'joint-hub'), default='link-length')
    args=p.parse_args();out=Path(args.directory)
    if (out/'physical_screen.json').exists():raise FileExistsError(out)
    cfg=load_config(args.config);canonical=load_config(args.canonical_config)
    check=copy.deepcopy(canonical);check['env']['n_links']=7
    errors=validate_canonical_config(check)+verify_manifest(Path(args.source_manifest))
    difference=validate_geometry_difference(cfg,canonical,args.study)
    prior=json.loads(Path(args.source).read_text());manifest=json.loads(Path(args.source_manifest).read_text())
    if (errors
            or manifest['n_links']!=cfg['env']['n_links']-1
            or prior['shared_capture_recipe']['parameters']['config']!=args.config):
        raise ValueError('Verified adjacent predecessor and declared auxiliary geometry required')
    validate_development_seeds(cfg['env']['n_links'],prior['seed'])
    handoffs=validate_handoff_times((8.,9.,10.,12.),cfg['env']['timestep']*cfg['env']['frame_skip'],len(prior['controller']['controls']))
    record=dict(not_solution=True,canonical_release_evidence=False,release_promotion=False,
        status='running',started_at=utc_timestamp(),source=file_metadata(args.source),config=file_metadata(args.config),
        canonical_config=file_metadata(args.canonical_config),source_manifest=file_metadata(args.source_manifest),
        study=args.study,physical_difference=difference,
        declared_handoff_seconds=list(handoffs),handoff_results=[],stages=[],reserved_seeds_used=False,noisy_development_seeds_used=False)
    out.mkdir(parents=True,exist_ok=True);journal=out/'physical_screen.json'
    def run(label,script,source,options):
        directory=out/label
        command=[sys.executable,'scripts/run_frontier_experiment.py','--directory',str(directory),
            '--input',source,'--input',args.config,'--input',args.canonical_config,
            '--',sys.executable,'scripts/'+script,'--source',source,'--config',args.config,'--directory',str(directory),*options]
        subprocess.run(command,check=True)
        path=directory/'result.json';record['stages'].append(dict(label=label,result=file_metadata(path),execution=file_metadata(directory/'execution.json')))
        dump_json(record,journal);return path,json.loads(path.read_text())
    dump_json(record,journal)
    try:
        for seconds in handoffs:
            path,data=run(f'handoff{seconds:g}','replay_frontier_handoff.py',args.source,['--handoff-seconds',str(seconds)])
            record['handoff_results'].append(dict(seconds=seconds,result=file_metadata(path),auxiliary_full_physical_pass=physical_replay_passed(data['result'],cfg)))
            dump_json(record,journal)
        passing=[x for x in record['handoff_results'] if x['auxiliary_full_physical_pass']]
        if not passing:record['status']='finished_auxiliary_negative'
        else:
            selected=min(passing,key=lambda x:x['seconds'])
            path,data=run('physical_rebuild','rebuild_frontier_physical_route.py',selected['result']['path'],[])
            if not exact_candidate_passed(data,cfg) or not data['physical_rebuild_comparison']['all_physical_states_identical']:
                raise ValueError('Auxiliary pass lacks exact identical physical rebuild')
            record.update(status='passed_auxiliary_physical_requires_length_continuation' if args.study == 'link-length' else 'passed_auxiliary_physical_requires_hub_continuation',candidate=file_metadata(path),selected_handoff_seconds=selected['seconds'])
    except BaseException as error:
        record.update(status='failed_or_interrupted',error=repr(error));raise
    finally:record['finished_at']=utc_timestamp();dump_json(record,journal)
    print(json.dumps(dict(status=record['status'],canonical_release_evidence=False)))

if __name__=='__main__':main()
