"""Finite native first/second-action viability and reference-continuation comparison."""
import argparse,json
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from gcartpole.angles import wrap_angle
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.refine_native_feedback_arrival import raw_feedback
read=lambda p:json.loads(Path(p).read_text())
def metrics(state):
 angle=float(np.max(abs(wrap_angle(np.cumsum(state[1:16])))));cart=float(state[0]);return dict(maximum_angle=angle,cart=cart,safe149=angle<.149 and abs(cart)<=3,upright150=angle<.15,maximum_absolute_rate=float(np.max(abs(np.cumsum(state[17:])))))
def prefix(states):
 ok=[metrics(x)['safe149'] for x in states];bad=[i for i,v in enumerate(ok) if not v];return bad[0] if bad else len(states)
def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--directory',required=True);a=p.parse_args();m=read(a.manifest);out=Path(a.directory);out.mkdir(exist_ok=False);s=read(m['source']['path']);base=read(s['source']['path']);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in s['result']['trajectory']]]);U=np.asarray([q['action'] for q in s['result']['trajectory']],np.float32).astype(float);r=read(m['source_result']['path']);gain=np.asarray(r['gain']);assert read(m['source_audit']['path'])['passed'] and read(m['tracking_audit']['path'])['passed']
 for key in ('source','config','source_result','source_audit','tracking_array','tracking_audit'):assert m[key]==file_metadata(m[key]['path'])
 with np.load(m['tracking_array']['path']) as z:K=z['gains'][m['tracking_variant_index']];ref=z['states'];assert ref.tobytes()==X[m['tracking_start']:m['tracking_start']+len(K)+1].tobytes()
 cases={}
 for q in m['cases']:
  if q['tape'] is None:state=X[q['step']].copy()
  else:
   assert q['tape']==file_metadata(q['tape']['path'])
   with np.load(q['tape']['path']) as z:state=z['states'][q['step']].copy()
  cases[q['label']]=state
 cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);assert cfg['env']['n_links']==15 and cfg['env']['timestep']==.005 and cfg['env']['frame_skip']==4;env=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);env.reset(seed=20265100);native=MujocoTransition(env,np.eye(32),continuous_angles=True);cache={};tapes=[];queries=[];pairs=[];screens=[];continuations=[]
 payload=dict(status='running',generated_at=utc_timestamp(),script=file_metadata(__file__),manifest=file_metadata(a.manifest),runtime=runtime_metadata(),one_step_candidates=[],queries=queries,pair_maps=pairs,one_step_screens=screens,continuations=continuations,not_solution=True,canonical_release_evidence=False,actual_hanging_start_episode_steps=0,noisy_development_seeds_used=False,reserved_seeds_used=False,state_sources=m['cases'])
 def query(state,raw,label,kind):
  u=float(np.float32(np.clip(raw,-1,1)));key=(state.tobytes(),np.float32(u).tobytes())
  if key not in cache:
   states=[state.copy()];error=None
   try:states.append(native(state,u))
   except SimulationError as e:error=f'SimulationError: {e}'
   i=len(tapes);cache[key]=i;tapes.append(dict(states=np.asarray(states),action=u));mm=metrics(states[-1]) if len(states)==2 else None;payload['one_step_candidates'].append(dict(index=i,action=u,metrics=mm,error=error,completed_steps=len(states)-1))
  i=cache[key];queries.append(dict(index=len(queries),candidate=i,label=label,kind=kind,raw_action=float(raw),delivered_action=u));return i
 def angle(index):
  q=payload['one_step_candidates'][index];return q['metrics']['maximum_angle'] if q['error'] is None else 1e100
 def coarse(state,tick,label):
  grid=np.unique(np.r_[np.linspace(-1,1,m['grid_points']).astype(np.float32).astype(float),U[tick]]);ids=[query(state,float(u),label,'grid') for u in grid];return grid,ids
 def refine(state,grid,ids,label):
  best=min(range(len(ids)),key=lambda i:angle(ids[i]));lo=float(grid[max(0,best-1)]);hi=float(grid[min(len(grid)-1,best+1)]);left,right=lo,hi;ratio=(np.sqrt(5)-1)/2;c=right-ratio*(right-left);d=left+ratio*(right-left);ci=query(state,c,label,'golden_initial_c');di=query(state,d,label,'golden_initial_d');allids=list(ids)+[ci,di];history=[]
  for it in range(m['golden_iterations']):
   if angle(ci)<=angle(di):right,d,di=d,c,ci;c=right-ratio*(right-left);ci=query(state,c,label,'golden_c');new=ci;branch='left'
   else:left,c,ci=c,d,di;d=left+ratio*(right-left);di=query(state,d,label,'golden_d');new=di;branch='right'
   allids.append(new);history.append(dict(iteration=it,branch=branch,left=left,right=right,c=c,d=d,candidate_c=ci,candidate_d=di,new_candidate=new))
  winner=min(allids,key=angle);return dict(initial_bracket=[lo,hi],coarse_ids=ids,golden_initial_ids=allids[len(ids):len(ids)+2],history=history,best_candidate=winner,coarse_best_candidate=ids[best],best_metrics=payload['one_step_candidates'][winner]['metrics'])
 try:
  for i in range(376):assert native(X[i],float(U[i])).tobytes()==X[i+1].tobytes()
  for q in m['cases']:
   label=q['label'];grid,ids=coarse(cases[label],q['step'],label);rr=refine(cases[label],grid,ids,label);screens.append(dict(label=label,step=q['step'],initial_state=cases[label].tolist(),grid_actions=grid.tolist(),grid_safe_count=sum(payload['one_step_candidates'][i]['metrics']['safe149'] for i in ids if payload['one_step_candidates'][i]['metrics'] is not None),gain_raw_action=raw_feedback(gain,cases[label],15),gain_delivered_action=float(np.float32(np.clip(raw_feedback(gain,cases[label],15),-1,1))),**rr))
  for label in m['pair_cases']:
   state=cases[label];g0,ids0=coarse(state,375,label+'_pair_first');g1=np.unique(np.r_[np.linspace(-1,1,m['grid_points']).astype(np.float32).astype(float),U[376]]);states=np.full((len(g0),len(g1),3,32),np.nan);actions=np.empty((len(g0),len(g1),2));safe=np.zeros((len(g0),len(g1)),int);secondids=[];refinements=[]
   for i,(u0,index0) in enumerate(zip(g0,ids0)):
    assert len(tapes[index0]['states'])==2;x1=tapes[index0]['states'][1];rowids=[]
    for j,u1 in enumerate(g1):
     index1=query(x1,float(u1),label+f'_pair_second_{i}','grid');rowids.append(index1);states[i,j,0]=state;states[i,j,1]=x1
     if len(tapes[index1]['states'])==2:states[i,j,2]=tapes[index1]['states'][1];safe[i,j]=prefix(states[i,j,1:])
     actions[i,j]=[u0,u1]
    rr=refine(x1,g1,rowids,label+f'_pair_second_{i}');rr['first_action']=float(u0);rr['first_candidate']=index0;refinements.append(rr);secondids.append(rowids)
   path=out/(label+'_pairs.npz');np.savez_compressed(path,states=states,actions=actions,safe_prefix=safe,first_actions=g0,second_actions=g1,first_candidate_ids=np.asarray(ids0),second_candidate_ids=np.asarray(secondids));pairs.append(dict(label=label,tape=file_metadata(path),first_actions=len(g0),second_actions=len(g1),coarse_two_safe_pairs=int(np.sum(safe==2)),first_actions_with_coarse_second_safe=int(np.sum(np.any(safe==2,axis=1))),first_actions_with_refined_second_safe=sum(metrics(tapes[q['first_candidate']]['states'][1])['safe149'] and q['best_metrics'] is not None and q['best_metrics']['safe149'] for q in refinements),refinements=refinements));print({k:v for k,v in pairs[-1].items() if k!='refinements'},flush=True)
  for case in m['cases']:
   for policy in m['policies']:
    state=cases[case['label']].copy();xs=[state.copy()];us=[];raws=[];error=None
    try:
     for j in range(m['continuation_steps']):
      tick=case['step']+j
      if policy=='maintenance':raw=raw_feedback(gain,state,15)
      elif policy=='source_feedforward':raw=float(U[tick])
      else:raw=float(U[tick])+float(K[tick-m['tracking_start']]@(state-X[tick]))
      u=float(np.float32(np.clip(raw,-1,1)));raws.append(raw);us.append(u);state=native(state,u);xs.append(state.copy())
    except SimulationError as e:error=f'SimulationError: {e}'
    path=out/(case['label']+'_'+policy+'.npz');np.savez_compressed(path,states=np.asarray(xs),actions=np.asarray(us),raws=np.asarray(raws));record=dict(label=case['label'],policy=policy,step=case['step'],completed_steps=len(xs)-1,attempted_steps=len(us),error=error,safe_prefix=prefix(xs[1:]),maximum_angle=max(metrics(x)['maximum_angle'] for x in xs[1:]),maximum_cart=max(abs(float(x[0])) for x in xs[1:]),tape=file_metadata(path));continuations.append(record)
    if case['label'] in ('source375','source376') and policy in ('source_feedforward','source_tracking'):assert np.asarray(xs).tobytes()==X[case['step']:case['step']+len(xs)].tobytes();record['source_reference_byte_exact']=True
  path=out/'one_step_tapes.npz';assert all(len(q['states'])==2 for q in tapes);np.savez_compressed(path,states=np.asarray([q['states'] for q in tapes]),actions=np.asarray([q['action'] for q in tapes]));payload.update(status='finished',one_step_tape=file_metadata(path),total_native_transition_calls=native.evaluations,scope=m['scope']);assert native.evaluations<=m['execution_native_transition_ceiling'];dump_json(payload,out/'result.json');print(dict(calls=native.evaluations,one_step_candidates=len(tapes),queries=len(queries),screens=[dict(label=q['label'],safe_grid=q['grid_safe_count'],best=q['best_metrics']['maximum_angle']) for q in screens],continuations=[{k:q[k] for k in ('label','policy','safe_prefix','completed_steps')} for q in continuations]),flush=True)
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}',total_native_transition_calls=native.evaluations);dump_json(payload,out/'result.failed.json');raise
 finally:env.close()
if __name__=='__main__':main()
