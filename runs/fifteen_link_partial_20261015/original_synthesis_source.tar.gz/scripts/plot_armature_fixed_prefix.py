"""Scientific fixed-prefix capture figure from independently replayed tapes."""
import argparse,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gcartpole.angles import wrap_angle
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',required=True);args=p.parse_args();root=Path(args.directory)
    read=lambda p:json.loads(Path(p).read_text());audit=read(root/'verified_fixed_prefix.json');assert audit['passed']
    output=root/'fixed_prefix_figures';output.mkdir(exist_ok=False)
    candidate=read(root/'armature0.98_actual8s_prefix_capture8/diagnostic/result.json')
    ff=read(root/'armature0.98_actual8s_prefix_native_defect_feedback/diagnostic/result.json')
    screen=read(root/'armature0.98_actual8s_solver_handoff_screen/diagnostic/result.json')
    passing=next(r for r in screen['records'] if r['handoff_seconds']==9.)
    traces=[('Saved suffix feedback / 14s horizon',candidate['tape'],'#b16b3c'),('MP affine suffix feedback',next(r['tape'] for r in ff['records'] if r['affine']),'#a23c50'),('Saved suffix feedback / 9s handoff',passing['tape'],'#167a78')]
    fig,axes=plt.subplots(2,2,figsize=(12,8),layout='constrained')
    for label,ref,color in traces:
        assert file_metadata(ref['path'])==ref
        x=np.load(ref['path'])['states'];t=np.arange(len(x))*.02
        axes[0,0].plot(t,x[:,0],color=color,label=label,lw=1)
        angle=np.max(abs(wrap_angle(np.cumsum(x[:,1:15],axis=1))),axis=1)
        axes[0,1].plot(t,np.maximum(angle,1e-18),color=color,label=label,lw=1)
    for ax in axes[0]:ax.axvline(8,color='gray',ls=':',lw=1);ax.axvline(9,color='gray',ls='--',lw=1);ax.set_xlabel('Time from hanging start (s)');ax.grid(alpha=.2)
    axes[0,0].axhline(3,color='gray',lw=1);axes[0,0].axhline(-3,color='gray',lw=1);axes[0,0].set(title='Identical first 8s, different capture behavior',ylabel='Actual cart position (m)');axes[0,0].legend(fontsize=8)
    axes[0,1].axhline(.15,color='black',lw=1,ls=':');axes[0,1].set(title='Full pass with 24.2s upright',ylabel='Maximum wrapped absolute angle (rad)',yscale='log');axes[0,1].set_ylim(1e-16,5)
    ax=axes[1,0];full=read(root/'armature0.98_repair16/diagnostic/candidate.json');suffix=read(candidate['candidate']['path'])
    defects=[full['controller']['final_trajectory_diagnostics']['maximum_dynamics_defect'],suffix['controller']['final_trajectory_diagnostics']['maximum_dynamics_defect']]
    ax.bar([0,1],defects,color=['#196f91','#167a78']);ax.set(xticks=[0,1],xticklabels=['Full route\n8+8 repair','Fixed actual 8s prefix\n8 suffix iterations'],ylabel='Maximum raw coordinate defect',yscale='log',title='Repair capture after preserving the physical swing')
    for i,value in enumerate(defects):ax.text(i,value*1.7,f'{value:.2e}',ha='center',fontsize=9)
    ax.set_ylim(1e-12,1e-3);ax.grid(axis='y',alpha=.2)
    ax=axes[1,1];raw_hold=candidate['result']['max_upright_streak_seconds'];pure=next(r for r in ff['records'] if not r['affine']);affine=next(r for r in ff['records'] if r['affine'])
    values=[raw_hold,pure['result']['max_upright_streak_seconds'],affine['result']['max_upright_streak_seconds'],passing['result']['max_upright_streak_seconds']]
    ax.bar(range(4),values,color=['#b16b3c','#b95462','#a23c50','#167a78']);ax.set(xticks=range(4),xticklabels=['Saved\n14s horizon','MP pure\n14s horizon','MP affine\n14s horizon','Saved\n9s handoff'],ylabel='Maximum actual upright hold (s)',title='Redesigning feedback can discard a usable controller',ylim=(0,27));ax.axhline(5,color='gray',lw=1,ls=':');ax.grid(axis='y',alpha=.2)
    for i,v in enumerate(values):ax.text(i,v+.4,f'{v:.2f}s',ha='center',fontsize=9)
    fig.suptitle('Altered fourteen at armature 0.98 • native F32 actions • continuous hanging starts • byte replay',fontsize=13)
    figs=[]
    for extension in ('png','pdf'):
        path=output/f'native_fixed_prefix_capture.{extension}';fig.savefig(path,dpi=180);figs.append(file_metadata(path))
    plt.close(fig)
    dump_json(dict(generated_at=utc_timestamp(),script=file_metadata(__file__),audit=file_metadata(root/'verified_fixed_prefix.json'),tapes=[r for _,r,_ in traces],figures=figs,angle_floor_display_only=1e-18,native_transition_calls=0),output/'figures.json')

if __name__=='__main__':main()
