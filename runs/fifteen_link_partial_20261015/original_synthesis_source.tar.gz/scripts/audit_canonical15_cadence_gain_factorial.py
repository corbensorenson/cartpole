"""Independent21-arm cadence/gain controller and native physics proof."""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg
read=lambda p:json.loads(Path(p).read_text())
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);args=p.parse_args();root=Path(args.root);out=Path(args.out);out.mkdir(exist_ok=False);m=read(root/'manifest.json');r=read(root/'execution/diagnostic/result.json');acc=read(root/'execution/inclusive_accounting.json');unit_source=read('runs/canonical15_actual_cadence_20261004/execution/diagnostic/result.json');j=read(root/'execution/execution.json');assert j['status']=='finished' and j['returncode']==0 and r['status']=='finished' and acc['status']=='finished'
 for k in ('source','config','gain_source','source_audit','matched_baseline'):assert m[k]==file_metadata(m[k]['path'])
 source=read(m['source']['path']);base=read(source['source']['path']);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in source['result']['trajectory']]]);U=np.asarray([q['action'] for q in source['result']['trajectory']],np.float32).astype(float);gain=np.asarray(read(m['gain_source']['path'])['gain']);cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);env=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);env.reset(seed=20265100);native=MujocoTransition(env,np.eye(32),continuous_angles=True);rows=[];total_substeps=0;actual_ticks=0;by_skip={};max_time_error=0
 try:
  env.frame_skip=4
  for tick in range(m['start_step']):assert native(X[tick],float(U[tick])).tobytes()==X[tick+1].tobytes();total_substeps+=4
  for row in r['records']:
   assert row['tape']==file_metadata(row['tape']['path']);assert row['plant_xml_sha256']==hashlib.sha256(env.xml.encode()).hexdigest()
   with np.load(row['tape']['path']) as z:xs=z['states'];us=z['actions'];raws=z['raw_actions'];skips=z['frame_skips'];times=z['native_times']
   n=len(us);skip=row['maintenance_frame_skip'];multiplier=row['gain_multiplier'];assert multiplier in m['gain_multipliers'];assert skip in (4,2,1) and row['maintenance_hz']==200//skip and xs.shape==(n+1,32) and n==row['actual_hanging_start_episode_steps'];assert xs[0].tobytes()==initial.tobytes() and np.all(skips[:m['start_step']]==4) and np.all(skips[m['start_step']:]==skip);assert xs[:m['start_step']+1].tobytes()==X[:m['start_step']+1].tobytes();assert us[:m['start_step']].tobytes()==U[:m['start_step']].tobytes()
   expected=[]
   for tick in range(n):
    x=xs[tick].copy();x[1:16]=wrap_angle(x[1:16]);raw=float(U[tick]) if tick<m['start_step'] else multiplier*(-float(gain@x));expected.append(raw);assert float(np.float32(np.clip(raw,-1,1)))==us[tick];env.frame_skip=int(skips[tick]);assert native(xs[tick],float(us[tick])).tobytes()==xs[tick+1].tobytes();total_substeps+=int(skips[tick]);by_skip[str(int(skips[tick]))]=by_skip.get(str(int(skips[tick])),0)+1
   assert np.asarray(expected).tobytes()==raws.tobytes();cumulative=np.cumsum(skips);assert np.max(abs(times-np.r_[0,cumulative*.005]))<1e-9;max_time_error=max(max_time_error,float(np.max(abs(times-np.r_[0,cumulative*.005]))));actual_ticks+=n
   angles=np.max(abs(wrap_angle(np.cumsum(xs[1:,1:16],axis=1))),axis=1);safe=angles<.15;starts=np.flatnonzero(safe & np.r_[True,~safe[:-1]]);ends=np.flatnonzero(safe & np.r_[~safe[1:],True]);longest=max((int(np.sum(skips[b:e+1])) for b,e in zip(starts,ends)),default=0);mask=cumulative%4==0;common=safe[mask];cstarts=np.flatnonzero(common & np.r_[True,~common[:-1]]);cends=np.flatnonzero(common & np.r_[~common[1:],True]);clong=max((int(e-b+1)*4 for b,e in zip(cstarts,cends)),default=0)
   prefixsafe=safe[m['start_step']:] & (abs(xs[m['start_step']+1:,0])<=3);firstbad=np.flatnonzero(~prefixsafe);prefixn=int(firstbad[0]) if len(firstbad) else len(prefixsafe);prefixsum=int(np.sum(skips[m['start_step']:m['start_step']+prefixn]));maxcart=float(np.max(abs(xs[:,0])));infos=row['per_step_info'];assert len(infos)==n and not any(q['simulation_error'] for q in infos);assert not any(q['terminated'] or q['truncated'] for q in infos[:-1]);assert infos[-1]['termination_reason']==row['termination_reason']
   reason=row['termination_reason'];full=int(np.sum(skips))==6000 and reason=='time_limit' and maxcart<=3;component=full and longest>=1000;assert row['native_substeps']==int(np.sum(skips));assert row['episode_elapsed_seconds']==int(np.sum(skips))*.005 and row['hold_seconds']==longest*.005 and row['common_50hz_hold_seconds']==clong*.005 and row['posthandoff_safe_prefix_seconds']==prefixsum*.005 and row['maximum_cart']==maxcart and row['full_duration_clean_inrail']==full and row['cadence_component_gate_passed']==component and row['full_nominal_gate_passed']==(component and skip==4);assert row['maintenance_saturation_count']==sum(abs(us[m['start_step']:])==1)
   if reason=='rail_violation':assert abs(xs[-1,0])>3 and infos[-1]['terminated']
   elif reason=='time_limit':assert n==375+4500//skip and infos[-1]['truncated'] and not infos[-1]['terminated']
   elif reason=='angle_limit':assert angles[-1]>float(cfg['env']['terminate_abs_angle']) and infos[-1]['terminated']
   else:raise AssertionError('Unexpected termination needs explicit audit')
   if skip==4 and multiplier==1.:
    with np.load(m['matched_baseline']['path']) as z:assert z['states'].tobytes()==xs.tobytes() and z['actions'].tobytes()==us.tobytes()
    assert row['matched_baseline_byte_exact']
   if multiplier==1.:
    previous=next(q for q in unit_source['records'] if q['maintenance_frame_skip']==skip)
    with np.load(previous['tape']['path']) as z:assert z['states'].tobytes()==xs.tobytes() and z['actions'].tobytes()==us.tobytes()
   rows.append({k:row[k] for k in ('label','gain_multiplier','maintenance_hz','hold_seconds','common_50hz_hold_seconds','posthandoff_safe_prefix_seconds','actual_hanging_start_episode_steps','native_substeps','episode_elapsed_seconds','maximum_cart','termination_reason','maintenance_saturation_count','cadence_component_gate_passed','full_nominal_gate_passed','tape')})
  expected_execution=1500+2*sum(q['native_substeps'] for q in rows);assert acc['native_physics_substeps']==expected_execution and acc['counts']['attempted_substeps']==acc['counts']['completed_substeps'] and acc['actual_hanging_start_episode_steps']==actual_ticks and acc['counts']['actual_completed']==actual_ticks;assert {k:v['completed'] for k,v in acc['actual_calls_by_frame_skip'].items()}==by_skip
  assert total_substeps<=m['audit_substep_ceiling'];dump_json(dict(status='finished',passed=True,generated_at=utc_timestamp(),scope=m['scope'],outcomes=rows,actual_tapes_controller_raws_f32_prefix_and_all_native_transitions_byte_exact=True,plant_xml_identical=True,elapsed_time_and_dense_common_sampling_gates_independent=True,maximum_native_time_accumulation_error_seconds=max_time_error,native_physics_substeps=total_substeps,total_native_transition_calls=total_substeps/4,actual_hanging_start_episode_steps=0,actual_source_steps_proved=actual_ticks,by_frame_skip=by_skip,execution_accounting_verified=acc,script=file_metadata(__file__)),out/'result.json');print(rows,flush=True)
 finally:env.close()
if __name__=='__main__':main()
