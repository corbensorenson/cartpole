"""Independent native byte proofs and finite-grid/refinement reconstruction for R38."""
import argparse,json
from pathlib import Path
import numpy as np,mujoco
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg
read=lambda p:json.loads(Path(p).read_text())
def same(a,b):assert np.asarray(a).tobytes()==np.asarray(b).tobytes()
def measure(x):
 angle=float(np.max(abs(wrap_angle(np.cumsum(x[1:16])))));cart=float(x[0]);return dict(maximum_angle=angle,cart=cart,safe149=angle<.149 and abs(cart)<=3,upright150=angle<.15,maximum_absolute_rate=float(np.max(abs(np.cumsum(x[17:])))))
def prefix(states):
 ok=[measure(x)['safe149'] for x in states];bad=np.flatnonzero(~np.asarray(ok,bool));return int(bad[0]) if len(bad) else len(states)
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(a.root);out=Path(a.out);out.mkdir(exist_ok=False);m=read(root/'manifest.json');r=read(root/'execution/diagnostic/result.json');acc=read(root/'execution/inclusive_accounting.json');s=read(m['source']['path']);base=read(s['source']['path']);initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']);X=np.vstack([initial,[q['qpos']+q['qvel'] for q in s['result']['trajectory']]]);U=np.asarray([q['action'] for q in s['result']['trajectory']],np.float32).astype(float);gain=np.asarray(read(m['source_result']['path'])['gain'])
 with np.load(m['tracking_array']['path']) as z:K=z['gains'][m['tracking_variant_index']]
 cases={}
 for q in m['cases']:
  if q['tape'] is None:cases[q['label']]=X[q['step']]
  else:
   assert q['tape']==file_metadata(q['tape']['path'])
   with np.load(q['tape']['path']) as z:cases[q['label']]=z['states'][q['step']]
 assert r['one_step_tape']==file_metadata(r['one_step_tape']['path'])
 with np.load(r['one_step_tape']['path']) as z:states=z['states'];actions=z['actions']
 candidates=r['one_step_candidates'];assert len(candidates)==len(states);count=[0];old=mujoco.mj_step;attempts=0;env=None;refinements=0
 payload=dict(status='running',generated_at=utc_timestamp(),script=file_metadata(__file__),source_result=file_metadata(root/'execution/diagnostic/result.json'),source_accounting=file_metadata(root/'execution/inclusive_accounting.json'),native_transition_ceiling=10000,actual_hanging_start_episode_steps=0,not_solution=True,canonical_release_evidence=False)
 def counted(model,data,*args,**kw):
  n=int(kw.get('nstep',args[0] if args else 1));assert count[0]+n<=40000;count[0]+=n;return old(model,data,*args,**kw)
 def rawgain(x):
  y=x.copy();y[1:16]=wrap_angle(y[1:16]);return -float(gain@y)
 def phi(index):return candidates[index]['metrics']['maximum_angle']
 def lookup(state,raw):
  u=float(np.float32(np.clip(raw,-1,1)));return keys[(state.tobytes(),np.float32(u).tobytes())]
 def refine(state,grid,rr):
  nonlocal refinements
  ids=[lookup(state,u) for u in grid];assert ids==rr['coarse_ids'];best=min(range(len(ids)),key=lambda i:phi(ids[i]));left=float(grid[max(0,best-1)]);right=float(grid[min(len(grid)-1,best+1)]);assert rr['initial_bracket']==[left,right];ratio=(np.sqrt(5)-1)/2;c=right-ratio*(right-left);d=left+ratio*(right-left);ci=lookup(state,c);di=lookup(state,d);assert rr['golden_initial_ids']==[ci,di];allids=ids+[ci,di]
  for it,hist in enumerate(rr['history']):
   if phi(ci)<=phi(di):right,d,di=d,c,ci;c=right-ratio*(right-left);ci=lookup(state,c);new=ci;branch='left'
   else:left,c,ci=c,d,di;d=left+ratio*(right-left);di=lookup(state,d);new=di;branch='right'
   assert hist==dict(iteration=it,branch=branch,left=left,right=right,c=c,d=d,candidate_c=ci,candidate_d=di,new_candidate=new);allids.append(new)
  assert len(rr['history'])==m['golden_iterations'];winner=min(allids,key=phi);assert winner==rr['best_candidate'] and ids[best]==rr['coarse_best_candidate'] and candidates[winner]['metrics']==rr['best_metrics'];refinements+=1
 mujoco.mj_step=counted
 try:
  cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);env=NLinkCartPoleEnv(cfg,progress=1.,seed=20265100);env.reset(seed=20265100);native=MujocoTransition(env,np.eye(32),continuous_angles=True)
  for i in range(376):attempts+=1;same(native(X[i],float(U[i])),X[i+1])
  keys={}
  for i,(xs,u,record) in enumerate(zip(states,actions,candidates,strict=True)):
   assert record['index']==i and record['error'] is None and record['completed_steps']==1 and record['action']==u;assert float(np.float32(u))==u and abs(u)<=1;key=(xs[0].tobytes(),np.float32(u).tobytes());assert key not in keys;keys[key]=i;attempts+=1;same(native(xs[0],float(u)),xs[1]);assert measure(xs[1])==record['metrics']
  pairmeta={q['label']:q for q in r['pair_maps']}
  for q in r['queries']:
   label=q['label'];state=cases.get(label)
   if state is None:
    if label.endswith('_pair_first'):state=cases[label.removesuffix('_pair_first')]
    else:
     head,number=label.rsplit('_pair_second_',1);idx=pairmeta[head]['refinements'][int(number)]['first_candidate'];state=states[idx,1]
   assert lookup(state,q['raw_action'])==q['candidate'];assert float(np.float32(np.clip(q['raw_action'],-1,1)))==q['delivered_action']
  for q in r['one_step_screens']:
   state=cases[q['label']];same(q['initial_state'],state);grid=np.unique(np.r_[np.linspace(-1,1,m['grid_points']).astype(np.float32).astype(float),U[q['step']]]);same(grid,q['grid_actions']);refine(state,grid,q);assert q['grid_safe_count']==sum(candidates[i]['metrics']['safe149'] for i in q['coarse_ids']);assert q['gain_raw_action']==rawgain(state) and q['gain_delivered_action']==float(np.float32(np.clip(rawgain(state),-1,1)))
  for q in r['pair_maps']:
   assert q['tape']==file_metadata(q['tape']['path']);initialstate=cases[q['label']]
   with np.load(q['tape']['path']) as z:pairxs=z['states'];us=z['actions'];safe=z['safe_prefix'];g0=z['first_actions'];g1=z['second_actions'];first=z['first_candidate_ids'];second=z['second_candidate_ids']
   same(g0,np.unique(np.r_[np.linspace(-1,1,m['grid_points']).astype(np.float32).astype(float),U[375]]));same(g1,np.unique(np.r_[np.linspace(-1,1,m['grid_points']).astype(np.float32).astype(float),U[376]]));assert q['first_actions']==len(g0) and q['second_actions']==len(g1)
   for i,u0 in enumerate(g0):
    assert lookup(initialstate,u0)==first[i];x1=states[first[i],1];rr=q['refinements'][i];assert rr['first_action']==u0 and rr['first_candidate']==first[i];refine(x1,g1,rr)
    for j,u1 in enumerate(g1):same(us[i,j],[u0,u1]);assert lookup(x1,u1)==second[i,j];same(pairxs[i,j],np.vstack([initialstate,x1,states[second[i,j],1]]));assert safe[i,j]==prefix(pairxs[i,j,1:])
   assert q['coarse_two_safe_pairs']==int(np.sum(safe==2)) and q['first_actions_with_coarse_second_safe']==int(np.sum(np.any(safe==2,axis=1)));assert q['first_actions_with_refined_second_safe']==sum(measure(states[v['first_candidate'],1])['safe149'] and v['best_metrics']['safe149'] for v in q['refinements'])
  for q in r['continuations']:
   assert q['tape']==file_metadata(q['tape']['path'])
   with np.load(q['tape']['path']) as z:xs=z['states'];us=z['actions'];raws=z['raws']
   same(xs[0],cases[q['label']]);assert q['error'] is None and len(us)==q['completed_steps']==q['attempted_steps']==m['continuation_steps']
   for j,u in enumerate(us):
    tick=q['step']+j;raw=rawgain(xs[j]) if q['policy']=='maintenance' else float(U[tick]) if q['policy']=='source_feedforward' else float(U[tick])+float(K[tick-m['tracking_start']]@(xs[j]-X[tick]));assert raw==raws[j] and float(np.float32(np.clip(raw,-1,1)))==u;attempts+=1;same(native(xs[j],float(u)),xs[j+1])
   assert q['safe_prefix']==prefix(xs[1:]);assert q['maximum_angle']==max(measure(x)['maximum_angle'] for x in xs[1:]);assert q['maximum_cart']==max(abs(float(x[0])) for x in xs[1:])
   if q.get('source_reference_byte_exact'):same(xs,X[q['step']:q['step']+len(xs)])
  assert attempts==r['total_native_transition_calls']==acc['total_native_transition_calls'] and count[0]==acc['native_physics_substeps'];payload.update(status='finished',passed=True,outcomes=dict(screens=[{k:q[k] for k in ('label','grid_safe_count','best_metrics','gain_raw_action','gain_delivered_action')} for q in r['one_step_screens']],pairs=[{k:q[k] for k in ('label','first_actions','second_actions','coarse_two_safe_pairs','first_actions_with_coarse_second_safe','first_actions_with_refined_second_safe')} for q in r['pair_maps']],continuations=[{k:q[k] for k in ('label','policy','safe_prefix','completed_steps','maximum_angle','maximum_cart')} for q in r['continuations']]),independent_one_step_tapes=len(candidates),independent_queries=len(r['queries']),independent_refinements=refinements,scope='Every uniqueone-stepnativeprediction, queryF32cachemapping,89bracketedgoldenrefinements, two42x42pairmaps and15private50stepcontinuations independentlyreconstructed/nativebyteproved. Actualstateprovenanceand376sourcecoldproof exact. Finitegrid/localrefinement only, zeroactualepisodes; noforceimpossibility orclosedloop/releaseclaim.')
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}');raise
 finally:
  if env is not None:env.close()
  mujoco.mj_step=old;payload.update(total_native_transition_calls=count[0]/4,native_physics_substeps=count[0],attempted_transition_calls=attempts,finished_at=utc_timestamp());dump_json(payload,out/'result.json');print({k:v for k,v in payload.items() if k!='outcomes'},flush=True)
if __name__=='__main__':main()
