"""Screen target-count closed-loop invariant directions in native mechanics.

Local resets are directional diagnostics, never hanging-start release evidence.
"""
import argparse
import json
from pathlib import Path
import time
import mpmath
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata,utc_timestamp
from gcartpole.ilqr import MujocoTransition
from gcartpole.upright_mechanics import upright_rk4_matrices
from scripts.search_capture_sequence import fixed_state_cfg


AMPLITUDES=(1e-12,1e-10,1e-8,1e-6,1e-4)


def mode_directions(a,b,gain,n,gravity):
    ctx=mpmath.mp.clone();ctx.dps=100
    am=ctx.matrix(a.tolist());bm=ctx.matrix(b.tolist());k=ctx.matrix([gain.tolist()])
    closed=am-bm*k
    values,vectors=ctx.eig(closed,left=False,right=True)
    assert len(values)==2*(n+1) and max(abs(z) for z in values)<1
    timescale=ctx.sqrt(ctx.mpf(3)/ctx.mpf(gravity))
    def norm(x):
        physical=[x[0]/3,timescale*x[n+1]/3]
        angle=rate=ctx.mpf(0)
        for i in range(n):
            angle+=x[i+1];rate+=x[n+2+i]
            physical.extend((angle/ctx.mpf('.15'),timescale*rate/ctx.mpf('.15')))
        return ctx.sqrt(ctx.fsum(v*v for v in physical))
    directions=[]
    for index in sorted(range(len(values)),key=lambda i:(abs(values[i]),ctx.re(values[i]),ctx.im(values[i]))):
        pole=values[index]
        if ctx.im(pole)<-ctx.mpf('1e-60'):continue
        vector=vectors[:,index]
        pivot=max(range(vector.rows),key=lambda i:abs(vector[i]))
        vector=vector/vector[pivot]
        residual=ctx.norm(closed*vector-pole*vector)/ctx.norm(vector)
        assert residual<ctx.mpf('1e-70')
        phases=[('real',ctx.matrix([ctx.re(v) for v in vector]))]
        if abs(ctx.im(pole))>ctx.mpf('1e-60'):
            phases.append(('imaginary',ctx.matrix([ctx.im(v) for v in vector])))
        for phase,direction in phases:
            scale=norm(direction)
            assert scale>0
            exact=direction/scale
            rounded=np.array(list(exact),dtype=float)
            assert np.all(np.isfinite(rounded))
            directions.append(dict(mode=len(directions),source_eigenvector=index,phase=phase,
                pole_real=str(ctx.re(pole)),pole_imaginary=str(ctx.im(pole)),pole_modulus=str(abs(pole)),
                source_eigen_residual=str(residual),dimensionless_norm_of_rounded_direction=str(norm(ctx.matrix(rounded.tolist()))),
                rounded_direction=rounded.tolist(),
                raw_action_per_unit_amplitude=str(-(k*ctx.matrix(rounded.tolist()))[0])))
    assert len(directions)==2*(n+1)
    return directions,dict(decimal_digits=100,length_scale_m=3.,angle_scale_rad=.15,
        time_scale_seconds=str(timescale),definition='L2 of cart position/3, cart speed*T/3, '
        'cumulative absolute angles/0.15 and cumulative absolute rates*T/0.15. T=sqrt(3/g). '
        'Preserves whole-state invariant directions including cart coordinates; amplitudes are dimensionless '
        'and not numerically identical to earlier mixed relative-angle/rate norms.',
        complex_poles_use_two_real_invariant_plane_phases=True)


def screen(cfg,initial,gain,predictor,path):
    n=cfg['env']['n_links'];nx=n+1
    local=fixed_state_cfg(cfg,dict(qpos=initial[:nx].tolist(),qvel=initial[nx:].tolist()),30.)
    for key in ('init_qpos_scale_start','init_qpos_scale_end'):local['env'].pop(key,None)
    env=NLinkCartPoleEnv(local,progress=1.,seed=0);env.reset(seed=0)
    assert np.r_[env.data.qpos,env.data.qvel].tobytes()==initial.tobytes()
    states=[initial.copy()];actions=[];longest=streak=0;first_failure=None
    maximum_angle=maximum_rate=maximum_cart=maximum_raw=0.;saturated=0
    try:
        for _ in range(env.max_steps):
            physical=states[-1].copy();physical[1:nx]=wrap_angle(physical[1:nx])
            raw=-float(gain@physical);action=float(np.float32(np.clip(raw,-1,1)))
            assert abs(action)<=1 and action==float(np.float32(action))
            maximum_raw=max(maximum_raw,abs(raw));saturated+=abs(raw)>1
            _,_,terminated,truncated,info=env.step([action])
            current=np.r_[env.data.qpos,env.data.qvel]
            states.append(current);actions.append(action)
            angle=float(np.max(np.abs(wrap_angle(np.cumsum(current[1:nx])))))
            rate=float(np.max(np.abs(np.cumsum(current[nx+1:]))))
            maximum_angle=max(maximum_angle,angle);maximum_rate=max(maximum_rate,rate)
            maximum_cart=max(maximum_cart,abs(current[0]))
            streak=streak+1 if angle<.15 else 0;longest=max(longest,streak)
            if angle>=.15 and first_failure is None:first_failure=len(actions)*env.dt
            if terminated or truncated:break
        before=predictor.evaluations
        for index,action in enumerate(actions):
            assert predictor(states[index],action).tobytes()==states[index+1].tobytes()
        proof=predictor.evaluations-before
        assert proof==len(actions)
        np.savez_compressed(path,states=np.asarray(states),actions=np.asarray(actions))
        return dict(steps=len(actions),physical_hold_seconds=longest*env.dt,
            first_angle_failure_seconds=first_failure,all_samples_upright=first_failure is None,
            local_gate_pass=len(actions)==1500 and longest*env.dt>=5 and
                info['termination_reason']=='time_limit' and not info['simulation_error'],
            maximum_angle=maximum_angle,maximum_absolute_rate=maximum_rate,
            maximum_cart=maximum_cart,maximum_raw_action=maximum_raw,saturated_ticks=saturated,
            termination_reason=info['termination_reason'],simulation_error=info['simulation_error'],
            actual_local_episode_steps=len(actions),independent_tape_replay_calls=proof,
            total_native_transition_calls=len(actions)+proof,independent_tape_replay_bytes_exact=True,
            tape=file_metadata(path),initial_state=initial.tolist())
    finally:env.close()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline',required=True);parser.add_argument('--spectral-component',required=True)
    parser.add_argument('--directory',required=True)
    parser.add_argument('--verify-prefix')
    args=parser.parse_args();out=Path(args.directory)
    if out.exists():raise FileExistsError(out)
    out.mkdir(parents=True);(out/'tapes').mkdir()
    base=json.loads(Path(args.baseline).read_text());spectral=json.loads(Path(args.spectral_component).read_text())
    assert spectral['baseline']==file_metadata(args.baseline)
    cache_ref=next(r for r in base['sources'] if r['path'].endswith('capture_cache.json'))
    assert cache_ref==file_metadata(cache_ref['path'])
    cache=json.loads(Path(cache_ref['path']).read_text())
    selected=next(r for r in spectral['records'] if r['label']=='moderately_separated_decay')
    assert selected['status']=='finished'
    gains=dict(saved_baseline=np.asarray(cache['gain']),moderately_separated_decay=np.asarray(selected['gain']))
    prefix=None
    if args.verify_prefix:
        prefix=json.loads(Path(args.verify_prefix).read_text())
        assert prefix['baseline']==file_metadata(args.baseline)
        assert prefix['spectral_component']==file_metadata(args.spectral_component)
    cfg=load_config('configs/swingup15_uniform.yaml')
    forecast=NLinkCartPoleEnv(cfg,progress=1.,seed=0);forecast.reset(seed=0)
    a,b,mechanics=upright_rk4_matrices(forecast,decimal_digits=100)
    predictor=MujocoTransition(forecast,np.eye(32),continuous_angles=True)
    gravity=-float(forecast.model.opt.gravity[2])
    payload=dict(generated_at=utc_timestamp(),parameters=vars(args),runtime=runtime_metadata(),
        script=file_metadata(__file__),baseline=file_metadata(args.baseline),spectral_component=file_metadata(args.spectral_component),
        config=file_metadata('configs/swingup15_uniform.yaml'),mechanics=mechanics,
        amplitudes=list(AMPLITUDES),gains={k:v.tolist() for k,v in gains.items()},designs=[],records=[],
        actual_local_episode_steps=0,independent_tape_replay_calls=0,total_native_transition_calls=0,
        native_transition_ceiling=1926000,actual_hanging_start_episode_steps=0,
        reserved_seeds_used=False,noisy_development_seeds_used=False,canonical_release_evidence=False,not_solution=True,
        scope='All32real invariant directions (complex pairs as real/imaginary phases) for each of two frozen '
              'target15gains;five dimensionless amplitudes and both signs plus origin control. '
              'Native bounded F32 feedback,full30s local diagnostics and independent full-tape proof. '
              'No hanging-start solve, exhaustive basin certificate, arbitrary disturbance guarantee or new canonical gate.')
    payload['zero_initialization_convention']='Normalize both signs of exact zero to positive zero before reset; nonzero coordinates unchanged.'
    if prefix is not None:payload['interrupted_prefix_source']=file_metadata(args.verify_prefix)
    began=time.monotonic()
    try:
        for label,gain in gains.items():
            directions,definition=mode_directions(a,b,gain,15,gravity)
            payload['designs'].append(dict(gain_label=label,directions=directions,normalization=definition))
            sources=[(None,0.,1,np.zeros(32))]
            sources.extend((d['mode'],amplitude,sign,sign*amplitude*np.asarray(d['rounded_direction']))
                for d in directions for amplitude in AMPLITUDES for sign in (1,-1))
            for mode,amplitude,sign,initial in sources:
                initial[initial==0]=0.
                tape=out/'tapes'/f'{label}_{len(payload["records"]):04d}.npz'
                result=screen(cfg,initial,gain,predictor,tape)
                index=len(payload['records'])
                if prefix is not None and index<len(prefix['records']):
                    old=prefix['records'][index]
                    assert (label,mode,amplitude,sign)==(old['gain_label'],old['mode'],old['amplitude'],old['sign'])
                    assert old['result']['tape']==file_metadata(old['result']['tape']['path'])
                    with np.load(old['result']['tape']['path']) as previous,np.load(tape) as current:
                        for key in ('states','actions'):
                            assert previous[key].tobytes()==current[key].tobytes()
                    assert result['total_native_transition_calls']==old['result']['total_native_transition_calls']
                    result['interrupted_prefix_actions_states_and_call_count_byte_exact']=True
                payload['records'].append(dict(gain_label=label,mode=mode,amplitude=amplitude,sign=sign,result=result))
                for key in ('actual_local_episode_steps','independent_tape_replay_calls','total_native_transition_calls'):
                    payload[key]+=result[key]
                assert payload['total_native_transition_calls']<=payload['native_transition_ceiling']
                payload['wall_seconds']=time.monotonic()-began
                dump_json(payload,out/'result.progress.json')
                if mode is None or result['local_gate_pass'] or (amplitude==AMPLITUDES[-1] and sign==-1):
                    print(json.dumps(dict(gain=label,mode=mode,amplitude=amplitude,sign=sign,
                        pass30=result['local_gate_pass'],hold=result['physical_hold_seconds'],
                        completed=len(payload['records']),calls=payload['total_native_transition_calls'])),flush=True)
        assert len(payload['records'])==642
        payload['wall_seconds']=time.monotonic()-began;dump_json(payload,out/'result.json')
    finally:forecast.close()


if __name__=='__main__':main()
