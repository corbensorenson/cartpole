"""Scientific exports of eigenvalue, input-correlation and transient maps."""
import argparse,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import numpy as np
from gcartpole.evidence import file_metadata


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--spectrum',required=True);p.add_argument('--transients',required=True)
    args=p.parse_args();s=json.loads(Path(args.spectrum).read_text());t=json.loads(Path(args.transients).read_text())
    assert s['independent_gramian_spectra_verified']==129 and len(t['records'])==24
    out=Path(args.spectrum).parent/'figures';out.mkdir(exist_ok=True);figures=[]
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    def save(fig,name):
        for suffix in ('png','pdf'):
            path=out/f'{name}.{suffix}';fig.savefig(path,dpi=180,facecolor='white');figures.append(file_metadata(path))
        plt.close(fig)
    base=[r for r in s['records'] if r['axis']=='count'];ns=[r['n_links'] for r in base]
    fig,axes=plt.subplots(2,2,figsize=(12,8))
    for r in base:axes[0,0].scatter([r['n_links']]*r['n_links'],[float(v) for v in r['spectrum']['unstable_growth_rates_per_second']],s=12,color='#176b92')
    axes[0,0].set_ylabel('Unstable mode growth rate (s⁻¹)');axes[0,0].set_title('More growing modes, similar fastest growth')
    axes[0,1].plot(ns,[float(r['spectrum']['normalized_backward_gram_condition']) for r in base],'o-',color='#a34d11')
    axes[0,1].set_yscale('log');axes[0,1].set_ylabel('Normalized backward Gram condition');axes[0,1].set_title('Single-input time responses become nearly dependent')
    axes[1,0].plot(ns,[float(r['spectrum']['minimum_left_mode_input_overlap']) for r in base],'o-',color='#387f59')
    axes[1,0].set_ylabel('Minimum normalized left-mode input overlap');axes[1,0].set_title('Every individual unstable mode remains coupled')
    rr=[r for r in t['records'] if (r['length_scale'],r['hub_diameter_m'])==(1.,0.)]
    axes[1,1].plot([r['n_links'] for r in rr],[max(v['maximum_state_amplification_largest_singular_value'] for v in r['transient']) for r in rr],'o-',color='#7f4995')
    axes[1,1].set_yscale('log');axes[1,1].set_ylabel('Largest sampled closed-loop state amplification');axes[1,1].set_title('Stable feedback poles permit very large transients')
    for ax in axes.flat:ax.set_xlabel('Link count');ax.grid(alpha=.15);ax.set_xticks([7,10,14,15,20])
    axes[1,1].set_xticks([7,10,14,15])
    fig.suptitle('The frontier changes more in control geometry than in fastest instability',fontsize=15)
    fig.tight_layout(rect=[0,.11,1,.94])
    fig.text(.06,.065,'Canonical plants, MP100 mechanics/spectra. The backward Gram isolates unstable modal response similarity.',fontsize=10)
    fig.text(.06,.035,'Transient panel: shared-cost redesigned controllers, fixed whole-state units, sampled at 0.02/0.1/0.5/2/8 s.',fontsize=10)
    fig.text(.06,.008,'Local unbounded linear diagnostics. Counts 15–20 are component analyses, not accepted solves.',fontsize=10)
    save(fig,'count_spectral_relationships')
    fig,axes=plt.subplots(2,2,figsize=(12,8),sharex=True,sharey=True)
    for n,ax in zip((7,10,14,15),axes.flat):
        baseline=next(r for r in base if r['n_links']==n);c0=float(baseline['spectrum']['normalized_backward_gram_condition']);values=np.zeros((4,3))
        for r in s['records']:
            if r['n_links']!=n or r['axis'] not in ('count','geometry'):continue
            i=[0.,.05,.10,.15].index(r['hub_diameter_m']);j=[.95,1.,1.05].index(r['length_scale'])
            values[i,j]=float(r['spectrum']['normalized_backward_gram_condition'])/c0
        im=ax.imshow(values,origin='lower',aspect='auto',cmap='RdYlBu_r',norm=LogNorm(.4,2.5))
        for i in range(4):
            for j in range(3):ax.text(j,i,f'{values[i,j]:.2f}×',ha='center',va='center',fontsize=10)
        ax.set_title(f'{n} links');ax.set_xticks(range(3),['−5%','Original','+5%']);ax.set_yticks(range(4),['0','5','10','15'])
    for ax in axes[1]:ax.set_xlabel('Individual link length change')
    for ax in axes[:,0]:ax.set_ylabel('Hub diameter (cm)')
    fig.suptitle('Geometry shifts input conditioning, but count scaling remains',fontsize=16)
    fig.subplots_adjust(left=.08,right=.86,bottom=.16,top=.88,hspace=.25,wspace=.15)
    fig.colorbar(im,cax=fig.add_axes([.90,.25,.018,.5]),label='Condition / same-count baseline')
    fig.text(.06,.065,'Smaller is better for this diagnostic only. Original 14→15 condition ratio is about 102×.',fontsize=10)
    fig.text(.06,.032,'Nonzero hubs all add 0.1 kg; comparing with zero also changes mass/COM. No nonlinear capture certificate.',fontsize=10)
    save(fig,'geometry_input_conditioning')
    # Common original no-hub reference for all interventions; mass confounds explicit.
    names=['Length +5%','Hub 15 cm (+0.1 kg)','Length +5%, hub 15 cm','Armature ×0.5','Armature ×2',
           'Damping ×2','Control 100 Hz','Control 200 Hz','Hub 15 cm (+0.4 kg)','Hub 15 cm (+0.9 kg)']
    def selected(n):
        rows=[r for r in s['records'] if r['n_links']==n]
        pick=lambda axis,variant:next(r for r in rows if r['axis']==axis and r['variant']==variant)
        geom=lambda l,d:next(r for r in rows if r['axis']=='geometry' and (r['length_scale'],r['hub_diameter_m'])==(l,d))
        return [geom(1.05,0.),geom(1.,.15),geom(1.05,.15),pick('armature','factor0.5'),pick('armature','factor2.0'),
                pick('damping','factor2.0'),pick('control_cadence','frame2'),pick('control_cadence','frame1'),
                pick('hub_mass','added0.4kg'),pick('hub_mass','added0.9kg')]
    fig,axes=plt.subplots(1,2,figsize=(13,6),sharey=True)
    for n,color,marker in ((14,'#7a8a96','o'),(15,'#bc5a24','D')):
        b=next(r for r in base if r['n_links']==n)['spectrum'];rows=selected(n);y=np.arange(len(names))
        growth=[100*(float(r['spectrum']['fastest_unstable_growth_per_second'])/float(b['fastest_unstable_growth_per_second'])-1) for r in rows]
        condition=[float(r['spectrum']['normalized_backward_gram_condition'])/float(b['normalized_backward_gram_condition']) for r in rows]
        axes[0].scatter(growth,y,label=f'{n} links',color=color,marker=marker,s=45)
        axes[1].scatter(condition,y,label=f'{n} links',color=color,marker=marker,s=45)
    axes[0].set_yticks(range(len(names)),names);axes[0].invert_yaxis();axes[0].axvline(0,color='gray',lw=.7)
    axes[0].set_xlabel('Change in fastest growth (%)');axes[0].legend(loc='upper right')
    axes[1].set_xscale('log');axes[1].axvline(1,color='gray',lw=.7);axes[1].set_xlabel('Backward Gram condition / baseline')
    for ax in axes:ax.grid(alpha=.15)
    fig.suptitle('Slower instability can come with worse input conditioning',fontsize=16)
    fig.tight_layout(rect=[0,.13,1,.92])
    fig.text(.06,.075,'Each count uses its original no-hub 50 Hz baseline. Armature changes both cart and hinge armature.',fontsize=10)
    fig.text(.06,.043,'Damping scales cart and total hinge damping. Hub comparisons also change mass/COM; Hz changes held-input cadence.',fontsize=10)
    fig.text(.06,.014,'These rankings concern local model diagnostics, not resynthesized swing-up success or control energy.',fontsize=10)
    save(fig,'parameter_spectral_tradeoffs')
    fig,axes=plt.subplots(1,2,figsize=(13,6))
    for r in rr:
        axes[0].plot([v['seconds'] for v in r['transient']],[v['maximum_state_amplification_largest_singular_value'] for v in r['transient']],
                     'o-',label=f'{r["n_links"]} links')
    axes[0].set_xscale('log');axes[0].set_yscale('log');axes[0].set_xlabel('Time after perturbation (s)')
    axes[0].set_ylabel('Maximum state amplification in fixed units');axes[0].legend();axes[0].set_title('Stable poles: spectral radii < 1 in every case')
    r=next(r for r in rr if r['n_links']==15);e=next(e for e in r['episodes'] if e['amplitude']==1e-13 and e['direction_index']==0)
    fields=[('native_state_norm','Native state','#222222'),('ideal_unbounded_model_state_norm','Ideal feedback model','#176b92'),
            ('propagated_action_forcing_norm','Action-forcing contribution','#b55b15'),('propagated_model_remainder_norm','Model-remainder contribution','#95446a')]
    for field,label,color in fields:axes[1].plot([v['tick']*.02 for v in e['history']],[float(v[field]) for v in e['history']],'.-',label=label,color=color)
    axes[1].set_yscale('log');axes[1].set_xlabel('Time after perturbation (s)');axes[1].set_ylabel('State/contribution norm in fixed units')
    axes[1].set_title('15 links, one stored 10⁻¹³-direction episode');axes[1].legend(fontsize=8)
    for ax in axes:ax.grid(alpha=.15)
    fig.suptitle('Eigenvalues describe eventual behavior; transients and forcing determine the path',fontsize=15)
    fig.tight_layout(rect=[0,.23,1,.91])
    fig.text(.06,.10,'Left: MP100 matrix powers, largest singular values after rounding. Right: algebraic decomposition of an existing native tape.',fontsize=10)
    fig.text(.06,.066,'Model remainder includes nonlinear physics and numerical arithmetic. Action forcing includes clipping, F32 and wrapped feedback.',fontsize=10)
    fig.text(.06,.032,'Contributions can cancel; their norms do not add. The right trace ends at the first transition leaving the local angle window.',fontsize=10)
    save(fig,'feedback_transients_and_native_forcing')
    payload=dict(spectrum=file_metadata(args.spectrum),transients=file_metadata(args.transients),script=file_metadata(__file__),figures=figures,native_transition_calls=0)
    (out/'figures.json').write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps({'figures':len(figures),'directory':str(out),'native_transition_calls':0}))


if __name__=='__main__':main()
