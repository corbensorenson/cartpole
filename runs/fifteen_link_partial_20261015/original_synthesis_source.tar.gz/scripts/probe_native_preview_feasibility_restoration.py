#!/usr/bin/env python
"""Restore a physical forecast sequence at a retained online-policy fallback."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.ilqr import MujocoTransition
from gcartpole.native_sequence_feasibility import restore_native_sequence
from scripts.search_capture_sequence import fixed_state_cfg

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    source=json.loads(Path(args.source).read_text());cfgpath=source['config']['path']
    if file_metadata(cfgpath)!=source['config'] or file_metadata(source['source']['path'])!=source['source']:
        raise ValueError('Declared source inputs changed')
    base=json.loads(Path(source['source']['path']).read_text());cfg=load_config(cfgpath);n=cfg['env']['n_links']
    if not np.array_equal(base['controller']['coordinate_transform'],np.eye(2*(n+1))):
        raise ValueError('Physical coordinates required')
    rows=source['result']['trajectory'];index=next(i for i,r in enumerate(rows) if r.get('tracking_preview',{}).get('fallback'))
    previous=rows[index-1];plan=np.asarray(previous['tracking_preview']['selected_sequence']);horizon=len(plan)
    state=np.asarray(previous['qpos']+previous['qvel']);step=previous['step']
    reference=np.asarray(base['controller']['controls'][step:step+horizon])
    seeds=np.vstack([reference,np.r_[plan[1:],-1.]])
    def physical(states):
        return np.abs(wrap_angle(np.cumsum(states[:,1:n+1],axis=1))),np.abs(np.cumsum(states[:,n+2:],axis=1)),np.abs(states[:,0])
    def residual(states):
        angle,rate,cart=physical(states)
        return np.r_[(np.maximum(angle-.13,0.)/.13).ravel(),
            (np.maximum(rate-.20,0.)/.20).ravel(),np.maximum(cart-2.85,0.)/2.85]
    def admissible(states):
        angle,rate,cart=physical(states)
        return bool(np.max(angle)<=.14 and np.max(rate)<=.25 and np.max(cart)<=3.)
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    predictor=MujocoTransition(env,np.eye(2*(n+1)),continuous_angles=True);started=time.monotonic()
    try:
        selected,diagnostics=restore_native_sequence(predictor,state,seeds,reference_actions=reference,
            constraint_residual=residual,admissible=admissible,derivative_epsilon=1e-5,
            max_evaluations=20,action_regularization=1e-5)
        if diagnostics['native_transition_calls']!=predictor.evaluations:raise ValueError('Native call budget mismatch')
        selected_metrics=None
        if selected is not None:
            angle,rate,cart=physical(np.asarray(diagnostics['selected_states']))
            selected_metrics=dict(maximum_absolute_angle=float(np.max(angle)),maximum_absolute_angular_rate=float(np.max(rate)),maximum_cart=float(np.max(cart)))
    finally:env.close()
    dump_json(dict(not_solution=True,benchmark_evidence=False,source=file_metadata(args.source),config=file_metadata(cfgpath),
        component_state=state.tolist(),controller_step=step,controller_time_seconds=step*.02,
        horizon_steps=horizon,seed_labels=['source_reference','previous_suffix_and_minus_one'],
        residual_margins=dict(angle=.13,maximum_absolute_rate=.20,cart=2.85),
        admissibility_limits=dict(angle=.14,maximum_absolute_rate=.25,cart=3.),
        selected_sequence=None if selected is None else selected.tolist(),selected_metrics=selected_metrics,
        diagnostics=diagnostics,native_transition_calls=predictor.evaluations,wall_seconds=time.monotonic()-started,
        runtime=runtime_metadata(),reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Isolated native full-input-sequence local feasibility restoration from a retained actual state. No live rollout, hanging-start solution, recursive viability or canonical robustness is claimed.'),out/'result.json')
    print(json.dumps(dict(found=selected is not None,metrics=selected_metrics,calls=predictor.evaluations)))
if __name__=='__main__':main()
