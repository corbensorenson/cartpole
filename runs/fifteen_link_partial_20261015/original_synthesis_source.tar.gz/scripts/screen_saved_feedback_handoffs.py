"""Prefix-preserving handoffs using the optimizer's original saved feedback."""
import argparse,copy,json
from pathlib import Path
import mujoco,numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.ilqr import MujocoTransition
from scripts.evaluate_fddp_two_expert import load_controller
from scripts.evaluate_fddp_parked_route import run_episode
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source-result',required=True);p.add_argument('--gain-result',required=True);p.add_argument('--directory',required=True);p.add_argument('--handoff-seconds',nargs='+',type=float,required=True);args=p.parse_args()
    read=lambda p:json.loads(Path(p).read_text());d=read(args.source_result);g=read(args.gain_result)
    assert d['status']=='finished' and g['status']=='finished' and d['config']==g['config']
    for r in (d['config'],d['candidate'],d['tape']):assert file_metadata(r['path'])==r
    prior=read(d['candidate']['path']);cfg=load_config(d['config']['path']);controller=load_controller(Path(d['candidate']['path']),14,load_config('benchmarks/p1_capture_envelope.yaml'))
    old=np.load(d['tape']['path']);prefix_steps=prior['controller']['frozen_prefix_steps']
    for t in args.handoff_seconds:assert prefix_steps<=round(t/.02)<=len(old['actions'])
    out=Path(args.directory);out.mkdir(parents=True,exist_ok=False);frame=4;count=[0];step=mujoco.mj_step
    def counted(model,data,*a,**kw):
        n=int(kw.get('nstep',a[0] if a else 1));count[0]+=n
        if count[0]>24000*frame:raise RuntimeError('native call ceiling')
        return step(model,data,*a,**kw)
    mujoco.mj_step=counted
    payload=dict(generated_at=utc_timestamp(),status='running',script=file_metadata(__file__),source=file_metadata(args.source_result),gain_source=file_metadata(args.gain_result),config=d['config'],records=[],native_transition_ceiling=24000,total_native_transition_calls=0,actual_hanging_start_episode_steps=0,not_solution=True,canonical_release_evidence=False,reserved_seeds_used=False,noisy_development_seeds_used=False,scope='Saved optimizer feedback,zero extra affine offsets; same targetplant MP100maintenancegain; continuous exact hanging rollouts and byte-identical actualprefix/fulltape proofs. No unregularized tracking substitution.')
    try:
        for seconds in args.handoff_seconds:
            h=round(seconds/.02);c=copy.deepcopy(controller);c.update(controls=c['controls'][:h],feedback_gains=c['feedback_gains'][:h],nominal_states=c['nominal_states'][:h+1])
            ecfg=fixed_state_cfg(cfg,prior['selected_state'],30.)
            result=run_episode(ecfg,c,np.array(g['gain']),np.zeros(30),seed=0,park_seconds=0.,cart_target=0.,tracking_gain_scale=1.,phase_adaptive=False,phase_window=12,include_trace=True)
            u=np.array([r['action'] for r in result['trajectory']],np.float32).astype(float);x=np.vstack([prior['selected_state']['qpos']+prior['selected_state']['qvel'],[r['qpos']+r['qvel'] for r in result['trajectory']]])
            payload['actual_hanging_start_episode_steps']+=len(u)
            assert x[:h+1].tobytes()==old['states'][:h+1].tobytes() and u[:h].tobytes()==old['actions'][:h].tobytes()
            env=NLinkCartPoleEnv(ecfg,progress=1.,seed=0);env.reset(seed=0);native=MujocoTransition(env,np.eye(30),continuous_angles=True)
            try:
                for i,action in enumerate(u):assert native(x[i],float(action)).tobytes()==x[i+1].tobytes()
            finally:env.close()
            path=out/f'handoff{seconds}.npz';np.savez_compressed(path,states=x,actions=u)
            gate=bool(result['success'] and len(u)==1500 and result['termination_reason']=='time_limit' and result['max_upright_streak_seconds']>=5 and result['max_cart_excursion']<=3 and not result['final_info'].get('simulation_error'))
            r=dict(handoff_seconds=seconds,tape=file_metadata(path),full_nominal_component_gate_passed=gate,prefix_actual_states_and_actions_byte_identical=True,independent_whole_actual_tape_bytes_exact=True,actual_hanging_start_episode_steps=len(u),independent_tape_replay_transition_calls=len(u),total_native_transition_calls=2*len(u),result={k:v for k,v in result.items() if not isinstance(v,(list,dict))});payload['records'].append(r);print(json.dumps(r),flush=True)
        payload['status']='finished'
    except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}');raise
    finally:
        mujoco.mj_step=step;payload.update(total_native_transition_calls=count[0]/4,native_physics_substeps=count[0],partial_transition_substeps=count[0]%4);dump_json(payload,out/'result.json')

if __name__=='__main__':main()
