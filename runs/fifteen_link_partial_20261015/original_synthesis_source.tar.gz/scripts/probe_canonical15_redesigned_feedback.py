"""Matched native arrival probes with freshly redesigned physical feedback."""
import argparse
from pathlib import Path
import mujoco
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import dump_json,load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.ilqr import MujocoTransition
from gcartpole.simulation import SimulationError
from scripts.refine_swingup_endpoint_gauss_newton import interpolation_matrix
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.audit_armature_route_increment import checked,read


def main():
    p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--directory',required=True)
    args=p.parse_args();m=read(args.manifest)
    for key in ('source','controller_source','config','previous_open_loop','gain_design','oracle_audit'):checked(m[key])
    saved=read(m['source']['path']);base=read(m['controller_source']['path']);old=read(m['previous_open_loop']['path'])
    assert old['source']==m['source'] and saved['source']==m['controller_source']
    start,end,knots=m['start_step'],m['arrival_step'],m['knots']
    assert (start,end,knots)==(291,439,48)
    cfg=load_config(m['config']['path']);assert cfg['env']['n_links']==15
    assert base['seed']==20265100 and cfg['env']['frame_skip']==4 and cfg['env']['timestep']==.005
    K=np.asarray(base['controller']['feedback_gains']);assert K.shape==(700,32)
    original_K=K.copy()
    assert read(m['oracle_audit']['path'])['passed']
    with np.load(m['gain_design']['path']) as design: redesigned_gains=design['gains'].copy()
    assert redesigned_gains.shape==(3,148,32) and np.all(np.isfinite(redesigned_gains))
    assert np.asarray(base['controller']['coordinate_transform']).tobytes()==np.eye(32).tobytes()
    initial=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
    source_u=np.asarray([r['action'] for r in saved['result']['trajectory'][:end]],np.float32).astype(float)
    known=np.vstack([initial,[r['qpos']+r['qvel'] for r in saved['result']['trajectory'][:end]]])
    basis=interpolation_matrix(knots,end-start)
    out=Path(args.directory);out.mkdir(exist_ok=False);(out/'tapes').mkdir()
    payload=dict(generated_at=utc_timestamp(),status='running',script=file_metadata(__file__),manifest=file_metadata(args.manifest),
        source=m['source'],controller_source=m['controller_source'],config=m['config'],gain_design=m['gain_design'],records=[],redesigned_zero_bias_baselines=[],
        native_transition_ceiling=m['native_transition_ceiling'],total_native_transition_calls=0,
        actual_hanging_start_episode_steps=0,new_actual_episodes=0,canonical_release_evidence=False,not_solution=True,
        reserved_seeds_used=False,noisy_development_seeds_used=False,scope=m['scope'])
    original=mujoco.mj_step;count=[0];env=None
    def counted(model,data,*a,**kw):
        n=int(kw.get('nstep',a[0] if a else 1))
        if count[0]+n>4*m['native_transition_ceiling']:raise RuntimeError('inclusive native ceiling reached')
        count[0]+=n;return original(model,data,*a,**kw)
    mujoco.mj_step=counted
    try:
        local=fixed_state_cfg(cfg,base['selected_state'],30.)
        env=NLinkCartPoleEnv(local,progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
        untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
        assert untouched.tobytes()==initial.tobytes()
        native=MujocoTransition(env,np.eye(32),continuous_angles=True)
        current=initial.copy()
        for i,u in enumerate(source_u):current=native(current,float(u));assert current.tobytes()==known[i+1].tobytes()
        # Rebuild the moving reference from actual delivered actions and states.
        current=known[start].copy();zero_x=[current.copy()];zero_u=[]
        for i in range(start,end):
            u=float(np.float32(np.clip(source_u[i]+K[i]@(current-known[i]),-1,1)))
            current=native(current,u);zero_x.append(current.copy());zero_u.append(u)
        assert np.asarray(zero_x).tobytes()==known[start:end+1].tobytes()
        assert np.asarray(zero_u).tobytes()==source_u[start:end].tobytes()
        baseline=out/'zero_bias_feedback_reference.npz';np.savez_compressed(baseline,states=zero_x,actions=zero_u)
        payload.update(cold_source439_byte_exact=True,zero_bias_feedback148_byte_exact=True,baseline=file_metadata(baseline),setup_native_calls=count[0]/4)
        oldrows={(q['amplitude'],q['column'],q['sign']):q for q in old['records']}
        for variant in m['gain_variants']:
            scale=1.
            K=original_K.copy();K[start:end]=redesigned_gains[variant['array_index']]
            current=known[start].copy();zx=[current.copy()];zu=[]
            for i in range(start,end):
                u=float(np.float32(np.clip(source_u[i]+K[i]@(current-known[i]),-1,1)))
                current=native(current,u);zx.append(current.copy());zu.append(u)
            assert np.asarray(zx).tobytes()==known[start:end+1].tobytes()
            assert np.asarray(zu).tobytes()==source_u[start:end].tobytes()
            zpath=out/f"zero_bias_{variant['tag']}.npz";np.savez_compressed(zpath,states=zx,actions=zu)
            payload['redesigned_zero_bias_baselines'].append(dict(tag=variant['tag'],tape=file_metadata(zpath),native_transition_calls=148,byte_exact=True))
            payload['setup_native_calls']+=148
            for amplitude in m['amplitudes']:
                for column in range(knots):
                    for sign in (1,-1):
                        bias=sign*amplitude*basis[:,column]
                        shifted=np.clip(source_u[start:end]+bias,-1,1).astype(np.float32).astype(float)
                        changed=np.flatnonzero(shifted!=source_u[start:end])
                        row=dict(gain_variant=variant['tag'],regularization=variant['regularization'],feedback_scale=scale,amplitude=amplitude,column=column,sign=sign,
                                 changed_input_count=len(changed),no_op_after_f32=not len(changed))
                        before=count[0];xs=[];us=[];error=None
                        if len(changed):
                            first=int(changed[0]);current=known[start+first].copy();xs=[current.copy()]
                            try:
                                for j in range(first,end-start):
                                    i=start+j
                                    u=float(np.float32(np.clip(source_u[i]+bias[j]+scale*(K[i]@(current-known[i])),-1,1)))
                                    current=native(current,u);xs.append(current.copy());us.append(u)
                            except SimulationError as exception:error=f'{type(exception).__name__}: {exception}'
                            path=out/'tapes'/f"{variant['tag']}_amp{amplitude}_k{column}_sign{sign}.npz"
                            np.savez_compressed(path,states=np.asarray(xs),actions=np.asarray(us))
                            post=np.vstack([known[start+1:start+first+1],xs[1:]])
                            angles=np.abs(wrap_angle(np.cumsum(post[:,1:16],axis=1)))
                            row.update(tape=file_metadata(path),first_changed_absolute_step=start+first,
                                last_changed_absolute_step=start+int(changed[-1]),
                                maximum_delivered_action_change=float(np.max(abs(shifted-source_u[start:end]))),
                                maximum_arrival_angle=float(np.max(angles)),maximum_arrival_cart=float(np.max(abs(post[:,0]))),
                                arrival_bounds_passed=bool(error is None and len(post)==end-start and np.all(angles<.149) and np.all(abs(post[:,0])<=3)),
                                endpoint_state_difference_norm=None if error else float(np.linalg.norm(current-known[end])),
                                simulation_error=error,failed_input_action=None if error is None else u)
                        row['native_transition_calls']=(count[0]-before)/4
                        if scale==0:
                            prior=oldrows[(amplitude,column,sign)]
                            for key in prior:
                                assert row[key]==prior[key],(key,amplitude,column,sign,row.get(key),prior[key])
                            row['archived_open_loop_summary_exact']=True
                        payload['records'].append(row)
                payload['total_native_transition_calls']=count[0]/4;dump_json(payload,out/'result.progress.json')
                group=[q for q in payload['records'] if q['gain_variant']==variant['tag'] and q['amplitude']==amplitude]
                print(dict(gain_variant=variant['tag'],feedback_scale=scale,amplitude=amplitude,noops=sum(q['no_op_after_f32'] for q in group),
                    nonzero_local=sum(q.get('arrival_bounds_passed',False) for q in group),calls=count[0]/4),flush=True)
        assert len(payload['records'])==576
        assert count[0]/4==payload['setup_native_calls']+sum(q['native_transition_calls'] for q in payload['records'])
        assert np.r_[env.data.qpos,env.data.qvel].tobytes()==untouched.tobytes()
        payload.update(status='finished',live_state_unchanged=True)
    except BaseException as error:payload.update(status='failed',error=f'{type(error).__name__}: {error}');raise
    finally:
        if env is not None:env.close()
        mujoco.mj_step=original
        payload.update(total_native_transition_calls=count[0]/4,native_physics_substeps=count[0],partial_transition_substeps=count[0]%4,finished_at=utc_timestamp())
        dump_json(payload,out/'result.json')


if __name__=='__main__':main()
