"""Native full-route tracking design with every derivative query preserved."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.evidence import file_metadata,utc_timestamp,runtime_metadata
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.ilqr import QuadraticTrajectoryCost
from gcartpole.sqrt_ilqr import square_root_tracking_gains
from gcartpole.simulation import SimulationError
from scripts.search_capture_sequence import fixed_state_cfg
read=lambda p:json.loads(Path(p).read_text())
def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--directory',required=True);args=p.parse_args();m=read(args.manifest);out=Path(args.directory);out.mkdir(exist_ok=False);(out/'private').mkdir();base=read(m['controller_source']['path']);c=base['controller'];h=m['horizon']
 for key in ('controller_source','config','route_tape','source_audit'):assert m[key]==file_metadata(m[key]['path'])
 assert read(m['source_audit']['path'])['passed']
 with np.load(m['route_tape']['path']) as z:X=z['states'][:h+1].copy();U=z['actions'][:h].copy()
 assert X.shape==(h+1,32) and U.shape==(h,) and X[0].tobytes()==np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel']).tobytes()
 D=np.asarray(c['normalized_cost_mapping']);weights=np.ones(32);weights[1:16]*=c['terminal_angle_factor'];weights[16]*=c['terminal_cart_velocity_factor'];weights[17:]*=c['terminal_hinge_velocity_factor'];tf=np.diag(np.sqrt(c['terminal_state_weight']*weights))@D;sf=np.sqrt(c['stage_weight'])*D
 assert np.max(abs(X[:,0]))<=c['rail_soft_limit'];cost=QuadraticTrajectoryCost(stage_state=sf.T@sf,stage_factor=sf,terminal_state=tf.T@tf,terminal_factor=tf,control=c['control_cost'],rail_soft_limit=c['rail_soft_limit'],rail_limit=3.,rail_weight=c['rail_weight'],wrap_angles=False)
 cfg=fixed_state_cfg(load_config(m['config']['path']),base['selected_state'],30.);env=NLinkCartPoleEnv(cfg,progress=1.,seed=m['nominal_seed']);env.reset(seed=m['nominal_seed']);began=time.monotonic();payload=dict(status='running',generated_at=utc_timestamp(),manifest=file_metadata(args.manifest),script=file_metadata(__file__),runtime=runtime_metadata(),derivative_queries=[],gain_history=[],actual_hanging_start_episode_steps=0,not_solution=True,canonical_release_evidence=False)
 class Recorded(FourthOrderMujocoTransition):
  def __call__(self,state,action):
   pair=np.full((2,32),np.nan);pair[0]=state;error=None;failed=np.full(32,np.nan);ft=np.nan
   try:pair[1]=super().__call__(state,action)
   except SimulationError as e:error=f'SimulationError: {e}';failed=np.r_[self.data.qpos,self.data.qvel].copy();ft=float(self.data.time);raise
   finally:
    if self.calls is not None:self.calls.append((pair,float(np.float32(np.clip(action,-1,1))),float(action),error,failed,ft))
   return pair[1].copy()
 native=Recorded(env,np.eye(32),continuous_angles=True);native.calls=None
 try:
  for i,u in enumerate(U):assert native(X[i],float(u)).tobytes()==X[i+1].tobytes()
  A=np.empty((h,32,32));B=np.empty((h,32,1))
  for i in range(h):
   native.calls=[]
   try:A[i],B[i]=native.linearize(X[i],float(U[i]),state_epsilon=m['state_epsilon'],action_epsilon=m['action_epsilon'])
   finally:
    qt=out/'private'/f'derivative_{i:05d}.npz';np.savez_compressed(qt,states=np.asarray([q[0] for q in native.calls]),actions=np.asarray([q[1] for q in native.calls]),raw_actions=np.asarray([q[2] for q in native.calls]),failed_post_states=np.asarray([q[4] for q in native.calls]),failed_times=np.asarray([q[5] for q in native.calls]));payload['derivative_queries'].append(dict(step=i,tape=file_metadata(qt),errors=[q[3] for q in native.calls]));native.calls=None
   if i%100==0:print(dict(design_step=i,calls=native.evaluations),flush=True);dump_json(payload,out/'result.progress.json')
  dp=out/'native_derivatives.npz';np.savez_compressed(dp,states=X,actions=U,A=A,B=B,stage_factor=sf,terminal_factor=tf)
  def callback(q):payload['gain_history'].append(q);print(q,flush=True);dump_json(payload,out/'result.progress.json')
  K=square_root_tracking_gains(native,X,U,cost,regularization=m['regularization'],decimal_digits=m['decimal_digits'],mp_linearization=lambda i,x,u,ctx:(ctx.matrix(A[i].tolist()),ctx.matrix(B[i].tolist())),callback=callback);assert K.shape==(h,32) and np.all(np.isfinite(K))
  full=out/'gain_design.npz';np.savez_compressed(full,states=X,actions=U,gains=K,A=A,B=B,stage_factor=sf,terminal_factor=tf);export=out/'tracking_export.npz';np.savez_compressed(export,states=X[:-1],controls=U[:-1],gains=K[None,:-1]);spectra=out/'local_matrix_diagnostics.npz';closed=A+B*K[:,None,:];np.savez_compressed(spectra,A_singular_values=np.linalg.svd(A,compute_uv=False),closed_singular_values=np.linalg.svd(closed,compute_uv=False),A_eigenvalues=np.linalg.eigvals(A),closed_eigenvalues=np.linalg.eigvals(closed),gain_norms=np.linalg.norm(K,axis=1))
  payload.update(status='finished',passed=True,derivative_array=file_metadata(dp),full_gain_array=file_metadata(full),tracking_export=file_metadata(export),local_diagnostics=file_metadata(spectra),maximum_gain_entry=float(np.max(abs(K))),maximum_gain_norm=float(np.max(np.linalg.norm(K,axis=1))),whole441_source_native_byte_exact=True,scope=m['scope'],cost_scope='Same physical stage/terminal tracking Hessian as historicalnative design;capturevalue term andobjectivegradient omitted. No active soft-rail curvature on measuredroute. Local time-varying poles are descriptive, not robustness orfinite-horizon stability certificates.')
 except BaseException as e:payload.update(status='failed',error=f'{type(e).__name__}: {e}');raise
 finally:payload.update(total_native_transition_calls=native.evaluations,wall_seconds=time.monotonic()-began,actual_hanging_start_episode_steps=0);dump_json(payload,out/'result.json');env.close()
if __name__=='__main__':main()
