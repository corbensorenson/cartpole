#!/usr/bin/env python
"""Test existing partial feedback linearization on a frontier capture route."""
import argparse
import json
import time
from pathlib import Path
from types import SimpleNamespace

import mujoco
import numpy as np

from gcartpole.config import dump_json, load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import data_sha256, file_metadata, runtime_metadata
from gcartpole.generalized_energy import force_for_desired_cart_acceleration
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg
from scripts.search_fddp_capture import warm_start_diagnostics
from scripts.search_ilqr_capture import execute_controller
from scripts.solve_frontier_capture_increment import physical_replay_passed, validate_development_seeds


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('source', 'config', 'capture-cache', 'directory'):
        parser.add_argument('--' + key, required=True)
    parser.add_argument('--start-seconds', type=float, default=7.5)
    parser.add_argument('--state-secant', type=float, default=1e-5)
    args = parser.parse_args()
    out = Path(args.directory)
    if (out / 'result.json').exists():
        raise FileExistsError(out)
    source = json.loads(Path(args.source).read_text())
    cache = json.loads(Path(args.capture_cache).read_text())
    cfg = load_config(args.config)
    n = cfg['env']['n_links']
    dt = cfg['env']['timestep'] * cfg['env']['frame_skip']
    start = round(args.start_seconds / dt)
    c = source['controller']
    validate_development_seeds(n, source['seed'])
    if (cache['source'] != file_metadata(args.source)
            or cache['config'] != file_metadata(args.config)
            or not 0 < start < len(c['controls'])
            or not np.isclose(start * dt, args.start_seconds)
            or not np.isfinite(args.state_secant) or args.state_secant <= 0
            or not c['continuous_angles'] or c['phase_adaptive']
            or not np.array_equal(c['coordinate_transform'], np.eye(2 * (n + 1)))):
        raise ValueError('Verified physical-coordinate source/cache and aligned prefix required')
    gain = np.asarray(cache['gain'])
    factor = np.asarray(source['lyapunov']['factor'])
    if (data_sha256(gain.tolist()) != cache['gain_sha256']
            or data_sha256(factor.tolist()) != cache['factor_sha256']):
        raise ValueError('Maintenance inputs changed')
    cfg = fixed_state_cfg(cfg, source['selected_state'], 30.)
    env = NLinkCartPoleEnv(cfg, progress=1., seed=source['seed'])
    env.reset(seed=source['seed'])
    model = env.model
    data = mujoco.MjData(model)
    proxy = SimpleNamespace(model=model, data=data)
    predictor = MujocoTransition(env, np.eye(2 * (n + 1)), continuous_angles=True)
    assert data is not env.data and predictor.data is not env.data
    controls = np.asarray(c['controls'])
    nodes = np.asarray(source['search']['nominal_coordinate_states'])
    gains = np.asarray(c['feedback_gains'])
    nx, d = 2 * (n + 1), n + 1
    forward_calls = 0
    linearizations = {}
    started = time.monotonic()

    def acceleration(state, force):
        nonlocal forward_calls
        mujoco.mj_resetData(model, data)
        data.qpos[:] = state[:d]
        data.qvel[:] = state[d:]
        data.ctrl[0] = force
        mujoco.mj_forward(model, data)
        forward_calls += 1
        if data.nefc or not np.all(np.isfinite(data.qacc)):
            raise ValueError('Unconstrained finite native acceleration required')
        return float(data.qacc[0])

    def reference_linearization(step):
        if step not in linearizations:
            reference = nodes[step]
            u = float(np.float32(np.clip(controls[step], -1., 1.)))
            a = acceleration(reference, env.force_limit * u)
            mass = np.zeros((d, d))
            mujoco.mj_fullM(model, mass, data.qM)
            alpha = float(np.linalg.solve(mass, np.eye(d)[:, 0])[0])
            jac = np.empty(nx)
            for j in range(nx):
                delta = np.zeros(nx)
                delta[j] = args.state_secant
                jac[j] = (acceleration(reference + delta, env.force_limit * u)
                          - acceleration(reference - delta, env.force_limit * u)) / (2 * args.state_secant)
            linearizations[step] = a, alpha, jac, u
        return linearizations[step]

    def selector(step, state, baseline):
        if step < start:
            return baseline, None
        a, alpha, jac, reference_action = reference_linearization(step)
        baseline_delivered = float(np.float32(np.clip(baseline, -1., 1.)))
        desired = float(a + jac @ (state - nodes[step])
                        + alpha * env.force_limit * (baseline_delivered - reference_action))
        zero_force_acceleration = acceleration(state, 0.)
        mass = np.zeros((d, d))
        mujoco.mj_fullM(model, mass, data.qM)
        current_alpha = float(np.linalg.solve(mass, np.eye(d)[:, 0])[0])
        force = force_for_desired_cart_acceleration(proxy, desired)
        # The XML motor clamps force; the unconstrained inverse may request
        # more than the available force. Verify its algebra separately, then
        # check forward dynamics using the force actually delivered.
        discrepancy = abs(zero_force_acceleration + current_alpha * force - desired)
        if discrepancy > 1e-10 * max(1., abs(desired)):
            raise ValueError('Partial feedback linearization does not match native instantaneous acceleration')
        raw = force / env.force_limit
        selected = float(np.float32(np.clip(raw, -1., 1.)))
        delivered_force = selected * env.force_limit
        checked = acceleration(state, delivered_force)
        delivered_discrepancy = abs(checked - (zero_force_acceleration + current_alpha * delivered_force))
        if delivered_discrepancy > 1e-10 * max(1., abs(checked)):
            raise ValueError('Delivered native force does not match the acceleration affine law')
        return selected, dict(baseline_action=baseline_delivered,
                              corrected_action=selected, raw_corrected_action=raw,
                              desired_instantaneous_cart_acceleration=desired,
                              unclipped_native_cart_acceleration_error=discrepancy,
                              delivered_native_cart_acceleration_error=delivered_discrepancy,
                              achieved_instantaneous_cart_acceleration=checked,
                              saturated=abs(raw) > 1.,
                              reference_state_secant=args.state_secant,
                              scope='Instantaneous native cart-acceleration compensation; force remains held and quantized at the original control cadence. No internal-mode linearization or viability claim.')

    try:
        result = execute_controller(cfg, progress=1., seed=source['seed'], controls=controls,
            nominal_states=nodes, feedback_gains=gains, gain=gain, lqr_scale=c['lqr_scale'],
            transform=np.eye(nx), lyapunov=factor.T @ factor, lyapunov_factor=factor,
            handoff_lyapunov=c['handoff_lyapunov'], handoff_cart_abs=c['handoff_cart_abs'],
            handoff_angle_abs=c['handoff_angle_abs'], handoff_cart_velocity_abs=c['handoff_cart_velocity_abs'],
            handoff_hinge_velocity_rms=c['handoff_hinge_velocity_rms'],
            defer_handoff_until_horizon=True, continuous_angles=True,
            tracking_mode='native_cart_acceleration_compensation', tracking_action_selector=selector)
        rows = result['trajectory']
        original = source['result']['trajectory']
        prefix_same = len(rows) >= start and all(
            a['qpos'] == b['qpos'] and a['qvel'] == b['qvel']
            and np.float32(a['action']) == np.float32(b['action'])
            for a, b in zip(rows[:start], original[:start]))
        if not prefix_same:
            raise ValueError('Inherited prefix changed')
        initial = np.asarray(source['selected_state']['qpos'] + source['selected_state']['qvel'])
        states = np.vstack([initial, [r['qpos'] + r['qvel'] for r in rows]])
        actions = np.asarray([r['action'] for r in rows], dtype=np.float32).astype(float)
        tape = warm_start_diagnostics(predictor, initial, actions, states)
        if not tape['is_exactly_feasible']:
            raise ValueError('Actual policy tape did not exactly reproduce')
        diagnostics = [r['tracking_preview'] for r in rows if 'tracking_preview' in r]
        payload = dict(not_solution=True, canonical_release_evidence=False,
            parameters=vars(args), runtime=runtime_metadata(), source=file_metadata(args.source),
            config=file_metadata(args.config), capture_cache=file_metadata(args.capture_cache),
            result=result, full_development_episode_passed=physical_replay_passed(result, cfg),
            inherited_prefix_states_and_actions_bit_identical=True,
            physical_tape_diagnostics=tape, native_acceleration_forward_calls=forward_calls,
            actual_tape_validation_transition_calls=predictor.evaluations,
            corrected_steps=len(diagnostics), reference_linearization_steps=len(linearizations),
            maximum_unclipped_instantaneous_inverse_error=max((r['unclipped_native_cart_acceleration_error'] for r in diagnostics), default=0.),
            wall_seconds=time.monotonic() - started, reserved_seeds_used=False, noisy_development_seeds_used=False,
            executed_policy=dict(type='native_cart_acceleration_compensation_of_route_feedback',
                start_seconds=args.start_seconds, end_seconds=len(controls) * dt, frequency_hz=1 / dt,
                action_precision='float32', after_route='Existing upright maintenance controller',
                generalist_primitive='gcartpole.generalized_energy.force_for_desired_cart_acceleration',
                predictor_data_is_separate=True, native_state_overwrites=False),
            scope='Uninterrupted exact-start development trial using an existing generalist physics primitive on frontier tracking. No noisy or reserved release evidence. The inverse identity is instantaneous; held-force nonlinear dynamics and internal chain modes remain.')
        dump_json(payload, out / 'result.json')
        print(json.dumps(dict(full_pass=payload['full_development_episode_passed'],
                              length=result['length'], hold=result['max_upright_streak_seconds'],
                              native_acceleration_forward_calls=forward_calls)))
    finally:
        env.close()


if __name__ == '__main__':
    main()
