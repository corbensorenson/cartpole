"""Independent MP80 recurrence and actual-action audit for direct fifteen bias."""
import argparse
from pathlib import Path
import mpmath
import numpy as np
from gcartpole.config import dump_json, load_config
from gcartpole.env import wrap_angle
from gcartpole.evidence import file_metadata, utc_timestamp
from scripts.audit_armature_route_increment import checked, journal, read, tape


def recurrence(array, c, regularization):
    ctx = mpmath.mp.clone(); ctx.dps = 80
    mat = lambda x: ctx.matrix(np.asarray(x).tolist())
    tf = mat(array['terminal_factor']); P = tf.T*tf; s = ctx.zeros(32,1)
    sf = mat(np.linalg.cholesky(array['stage_state']).T); cf = mat(array['capture_factor'])
    Q0, Q1 = sf.T*sf, cf.T*cf
    offsets, gains = np.zeros(700), np.empty((700,32))
    boundary = round(c['capture_start_seconds']/.02)
    for i in range(699,-1,-1):
        A, B, d = mat(array['A'][i]), mat(array['B'][i]), mat(array['defects'][i])
        S = B.T*P*A
        H = ctx.mpf(c['control_cost'])+ctx.mpf(regularization)+(B.T*P*B)[0]
        z = P*d+s; b = (B.T*z)[0]
        offsets[i] = float(-b/H); gains[i] = [float(v) for v in -S/H]
        s = A.T*z-S.T*(b/H)
        P = (Q0 if i<boundary else Q1)+A.T*P*A-S.T*S/H
        P = (P+P.T)/2
    return offsets, gains


def main():
    p = argparse.ArgumentParser(); p.add_argument('--directory',required=True)
    args = p.parse_args(); root = Path(args.directory)
    m = read(root/'manifest.json'); execution = journal(root/'execution')
    r = read(root/'execution/diagnostic/result.json')
    assert r['status'] == 'finished' and r['manifest'] == file_metadata(root/'manifest.json')
    for meta in (m['source'],m['source_journal'],m['config']): checked(meta)
    source = read(m['source']['path']); c = source['controller']
    assert load_config(m['config']['path'])['env']['n_links'] == 15
    assert len(r['designs']) == 1 and len(r['records']) == 15
    assert {(q['offset_scale'],q['handoff_seconds']) for q in r['records']} == {(s,h) for s in m['offset_scales'] for h in m['route_seconds']}
    design = r['designs'][0]; checked(design['array'])
    a = np.load(design['array']['path'])
    assert a['A'].shape == (700,32,32) and a['B'].shape == (700,32,1)
    assert a['runtime_gains'].tobytes() == np.asarray(c['feedback_gains']).tobytes()
    assert a['states'].tobytes() == np.asarray(source['search']['nominal_coordinate_states']).tobytes()
    assert a['controls'].tobytes() == np.asarray(c['controls']).tobytes()
    assert a['defects'].tobytes() == (a['native_predictions']-a['states'][1:]).tobytes()
    assert design['regularization'] == m['regularization'] == source['search']['optimizer_history'][-1]['regularization']
    offsets, gains = recurrence(a,c,m['regularization'])
    bias_error = float(np.max(abs(offsets-a['offsets'])))
    gain_error = float(np.max(abs(gains-a['offset_design_gains'])))
    assert bias_error <= 1e-12+1e-12*np.max(abs(a['offsets']))
    assert gain_error <= 1e-8+1e-12*np.max(abs(a['offset_design_gains']))
    print(dict(mp80_bias_maximum_residual=bias_error,mp80_gain_maximum_residual=gain_error),flush=True)
    original_x = np.vstack([source['selected_state']['qpos']+source['selected_state']['qvel'],
        [q['qpos']+q['qvel'] for q in source['result']['trajectory']]])
    original_u = np.asarray([q['action'] for q in source['result']['trajectory']],np.float32).astype(float)
    outcomes, unique, baseline_matches = [], set(), 0
    for q in r['records']:
        x,u,gate = tape(q,n=15); h = round(q['handoff_seconds']/.02); N = min(h,len(u))
        controls = np.clip(a['controls']+q['offset_scale']*a['offsets'],-1,1)
        commands = np.asarray([controls[i]+a['runtime_gains'][i]@(x[i]-a['states'][i]) for i in range(N)])
        assert np.clip(commands,-1,1).astype(np.float32).astype(float).tobytes() == u[:N].tobytes()
        if len(u)>h:
            xx=x[h:-1].copy(); xx[:,1:16]=wrap_angle(xx[:,1:16]); gain=np.asarray(design['target_maintenance_gain'])
            expected=np.asarray([np.float32(np.clip(-c['lqr_scale']*float(gain@y),-1,1)) for y in xx],dtype=float)
            assert expected.tobytes()==u[h:].tobytes()
        if q['offset_scale']==0:
            assert x.tobytes()==original_x.tobytes() and u.tobytes()==original_u.tobytes()
            baseline_matches += 1
        assert q['total_native_transition_calls']==2*len(u)
        assert q['shifted_nominal_controls_clipped_ticks']==int(np.sum(abs(a['controls']+q['offset_scale']*a['offsets'])>1))
        unique.add((x.tobytes(),u.tobytes()))
        sat=np.flatnonzero(abs(commands)>1)
        outcomes.append(dict(offset_scale=q['offset_scale'],handoff_seconds=q['handoff_seconds'],
            passed=gate,actual_steps=len(u),hold_seconds=q['result']['max_upright_streak_seconds'],
            reached_maintenance=len(u)>h,
            first_tracking_saturation_seconds=None if not len(sat) else float(sat[0]*.02),tape=q['tape']))
    total = design['native_transition_calls']+sum(q['total_native_transition_calls'] for q in r['records'])
    assert total==r['total_native_transition_calls']<=m['native_transition_ceiling']
    assert r['native_physics_substeps']==4*total and r['partial_transition_substeps']==0
    assert r['actual_hanging_start_episode_steps']==sum(q['actual_hanging_start_episode_steps'] for q in r['records'])
    assert not r['reserved_seeds_used'] and not r['noisy_development_seeds_used']
    payload=dict(generated_at=utc_timestamp(),passed=True,script=file_metadata(__file__),manifest=file_metadata(root/'manifest.json'),
        execution=execution,result=file_metadata(root/'execution/diagnostic/result.json'),designs=r['designs'],records=r['records'],outcomes=outcomes,
        total_new_native_transition_calls=total,actual_hanging_start_episode_steps=r['actual_hanging_start_episode_steps'],
        new_actual_episodes=15,distinct_actual_trajectories=len(unique),zero_bias_original_full_tapes_byte_exact=baseline_matches,
        full_nominal_passes=sum(q['passed'] for q in outcomes),mp80_maximum_offset_residual=bias_error,mp80_maximum_gain_residual=gain_error,
        native_transition_calls_for_this_audit=0,canonical_release_evidence=False,not_solution=True,
        scope='Direct canonical15 exact nominal comparison. OriginalruntimeK unchanged; native binary64 derivative/defect arrays saved; independentMP80 recurrence and actualtracking/maintenance actions/gates/counters verified. Zeroarms reproduce archived fullsource; no noisy/reserved or accepted-record evidence. Recurrence consistency does not certify derivative accuracy or arbitrary robustness.')
    dump_json(payload,root/'verified.json')
    print(dict(passed=True,calls=total,actual_steps=payload['actual_hanging_start_episode_steps'],
               fullpasses=payload['full_nominal_passes'],distinct_actual_trajectories=len(unique)),flush=True)


if __name__ == '__main__':main()
