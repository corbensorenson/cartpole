#!/usr/bin/env python
"""Reproduce a frozen failed check with read-only exception instrumentation."""
import argparse
import importlib.util
import sys
from pathlib import Path

from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata, runtime_metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('failed-directory', 'directory'):
        parser.add_argument('--' + key, required=True)
    args = parser.parse_args()
    failed = Path(args.failed_directory)
    out = Path(args.directory)
    if (out / 'result.json').exists():
        raise FileExistsError(out)
    script = failed / 'snapshot/scripts/replay_frontier_cart_acceleration_tracking.py'
    spec = importlib.util.spec_from_file_location('frozen_cart_acceleration_check', script)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    captured = {}

    def trace(frame, event, arg):
        if event == 'exception' and str(arg[1]) == 'Partial feedback linearization does not match native instantaneous acceleration':
            local = frame.f_locals
            if frame.f_code.co_name == 'selector':
                proxy = local['proxy']
                captured['check'] = dict(step=local['step'], desired_acceleration=local['desired'],
                    requested_force=local['force'], native_checked_acceleration=local['checked'],
                    acceleration_discrepancy=local['discrepancy'],
                    actual_native_actuator_force=float(proxy.data.actuator_force[0]))
            elif frame.f_code.co_name == 'execute_controller':
                captured['actual_episode_steps'] = int(local['env'].step_count)
                captured['actual_rows_recorded'] = len(local['trajectory'])
            elif frame.f_code.co_name == 'main' and Path(frame.f_code.co_filename).resolve() == script.resolve():
                captured['native_acceleration_forward_calls'] = local['forward_calls']
                captured['native_transition_predictor_calls'] = local['predictor'].evaluations
        return trace

    previous_args = sys.argv
    previous_trace = sys.gettrace()
    sys.argv = [str(script), '--source', 'runs/frontier_campaign_20261001/n15_adjacent_best_refined2p2_tracking_value_identity/result.json',
        '--config', 'configs/swingup15_uniform.yaml', '--capture-cache',
        'runs/frontier_campaign_20261001/n15_adjacent_best_refined2p2_nonlinear_value_inputs/capture_cache.json',
        '--directory', str(out)]
    try:
        sys.settrace(trace)
        try:
            module.main()
        except ValueError as error:
            if str(error) != 'Partial feedback linearization does not match native instantaneous acceleration':
                raise
            captured['expected_error_reproduced'] = True
        else:
            raise AssertionError('Frozen failed check unexpectedly succeeded')
    finally:
        sys.settrace(previous_trace)
        sys.argv = previous_args
    if (not captured.get('expected_error_reproduced')
            or abs(captured['check']['requested_force']) <= 80
            or abs(captured['check']['actual_native_actuator_force']) != 80.
            or 'native_acceleration_forward_calls' not in captured
            or 'native_transition_predictor_calls' not in captured
            or captured['actual_episode_steps'] != captured['actual_rows_recorded']):
        raise AssertionError('The reproduced failure was not motor clipping')
    dump_json(dict(not_solution=True, canonical_release_evidence=False,
        frozen_script=file_metadata(script), original_execution=file_metadata(failed / 'execution.json'),
        runtime=runtime_metadata(), reproduction=captured,
        scope='Frozen check reproduced with read-only Python exception tracing. Counters belong to this reproduction; original failed-run counters remain unavailable. No positive/negative full physical trial is inferred.'), out / 'result.json')
    print(captured)


if __name__ == '__main__':
    main()
