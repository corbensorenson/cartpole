"""Independent read-only prefix, capture, handoff, native gate and accounting audit."""
import argparse,json,math
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.physical_initializers import extend_actual_prefix_initializer
from scripts.audit_armature_route_increment import checked,journal,read,tape

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',required=True);a=p.parse_args();root=Path(a.directory);m=read(root/'manifest.json');assert m['eight_second_control_arrays_match_prior_initializer_byte_exact'];c=read(m['source']['path']);f=read(m['gain_source']['path']);ref=np.load(f['reference']['path']);actual=np.load(m['actual_tape']['path']);rows=[];parents=[];checks=[]
 for k in ['source','source_result','gain_source','actual_tape','config']:checked(m[k])
 for case in m['cases']:
  sec=case['prefix_seconds'];steps=50*sec;checked(case['initializer']);seed=read(case['initializer']['path']);expected=extend_actual_prefix_initializer(c,actual['states'],actual['actions'],ref['feedback_gains'],steps)
  for k in ['selected_state','controller','search']:assert seed[k]==expected[k]
  assert seed['physical_prefix_tape']==m['actual_tape'] and seed['physical_prefix_selection']==case['selection']
  folder=root/f'prefix{sec}';pj=journal(folder);path=folder/'diagnostic/result.json';d=read(path);assert d['status']=='finished' and d['config']==m['config'] and d['gain_source']==m['gain_source'] and d['initializer']==case['initializer'] and d['prefix_seconds']==sec;checked(d['memo']);checked(d['script']);stage={};last=None;passrows=[];selected=None
  for s in d['stages']:
   checked(s['result']);assert journal(Path(s['directory']))==s['execution'];r=read(s['result']['path']);assert r['status']=='finished' and r['config']==m['config'];assert r['total_native_transition_calls']==s['total_native_transition_calls']<=r['native_transition_ceiling'];assert r['actual_hanging_start_episode_steps']==s['actual_hanging_start_episode_steps'];assert r['partial_transition_substeps']==0 and r['native_physics_substeps']==4*r['total_native_transition_calls'];assert not r['reserved_seeds_used'] and not r['noisy_development_seeds_used'];stage[s['name']]=r;row=dict(s,role='primitive',config=r['config'])
   if s['name'].startswith('capture_suffix'):
    xx,uu,gate=tape(r);cc=read(r['candidate']['path']);checked(r['candidate']);checked(r['initializer']);assert r['optimize_suffix_start_seconds']==sec and r['optimizer_iterations']==8;assert cc['controller']['frozen_prefix_steps']==steps and cc['search']['optimized_horizon_steps']==700-steps;assert cc['controller']['capture_start_seconds']==9 and cc['controller']['capture_interval_steps']==250;assert len(cc['controller']['controls'])==700
    assert xx[:steps+1].tobytes()==actual['states'][:steps+1].tobytes() and uu[:steps].tobytes()==actual['actions'][:steps].tobytes()
    assert np.array(cc['search']['nominal_coordinate_states'])[:steps+1].tobytes()==actual['states'][:steps+1].tobytes()
    for key in ['controls','feedback_gains']:assert np.array(cc['controller'][key])[:steps].tobytes()==np.array(seed['controller'][key])[:steps].tobytes()
    assert r['initializer']==(case['initializer'] if last is None else last['candidate']);last=r
    row.update(candidate=r['candidate'],initializer=r['initializer'],tape=r['tape'],hold_seconds=r['result']['max_upright_streak_seconds'],full_nominal_component_gate_passed=gate,maximum_model_defect=cc['controller']['final_trajectory_diagnostics']['maximum_dynamics_defect'])
    if sec==8 and s['name']=='capture_suffix8':
     old=read('runs/armature_adaptive_continuation_20261004/target0.95/diagnostic/capture_suffix8/diagnostic/result.json');prior=np.load(old['tape']['path']);checks.append(dict(comparison='repeated8scontrol',prior_result=file_metadata('runs/armature_adaptive_continuation_20261004/target0.95/diagnostic/capture_suffix8/diagnostic/result.json'),states_and_actions_byte_exact=xx.tobytes()==prior['states'].tobytes() and uu.tobytes()==prior['actions'].tobytes(),new_hold_seconds=row['hold_seconds'],prior_hold_seconds=old['result']['max_upright_streak_seconds']))
   else:
    assert s['name'].startswith('saved_feedback_handoffs');it=int(s['name'].replace('saved_feedback_handoffs',''));source=stage[f'capture_suffix{it}'];available=[float(t) for t in range(math.ceil(sec),14) if t*50<=source['actual_hanging_start_episode_steps']];assert [x['handoff_seconds'] for x in r['records']]==available
    assert r['source']==next(z['result'] for z in d['stages'] if z['name']==f'capture_suffix{it}') and r['gain_source']==m['gain_source'];orig=np.load(source['tape']['path']);passes=[]
    for rr in r['records']:
     x,u,g=tape(rr);h=round(rr['handoff_seconds']/.02);assert x[:h+1].tobytes()==orig['states'][:h+1].tobytes() and u[:h].tobytes()==orig['actions'][:h].tobytes()
     if g:passes.append(rr)
    assert sum(q['total_native_transition_calls'] for q in r['records'])==r['total_native_transition_calls'];row['records']=r['records']
    if passes:passrows=passes;selected=source
   rows.append(row)
  for e in d['available_handoffs']:
   rr=stage[f"capture_suffix{e['after_cumulative_iterations']}"];assert e['seconds']==[float(t) for t in range(math.ceil(sec),14) if t*50<=rr['actual_hanging_start_episode_steps']]
  assert d['component_passed']==bool(passrows)
  if passrows:
   assert d['full_passing_handoffs']==[x['handoff_seconds'] for x in passrows];best=min(passrows,key=lambda q:q['handoff_seconds']);checked(d['passing_physical_initializer']);phys=read(d['passing_physical_initializer']['path']);tt=np.load(best['tape']['path']);h=round(best['handoff_seconds']/.02);cc=read(selected['candidate']['path']);k=np.vstack([np.array(cc['controller']['feedback_gains'])[:h],np.tile(-np.array(f['gain']),(700-h,1))]);assert np.array(phys['controller']['controls']).tobytes()==tt['actions'][:700].tobytes();assert np.array(phys['search']['nominal_coordinate_states']).tobytes()==tt['states'][:701].tobytes();assert np.array(phys['controller']['feedback_gains']).tobytes()==k.tobytes();assert phys['passing_tape']==best['tape']
  else:assert 'capture_suffix16' in stage
  local=[r for r in rows if r['directory'].startswith(str(folder)+'/')];assert sum(r['total_native_transition_calls'] for r in local)==d['total_native_transition_calls']<=1348000;assert sum(r['actual_hanging_start_episode_steps'] for r in local)==d['actual_hanging_start_episode_steps']
  parents.append(dict(directory=str(folder),execution=pj,result=file_metadata(path),config=m['config'],role='pipeline_parent_not_additive',component_passed=d['component_passed'],prefix_seconds=sec,total_native_transition_calls=d['total_native_transition_calls'],actual_hanging_start_episode_steps=d['actual_hanging_start_episode_steps'],passing_physical_initializer=d.get('passing_physical_initializer'),available_handoffs=d['available_handoffs']))
 total=sum(r['total_native_transition_calls'] for r in rows);assert total<=4044000
 result=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),passed=True,studies=rows,pipelines=parents,control_reproduction=checks,total_new_native_transition_calls=int(total),actual_hanging_start_episode_steps=sum(r['actual_hanging_start_episode_steps'] for r in rows),native_transition_calls_for_this_audit=0,canonical_release_evidence=False,not_solution=True,reserved_seeds_used=False,noisy_development_seeds_used=False,budget_scope='Primitive capture and handoff stages summed once; three pipeline parents excluded. Sameplant/source/config; only actualprefixlength and subsequent optimized capture path change.')
 dump_json(result,root/'verified.json');print(json.dumps(dict(passed=True,nativecalls=total,actualsteps=result['actual_hanging_start_episode_steps'],primitives=len(rows),pipelines=len(parents),passing_prefixes=[x['prefix_seconds'] for x in parents if x['component_passed']],control_reproduction=checks)))
if __name__=='__main__':main()
