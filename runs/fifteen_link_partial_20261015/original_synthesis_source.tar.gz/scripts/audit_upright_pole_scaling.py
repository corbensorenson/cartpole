#!/usr/bin/env python
"""Test slower unstable-mode replacement with native saturated local episodes."""
import argparse,copy,json,time
from pathlib import Path
import mpmath
import numpy as np
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.lqr_design import _precision_eigenvalues,high_precision_discrete_lqr
from gcartpole.pole_design import high_precision_siso_pole_gain
from gcartpole.upright_mechanics import upright_rk4_matrices
from scripts.audit_link_count_frontier import WEIGHTS,exact_capture
from scripts.make_lqr_checkpoint import absolute_angle_cost


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',default='configs/swingup15_uniform.yaml')
    parser.add_argument('--counts',nargs='+',type=int,default=[14,15])
    parser.add_argument('--decay-factors',nargs='+',type=float,default=[.1,.25,.5,1.])
    parser.add_argument('--cart-decay',type=float,default=.5)
    parser.add_argument('--directory',required=True)
    args=parser.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    if min(args.counts)<1 or any(not np.isfinite(x) or x<=0 for x in [args.cart_decay,*args.decay_factors]):
        raise ValueError('positive counts and finite positive decay settings required')
    base=load_config(args.config);began=time.monotonic();ctx=mpmath.mp.clone();ctx.dps=100
    payload=dict(not_solution=True,canonical_release_evidence=False,config=file_metadata(args.config),
        parameters=vars(args),runtime=runtime_metadata(),records=[],actual_local_episode_steps=0,
        optimizer_transition_calls=0,reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Canonical geometry local components only. Retain stable open-loop poles; replace real unstable z by z**(-decay_factor), and neutral cart pole by exp(-cart_decay*dt). MP100 input-model pole diagnostics and rounded-gain native F32 saturated episodes are separate evidence. Same paired local directions as geometry studies. No hanging-start or noisy-cohort record is inferred.')
    for n in args.counts:
        cfg=copy.deepcopy(base);cfg['env']['n_links']=n
        directions=np.random.default_rng(20265500+n).uniform(-1,1,(4,2*n))
        env=NLinkCartPoleEnv(cfg,progress=1.,seed=0)
        try:
            env.reset(seed=0);a,b,mechanics=upright_rk4_matrices(env,decimal_digits=100);dt=env.dt
            roots=_precision_eigenvalues(ctx.matrix(a.tolist()),ctx)
        finally:env.close()
        for factor in [None,*args.decay_factors]:
            record=dict(n_links=n,method='lqr' if factor is None else 'stable_mode_preserving_pole_placement',
                decay_factor=factor,resolved_config=cfg,paired_directions=directions.tolist(),
                mechanics=mechanics,open_loop_poles=[str(z) for z in roots],local_capture={})
            payload['records'].append(record);started=time.monotonic()
            try:
                if factor is None:
                    gain,_,diag=high_precision_discrete_lqr(a.tolist(),b.tolist(),absolute_angle_cost(n,WEIGHTS),
                        np.array([[1000.]]),decimal_digits=100,preserve_input_precision=True)
                else:
                    targets=[]
                    for z in roots:
                        if abs(z-1)<ctx.mpf('1e-30'):targets.append(ctx.exp(-ctx.mpf(args.cart_decay)*ctx.mpf(dt)))
                        elif abs(z)>1:
                            if abs(ctx.im(z))>ctx.mpf('1e-40') or ctx.re(z)<=1:
                                raise ValueError('this target family requires positive real unstable poles')
                            targets.append(ctx.re(z)**(-ctx.mpf(factor)))
                        else:targets.append(z)
                    gain,diag=high_precision_siso_pole_gain(a.tolist(),b.tolist(),targets,decimal_digits=100)
                record.update(design_diagnostics=diag,gain=gain.ravel().tolist(),design_wall_seconds=time.monotonic()-started)
                for amplitude in (1e-5,1e-9,1e-13):
                    episodes=[exact_capture(cfg,dict(qpos=np.r_[0.,amplitude*d[:n]].tolist(),
                        qvel=np.r_[0.,amplitude*d[n:]].tolist()),gain.ravel(),seconds=30.) for d in directions]
                    successes=sum(e['success'] and e['termination_reason']=='time_limit' and e['steps']==round(30/dt)
                        and e['trajectory_clean'] and e['max_hold_seconds']>=5 and e['max_cart_excursion']<=3 for e in episodes)
                    record['local_capture'][str(amplitude)]=dict(episodes=episodes,successes=successes)
                    payload['actual_local_episode_steps']+=sum(e['steps'] for e in episodes)
            except (ValueError,ZeroDivisionError,np.linalg.LinAlgError) as error:
                record['error']=f'{type(error).__name__}: {error}'
            payload['wall_seconds']=time.monotonic()-began;dump_json(payload,out/'result.progress.json')
            print(json.dumps(dict(n_links=n,factor=factor,error=record.get('error'),
                gain_norm=record.get('design_diagnostics',{}).get('gain_norm'),
                successes={k:v['successes'] for k,v in record['local_capture'].items()})),flush=True)
    payload['wall_seconds']=time.monotonic()-began;dump_json(payload,out/'result.json')


if __name__=='__main__':main()
