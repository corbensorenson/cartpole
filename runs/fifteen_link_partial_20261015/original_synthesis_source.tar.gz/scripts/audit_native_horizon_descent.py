#!/usr/bin/env python
"""Compare proposed physical-task descent with delivered native perturbations."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.ilqr import MujocoTransition
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.native_task_derivatives import physical_task_residual,chained_physical_task_jacobian
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',required=True)
    parser.add_argument('--directory',required=True)
    args=parser.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    source=json.loads(Path(args.source).read_text())
    if source['stages'][-1]['feasible_sequence_found']:raise ValueError('bounded audit requires a first failed horizon')
    for key in ('source','config','teacher'):
        if file_metadata(source[key]['path'])!=source[key]:raise ValueError('source input changed')
    base=json.loads(Path(source['source']['path']).read_text());cfg=load_config(source['config']['path'])
    n=cfg['env']['n_links'];nx=2*(n+1);step=source['parameters']['start_step'];rate=source['parameters']['rate_residual_weight']
    known=np.asarray(source['last_valid_plan'],np.float32).astype(float)
    horizon=source['stages'][-1]['horizon_steps']
    reference=np.asarray(base['controller']['controls'][step:step+horizon],np.float32).astype(float)
    if len(reference)!=horizon or horizon!=len(known)+1:raise ValueError('one-tick failure and unpadded reference required')
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    native=MujocoTransition(env,np.eye(nx),continuous_angles=True);local=FourthOrderMujocoTransition(env,np.eye(nx),continuous_angles=True)
    began=time.monotonic();untouched=np.r_[env.data.qpos.copy(),env.data.qvel.copy()]
    def forecast(state,actions):
        current=state.copy();states=[]
        for action in actions:current=native(current,float(action));states.append(current.copy())
        return np.asarray(states)
    def residual(states):return physical_task_residual(states,n,rate,.1)
    def feasible(states):return bool(np.all(np.abs(states[:,0])<=env.rail_limit) and np.max(np.abs(wrap_angle(np.cumsum(states[:,1:n+1],axis=1))))<.14)
    payload=dict(not_solution=True,canonical_release_evidence=False,source=file_metadata(args.source),parameters=vars(args),
        runtime=runtime_metadata(),records=[],actual_episode_steps=0,optimizer_transition_calls=0,
        reserved_seeds_used=False,noisy_development_seeds_used=False,
        scope='Diagnostic at independently replayed last valid horizon and one-tick reference-tail extension. Composed native4/MP100 Jacobian linearized residual predictions are compared to actual bounded delivered F32 action perturbations. Measured direction costs are not a derivative certificate or complete optimizer; no actual policy or global infeasibility claim.')
    try:
        state=np.asarray(base['selected_state']['qpos']+base['selected_state']['qvel'])
        for row in base['result']['trajectory'][:step]:
            state=native(state,float(np.float32(row['action'])))
            if state.tobytes()!=np.asarray(row['qpos']+row['qvel']).tobytes():raise ValueError('cold prefix changed')
        for center in (known,np.r_[known,reference[len(known):]]):
            h=len(center);ref=reference[:h];states=forecast(state,center);r=residual(states)
            if h==len(known) and (states.tobytes()!=np.asarray(source['last_valid_forecast_states']).tobytes() or not feasible(states)):
                raise ValueError('last valid plan changed')
            before=local.evaluations
            jac=chained_physical_task_jacobian(local,state,center,states,n_links=n,rate_weight=rate,
                state_epsilon=base['controller']['state_epsilon'],action_epsilon=base['controller']['action_epsilon'],angle_band=.1)
            gradient=2*(jac.T@r+1e-4*(center-ref))
            rng=np.random.default_rng(20265755+h)
            directions=[-gradient,*rng.uniform(-1,1,(4,h))]
            cost=float(r@r+1e-4*np.sum((center-ref)**2))
            record=dict(horizon_steps=h,initial_feasible=feasible(states),initial_cost=cost,
                jacobian_norm=float(np.linalg.norm(jac)),gradient_norm=float(np.linalg.norm(gradient)),
                native_local_derivative_transition_calls=local.evaluations-before,directions=[])
            payload['records'].append(record)
            for index,direction in enumerate(directions):
                norm=np.max(np.abs(direction))
                if norm==0:continue
                direction=direction/norm
                for epsilon in (1e-3,1e-5,1e-7,1e-9,1e-11):
                    for sign in (1,-1):
                        actions=np.clip(center+sign*epsilon*direction,-1,1).astype(np.float32).astype(float)
                        delta=actions-center
                        if not np.any(delta):
                            record['directions'].append(dict(direction=index,epsilon=epsilon,sign=sign,delivered_unchanged=True));continue
                        predicted_r=r+jac@delta
                        predicted_cost=float(predicted_r@predicted_r+1e-4*np.sum((actions-ref)**2))
                        checked=forecast(state,actions);actual_r=residual(checked)
                        actual_cost=float(actual_r@actual_r+1e-4*np.sum((actions-ref)**2))
                        change=actual_r-r;predicted_change=jac@delta
                        record['directions'].append(dict(direction=index,epsilon=epsilon,sign=sign,delivered_unchanged=False,
                            maximum_delivered_action_delta=float(np.max(np.abs(delta))),
                            linear_gradient_dot_delivered_delta=float(gradient@delta),
                            linearized_residual_cost_change=predicted_cost-cost,native_cost_change=actual_cost-cost,
                            relative_residual_prediction_error=float(np.linalg.norm(change-predicted_change)/max(np.linalg.norm(change),1e-300)),
                            native_residual_change_norm=float(np.linalg.norm(change)),
                            native_forecast_admissible=feasible(checked)))
            print(json.dumps(dict(horizon=h,initial_feasible=record['initial_feasible'],initial_cost=cost,
                gradient_norm=record['gradient_norm'],native_lower_cost_trials=sum(t.get('native_cost_change',0)<0 for t in record['directions']))),flush=True)
        if untouched.tobytes()!=np.r_[env.data.qpos,env.data.qvel].tobytes():raise ValueError('diagnostic changed live data')
        payload.update(source_prefix_byte_identical=True,last_valid_forecast_byte_identical=True,live_state_unchanged=True,
            native_forecast_transition_calls=native.evaluations,native_local_derivative_transition_calls=local.evaluations,
            total_native_transition_calls=native.evaluations+local.evaluations,wall_seconds=time.monotonic()-began)
        dump_json(payload,out/'result.json')
    finally:env.close()


if __name__=='__main__':main()
