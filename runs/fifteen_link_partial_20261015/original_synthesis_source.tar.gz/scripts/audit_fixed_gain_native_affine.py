"""Independent fixed-K affine control audit; MP80 bias recurrence, zero new physics."""
import argparse,json
from pathlib import Path
import mpmath,numpy as np
from gcartpole.config import dump_json
from gcartpole.env import wrap_angle
from gcartpole.evidence import file_metadata,utc_timestamp
from scripts.audit_armature_route_increment import checked,journal,read,tape


def recurrence(array,c,prefix,regularization):
 ctx=mpmath.mp.clone();ctx.dps=80;mat=lambda x:ctx.matrix(np.asarray(x).tolist());tf=mat(array['terminal_factor']);P=tf.T*tf;s=ctx.zeros(30,1);offsets=np.zeros(700);gains=np.empty((300,30));stage=np.linalg.cholesky(array['stage_state']).T;sf=mat(stage);cf=mat(array['capture_factor']);Q0=sf.T*sf;Q1=cf.T*cf
 boundary=round(c['capture_start_seconds']/.02)
 for i in range(699,prefix-1,-1):
  A=mat(array['A'][i-prefix]);B=mat(array['B'][i-prefix]);d=mat(array['defects'][i]);S=B.T*P*A;H=ctx.mpf(c['control_cost'])+ctx.mpf(regularization)+(B.T*P*B)[0];z=P*d+s;b=(B.T*z)[0];off=-b/H;offsets[i]=float(off);gains[i-prefix]=[float(x) for x in -S/H];s=A.T*z-S.T*(b/H);P=(Q0 if i<boundary else Q1)+A.T*P*A-S.T*S/H;P=(P+P.T)/2
 return offsets,gains


def main():
 p=argparse.ArgumentParser();p.add_argument('--directory',required=True);args=p.parse_args();root=Path(args.directory);m=read(root/'manifest.json');j=journal(root/'execution');r=read(root/'execution/diagnostic/result.json');assert r['status']=='finished' and r['manifest']==file_metadata(root/'manifest.json') and r['config']==m['config'];checked(m['config']);checked(m['gain_source']);gain=np.array(read(m['gain_source']['path'])['gain']);cases={c['tag']:c for c in m['cases']};designs={d['tag']:d for d in r['designs']};assert len(cases)==len(designs)==3;expected={(c,s,t) for c in cases for s in m['offset_scales'] for t in m['route_seconds']};assert {(rr['tag'],rr['offset_scale'],rr['handoff_seconds']) for rr in r['records']}==expected and len(r['records'])==27
 data={};outcomes=[];passes=[];baseline_reproductions=0;max_offset_residual=max_gain_residual=0.;tracking=maintenance=0
 for tag,case in cases.items():
  for key in ('source_result','candidate','baseline_tape'):checked(case[key])
  d=designs[tag];checked(d['array']);a=np.load(d['array']['path']);c=read(case['candidate']['path']);K=np.array(c['controller']['feedback_gains']);nom=np.array(c['search']['nominal_coordinate_states']);cu=np.array(c['controller']['controls']);old=np.load(case['baseline_tape']['path']);assert K.tobytes()==a['runtime_gains'].tobytes() and nom.tobytes()==a['states'].tobytes() and cu.tobytes()==a['controls'].tobytes();assert a['native_predictions'].shape==(700,30) and a['A'].shape==(300,30,30) and a['B'].shape==(300,30,1);assert a['defects'].tobytes()==(a['native_predictions']-nom[1:]).tobytes();assert a['native_predictions'][:400].tobytes()==nom[1:401].tobytes();assert np.array_equal(a['offsets'][:400],np.zeros(400));assert d['regularization']==case['regularization']==c['search']['optimizer_history'][-1]['regularization'];assert d['native_transition_calls']==38500
  o,kg=recurrence(a,c['controller'],400,case['regularization']);ores=float(np.max(abs(o-a['offsets'])));kres=float(np.max(abs(kg-a['offset_design_gains'])));assert ores<=1e-18+1e-12*max(abs(a['offsets'])) and kres<=1e-8+1e-12*np.max(abs(a['offset_design_gains']));max_offset_residual=max(max_offset_residual,ores);max_gain_residual=max(max_gain_residual,kres);data[tag]=(a,c,old)
  print(json.dumps(dict(tag=tag,mp80_offset_maximum_residual=ores,mp80_gain_maximum_residual=kres)),flush=True)
 for rr in r['records']:
  x,u,g=tape(rr);a,c,old=data[rr['tag']];h=round(rr['handoff_seconds']/.02);assert x[:401].tobytes()==old['states'][:401].tobytes() and u[:400].tobytes()==old['actions'][:400].tobytes();cu=(a['controls']+rr['offset_scale']*a['offsets']).clip(-1,1);N=min(h,len(u));commands=np.array([cu[i]+float(a['runtime_gains'][i]@(x[i]-a['states'][i])) for i in range(N)]);eu=commands.clip(-1,1).astype(np.float32).astype(float);assert eu.tobytes()==u[:N].tobytes();tracking+=N
  if len(u)>h:
   xx=x[h:-1].copy();xx[:,1:15]=wrap_angle(xx[:,1:15]);eu=np.array([float(np.float32(np.clip(-c['controller']['lqr_scale']*float(gain@q),-1,1))) for q in xx]);assert eu.tobytes()==u[h:].tobytes();maintenance+=len(eu)
  assert rr['total_native_transition_calls']==2*len(u)
  if rr['offset_scale']==0:
   dense=read(f"runs/directional_dense_handoffs_20261004/{rr['tag']}/diagnostic/result.json");prior=next((q for q in dense['records'] if q['handoff_seconds']==rr['handoff_seconds']),None)
   source=old if prior is None else np.load(prior['tape']['path']);assert x.tobytes()==source['states'].tobytes() and u.tobytes()==source['actions'].tobytes();baseline_reproductions+=1
  if g:
   checked(rr['passing_physical_initializer']);p=read(rr['passing_physical_initializer']['path']);assert np.array(p['controller']['controls']).tobytes()==u[:700].tobytes() and np.array(p['search']['nominal_coordinate_states']).tobytes()==x[:701].tobytes();pk=np.vstack([a['runtime_gains'][:h],np.tile(-gain,(700-h,1))]);assert np.array(p['controller']['feedback_gains']).tobytes()==pk.tobytes();passes.append(rr)
  sat=np.flatnonzero(abs(commands[400:])>1);outcomes.append(dict(tag=rr['tag'],offset_scale=rr['offset_scale'],handoff_seconds=rr['handoff_seconds'],hold_seconds=rr['result']['max_upright_streak_seconds'],actual_steps=len(u),maximum_cart_excursion=rr['result']['max_cart_excursion'],passed=g,first_tracking_saturation_after_prefix_seconds=float(sat[0]*.02) if len(sat) else None,changed_nominal_f32_ticks=int(np.sum(cu.astype(np.float32)!=a['controls'].astype(np.float32)))))
 total=sum(d['native_transition_calls'] for d in r['designs'])+sum(q['total_native_transition_calls'] for q in r['records']);assert total==r['total_native_transition_calls']<=m['native_transition_ceiling'];assert r['actual_hanging_start_episode_steps']==sum(q['actual_hanging_start_episode_steps'] for q in r['records']);assert r['partial_transition_substeps']==0 and r['native_physics_substeps']==4*total;assert not r['reserved_seeds_used'] and not r['noisy_development_seeds_used']
 selected=min(passes,key=lambda rr:(cases[rr['tag']]['tag']!='legacy',rr['handoff_seconds'])) if passes else None
 result=dict(generated_at=utc_timestamp(),script=file_metadata(__file__),passed=True,execution=j,result=file_metadata(root/'execution/diagnostic/result.json'),manifest=file_metadata(root/'manifest.json'),designs=r['designs'],records=r['records'],outcomes=outcomes,total_new_native_transition_calls=total,actual_hanging_start_episode_steps=r['actual_hanging_start_episode_steps'],native_transition_calls_for_this_audit=0,mp80_maximum_offset_residual=max_offset_residual,mp80_maximum_design_gain_residual=max_gain_residual,baseline_full_tapes_byte_exact=baseline_reproductions,independently_reconstructed_tracking_ticks=tracking,independently_reconstructed_maintenance_ticks=maintenance,passing_physical_initializer=None if selected is None else selected['passing_physical_initializer'],full_component_passes=len(passes),canonical_release_evidence=False,not_solution=True,reserved_seeds_used=False,noisy_development_seeds_used=False,scope='All27 exact altered14 episodes, original runtimeK fixed, prefix/wholeproof/action/baseline/counter checks. MP80 independent recurrence verifies offsets against MP100 using stored binary64 native secants; no derivative or robustness certificate. Offset-design gains not used at runtime; only bias+handoff change within reference.')
 dump_json(result,root/'verified.json');print(json.dumps({k:result[k] for k in ['passed','total_new_native_transition_calls','actual_hanging_start_episode_steps','full_component_passes','passing_physical_initializer','baseline_full_tapes_byte_exact']}))

if __name__=='__main__':main()
