#!/usr/bin/env python
"""Rebuild local periodic feedback on a fixed orbit and matched perturbations.

This component comparison never establishes hanging-start reachability.
"""
import argparse
import json
from pathlib import Path
from types import SimpleNamespace
import time

import numpy as np

from gcartpole.config import dump_json, load_config
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, runtime_metadata
from gcartpole.high_order_dynamics import FourthOrderMujocoTransition
from gcartpole.ilqr import QuadraticTrajectoryCost
from gcartpole.modal import StateScales, dimensionless_absolute_transform
from gcartpole.sqrt_ilqr import square_root_tracking_gains
from scripts.audit_periodic_capture import execute_component


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', required=True)
    p.add_argument('--config', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--state-epsilon', type=float, default=.0002)
    p.add_argument('--action-epsilon', type=float, default=.0005)
    p.add_argument('--decimal-digits', type=int, default=0)
    p.add_argument('--export-value-factors', action='store_true')
    args = p.parse_args()
    out = Path(args.out)
    if out.exists():
        raise FileExistsError(out)
    if min(args.state_epsilon, args.action_epsilon) <= 0 or not np.all(np.isfinite([args.state_epsilon, args.action_epsilon])):
        raise ValueError('finite positive derivative increments required')
    if (args.decimal_digits < 0 or 0 < args.decimal_digits < 40
            or (args.export_value_factors and not args.decimal_digits)):
        raise ValueError('design precision must be zero or at least40 digits; value export requires MP')
    source = json.loads(Path(args.source).read_text())
    cfg = load_config(args.config)
    if source['config'] != file_metadata(args.config) or source['n_links'] != cfg['env']['n_links']:
        raise ValueError('fixed orbit source/config differ')
    nodes = np.asarray(source['search']['nominal_coordinate_states'])
    controls = np.asarray(source['controller']['controls'])
    n, nx = source['n_links'], nodes.shape[1]
    if (nx != 2*(n+1) or nodes.shape != (len(controls)+1, nx)
            or len(controls) != source['period_steps']
            or not np.array_equal(source['controller']['coordinate_transform'], np.eye(nx))
            or not np.all(np.isfinite(nodes)) or not np.all(np.isfinite(controls))
            or np.any(np.abs(controls) > 1) or not np.array_equal(nodes[0], nodes[-1])):
        raise ValueError('requires a finite closed physical-coordinate orbit with bounded controls')
    begun = time.monotonic()
    env = NLinkCartPoleEnv(cfg, progress=1., seed=0)
    try:
        env.reset(seed=0)
        if source['period_seconds'] != env.dt*len(controls):
            raise ValueError('physical cadence differs from source')
        transition = FourthOrderMujocoTransition(env, np.eye(nx), continuous_angles=True)
        derivatives = [transition.linearize(x, float(u), state_epsilon=args.state_epsilon,
                        action_epsilon=args.action_epsilon) for x,u in zip(nodes[:-1], controls)]
        calls = transition.evaluations
        cycles = source['controller']['backwards_cycles']
        class CachedCycle:
            env = SimpleNamespace(n=n)
            def __init__(self):
                self.cursor = cycles*len(controls)-1
            def linearize(self, x, u, **kwargs):
                phase = self.cursor % len(controls)
                assert np.array_equal(x, nodes[phase]) and u == controls[phase]
                self.cursor -= 1
                return derivatives[phase]
        transform = dimensionless_absolute_transform(n, StateScales(1.25, .15, .5, .75))
        cost = QuadraticTrajectoryCost(transform.T@transform, transform.T@transform,
            source['controller']['feedback_control_cost'], 2.85, 3., 0., wrap_angles=False,
            stage_factor=transform, terminal_factor=transform)
        tape_nodes = np.vstack([np.tile(nodes[:-1], (cycles, 1)), nodes[:1]])
        tape_controls = np.tile(controls, cycles)
        factors = {}
        all_gains = square_root_tracking_gains(CachedCycle(), tape_nodes, tape_controls, cost,
            decimal_digits=args.decimal_digits,
            callback=lambda row: print(json.dumps(row), flush=True),
            value_factor_callback=(lambda step, root: factors.__setitem__(step, root)) if args.export_value_factors else None,
            value_factor_steps=range(len(controls)+1) if args.export_value_factors else None)
        gains = all_gains[:len(controls)]
        change = float(np.linalg.norm(gains-all_gains[len(controls):2*len(controls)])/max(1., np.linalg.norm(gains)))
    finally:
        env.close()
    seed = 20261900
    base = 200000+1000*n
    if seed in set(range(base, base+20)) | set(range(base+100, base+220)) | {base+500}:
        raise ValueError('local component seed intersects reserved seeds')
    episodes = []
    for old in source['episode_results']:
        episode = execute_component(cfg, nodes, controls, gains, np.asarray(old['perturbation']), seed)
        episode['perturbation_absolute_angle_and_rate_scale'] = old['perturbation_absolute_angle_and_rate_scale']
        if not np.array_equal(episode['selected_state']['qpos'], old['selected_state']['qpos']) or not np.array_equal(episode['selected_state']['qvel'], old['selected_state']['qvel']):
            raise ValueError('matched physical initialization changed')
        episodes.append(episode)
        print(json.dumps({k:v for k,v in episode.items() if not isinstance(v,(dict,list))}), flush=True)
    dump_json(dict(not_solution=True, hanging_start_evidence=False, reserved_seeds_used=False,
        source=file_metadata(args.source), config=file_metadata(args.config), runtime=runtime_metadata(),
        n_links=n, period_steps=len(controls), period_seconds=source['period_seconds'],
        actual_maximum_absolute_angle=source['actual_maximum_absolute_angle'],
        nominal_maximum_cart_excursion=source['nominal_maximum_cart_excursion'],
        orbit_diagnostics=source['orbit_diagnostics'],
        force_amplitude_normalized=source['force_amplitude_normalized'],
        reference_waveform=source.get('reference_waveform', dict(type='single_cosine')),
        controller=dict(source['controller'], feedback_gains=gains.tolist(),
            implementation='pure_ltv_mp_riccati' if args.decimal_digits else 'pure_ltv_square_root_qr',
            design_decimal_digits=args.decimal_digits,
            maximum_gain_norm=float(np.max(np.linalg.norm(gains, axis=1))),
            first_two_cycle_gain_relative_change=change),
        value_factors=dict(period_node_steps=sorted(factors),
            factors=[factors[step].tolist() for step in sorted(factors)],
            purpose='MP value factors for the first period only; no physical robustness certificate'),
        search=dict(nominal_coordinate_states=nodes.tolist()), episode_results=episodes,
        comparison=dict(controls_identical=True, nominal_nodes_identical=True,
            physical_initializations_identical=True, perturbations_identical=True,
            native_control_hz=1/(cfg['env']['timestep']*cfg['env']['frame_skip']),
            action_precision='float32', derivative_order=4, state_epsilon=args.state_epsilon,
            action_epsilon=args.action_epsilon,
            feedback_arithmetic=f'MP{args.decimal_digits}_design_binary64_export' if args.decimal_digits else 'binary64_QR',
            derivative_transition_calls=calls, no_runtime_state_projection=True),
        wall_time_seconds=time.monotonic()-begun), out)


if __name__ == '__main__':
    main()
