"""Read-only independent tape, action, pairing and accounting audit for R27."""
import argparse
import json
from pathlib import Path
import numpy as np
from gcartpole.config import dump_json
from gcartpole.evidence import data_sha256, file_metadata, utc_timestamp
from scripts.audit_armature_route_increment import checked, journal, read, tape


def actions_match(x, u, controls, gains, reference):
    expected = np.asarray([np.float32(np.clip(controls[i] + gains[i] @ (x[i]-reference[i]), -1., 1.))
                           for i in range(len(u))], dtype=float)
    assert expected.tobytes() == u.tobytes()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--directory', required=True)
    args = p.parse_args()
    root = Path(args.directory)
    manifest = read(root/'manifest.json')
    checked(manifest['source']); checked(manifest['source_audit'])
    studies, outcomes = [], []
    for case in manifest['cases']:
        tag = case['tag']; folder = root/tag
        execution = journal(folder); raw = read(folder/'diagnostic/result.json')
        assert raw['status'] == 'finished' and raw['config'] == case['config']
        assert raw['initializer'] == manifest['source'] and raw['entire_horizon_free']
        for k in ('candidate', 'config', 'initializer'): checked(raw[k])
        assert raw['native_physics_substeps'] == 4*raw['total_native_transition_calls']
        assert raw['partial_transition_substeps'] == 0
        assert raw['total_native_transition_calls'] <= manifest['repair_ceiling']
        candidate = read(raw['candidate']['path']); c = candidate['controller']
        history = candidate['search']['optimizer_history']; design = c['tracking_feedback_design']
        assert len(history) == raw['optimizer_iterations'] == manifest['iterations'] == 8
        assert design['regularization_source'] == 'solver'
        assert design['regularization'] == history[-1]['regularization']
        assert design['design_start_step'] == 0 and design['runtime_gains_retained']
        assert design['defect_source'] == 'native' and design['decimal_digits'] == 100
        U = np.asarray(design['reference_controls']); offsets = np.asarray(design['feedforward_control_offsets'])
        K = np.asarray(c['feedback_gains']); X = np.asarray(candidate['search']['nominal_coordinate_states'])
        assert U.shape == offsets.shape == (700,) and K.shape == (700, 30) and X.shape == (701, 30)
        assert np.all(np.isfinite(offsets))
        assert design['reference_controls_sha256'] == data_sha256(U.tolist())
        assert np.clip(U+offsets,-1,1).tobytes() == np.asarray(c['controls']).tobytes()
        rx, ru, gate = tape(raw)
        assert not gate and len(ru) < 450  # observed R27 failures precede every declared handoff
        actions_match(rx, ru, np.clip(U+offsets,-1,1), K, X)
        studies.append(dict(directory=str(folder), execution=execution, result=file_metadata(folder/'diagnostic/result.json'),
            candidate=raw['candidate'], tape=raw['tape'], role='primitive', status='finished', returncode=0,
            total_native_transition_calls=raw['total_native_transition_calls'], actual_hanging_start_episode_steps=len(ru)))
        outcomes.append(dict(tag=tag, kind='raw', offset_scale=1., handoff_seconds=14., passed=gate,
            actual_steps=len(ru), hold_seconds=raw['result']['max_upright_streak_seconds']))
        folder = root/(tag+'_paired_corrected' if tag=='factor0.94' else tag+'_paired')
        execution = journal(folder); paired = read(folder/'diagnostic/result.json')
        assert paired['status'] == 'finished' and paired['source'] == file_metadata(root/tag/'diagnostic/result.json')
        assert paired['gain_source'] == case['gain_result']
        assert paired['runtime_feedback_sha256'] == data_sha256(K.tolist())
        assert len(paired['records']) == 6 and paired['native_transition_ceiling'] == manifest['paired_screen_ceiling']
        assert paired['native_physics_substeps'] == 4*paired['total_native_transition_calls']
        assert paired['partial_transition_substeps'] == 0
        pairs = {}
        for row in paired['records']:
            x,u,passed = tape(row)
            assert not passed and not row['handoff_reached']
            assert row['total_native_transition_calls'] == 2*len(u)
            scale = row['offset_scale']; actions_match(x,u,np.clip(U+scale*offsets,-1,1),K,X)
            if scale == 1.:
                assert x.tobytes() == rx.tobytes() and u.tobytes() == ru.tobytes()
            if scale in pairs:
                assert (x.tobytes(),u.tobytes()) == pairs[scale]
            pairs[scale] = (x.tobytes(),u.tobytes())
            outcomes.append(dict(tag=tag, kind='paired', offset_scale=scale, handoff_seconds=row['handoff_seconds'],
                passed=passed, actual_steps=len(u), hold_seconds=row['result']['max_upright_streak_seconds']))
        assert paired['total_native_transition_calls'] == sum(r['total_native_transition_calls'] for r in paired['records'])
        assert paired['actual_hanging_start_episode_steps'] == sum(r['actual_hanging_start_episode_steps'] for r in paired['records'])
        assert paired['total_native_transition_calls'] <= manifest['paired_screen_ceiling']
        studies.append(dict(directory=str(folder),execution=execution,result=file_metadata(folder/'diagnostic/result.json'),
            records=paired['records'], role='primitive', status='finished', returncode=0,
            total_native_transition_calls=paired['total_native_transition_calls'],
            actual_hanging_start_episode_steps=paired['actual_hanging_start_episode_steps']))
    failed = root/'factor0.94_paired'; j = read(failed/'execution.json')
    assert j['status'] == 'interrupted_or_failed' and j['command'] == ['benchmarks-ignore']
    assert 'FileNotFoundError' in j['error'] and not (failed/'diagnostic').exists()
    for row in j['frozen_inputs']:
        assert file_metadata(failed/'snapshot'/row['path'])['sha256'] == row['sha256']
    studies.append(dict(directory=str(failed), execution=file_metadata(failed/'execution.json'),
        role='primitive_prephysics_launcher_failure',status=j['status'],returncode=1,
        total_native_transition_calls=0, actual_hanging_start_episode_steps=0,
        accounting_scope='Nonexistent executable prevented child startup; no physics process ran.'))
    total = sum(r['total_native_transition_calls'] for r in studies)
    actual = sum(r['actual_hanging_start_episode_steps'] for r in studies)
    assert total <= 3036000
    payload = dict(generated_at=utc_timestamp(),passed=True,script=file_metadata(__file__),
        manifest=file_metadata(root/'manifest.json'),studies=studies,outcomes=outcomes,
        full_component_passes=0,new_actual_episodes=14,distinct_preterminal_actual_trajectories=4,
        total_new_native_transition_calls=total,actual_hanging_start_episode_steps=actual,
        native_transition_calls_for_this_audit=0,canonical_release_evidence=False,not_solution=True,
        actual_action_reconstruction_bytes_exact=True,
        scope='Whole physical tapes independently counted/replayed during execution; this read-only audit independently recomputes gates, all actual tracking actions, pair equality, final regularization and accounting. No independent MP recurrence or finite-difference convergence certificate is claimed. Zero/full attempts fail before all declared handoffs. All failures and launcher correction retained.')
    dump_json(payload,root/'verified.json')
    print(json.dumps(dict(passed=True,calls=total,actual_steps=actual,episodes=14,distinct_trajectories=4)))


if __name__ == '__main__':
    main()
