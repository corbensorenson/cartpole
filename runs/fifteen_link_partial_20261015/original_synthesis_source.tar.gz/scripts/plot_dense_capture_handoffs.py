"""Native-tick capture phase scan, all finite negative controls retained."""
import argparse,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata,utc_timestamp

def main():
 p=argparse.ArgumentParser();p.add_argument('--directory',required=True);a=p.parse_args();root=Path(a.directory);d=json.loads((root/'verified.json').read_text());assert d['passed'];r=d['records'];out=root/'figures';out.mkdir(exist_ok=True);plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42});fig,ax=plt.subplots(1,2,figsize=(10.5,4.4));t=[q['handoff_seconds'] for q in r];hold=[q['result']['max_upright_streak_seconds'] for q in r];duration=[q['result']['length']*.02 for q in r];ax[0].plot(t,hold,'.-',color='#205493',ms=3);ax[0].axhline(5,color='#a14848',ls='--',label='Required hold (plus complete 30s)');ax[0].set(xlabel='Maintenance handoff time (s)',ylabel='Longest actual upright hold (s)',ylim=(0,5.5));ax[0].legend(frameon=False,fontsize=8);ax[1].plot(t,duration,'.-',color='#477f64',ms=3);ax[1].set(xlabel='Maintenance handoff time (s)',ylabel='Actual time before rail failure (s)');
 for axis in ax:axis.grid(axis='y',alpha=.15)
 fig.suptitle('Every available 20ms handoff fails on this capture reference',fontsize=13);fig.text(.5,.025,'80 ticks from 8.00 to 9.58s; same altered 14-link plant, armature factor 0.95, seed 0, 50Hz/F32.\nPrefix actions and states are exact; nine-second control repeats byte-for-byte. Longer survival is not capture.',ha='center',fontsize=8.5);fig.tight_layout(rect=(0,.13,1,.94));artifacts=[]
 for ext in ['png','pdf']:
  path=out/f'dense_handoff_scan.{ext}';fig.savefig(path,dpi=180);artifacts.append(file_metadata(path))
 plt.close(fig);dump_json(dict(generated_at=utc_timestamp(),script=file_metadata(__file__),audit=file_metadata(root/'verified.json'),artifacts=artifacts,native_transition_calls=0,scope='Complete80-tickavailablehandoffdomain ononefixed reference; noimpossibilityorrobustnessclaim.'),out/'figures.json');print(out/'dense_handoff_scan.png')
if __name__=='__main__':main()
