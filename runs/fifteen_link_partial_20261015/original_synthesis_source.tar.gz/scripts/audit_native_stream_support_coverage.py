"""Audit temporal coverage of a completed bounded stream without new rollouts."""
import argparse,json
from collections import Counter
from itertools import islice
from pathlib import Path
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata
from gcartpole.native_sparse_stream import temporal_supports

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',action='append',required=True)
    p.add_argument('--output',required=True)
    args=p.parse_args();output=Path(args.output)
    if output.exists():raise FileExistsError(output)
    rows=[]
    for path in args.source:
        data=json.loads(Path(path).read_text())
        if not data['parameters']['stream_proposals']:raise ValueError('completed streamed source required')
        rounds=[]
        for r in data['rounds']:
            m=r['proposal_model'];count=m['tested_supports']
            visited=list(islice(temporal_supports(m['active_action_columns'],m['arity'],m['max_support_span']),count))
            if len(visited)!=count:raise ValueError('reported traversal exceeds support inventory')
            histogram=Counter(s[-1]-s[0] for s in visited)
            rounds.append(dict(round=r['round'],visited_supports=count,
                visited_span_histogram={str(k):v for k,v in sorted(histogram.items())},
                maximum_visited_span_ticks=max(histogram,default=None),
                selected_move_span_ticks=None if r['selected_proposal'] is None else
                    r['selected_proposal']['indices'][-1]-r['selected_proposal']['indices'][0],
                scored_model_proposals=m['scored_model_proposals'],status=m['status']))
        rows.append(dict(source=file_metadata(path),arity=data['parameters']['move_arity'],rounds=rounds))
    result=dict(records=rows,native_transition_calls=0,
        script=file_metadata(__file__),
        scope='Reconstruct visited support traversal from completed immutable model counters and active columns. A last support may be partially generated at the model-proposal cap;visited counts are not complete candidate enumeration. No native replay,feasibility or causal arity claim.')
    dump_json(result,output);print(json.dumps(result))
if __name__=='__main__':main()
