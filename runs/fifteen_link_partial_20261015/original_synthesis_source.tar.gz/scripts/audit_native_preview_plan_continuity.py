#!/usr/bin/env python
"""Check retained previous-plan suffixes at a recorded forecast fallback."""
import argparse,json,time
from pathlib import Path
import numpy as np
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config,dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata,runtime_metadata
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    p.add_argument('--extension-grid-points',type=int,default=0)
    args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    source=json.loads(Path(args.source).read_text());cfgpath=source['config']['path']
    if file_metadata(cfgpath)!=source['config']:raise ValueError('Config changed')
    cfg=load_config(cfgpath);n=cfg['env']['n_links'];limit=source['parameters']['maximum_absolute_preview_angle']
    rows=source['result']['trajectory'];index=next(i for i,r in enumerate(rows) if r.get('tracking_preview',{}).get('fallback'))
    if index<2:raise ValueError('Previous actual state and successful forecast required')
    prior=rows[index-1];diag=prior['tracking_preview'];plan=np.asarray(diag['selected_sequence'],dtype=np.float32).astype(float)
    initial=np.asarray(rows[index-2]['qpos']+rows[index-2]['qvel']);actual=np.asarray(prior['qpos']+prior['qvel'])
    base=json.loads(Path(source['source']['path']).read_text());controls=np.asarray(base['controller']['controls']);gains=np.asarray(base['controller']['feedback_gains']);nodes=np.asarray(base['search']['nominal_coordinate_states'])
    if file_metadata(source['source']['path'])!=source['source']:
        raise ValueError('Underlying route changed')
    env=NLinkCartPoleEnv(fixed_state_cfg(cfg,base['selected_state'],30.),progress=1.,seed=base['seed']);env.reset(seed=base['seed'])
    predictor=MujocoTransition(env,np.eye(len(initial)),continuous_angles=True);began=time.monotonic()
    try:
        first=predictor(initial,float(plan[0]))
        if not np.array_equal(first,actual) or np.float32(prior['action'])!=np.float32(plan[0]):
            raise ValueError('Previous selected input did not exactly reproduce the next actual state')
        suffix=plan[1:];predictions=[];current=actual
        for u in suffix:current=predictor(current,float(u));predictions.append(current)
        def metrics(states):
            a=np.asarray(states);angles=np.max(np.abs(wrap_angle(np.cumsum(a[:,1:n+1],axis=1))),axis=1)
            return dict(maximum_absolute_angle=float(np.max(angles)),maximum_cart=float(np.max(np.abs(a[:,0]))),
                maximum_absolute_angular_rate=float(np.max(np.abs(np.cumsum(a[:,n+2:],axis=1)))),
                terminal_maximum_absolute_angular_rate=float(np.max(np.abs(np.cumsum(a[-1,n+2:])))),
                terminal_state=a[-1].tolist(),
                all_forecasts_admissible=bool(np.all(angles<=limit) and np.all(np.abs(a[:,0])<=cfg['env']['rail_limit'])))
        suffixmetrics=metrics(predictions)
        index_next=prior['step']+len(suffix)
        append=[('zero',0.),('reference',controls[index_next]),('last_previous_input',plan[-1]),
                ('tracking_feedback',np.clip(controls[index_next]+gains[index_next]@(current-nodes[index_next]),-1,1))]
        if args.extension_grid_points:
            if args.extension_grid_points<3:raise ValueError('extension grid requires at least three points')
            append.extend((f'grid{i}',u) for i,u in enumerate(np.linspace(-1,1,args.extension_grid_points)))
        records=[]
        for label,u in append:
            nextstate=predictor(current,float(np.float32(u)))
            records.append(dict(label=label,appended_action=float(np.float32(u)),
                sequence=np.r_[suffix,float(np.float32(u))].tolist(),**metrics([*predictions,nextstate])))
    finally:env.close()
    dump_json(dict(not_solution=True,benchmark_evidence=False,source=file_metadata(args.source),config=file_metadata(cfgpath),
        fallback_controller_step=prior['step'],fallback_time_seconds=prior['time_seconds'],
        prior_native_input_and_next_actual_state_bit_identical=True,previous_plan_suffix=suffix.tolist(),
        suffix_steps=len(suffix),suffix_metrics=suffixmetrics,full_horizon_candidates=records,
        native_transition_calls=predictor.evaluations,wall_seconds=time.monotonic()-began,runtime=runtime_metadata(),
        no_live_state_projection=True,reserved_seeds_used=False,
        scope='Forecast component from a retained actual state. Proves feasibility only for the explicitly tested suffix/candidate horizons; no longer-horizon viability, controller or canonical robustness is inferred.'),out/'result.json')
    print(json.dumps(dict(suffix=suffixmetrics,candidates=records)))
if __name__=='__main__':main()
