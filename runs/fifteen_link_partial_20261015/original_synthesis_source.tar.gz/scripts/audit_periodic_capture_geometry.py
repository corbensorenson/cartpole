#!/usr/bin/env python
"""Resynthesize one declared odd-harmonic local capture geometry."""
import argparse,json,copy,subprocess,sys
from pathlib import Path
from gcartpole.config import dump_json,load_config
from gcartpole.evidence import file_metadata,utc_timestamp
from gcartpole.roadmap import validate_canonical_config


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',required=True);p.add_argument('--directory',required=True)
    p.add_argument('--third-harmonic',type=float,required=True)
    p.add_argument('--fifth-harmonic',type=float,required=True)
    args=p.parse_args();out=Path(args.directory);out.mkdir(parents=True,exist_ok=True)
    journal=out/'geometry_component.json'
    if journal.exists() or (out/'result.json').exists():raise FileExistsError(out)
    cfg=load_config(args.config);checked=copy.deepcopy(cfg);checked['env']['n_links']=7
    if validate_canonical_config(checked):raise ValueError('canonical baseline required')
    if (args.third_harmonic,args.fifth_harmonic) not in ((.5,0.),(.5,.25)):
        raise ValueError('requires a predeclared geometry family member')
    record=dict(status='running',started_at=utc_timestamp(),not_solution=True,
        hanging_start_evidence=False,reserved_seeds_used=False,release_promotion=False,
        config=file_metadata(args.config),fundamental_frequency_hz=2.5,native_control_hz=50,
        third_harmonic=args.third_harmonic,fifth_harmonic=args.fifth_harmonic,stages=[])
    dump_json(record,journal)
    def stage(label,script,extra,inputs):
        directory=out/label;result=directory/'result.json'
        command=[sys.executable,'scripts/run_frontier_experiment.py','--directory',str(directory),
            '--input',args.config,'--input',str(journal)]
        for path in inputs:command+=['--input',str(path)]
        subprocess.run(command+['--',sys.executable,'scripts/'+script,'--config',args.config,
                                '--out',str(result),*extra],check=True)
        record['stages'].append(dict(label=label,result=file_metadata(result),execution=file_metadata(directory/'execution.json')))
        dump_json(record,journal);return result
    try:
        orbit=stage('orbit_second_order','audit_periodic_capture.py',
            ['--period-steps','20','--angle-amplitude','.12','--control-cost','1000','--max-force-amplitude','.5',
             '--third-harmonic',str(args.third_harmonic),'--fifth-harmonic',str(args.fifth_harmonic)],[])
        final=stage('fourth_order_feedback','replay_periodic_capture_feedback.py',['--source',str(orbit)],[orbit])
        record.update(status='finished_component_only',finished_at=utc_timestamp())
        result=json.loads(final.read_text());dump_json(dict(result,geometry_ablation=dict(record)),out/'result.json')
        record['result']=file_metadata(out/'result.json')
    except BaseException as error:
        record.update(status='failed_or_interrupted',error=f'{type(error).__name__}: {error}',finished_at=utc_timestamp())
        raise
    finally:dump_json(record,journal)
    print(json.dumps(dict(status=record['status'],journal=str(journal))))
if __name__=='__main__':main()
