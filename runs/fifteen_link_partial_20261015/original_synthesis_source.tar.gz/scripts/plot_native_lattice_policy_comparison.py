#!/usr/bin/env python
"""Separate fixed-state lattice gains from completed native policy outcomes."""
import argparse,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--component',required=True);p.add_argument('--policies',required=True,nargs=3)
    p.add_argument('--directory',required=True);args=p.parse_args();out=Path(args.directory)
    if (out/'result.json').exists():raise FileExistsError(out)
    component=json.loads(Path(args.component).read_text());policies=[json.loads(Path(v).read_text()) for v in args.policies]
    for data in policies:
        if (not data['inherited_prefix_states_and_actions_bit_identical'] or
                data['physical_tape_diagnostics']['maximum_dynamics_defect']!=0.):raise ValueError('Exact source-aligned native policy tapes required')
    labels=['Rollout secants','Composed gradients','Lattice polish'];colors=['#243a50','#b75735','#43816a']
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    fig,axes=plt.subplots(2,2,figsize=(10.5,7.5),layout='constrained')
    x=np.arange(3);rows=component['records']
    axes[0,0].bar(x-.18,[r['baseline_physical_cost'] for r in rows],width=.36,color='#aeb9c1',label='Saved plan')
    axes[0,0].bar(x+.18,[r['selected_physical_cost'] for r in rows],width=.36,color=colors[2],label='Lattice polish')
    axes[0,0].set(yscale='log',xticks=x,xticklabels=['7.50','7.82','8.14'],xlabel='Fixed actual state time (s)',
        ylabel='Native forecast physical cost',title='One local forecast improves substantially');axes[0,0].legend(fontsize=9)
    holds=[r['result']['max_upright_streak_seconds'] for r in policies]
    axes[0,1].bar(x,holds,color=colors)
    for i,v in enumerate(holds):axes[0,1].text(i,v+.10,f'{v:.2f}',ha='center')
    axes[0,1].axhline(5,color='#727b84',ls='--',label='Required 5 s hold')
    axes[0,1].set(ylim=(0,5.6),xticks=x,xticklabels=['Rollout','Composed','Lattice'],ylabel='Actual maximum hold (s)',
        title='The completed policies still fail');axes[0,1].legend(fontsize=9)
    for label,color,data in zip(labels,colors,policies):
        trajectory=data['result']['trajectory'];time=[r['time_seconds'] for r in trajectory]
        axes[1,0].semilogy(time,[max(r['max_abs_angle'],1e-6) for r in trajectory],color=color,label=label)
        axes[1,1].plot(time,[r['qpos'][0] for r in trajectory],color=color)
    axes[1,0].axhline(.15,color='#727b84',ls='--');axes[1,0].set(xlim=(5.5,13),ylim=(1e-4,3.5),
        xlabel='Simulation time (s)',ylabel='Worst actual link angle (rad)',title='Actual capture trajectories');axes[1,0].legend(fontsize=9)
    for value in [-3,3]:axes[1,1].axhline(value,color='#727b84',ls='--')
    axes[1,1].set(xlim=(5.5,13),ylim=(-3.4,3.4),xlabel='Simulation time (s)',ylabel='Actual cart position (m)',title='Rail exits occur after balance is lost')
    for ax in axes.flat:ax.grid(axis='y',alpha=.18)
    fig.suptitle('Better local derivatives and digital corrections do not yet supply a capture funnel',fontsize=13)
    fig.supxlabel('15-link exact-start research at 50 Hz; same H32/16-input commit/rate1 recipe.\n'
        'All executed tapes replay at zero defect. Traces stop at rail termination.\n'
        'No noisy/reserved gate or canonical release is inferred. Plotting uses zero new physics calls.',fontsize=9)
    out.mkdir(parents=True,exist_ok=True);outputs=[]
    for suffix in ['png','pdf','svg']:
        path=out/f'comparison.{suffix}';fig.savefig(path,dpi=180);outputs.append(file_metadata(path))
    plt.close(fig);dump_json(dict(not_solution=True,canonical_release_evidence=False,
        sources=[file_metadata(args.component),*[file_metadata(v) for v in args.policies]],outputs=outputs,
        native_transition_calls=0,scope='Measured fixed-state forecasts and completed actual native traces, kept separate. No new simulation or gate validation.'),out/'result.json')


if __name__=='__main__':main()
