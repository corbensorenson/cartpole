#!/usr/bin/env python
"""Measure native task secants and bounded local corrections on retained plans."""
import argparse, json, time
from pathlib import Path
import numpy as np
from scipy.optimize import lsq_linear
from gcartpole.angles import wrap_angle
from gcartpole.config import load_config, dump_json
from gcartpole.env import NLinkCartPoleEnv
from gcartpole.evidence import file_metadata, runtime_metadata
from gcartpole.ilqr import MujocoTransition
from scripts.search_capture_sequence import fixed_state_cfg


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', required=True)
    p.add_argument('--directory', required=True)
    p.add_argument('--delivered-steps',type=int,nargs='+',default=[376,386,391])
    p.add_argument('--secants',type=float,nargs='+',default=[1e-3,1e-4,1e-5,1e-6])
    args = p.parse_args(); out = Path(args.directory)
    if (out/'result.json').exists(): raise FileExistsError(out)
    source = json.loads(Path(args.source).read_text())
    cfgpath = source['config']['path']
    if file_metadata(cfgpath) != source['config']: raise ValueError('Config changed')
    cfg = load_config(cfgpath); n = cfg['env']['n_links']
    basepath = source['source']['path']
    if file_metadata(basepath) != source['source']: raise ValueError('Route changed')
    base = json.loads(Path(basepath).read_text())
    horizon=source['executed_policy']['requested_horizon_steps']
    rate_weight=source['executed_policy']['residual_weights']['rate']
    if (horizon<2 or not all(np.isfinite(v) and v>0 for v in args.secants)
            or 1e-5 not in args.secants):raise ValueError('Positive secants including1e-5 and a native MPC horizon required')
    env = NLinkCartPoleEnv(fixed_state_cfg(cfg, base['selected_state'], 30.), progress=1., seed=base['seed'])
    env.reset(seed=base['seed'])
    transition = MujocoTransition(env, np.eye(2*(n+1)), continuous_angles=True)
    rows = source['result']['trajectory']; records = []; began = time.monotonic()
    try:
        for delivered_step in args.delivered_steps:
            row = rows[delivered_step-1]; prior = rows[delivered_step-2]
            state = np.asarray(prior['qpos']+prior['qvel'])
            sequence = np.asarray(row['tracking_preview']['selected_sequence'], dtype=np.float32).astype(float)
            if len(sequence) != horizon: raise ValueError('Expected complete retained native plan at a planning tick')
            reference = np.asarray(base['controller']['controls'][delivered_step-1:delivered_step-1+horizon])
            if len(reference)!=horizon:raise ValueError('Retained plan exceeds source reference horizon')
            def forecast(u):
                current = state.copy(); states = []
                for action in np.asarray(u, dtype=np.float32).astype(float):
                    current = transition(current, float(action)); states.append(current.copy())
                a = np.asarray(states)
                angles = wrap_angle(np.cumsum(a[:, 1:n+1], axis=1))
                rates = np.cumsum(a[:, n+2:], axis=1)
                residual = np.r_[(angles/.15/np.sqrt(n*horizon)).ravel(),
                    (rate_weight*rates/.75/np.sqrt(n*horizon)).ravel(), .1*a[:,0]/1.5/np.sqrt(horizon),
                    .1*a[:,n+1]/.5/np.sqrt(horizon), np.sqrt(5)*angles[-1]/.15/np.sqrt(n),
                    np.sqrt(5)*rate_weight*rates[-1]/.75/np.sqrt(n)]
                return residual, a, dict(maximum_absolute_angle=float(np.max(np.abs(angles))),
                    maximum_absolute_rate=float(np.max(np.abs(rates))), maximum_cart=float(np.max(np.abs(a[:,0]))))
            residual, states, metrics = forecast(sequence)
            if not np.array_equal(states[0], row['qpos']+row['qvel']): raise ValueError('Retained plan first input is not actual native state')
            secants = []; jacobians = []
            for epsilon in args.secants:
                columns = [];neighbors=0;delivered_widths=[]
                for index in range(horizon):
                    plus = sequence.copy(); minus = sequence.copy()
                    plus[index] = float(np.float32(min(1., sequence[index]+epsilon)))
                    minus[index] = float(np.float32(max(-1., sequence[index]-epsilon)))
                    if plus[index]==minus[index]:
                        center=np.float32(sequence[index])
                        plus[index]=min(1.,float(np.nextafter(center,np.float32(np.inf))))
                        minus[index]=max(-1.,float(np.nextafter(center,np.float32(-np.inf))))
                        neighbors+=1
                    delivered_widths.append(plus[index]-minus[index])
                    columns.append((forecast(plus)[0]-forecast(minus)[0])/(plus[index]-minus[index]))
                jac = np.column_stack(columns); jacobians.append(jac)
                spectrum = np.linalg.svd(jac, compute_uv=False)
                unbounded_delta = np.linalg.lstsq(jac, -residual, rcond=1e-12)[0]
                unbounded_residual = residual+jac@unbounded_delta
                # Optimize absolute candidate inputs to avoid equal delta bounds at saturation.
                matrix = np.vstack([jac, .01*np.eye(horizon)])
                rhs = np.r_[jac@sequence-residual, .01*reference]
                fitted = lsq_linear(matrix, rhs, bounds=(-1.,1.), tol=1e-12, max_iter=200)
                candidate = np.asarray(fitted.x, dtype=np.float32).astype(float)
                native, _, candidate_metrics = forecast(candidate)
                secants.append(dict(epsilon=epsilon,f32_neighbor_fallback_columns=neighbors,
                    delivered_secant_widths=delivered_widths,physical_task_singular_values=spectrum.tolist(),
                    unbounded_linear_minimum_physical_cost=float(unbounded_residual@unbounded_residual),
                    unbounded_linear_maximum_input_change=float(np.max(np.abs(unbounded_delta))),
                    unbounded_linear_unremoved_residual_fraction=float((unbounded_residual@unbounded_residual)/(residual@residual)),
                    local_bounded_solver_success=bool(fitted.success), local_bounded_solver_status=int(fitted.status),
                    linear_predicted_physical_cost=float(np.sum((residual+jac@(candidate-sequence))**2)),
                    native_candidate_physical_cost=float(native@native), candidate_metrics=candidate_metrics,
                    candidate_sequence=candidate.tolist(), maximum_input_change=float(np.max(np.abs(candidate-sequence)))))
            for item, jac in zip(secants, jacobians):
                reference_jac=jacobians[args.secants.index(1e-5)]
                item['relative_jacobian_difference_from_1e5'] = float(np.linalg.norm(jac-reference_jac)/np.linalg.norm(reference_jac))
                item['absolute_jacobian_difference_from_1e5'] = float(np.linalg.norm(jac-reference_jac,ord=2))
            records.append(dict(delivered_step=delivered_step, controller_time_seconds=(delivered_step-1)*.02,
                actual_first_state_bit_identical=True, baseline_metrics=metrics,
                baseline_physical_cost=float(residual@residual), secants=secants))
    finally: env.close()
    dump_json(dict(not_solution=True, benchmark_evidence=False, source=file_metadata(args.source),
        config=file_metadata(cfgpath),parameters=vars(args),horizon_steps=horizon,rate_residual_weight=rate_weight,
        records=records, native_transition_calls=transition.evaluations,
        wall_seconds=time.monotonic()-began, runtime=runtime_metadata(), reserved_seeds_used=False,
        noisy_development_seeds_used=False,
        scope='Native fixed-state component. SVD measures finite-difference physical task sensitivities, not an exact controllability rank. Bounded linear corrections and their native forecasts do not prove global infeasibility, recursive viability or episode success.'), out/'result.json')
    print(json.dumps(dict(calls=transition.evaluations, cases=len(records))))

if __name__ == '__main__': main()
