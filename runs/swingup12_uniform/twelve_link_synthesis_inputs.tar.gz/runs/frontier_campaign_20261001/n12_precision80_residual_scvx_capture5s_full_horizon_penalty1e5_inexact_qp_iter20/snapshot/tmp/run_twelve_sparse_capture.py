"""Bounded matched residual-form SCvx trials on an explicitly virtual tail."""
import argparse
import json
import subprocess
from pathlib import Path
from gcartpole.config import dump_json
from gcartpole.evidence import file_metadata

p = argparse.ArgumentParser()
p.add_argument('--directory', required=True)
p.add_argument('--defect-penalty', type=float, required=True)
p.add_argument('--iterations', type=int, default=10)
p.add_argument('--qp-max-iterations', type=int, default=10000)
p.add_argument('--suffix-start-seconds', type=float, default=6.)
p.add_argument('--qp-initial-tolerance', type=float, default=None)
p.add_argument('--qp-inexact-dual-tolerance', type=float, default=0.)
args = p.parse_args()
out = Path(args.directory)
root = Path('runs/frontier_campaign_20261001')
initial = root/'n12_precision80_sustained_capture5s_value0_sqrt_fddp20/initial_controller.json'
reference = root/'n12_precision80_sustained_capture5s_value0_sqrt_fddp20/synthesis/execution.json'
command = json.loads(reference.read_text())['command']
changes = {'--optimizer': 'sparse-scvx', '--state-json': str(initial), '--initial-controller': str(initial),
           '--iterations': str(args.iterations), '--defect-penalty': str(args.defect_penalty),
           '--terminal-weight': '0', '--capture-value-weight': '0',
           '--out': str(out/'synthesis/result.json')}
for key, value in changes.items():
    command[command.index(key)+1] = value
command.extend(['--enforce-rail-during-search', '--optimize-suffix-start-seconds', str(args.suffix_start_seconds),
                '--sparse-capture-angle-limit', '.14', '--sparse-state-trust', '.05',
                '--sparse-control-trust', '.1', '--sparse-qp-max-iterations', str(args.qp_max_iterations),
                '--sparse-qp-tolerance', '1e-8'])
if args.qp_initial_tolerance is not None:
    command.extend(['--sparse-qp-initial-tolerance', str(args.qp_initial_tolerance)])
command.extend(['--sparse-qp-inexact-dual-tolerance', str(args.qp_inexact_dual_tolerance)])
subprocess.run(['.conda-aligator/bin/python', 'scripts/run_frontier_experiment.py',
                '--directory', str(out/'synthesis'), '--input', str(initial), '--input', str(reference),
                '--', *command], check=True)
d = json.loads((out/'synthesis/result.json').read_text())
d['simultaneous_capture_comparison'] = dict(
    initialization=file_metadata(initial), reference_command=file_metadata(reference),
    actual_optimizer='sparse_residual_scvx_with_l1_virtual_control',
    defect_penalty=args.defect_penalty, maximum_outer_iterations=args.iterations,
    maximum_native_qp_iterations=args.qp_max_iterations,
    qp_initial_tolerance=args.qp_initial_tolerance,
    qp_inexact_dual_tolerance=args.qp_inexact_dual_tolerance,
    frozen_prefix_seconds=args.suffix_start_seconds,
    virtual_capture_seconds=5, virtual_absolute_angle_margin=.14,
    no_runtime_state_projection=True, reserved_twelve_seeds_used=False,
    note='Native QP convergence and constrained virtual nodes do not establish physical capture. Full uninterrupted execution is saved independently.')
dump_json(d, out/'result.json')
print(json.dumps({k: v for k, v in d['result'].items() if not isinstance(v, (dict, list))}), flush=True)
