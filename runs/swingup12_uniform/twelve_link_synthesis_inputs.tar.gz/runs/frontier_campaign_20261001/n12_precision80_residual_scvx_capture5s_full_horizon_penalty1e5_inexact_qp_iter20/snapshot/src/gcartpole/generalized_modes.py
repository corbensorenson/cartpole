"""Morphology-derived normal modes for deterministic n-link control.

The generalized swing-up controller needs coordinates that retain the phase of
every internal degree of freedom.  A total-energy scalar cannot distinguish two
states with identical energy but opposite distal-link phases.  This module
derives a mass-normalized modal basis directly from the exact MuJoCo plant,
without fitting a policy or introducing link-count-specific parameters.
"""

from __future__ import annotations

from dataclasses import dataclass

import mujoco
import numpy as np
from scipy.linalg import eigh, expm

from gcartpole.env import NLinkCartPoleEnv, wrap_angle
from gcartpole.generalized_solver import setup_from_config


@dataclass(frozen=True)
class ChainNormalModes:
    """Mass-normalized small-oscillation modes about a chain equilibrium."""

    equilibrium: str
    relative_equilibrium: np.ndarray
    joint_mass_matrix: np.ndarray
    stiffness_matrix: np.ndarray
    damping_matrix: np.ndarray
    squared_frequencies: np.ndarray
    angular_frequencies: np.ndarray
    dimensionless_frequencies: np.ndarray
    relative_shapes: np.ndarray
    absolute_shapes: np.ndarray
    cart_acceleration_coupling: np.ndarray
    normalized_coupling: np.ndarray

    @property
    def n_links(self) -> int:
        return int(self.relative_equilibrium.size)

    def coordinates(
        self,
        relative_angles: np.ndarray,
        hinge_rates: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Project a physical state into mass-normalized modal coordinates."""

        angles = np.asarray(relative_angles, dtype=np.float64)
        rates = np.asarray(hinge_rates, dtype=np.float64)
        expected = (self.n_links,)
        if angles.shape != expected or rates.shape != expected:
            raise ValueError("angle and rate shapes do not match the modal basis")
        displacement = wrap_angle(angles - self.relative_equilibrium)
        projector = self.relative_shapes.T @ self.joint_mass_matrix
        return projector @ displacement, projector @ rates

    def phase_features(
        self,
        relative_angles: np.ndarray,
        hinge_rates: np.ndarray,
        *,
        energy_scale: float,
    ) -> dict[str, np.ndarray]:
        """Return per-mode phase, amplitude, and normalized energy features."""

        if not np.isfinite(energy_scale) or energy_scale <= 0.0:
            raise ValueError("energy_scale must be finite and positive")
        positions, velocities = self.coordinates(relative_angles, hinge_rates)
        frequency_positions = self.angular_frequencies * positions
        amplitudes = np.hypot(frequency_positions, velocities)
        phases = np.arctan2(frequency_positions, velocities)
        energies = 0.5 * (frequency_positions**2 + velocities**2)
        return {
            "position": positions,
            "velocity": velocities,
            "phase": phases,
            "amplitude": amplitudes / np.sqrt(energy_scale),
            "energy_fraction": energies / energy_scale,
        }

    def to_dict(self) -> dict[str, object]:
        return {
            "equilibrium": self.equilibrium,
            "squared_frequencies": self.squared_frequencies.astype(float).tolist(),
            "angular_frequencies": self.angular_frequencies.astype(float).tolist(),
            "dimensionless_frequencies": self.dimensionless_frequencies.astype(
                float
            ).tolist(),
            "relative_shapes": self.relative_shapes.astype(float).tolist(),
            "absolute_shapes": self.absolute_shapes.astype(float).tolist(),
            "cart_acceleration_coupling": self.cart_acceleration_coupling.astype(
                float
            ).tolist(),
            "normalized_coupling": self.normalized_coupling.astype(float).tolist(),
            "joint_mass_matrix": self.joint_mass_matrix.astype(float).tolist(),
            "stiffness_matrix": self.stiffness_matrix.astype(float).tolist(),
            "damping_matrix": self.damping_matrix.astype(float).tolist(),
        }


@dataclass(frozen=True)
class ModalPhaseSeed:
    """Minimum-energy linear modal schedule used only as a nonlinear warm start."""

    policy_dt: float
    horizon_seconds: float
    accelerations: np.ndarray
    states: np.ndarray
    target_state: np.ndarray
    terminal_residual: np.ndarray
    unclipped_accelerations: np.ndarray

    def to_dict(self) -> dict[str, object]:
        return {
            "policy_dt": float(self.policy_dt),
            "horizon_seconds": float(self.horizon_seconds),
            "accelerations": self.accelerations.astype(float).tolist(),
            "states": self.states.astype(float).tolist(),
            "target_state": self.target_state.astype(float).tolist(),
            "terminal_residual": self.terminal_residual.astype(float).tolist(),
            "unclipped_accelerations": self.unclipped_accelerations.astype(
                float
            ).tolist(),
        }


@dataclass(frozen=True)
class ModalTransitionSeed:
    """Minimum-energy linear modal transition from an arbitrary plant state."""

    policy_dt: float
    horizon_seconds: float
    initial_state: np.ndarray
    target_state: np.ndarray
    accelerations: np.ndarray
    states: np.ndarray
    terminal_residual: np.ndarray
    unclipped_accelerations: np.ndarray

    def to_dict(self) -> dict[str, object]:
        return {
            "policy_dt": float(self.policy_dt),
            "horizon_seconds": float(self.horizon_seconds),
            "initial_state": self.initial_state.astype(float).tolist(),
            "target_state": self.target_state.astype(float).tolist(),
            "accelerations": self.accelerations.astype(float).tolist(),
            "states": self.states.astype(float).tolist(),
            "terminal_residual": self.terminal_residual.astype(float).tolist(),
            "unclipped_accelerations": self.unclipped_accelerations.astype(
                float
            ).tolist(),
        }


def _modal_discrete_dynamics(
    modes: ChainNormalModes,
    policy_dt: float,
) -> tuple[np.ndarray, np.ndarray]:
    n = modes.n_links
    d = n + 1
    state_dim = 2 * d
    continuous_a = np.zeros((state_dim, state_dim), dtype=np.float64)
    continuous_b = np.zeros((state_dim, 1), dtype=np.float64)
    continuous_a[:d, d:] = np.eye(d, dtype=np.float64)
    continuous_a[d + 1 :, 1:d] = -np.diag(modes.squared_frequencies)
    modal_damping = (
        modes.relative_shapes.T @ modes.damping_matrix @ modes.relative_shapes
    )
    continuous_a[d + 1 :, d + 1 :] = -modal_damping
    continuous_b[d, 0] = 1.0
    continuous_b[d + 1 :, 0] = modes.cart_acceleration_coupling
    augmented = np.zeros((state_dim + 1, state_dim + 1), dtype=np.float64)
    augmented[:state_dim, :state_dim] = continuous_a
    augmented[:state_dim, state_dim:] = continuous_b
    discrete = expm(augmented * policy_dt)
    return discrete[:state_dim, :state_dim], discrete[:state_dim, state_dim:]


def minimum_energy_modal_transition(
    modes: ChainNormalModes,
    *,
    relative_angles: np.ndarray,
    hinge_rates: np.ndarray,
    cart_position: float,
    cart_velocity: float,
    policy_dt: float,
    horizon_seconds: float,
    gravity: float,
    target_relative_angles: np.ndarray | None = None,
    target_cart_position: float = 0.0,
    acceleration_limit_ratio: float = 4.0,
    regularization: float = 1.0e-8,
) -> ModalTransitionSeed:
    """Compute a morphology-derived transition between measured modal states."""

    if min(policy_dt, horizon_seconds, gravity, acceleration_limit_ratio) <= 0.0:
        raise ValueError("time, gravity, and acceleration limit must be positive")
    if regularization < 0.0 or not np.isfinite(regularization):
        raise ValueError("regularization must be finite and nonnegative")
    n = modes.n_links
    target_angles = (
        modes.relative_equilibrium
        if target_relative_angles is None
        else np.asarray(target_relative_angles, dtype=np.float64)
    )
    if target_angles.shape != (n,):
        raise ValueError("target relative angles do not match the modal basis")
    initial_modal_position, initial_modal_velocity = modes.coordinates(
        relative_angles, hinge_rates
    )
    target_modal_position, _ = modes.coordinates(
        target_angles, np.zeros(n, dtype=np.float64)
    )
    d = n + 1
    state_dim = 2 * d
    initial = np.zeros(state_dim, dtype=np.float64)
    initial[0] = float(cart_position)
    initial[1:d] = initial_modal_position
    initial[d] = float(cart_velocity)
    initial[d + 1 :] = initial_modal_velocity
    target = np.zeros(state_dim, dtype=np.float64)
    target[0] = float(target_cart_position)
    target[1:d] = target_modal_position
    steps = max(2, round(horizon_seconds / policy_dt))
    state_matrix, input_matrix = _modal_discrete_dynamics(modes, policy_dt)
    powers: list[np.ndarray] = [np.eye(state_dim, dtype=np.float64)]
    for _ in range(steps):
        powers.append(state_matrix @ powers[-1])
    reachability = np.column_stack(
        [powers[steps - 1 - step] @ input_matrix for step in range(steps)]
    )
    desired_change = target - powers[steps] @ initial
    gramian = reachability @ reachability.T
    rhs = np.linalg.solve(
        gramian + regularization * np.eye(state_dim, dtype=np.float64),
        desired_change,
    )
    unconstrained = reachability.T @ rhs
    limit = acceleration_limit_ratio * gravity
    accelerations = np.clip(unconstrained, -limit, limit)
    states = [initial.copy()]
    for acceleration in accelerations:
        states.append(
            state_matrix @ states[-1] + input_matrix[:, 0] * float(acceleration)
        )
    state_rows = np.asarray(states, dtype=np.float64)
    return ModalTransitionSeed(
        policy_dt=float(policy_dt),
        horizon_seconds=float(steps * policy_dt),
        initial_state=initial,
        target_state=target,
        accelerations=accelerations,
        states=state_rows,
        terminal_residual=state_rows[-1] - target,
        unclipped_accelerations=unconstrained,
    )


def minimum_energy_modal_phase_seed(
    modes: ChainNormalModes,
    *,
    policy_dt: float,
    horizon_seconds: float,
    gravity: float,
    acceleration_limit_ratio: float = 4.0,
    regularization: float = 1.0e-8,
) -> ModalPhaseSeed:
    """Solve a morphology-derived finite-horizon modal phase schedule.

    The hanging small-oscillation model includes the cart double integrator,
    every mass-normalized chain mode, exact modal damping, and the exact cart
    acceleration coupling. A regularized controllability-Gramian solve finds
    the minimum-energy acceleration sequence that places all modes at the
    upright relative configuration with zero velocity. The clipped schedule is
    a deterministic warm start only; exact nonlinear optimization must verify
    and refine it before any success claim.
    """

    if min(policy_dt, horizon_seconds, gravity, acceleration_limit_ratio) <= 0.0:
        raise ValueError("time, gravity, and acceleration limit must be positive")
    if regularization < 0.0 or not np.isfinite(regularization):
        raise ValueError("regularization must be finite and nonnegative")
    transition = minimum_energy_modal_transition(
        modes,
        relative_angles=modes.relative_equilibrium,
        hinge_rates=np.zeros(modes.n_links, dtype=np.float64),
        cart_position=0.0,
        cart_velocity=0.0,
        policy_dt=policy_dt,
        horizon_seconds=horizon_seconds,
        gravity=gravity,
        target_relative_angles=np.zeros(modes.n_links, dtype=np.float64),
        acceleration_limit_ratio=acceleration_limit_ratio,
        regularization=regularization,
    )
    return ModalPhaseSeed(
        policy_dt=transition.policy_dt,
        horizon_seconds=transition.horizon_seconds,
        accelerations=transition.accelerations,
        states=transition.states,
        target_state=transition.target_state,
        terminal_residual=transition.terminal_residual,
        unclipped_accelerations=transition.unclipped_accelerations,
    )


def modal_handoff_metrics(
    modes: ChainNormalModes,
    qpos: np.ndarray,
    qvel: np.ndarray,
    *,
    chain_length: float,
    natural_time: float,
    velocity_scale: float,
    energy_scale: float,
) -> dict[str, object]:
    """Score a measured state in dimensionless morphology-derived coordinates.

    The fixed thresholds are the canonical capture scales. The number of
    optimized weights does not grow with link count; added modes contribute
    through their exact energy in the target plant's modal basis.
    """

    position = np.asarray(qpos, dtype=np.float64)
    velocity = np.asarray(qvel, dtype=np.float64)
    expected = modes.n_links + 1
    if position.shape != (expected,) or velocity.shape != (expected,):
        raise ValueError("qpos/qvel shapes do not match the modal basis")
    if min(chain_length, natural_time, velocity_scale, energy_scale) <= 0.0:
        raise ValueError("handoff scales must be positive")
    absolute_angles = wrap_angle(np.cumsum(position[1:]))
    absolute_rates = np.cumsum(velocity[1:])
    modal = modes.phase_features(position[1:], velocity[1:], energy_scale=energy_scale)
    modal_energy = np.asarray(modal["energy_fraction"], dtype=np.float64)
    max_angle = float(np.max(np.abs(absolute_angles)))
    rate_ratio = float(np.sqrt(np.mean(absolute_rates**2)) * natural_time)
    cart_position_ratio = float(position[0] / chain_length)
    cart_velocity_ratio = float(velocity[0] / velocity_scale)
    collective_energy = float(modal_energy[0])
    internal_energy = float(np.sum(modal_energy[1:]))
    score = float(
        (max_angle / 0.15) ** 2
        + (rate_ratio / 0.50) ** 2
        + (cart_position_ratio / 0.42) ** 2
        + (cart_velocity_ratio / 0.15) ** 2
        + 4.0 * collective_energy
        + 8.0 * internal_energy
    )
    return {
        "score": score,
        "max_abs_angle": max_angle,
        "absolute_rate_rms_ratio": rate_ratio,
        "cart_position_ratio": cart_position_ratio,
        "cart_velocity_ratio": cart_velocity_ratio,
        "collective_modal_energy_fraction": collective_energy,
        "internal_modal_energy_fraction": internal_energy,
        "modal_energy_fraction": modal_energy.astype(float).tolist(),
        "modal_phase": np.asarray(modal["phase"]).astype(float).tolist(),
    }


def _generalized_bias(env: NLinkCartPoleEnv) -> np.ndarray:
    """Return the passive/bias term in ``M qdd + b = actuator``."""

    return np.asarray(
        env.data.qfrc_bias - env.data.qfrc_passive,
        dtype=np.float64,
    ).copy()


def chain_normal_modes(
    env: NLinkCartPoleEnv,
    *,
    equilibrium: str = "hanging",
    epsilon: float = 1.0e-6,
) -> ChainNormalModes:
    """Derive exact morphology-specific modes from MuJoCo finite differences.

    The cart acceleration is treated as the base input.  For joint coordinates
    ``q`` the linearized dynamics are

    ``M_jj qdd + D qdot + K q = -M_jx xdd``.

    The returned eigenvectors satisfy ``V.T @ M_jj @ V = I`` and are ordered by
    increasing natural frequency.  Their signs are canonicalized so serialized
    analyses are reproducible across runs.
    """

    if equilibrium not in {"hanging", "upright"}:
        raise ValueError("equilibrium must be 'hanging' or 'upright'")
    if not np.isfinite(epsilon) or epsilon <= 0.0:
        raise ValueError("epsilon must be finite and positive")

    n = int(env.n)
    d = n + 1
    saved_qpos = np.asarray(env.data.qpos, dtype=np.float64).copy()
    saved_qvel = np.asarray(env.data.qvel, dtype=np.float64).copy()
    saved_ctrl = np.asarray(env.data.ctrl, dtype=np.float64).copy()
    saved_time = float(env.data.time)

    relative_equilibrium = np.zeros(n, dtype=np.float64)
    if equilibrium == "hanging":
        relative_equilibrium[0] = np.pi
    base_qpos = np.r_[0.0, relative_equilibrium]
    zero_qvel = np.zeros(d, dtype=np.float64)

    def evaluate(qpos: np.ndarray, qvel: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        env.data.qpos[:] = qpos
        env.data.qvel[:] = qvel
        env.data.ctrl[:] = 0.0
        mujoco.mj_forward(env.model, env.data)
        full_mass = np.zeros((d, d), dtype=np.float64)
        mujoco.mj_fullM(env.model, full_mass, env.data.qM)
        return full_mass, _generalized_bias(env)

    full_mass, _ = evaluate(base_qpos, zero_qvel)
    stiffness = np.empty((n, n), dtype=np.float64)
    damping = np.empty((n, n), dtype=np.float64)
    for column in range(n):
        q_delta = np.zeros(d, dtype=np.float64)
        q_delta[1 + column] = epsilon
        _, plus = evaluate(base_qpos + q_delta, zero_qvel)
        _, minus = evaluate(base_qpos - q_delta, zero_qvel)
        stiffness[:, column] = (plus[1:] - minus[1:]) / (2.0 * epsilon)

        v_delta = np.zeros(d, dtype=np.float64)
        v_delta[1 + column] = epsilon
        _, plus = evaluate(base_qpos, zero_qvel + v_delta)
        _, minus = evaluate(base_qpos, zero_qvel - v_delta)
        damping[:, column] = (plus[1:] - minus[1:]) / (2.0 * epsilon)

    # Roundoff and MuJoCo finite differencing can introduce tiny asymmetric
    # components even though these physical matrices are symmetric.
    joint_mass = 0.5 * (full_mass[1:, 1:] + full_mass[1:, 1:].T)
    stiffness = 0.5 * (stiffness + stiffness.T)
    damping = 0.5 * (damping + damping.T)
    squared_frequencies, shapes = eigh(stiffness, joint_mass)
    # Hanging eigenvalues are positive while upright eigenvalues are negative.
    # Order both equilibria by oscillation/growth-rate magnitude so mode zero is
    # always the collective, lowest-frequency shape.
    order = np.argsort(np.sqrt(np.abs(squared_frequencies)))
    squared_frequencies = squared_frequencies[order]
    shapes = shapes[:, order]

    cumulative = np.tril(np.ones((n, n), dtype=np.float64))
    absolute_shapes = cumulative @ shapes
    coupling = -(shapes.T @ full_mass[1:, 0])
    for mode in range(n):
        pivot = int(np.argmax(np.abs(absolute_shapes[:, mode])))
        if absolute_shapes[pivot, mode] < 0.0:
            shapes[:, mode] *= -1.0
            absolute_shapes[:, mode] *= -1.0
            coupling[mode] *= -1.0

    coupling_norm = float(np.linalg.norm(coupling))
    normalized_coupling = (
        coupling / coupling_norm if coupling_norm > 1.0e-15 else np.zeros_like(coupling)
    )
    frequencies = np.sqrt(np.abs(squared_frequencies))
    setup = setup_from_config(env.cfg, progress=env.plant_progress)

    env.data.qpos[:] = saved_qpos
    env.data.qvel[:] = saved_qvel
    env.data.ctrl[:] = saved_ctrl
    env.data.time = saved_time
    mujoco.mj_forward(env.model, env.data)

    return ChainNormalModes(
        equilibrium=equilibrium,
        relative_equilibrium=relative_equilibrium,
        joint_mass_matrix=joint_mass,
        stiffness_matrix=stiffness,
        damping_matrix=damping,
        squared_frequencies=squared_frequencies,
        angular_frequencies=frequencies,
        dimensionless_frequencies=frequencies * setup.natural_time,
        relative_shapes=shapes,
        absolute_shapes=absolute_shapes,
        cart_acceleration_coupling=coupling,
        normalized_coupling=normalized_coupling,
    )


def modal_energy_acceleration_ratio(
    modes: ChainNormalModes,
    relative_angles: np.ndarray,
    hinge_rates: np.ndarray,
    *,
    total_energy_error: float,
    energy_scale: float,
    collective_gain: float,
    internal_damping_gain: float,
) -> tuple[float, dict[str, object]]:
    """Compute a count-agnostic energy-pump/internal-damping command.

    Mode zero is the lowest-frequency collective swing.  Remaining modes are
    internal deformation modes.  The law pumps the collective mode toward the
    upright energy while removing net input power from the internal modes.  It
    uses two scalar gains regardless of link count; all per-mode coefficients
    come from the measured plant.
    """

    if min(collective_gain, internal_damping_gain) < 0.0:
        raise ValueError("modal gains must be nonnegative")
    features = modes.phase_features(
        relative_angles,
        hinge_rates,
        energy_scale=energy_scale,
    )
    velocity = np.asarray(features["velocity"], dtype=np.float64) / np.sqrt(
        energy_scale
    )
    coupling = modes.normalized_coupling
    collective_power_direction = float(coupling[0] * velocity[0])
    internal_power_direction = float(coupling[1:] @ velocity[1:])
    ratio = (
        float(collective_gain) * float(total_energy_error) * collective_power_direction
        - float(internal_damping_gain) * internal_power_direction
    )
    diagnostics: dict[str, object] = {
        "modal_phase": np.asarray(features["phase"]).astype(float).tolist(),
        "modal_amplitude": np.asarray(features["amplitude"]).astype(float).tolist(),
        "modal_energy_fraction": np.asarray(features["energy_fraction"])
        .astype(float)
        .tolist(),
        "collective_power_direction": collective_power_direction,
        "internal_power_direction": internal_power_direction,
        "modal_acceleration_ratio": float(ratio),
    }
    return float(ratio), diagnostics
