"""Morphology-normalized building blocks for a generalized cart-pole solver.

This module deliberately contains no learned parameters and no link-count-specific
constants.  It turns a physical setup into dimensionless groups, transfers state
and feedback trajectories between arbitrary serial-chain discretizations, and
provides a conservative online calibration layer for actuator mismatch.

The transfer operation is a *seed generator*, not a claim that one force trace is
optimal for every morphology.  Exact dynamics optimization is still responsible
for closing the remaining gap after a transfer.
"""

from __future__ import annotations

import copy
from dataclasses import asdict, dataclass
from typing import Any

import numpy as np

GRAVITY = 9.81
DEFAULT_UPRIGHT_LQR_WEIGHTS = {
    "cart_position": 0.1,
    "absolute_angle": 100.0,
    "cart_velocity": 0.1,
    "absolute_angular_velocity": 1.0,
    "relative_angle": 1.0,
    "relative_angular_velocity": 0.01,
}


def periodic_coordinate_error(
    current: np.ndarray,
    reference: np.ndarray,
    transform: np.ndarray,
) -> np.ndarray:
    """Return current-reference on the nearest revolute-joint branch."""

    current_array = np.asarray(current, dtype=np.float64)
    reference_array = np.asarray(reference, dtype=np.float64)
    transform_array = np.asarray(transform, dtype=np.float64)
    error = current_array - reference_array
    state_dim = int(transform_array.shape[0])
    if transform_array.shape != (state_dim, state_dim) or state_dim % 2 != 0:
        raise ValueError("coordinate transform must be even-dimensional and square")
    physical_error = error @ np.linalg.inv(transform_array).T
    configuration_dim = state_dim // 2
    angles = physical_error[..., 1:configuration_dim]
    physical_error[..., 1:configuration_dim] = (
        angles + np.pi
    ) % (2.0 * np.pi) - np.pi
    return physical_error @ transform_array.T


def _positive_vector(name: str, values: np.ndarray | list[float]) -> np.ndarray:
    vector = np.asarray(values, dtype=np.float64)
    if vector.ndim != 1 or vector.size == 0:
        raise ValueError(f"{name} must be a nonempty one-dimensional vector")
    if not np.all(np.isfinite(vector)) or np.any(vector <= 0.0):
        raise ValueError(f"{name} must contain finite positive values")
    return vector


@dataclass(frozen=True)
class PhysicalSetup:
    """Physical quantities needed to instantiate the count-agnostic solver."""

    lengths: np.ndarray
    masses: np.ndarray
    cart_mass: float
    rail_half_length: float
    force_limit: float
    joint_damping: np.ndarray
    cart_damping: float = 0.0
    joint_armature: float = 0.0
    cart_half_length: float = 0.18
    link_radius: float = 0.025
    timestep: float = 0.005
    frame_skip: int = 1
    gravity: float = GRAVITY

    def __post_init__(self) -> None:
        lengths = _positive_vector("lengths", self.lengths)
        masses = _positive_vector("masses", self.masses)
        if lengths.shape != masses.shape:
            raise ValueError("lengths and masses must have the same shape")
        damping = np.asarray(self.joint_damping, dtype=np.float64)
        if damping.shape != lengths.shape:
            raise ValueError("joint_damping must have one value per link")
        if not np.all(np.isfinite(damping)) or np.any(damping < 0.0):
            raise ValueError("joint_damping must contain finite nonnegative values")
        positive_scalars = {
            "cart_mass": self.cart_mass,
            "rail_half_length": self.rail_half_length,
            "force_limit": self.force_limit,
            "cart_half_length": self.cart_half_length,
            "link_radius": self.link_radius,
            "timestep": self.timestep,
            "gravity": self.gravity,
        }
        for name, value in positive_scalars.items():
            if not np.isfinite(value) or float(value) <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if not np.isfinite(self.cart_damping) or self.cart_damping < 0.0:
            raise ValueError("cart_damping must be finite and nonnegative")
        if not np.isfinite(self.joint_armature) or self.joint_armature < 0.0:
            raise ValueError("joint_armature must be finite and nonnegative")
        if int(self.frame_skip) != self.frame_skip or int(self.frame_skip) < 1:
            raise ValueError("frame_skip must be a positive integer")
        object.__setattr__(self, "lengths", lengths.copy())
        object.__setattr__(self, "masses", masses.copy())
        object.__setattr__(self, "joint_damping", damping.copy())
        object.__setattr__(self, "frame_skip", int(self.frame_skip))

    @property
    def n_links(self) -> int:
        return int(self.lengths.size)

    @property
    def chain_length(self) -> float:
        return float(np.sum(self.lengths))

    @property
    def link_mass(self) -> float:
        return float(np.sum(self.masses))

    @property
    def system_mass(self) -> float:
        return float(self.cart_mass + self.link_mass)

    @property
    def natural_time(self) -> float:
        return float(np.sqrt(self.chain_length / self.gravity))

    @property
    def policy_dt(self) -> float:
        return float(self.timestep * self.frame_skip)


@dataclass(frozen=True)
class DimensionlessSetup:
    """Buckingham-pi description of a cart plus serial pendulum chain."""

    n_links: int
    length_fractions: np.ndarray
    mass_fractions: np.ndarray
    cart_to_link_mass: float
    force_authority: float
    rail_ratio: float
    usable_rail_ratio: float
    cart_half_length_ratio: float
    link_radius_ratio: float
    policy_dt_ratio: float
    cart_damping_ratio: float
    joint_damping_ratios: np.ndarray
    joint_armature_ratio: float
    chain_length: float
    system_mass: float
    natural_time: float

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        for key, value in tuple(result.items()):
            if isinstance(value, np.ndarray):
                result[key] = value.tolist()
        return result


def dimensionless_setup(setup: PhysicalSetup) -> DimensionlessSetup:
    """Return the complete scale-free setup used by the generalized recipe.

    Translational force and damping are normalized by ``M g`` and ``M/t0``.
    Joint damping and armature are normalized by ``M L^2/t0`` and ``M L^2``.
    ``usable_rail_ratio`` accounts for the cart body's half length.
    """

    length = setup.chain_length
    mass = setup.system_mass
    time = setup.natural_time
    rotational_damping_scale = mass * length * length / time
    return DimensionlessSetup(
        n_links=setup.n_links,
        length_fractions=setup.lengths / length,
        mass_fractions=setup.masses / setup.link_mass,
        cart_to_link_mass=float(setup.cart_mass / setup.link_mass),
        force_authority=float(setup.force_limit / (mass * setup.gravity)),
        rail_ratio=float(setup.rail_half_length / length),
        usable_rail_ratio=float((setup.rail_half_length - setup.cart_half_length) / length),
        cart_half_length_ratio=float(setup.cart_half_length / length),
        link_radius_ratio=float(setup.link_radius / length),
        policy_dt_ratio=float(setup.policy_dt / time),
        cart_damping_ratio=float(setup.cart_damping * time / mass),
        joint_damping_ratios=setup.joint_damping / rotational_damping_scale,
        joint_armature_ratio=float(setup.joint_armature / (mass * length * length)),
        chain_length=length,
        system_mass=mass,
        natural_time=time,
    )


def similarity_scaled_setup(
    setup: PhysicalSetup,
    *,
    length_scale: float,
    mass_scale: float,
) -> PhysicalSetup:
    """Construct a dynamically similar physical plant.

    ``length_scale`` is lambda and ``mass_scale`` is mu.  With gravity fixed,
    natural time scales by ``sqrt(lambda)``.  Every dimensional parameter is
    transformed so :func:`dimensionless_setup` is invariant, including the
    damping and armature terms that are easy to scale incorrectly.
    """

    if not all(
        np.isfinite(value) and float(value) > 0.0
        for value in (length_scale, mass_scale)
    ):
        raise ValueError("similarity length and mass scales must be positive")
    length = float(length_scale)
    mass = float(mass_scale)
    time = float(np.sqrt(length))
    return PhysicalSetup(
        lengths=length * setup.lengths,
        masses=mass * setup.masses,
        cart_mass=mass * setup.cart_mass,
        rail_half_length=length * setup.rail_half_length,
        force_limit=mass * setup.force_limit,
        joint_damping=mass * length**2 / time * setup.joint_damping,
        cart_damping=mass / time * setup.cart_damping,
        joint_armature=mass * length**2 * setup.joint_armature,
        cart_half_length=length * setup.cart_half_length,
        link_radius=length * setup.link_radius,
        timestep=time * setup.timestep,
        frame_skip=setup.frame_skip,
        gravity=setup.gravity,
    )


def similarity_scaled_config(
    cfg: dict[str, Any],
    *,
    length_scale: float,
    mass_scale: float,
) -> dict[str, Any]:
    """Scale a repository configuration while preserving its dimensionless plant.

    Controller and reward coefficients are intentionally left unchanged.  The
    returned configuration changes only dimensional plant, initialization,
    and clock quantities.  Explicit morphology profiles are scaled as well as
    uniform ``total_length``/``total_mass`` configurations.
    """

    source = setup_from_config(cfg)
    target = similarity_scaled_setup(
        source,
        length_scale=length_scale,
        mass_scale=mass_scale,
    )
    length = float(length_scale)
    mass = float(mass_scale)
    time = float(np.sqrt(length))
    result = copy.deepcopy(cfg)
    env = result["env"]

    scalar_scales = {
        "total_length": length,
        "total_mass": mass,
        "cart_mass": mass,
        "rail_limit": length,
        "rail_limit_start": length,
        "rail_limit_end": length,
        "force_limit": mass,
        "timestep": time,
        "episode_seconds": time,
        "success_sustain_seconds": time,
        "cart_damping": mass / time,
        "cart_frictionloss": mass,
        "joint_armature": mass * length**2,
        "link_radius": length,
        "cart_half_length": length,
        "init_cart_noise": length,
        "init_cart_vel_noise": length / time,
        "init_vel_noise": 1.0 / time,
    }
    defaults = {
        "cart_half_length": source.cart_half_length,
        "link_radius": source.link_radius,
    }
    for key, scale in scalar_scales.items():
        if key in env:
            env[key] = float(env[key]) * scale
        elif key in defaults:
            env[key] = float(defaults[key]) * scale

    if isinstance(env.get("init_qpos"), list):
        env["init_qpos"] = [
            length * float(env["init_qpos"][0]),
            *[float(value) for value in env["init_qpos"][1:]],
        ]
    if isinstance(env.get("init_qvel"), list):
        env["init_qvel"] = [
            length / time * float(env["init_qvel"][0]),
            *[float(value) / time for value in env["init_qvel"][1:]],
        ]

    morphology = result["morphology"]
    profile_scales = {
        "lengths": length,
        "masses": mass,
        "damping": mass * length**2 / time,
        "frictionloss": mass * length,
        "joint_stiffness": mass * length,
    }
    for name, scale in profile_scales.items():
        for endpoint in ("start", "end"):
            key = f"{name}_{endpoint}"
            if isinstance(morphology.get(key), list):
                morphology[key] = [scale * float(value) for value in morphology[key]]
    for endpoint in ("start", "end"):
        values = morphology.get(endpoint)
        if not isinstance(values, dict):
            continue
        if "total_damping" in values:
            values["total_damping"] = (
                float(values["total_damping"]) * mass * length**2 / time
            )
        if "total_frictionloss" in values:
            values["total_frictionloss"] = (
                float(values["total_frictionloss"]) * mass * length
            )

    experiment = result.setdefault("experiment", {})
    experiment["name"] = (
        f"{experiment.get('name', 'cartpole')}_similar_"
        f"l{length_scale:g}_m{mass_scale:g}"
    )
    # Assert the public contract at construction time rather than silently
    # emitting a partially scaled plant when a new dimensional field is added.
    source_pi = dimensionless_setup(source)
    target_pi = dimensionless_setup(setup_from_config(result))
    scalar_names = (
        "cart_to_link_mass",
        "force_authority",
        "rail_ratio",
        "usable_rail_ratio",
        "cart_half_length_ratio",
        "link_radius_ratio",
        "policy_dt_ratio",
        "cart_damping_ratio",
        "joint_armature_ratio",
    )
    if not all(
        np.isclose(getattr(source_pi, name), getattr(target_pi, name), atol=1e-12)
        for name in scalar_names
    ) or not all(
        np.allclose(first, second, atol=1e-12)
        for first, second in (
            (source_pi.length_fractions, target_pi.length_fractions),
            (source_pi.mass_fractions, target_pi.mass_fractions),
            (source_pi.joint_damping_ratios, target_pi.joint_damping_ratios),
        )
    ):
        raise RuntimeError("similarity-scaled configuration changed dimensionless plant")
    # Keep the setup computation above live in optimized builds and make the
    # expected target explicit for callers inspecting this helper.
    if not np.isclose(target.chain_length, target_pi.chain_length):
        raise RuntimeError("similarity-scaled configuration changed target length")
    return result


def similarity_scaled_lqr_weights(
    weights: dict[str, float] | None,
    *,
    length_scale: float,
) -> dict[str, float]:
    """Preserve an upright LQR state cost under gravitational similarity.

    Physical state scales are ``x -> lambda*x``, ``xdot -> sqrt(lambda)*xdot``,
    ``theta -> theta``, and ``omega -> omega/sqrt(lambda)``.  The returned
    weights therefore induce the same dimensionless quadratic cost.  The
    normalized-action control cost is already dimensionless and is unchanged.
    """

    if not np.isfinite(length_scale) or float(length_scale) <= 0.0:
        raise ValueError("similarity length scale must be positive")
    result = dict(DEFAULT_UPRIGHT_LQR_WEIGHTS)
    if weights is not None:
        unknown = set(weights) - set(result)
        if unknown:
            raise ValueError(f"unknown upright LQR weights: {sorted(unknown)}")
        result.update({key: float(value) for key, value in weights.items()})
    if not all(np.isfinite(value) and value >= 0.0 for value in result.values()):
        raise ValueError("upright LQR weights must be finite and nonnegative")
    length = float(length_scale)
    result["cart_position"] /= length**2
    result["cart_velocity"] /= length
    result["absolute_angular_velocity"] *= length
    result["relative_angular_velocity"] *= length
    return result


def setup_from_config(cfg: dict[str, Any], *, progress: float = 1.0) -> PhysicalSetup:
    """Construct a physical setup using the repository's morphology builder."""

    from gcartpole.morphology import build_morphology

    env = cfg["env"]
    morphology = build_morphology(env, cfg["morphology"], progress=progress)
    return PhysicalSetup(
        lengths=morphology.lengths,
        masses=morphology.masses,
        cart_mass=float(env["cart_mass"]),
        rail_half_length=float(env["rail_limit"]),
        force_limit=float(env["force_limit"]),
        joint_damping=morphology.damping,
        cart_damping=float(env.get("cart_damping", 0.0)),
        joint_armature=float(env.get("joint_armature", 0.0)),
        cart_half_length=float(env.get("cart_half_length", 0.18)),
        link_radius=float(env.get("link_radius", 0.025)),
        timestep=float(env["timestep"]),
        frame_skip=int(env.get("frame_skip", 1)),
    )


def normalized_link_centers(lengths: np.ndarray | list[float]) -> np.ndarray:
    """Arc-length coordinates of link centers on the normalized chain [0, 1]."""

    lengths = _positive_vector("lengths", lengths)
    edges = np.r_[0.0, np.cumsum(lengths)] / float(np.sum(lengths))
    return 0.5 * (edges[:-1] + edges[1:])


def interpolation_matrix(source_points: np.ndarray, target_points: np.ndarray) -> np.ndarray:
    """Piecewise-linear interpolation with constant boundary extrapolation."""

    source = np.asarray(source_points, dtype=np.float64)
    target = np.asarray(target_points, dtype=np.float64)
    if source.ndim != 1 or target.ndim != 1 or source.size == 0 or target.size == 0:
        raise ValueError("source_points and target_points must be nonempty vectors")
    if np.any(np.diff(source) <= 0.0) or not np.all(np.isfinite(source)):
        raise ValueError("source_points must be finite and strictly increasing")
    if not np.all(np.isfinite(target)):
        raise ValueError("target_points must be finite")
    matrix = np.zeros((target.size, source.size), dtype=np.float64)
    for row, point in enumerate(target):
        if point <= source[0]:
            matrix[row, 0] = 1.0
        elif point >= source[-1]:
            matrix[row, -1] = 1.0
        else:
            right = int(np.searchsorted(source, point, side="right"))
            left = right - 1
            fraction = float((point - source[left]) / (source[right] - source[left]))
            matrix[row, left] = 1.0 - fraction
            matrix[row, right] = fraction
    return matrix


def _relative_to_absolute_matrix(n_links: int) -> np.ndarray:
    return np.tril(np.ones((n_links, n_links), dtype=np.float64))


def _absolute_to_relative_matrix(n_links: int) -> np.ndarray:
    result = np.eye(n_links, dtype=np.float64)
    if n_links > 1:
        result[1:, :-1] -= np.eye(n_links - 1, dtype=np.float64)
    return result


def state_transfer_matrix(source: PhysicalSetup, target: PhysicalSetup) -> np.ndarray:
    """Map a scale-normalized physical state from one morphology to another.

    MuJoCo state order is ``[x, relative_angles, xdot, hinge_rates]``.  Angular
    positions and rates are first converted into an absolute orientation field,
    interpolated by normalized arc length, and converted back to relative joints.
    """

    ns = source.n_links
    nt = target.n_links
    source_centers = normalized_link_centers(source.lengths)
    target_centers = normalized_link_centers(target.lengths)
    interpolate = interpolation_matrix(source_centers, target_centers)
    angular = (
        _absolute_to_relative_matrix(nt)
        @ interpolate
        @ _relative_to_absolute_matrix(ns)
    )
    result = np.zeros((2 * (nt + 1), 2 * (ns + 1)), dtype=np.float64)
    result[0, 0] = target.chain_length / source.chain_length
    result[1 : nt + 1, 1 : ns + 1] = angular
    source_velocity = ns + 1
    target_velocity = nt + 1
    result[target_velocity, source_velocity] = np.sqrt(
        target.chain_length / source.chain_length
    )
    result[target_velocity + 1 :, source_velocity + 1 :] = (
        np.sqrt(source.chain_length / target.chain_length) * angular
    )
    return result


def transfer_state(state: np.ndarray, source: PhysicalSetup, target: PhysicalSetup) -> np.ndarray:
    state = np.asarray(state, dtype=np.float64)
    expected = 2 * (source.n_links + 1)
    if state.shape != (expected,):
        raise ValueError(f"source state must have shape ({expected},)")
    return state_transfer_matrix(source, target) @ state


def force_action_scale(source: PhysicalSetup, target: PhysicalSetup) -> float:
    """Scale normalized actions to preserve force/(system weight)."""

    source_authority = dimensionless_setup(source).force_authority
    target_authority = dimensionless_setup(target).force_authority
    return float(source_authority / target_authority)


def transfer_feedback_gains(
    gains: np.ndarray, source: PhysicalSetup, target: PhysicalSetup
) -> np.ndarray:
    """Transfer source feedback to a target's state coordinates.

    The target state is projected back onto the source chain before the source
    gain is applied.  Gain magnitude is then adjusted for force authority.
    """

    gains = np.asarray(gains, dtype=np.float64)
    was_vector = gains.ndim == 1
    if was_vector:
        gains = gains[None, :]
    expected = 2 * (source.n_links + 1)
    if gains.ndim != 2 or gains.shape[1] != expected:
        raise ValueError(f"source gains must have {expected} columns")
    project_target_to_source = state_transfer_matrix(target, source)
    transferred = force_action_scale(source, target) * gains @ project_target_to_source
    return transferred.reshape(-1) if was_vector else transferred


def transfer_coordinate_states(
    states: np.ndarray,
    source: PhysicalSetup,
    target: PhysicalSetup,
    source_transform: np.ndarray,
    target_transform: np.ndarray,
) -> np.ndarray:
    """Transfer a trajectory expressed in arbitrary linear state coordinates."""

    states = np.asarray(states, dtype=np.float64)
    source_transform = np.asarray(source_transform, dtype=np.float64)
    target_transform = np.asarray(target_transform, dtype=np.float64)
    source_size = 2 * (source.n_links + 1)
    target_size = 2 * (target.n_links + 1)
    if states.ndim != 2 or states.shape[1] != source_size:
        raise ValueError(f"source states must have {source_size} columns")
    if source_transform.shape != (source_size, source_size):
        raise ValueError("source coordinate transform has the wrong shape")
    if target_transform.shape != (target_size, target_size):
        raise ValueError("target coordinate transform has the wrong shape")
    source_physical = np.linalg.solve(source_transform, states.T)
    target_physical = state_transfer_matrix(source, target) @ source_physical
    return (target_transform @ target_physical).T


def transfer_coordinate_feedback_gains(
    gains: np.ndarray,
    source: PhysicalSetup,
    target: PhysicalSetup,
    source_transform: np.ndarray,
    target_transform: np.ndarray,
) -> np.ndarray:
    """Transfer feedback gains between arbitrary linear state coordinates.

    If ``z_s=T_s x_s`` and ``z_t=T_t x_t``, the target error is projected as
    ``z_s=T_s P T_t^-1 z_t`` before the source law is applied.  Keeping these
    transforms explicit avoids treating normalized absolute-angle gains as if
    they acted directly on MuJoCo's relative-joint state.
    """

    gains = np.asarray(gains, dtype=np.float64)
    was_vector = gains.ndim == 1
    if was_vector:
        gains = gains[None, :]
    source_size = 2 * (source.n_links + 1)
    target_size = 2 * (target.n_links + 1)
    source_transform = np.asarray(source_transform, dtype=np.float64)
    target_transform = np.asarray(target_transform, dtype=np.float64)
    if gains.ndim != 2 or gains.shape[1] != source_size:
        raise ValueError(f"source gains must have {source_size} columns")
    if source_transform.shape != (source_size, source_size):
        raise ValueError("source coordinate transform has the wrong shape")
    if target_transform.shape != (target_size, target_size):
        raise ValueError("target coordinate transform has the wrong shape")
    physical_projection = state_transfer_matrix(target, source)
    coordinate_projection = (
        source_transform @ physical_projection @ np.linalg.inv(target_transform)
    )
    transferred = force_action_scale(source, target) * gains @ coordinate_projection
    return transferred.reshape(-1) if was_vector else transferred


def resample_controls(
    controls: np.ndarray,
    source: PhysicalSetup,
    target: PhysicalSetup,
    *,
    target_steps: int | None = None,
) -> np.ndarray:
    """Resample a force sequence on the natural-time clock of the target."""

    controls = np.asarray(controls, dtype=np.float64)
    if controls.ndim != 1 or controls.size == 0 or not np.all(np.isfinite(controls)):
        raise ValueError("controls must be a nonempty finite vector")
    dimensionless_duration = controls.size * source.policy_dt / source.natural_time
    if target_steps is None:
        target_steps = max(
            1,
            round(dimensionless_duration * target.natural_time / target.policy_dt),
        )
    if target_steps < 1:
        raise ValueError("target_steps must be positive")
    source_tau = (np.arange(controls.size, dtype=np.float64) + 0.5) * (
        source.policy_dt / source.natural_time
    )
    target_tau = (np.arange(target_steps, dtype=np.float64) + 0.5) * (
        target.policy_dt / target.natural_time
    )
    result = np.interp(target_tau, source_tau, controls, left=controls[0], right=controls[-1])
    return np.clip(force_action_scale(source, target) * result, -1.0, 1.0)


def rail_requirement(
    cart_positions: np.ndarray,
    setup: PhysicalSetup,
    *,
    clearance: float = 0.0,
) -> dict[str, float]:
    """Measure trajectory rail demand in physical and chain-normalized units."""

    positions = np.asarray(cart_positions, dtype=np.float64)
    if positions.size == 0 or not np.all(np.isfinite(positions)):
        raise ValueError("cart_positions must contain finite values")
    if not np.isfinite(clearance) or clearance < 0.0:
        raise ValueError("clearance must be finite and nonnegative")
    center_excursion = float(np.max(np.abs(positions)))
    required_half_length = center_excursion + setup.cart_half_length + float(clearance)
    return {
        "max_cart_center_excursion": center_excursion,
        "required_rail_half_length": required_half_length,
        "required_rail_ratio": required_half_length / setup.chain_length,
        "configured_rail_ratio": setup.rail_half_length / setup.chain_length,
        "margin": setup.rail_half_length - required_half_length,
    }


def mirror_feedback_route(
    controls: np.ndarray,
    coordinate_states: np.ndarray,
    feedback_gains: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Reflect a planar feedback route through the cart origin.

    The dynamics are invariant under ``(q, qdot, u) -> (-q, -qdot, -u)``.
    The gain itself is unchanged because both the live and nominal state errors
    reverse sign.
    """

    actions = np.asarray(controls, dtype=np.float64)
    states = np.asarray(coordinate_states, dtype=np.float64)
    gains = np.asarray(feedback_gains, dtype=np.float64)
    if actions.ndim != 1:
        raise ValueError("controls must be one-dimensional")
    if states.ndim != 2 or states.shape[0] != actions.size + 1:
        raise ValueError("coordinate_states must contain one state per boundary")
    if gains.shape != (actions.size, states.shape[1]):
        raise ValueError("feedback_gains do not match the route dimensions")
    return -actions.copy(), -states.copy(), gains.copy()


@dataclass
class BoundedForceAdapter:
    """Projected RLS calibration for force gain and bias mismatch.

    The exact nominal model supplies its local action Jacobian ``B``.  After an
    observed transition, the model error is projected onto ``B`` to estimate the
    equivalent action actually delivered.  A two-parameter recursive least
    squares fit tracks ``u_equivalent = gain*u_command + bias``.  Projection and
    bounds keep this layer conservative; structural mismatch remains the job of
    receding-horizon replanning.
    """

    forgetting: float = 0.995
    covariance: float = 10.0
    gain_bounds: tuple[float, float] = (0.5, 1.5)
    bias_bound: float = 0.25
    correction_bound: float = 0.35
    projection_floor: float = 1e-10
    command_update_limit: float = 0.85
    structural_fraction_limit: float = 0.50
    equivalent_delta_limit: float = 0.75

    def __post_init__(self) -> None:
        if not 0.0 < self.forgetting <= 1.0:
            raise ValueError("forgetting must lie in (0, 1]")
        if self.covariance <= 0.0:
            raise ValueError("covariance must be positive")
        if self.gain_bounds[0] <= 0.0 or self.gain_bounds[0] > self.gain_bounds[1]:
            raise ValueError("gain_bounds must be ordered and positive")
        if self.bias_bound < 0.0 or self.correction_bound < 0.0:
            raise ValueError("adapter bounds must be nonnegative")
        if not 0.0 < self.command_update_limit <= 1.0:
            raise ValueError("command_update_limit must lie in (0, 1]")
        if not 0.0 <= self.structural_fraction_limit <= 1.0:
            raise ValueError("structural_fraction_limit must lie in [0, 1]")
        if self.equivalent_delta_limit <= 0.0:
            raise ValueError("equivalent_delta_limit must be positive")
        self.theta = np.array([1.0, 0.0], dtype=np.float64)
        self.P = float(self.covariance) * np.eye(2, dtype=np.float64)
        self.updates = 0
        self.rejections = 0
        self.last_observation: dict[str, float | bool | str] | None = None

    @property
    def gain(self) -> float:
        return float(self.theta[0])

    @property
    def bias(self) -> float:
        return float(self.theta[1])

    def command(self, nominal_action: float) -> float:
        desired = float(np.clip(nominal_action, -1.0, 1.0))
        compensated = (desired - self.bias) / self.gain
        correction = float(np.clip(compensated - desired, -self.correction_bound, self.correction_bound))
        return float(np.clip(desired + correction, -1.0, 1.0))

    def observe(
        self,
        commanded_action: float,
        predicted_next_state: np.ndarray,
        observed_next_state: np.ndarray,
        action_jacobian: np.ndarray,
    ) -> bool:
        return bool(
            self.observe_diagnostic(
                commanded_action,
                predicted_next_state,
                observed_next_state,
                action_jacobian,
            )["updated"]
        )

    def observe_diagnostic(
        self,
        commanded_action: float,
        predicted_next_state: np.ndarray,
        observed_next_state: np.ndarray,
        action_jacobian: np.ndarray,
    ) -> dict[str, float | bool | str]:
        """Project one-step error onto actuation and conditionally update RLS.

        State vectors and the action Jacobian should use the same dimensionless
        coordinates.  Updates are rejected when the command is too close to
        saturation, when the inferred action jump is implausibly large, or when
        too much model error lies orthogonal to the action direction.  The last
        condition is the explicit boundary between this narrow calibration
        layer and structural mismatch that requires model correction/replanning.
        """

        predicted = np.asarray(predicted_next_state, dtype=np.float64)
        observed = np.asarray(observed_next_state, dtype=np.float64)
        jacobian = np.asarray(action_jacobian, dtype=np.float64).reshape(-1)
        if predicted.shape != observed.shape or predicted.shape != jacobian.shape:
            raise ValueError("predicted, observed, and action_jacobian shapes must match")
        denominator = float(jacobian @ jacobian)
        if denominator <= self.projection_floor or not np.isfinite(denominator):
            diagnostic: dict[str, float | bool | str] = {
                "updated": False,
                "reason": "unobservable_action_direction",
                "commanded_action": float(commanded_action),
                "equivalent_action_delta": 0.0,
                "structural_fraction": 1.0,
                "innovation_norm": float(np.linalg.norm(observed - predicted)),
            }
            self.rejections += 1
            self.last_observation = diagnostic
            return diagnostic
        innovation = observed - predicted
        equivalent_delta = float(jacobian @ innovation / denominator)
        projected = equivalent_delta * jacobian
        innovation_norm = float(np.linalg.norm(innovation))
        orthogonal_norm = float(np.linalg.norm(innovation - projected))
        structural_fraction = (
            orthogonal_norm / innovation_norm
            if innovation_norm > self.projection_floor
            else 0.0
        )
        equivalent_action = float(commanded_action) + equivalent_delta
        reason = "accepted"
        if abs(float(commanded_action)) > self.command_update_limit:
            reason = "command_near_saturation"
        elif abs(equivalent_delta) > self.equivalent_delta_limit:
            reason = "action_innovation_out_of_bounds"
        elif structural_fraction > self.structural_fraction_limit:
            reason = "structural_mismatch"
        diagnostic = {
            "updated": reason == "accepted",
            "reason": reason,
            "commanded_action": float(commanded_action),
            "equivalent_action": equivalent_action,
            "equivalent_action_delta": equivalent_delta,
            "structural_fraction": structural_fraction,
            "innovation_norm": innovation_norm,
            "orthogonal_innovation_norm": orthogonal_norm,
        }
        if reason != "accepted":
            self.rejections += 1
            self.last_observation = diagnostic
            return diagnostic
        feature = np.array([float(commanded_action), 1.0], dtype=np.float64)
        p_feature = self.P @ feature
        denominator_rls = self.forgetting + float(feature @ p_feature)
        kalman = p_feature / denominator_rls
        self.theta += kalman * (equivalent_action - float(feature @ self.theta))
        self.P = (self.P - np.outer(kalman, feature) @ self.P) / self.forgetting
        self.theta[0] = np.clip(self.theta[0], *self.gain_bounds)
        self.theta[1] = np.clip(self.theta[1], -self.bias_bound, self.bias_bound)
        self.updates += 1
        self.last_observation = diagnostic
        return diagnostic

    def to_dict(self) -> dict[str, float | int]:
        return {
            "gain": self.gain,
            "bias": self.bias,
            "updates": self.updates,
            "rejections": self.rejections,
            "covariance_trace": float(np.trace(self.P)),
        }


@dataclass(frozen=True)
class SplitEmbedding:
    """Fixed-count representation of a smaller chain by locked link splits.

    ``segment_source_links`` assigns every target-count segment to one source
    link.  Consecutive segments with the same assignment are parts of one
    rigid source link, so the later segment's joint is locked at the embedded
    endpoint.  Length and mass totals are scaled to the target plant while the
    source dimensionless distributions are preserved.
    """

    source_lengths: np.ndarray
    source_masses: np.ndarray
    target_lengths: np.ndarray
    target_masses: np.ndarray
    segment_source_links: np.ndarray
    source_joint_locks: np.ndarray
    target_joint_locks: np.ndarray
    split_counts: np.ndarray
    morphology_cost: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_lengths": self.source_lengths.astype(float).tolist(),
            "source_masses": self.source_masses.astype(float).tolist(),
            "target_lengths": self.target_lengths.astype(float).tolist(),
            "target_masses": self.target_masses.astype(float).tolist(),
            "segment_source_links": self.segment_source_links.astype(int).tolist(),
            "source_joint_locks": self.source_joint_locks.astype(float).tolist(),
            "target_joint_locks": self.target_joint_locks.astype(float).tolist(),
            "split_counts": self.split_counts.astype(int).tolist(),
            "morphology_cost": float(self.morphology_cost),
        }


def _split_block(
    source_length_fraction: float,
    source_mass_fraction: float,
    target_length_fractions: np.ndarray,
    target_mass_fractions: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, float]:
    """Fit one rigid source link to a consecutive target-segment block."""

    length_share = target_length_fractions / float(np.sum(target_length_fractions))
    embedded_lengths = source_length_fraction * length_share
    # Preserve the source link's uniform linear density inside the rigid split.
    embedded_masses = source_mass_fraction * length_share
    length_residual = (embedded_lengths - target_length_fractions) / np.sqrt(
        target_length_fractions
    )
    mass_residual = (embedded_masses - target_mass_fractions) / np.sqrt(
        target_mass_fractions
    )
    cost = float(length_residual @ length_residual + mass_residual @ mass_residual)
    return embedded_lengths, embedded_masses, cost


def split_embedding(
    source_lengths: np.ndarray | list[float],
    source_masses: np.ndarray | list[float],
    target_lengths: np.ndarray | list[float],
    target_masses: np.ndarray | list[float],
) -> SplitEmbedding:
    """Embed a lower-count morphology in a target-count chain deterministically.

    Dynamic programming assigns consecutive target segments to source links.
    Each source link is divided in proportion to the target lengths in its
    assigned block, and mass follows length so the locked pieces retain the
    source link's linear density.  The objective is dimensionless and jointly
    minimizes length- and mass-profile mismatch.  Equal-cost ties defer extra
    splits distally, preserving proximal dynamics as long as possible.
    """

    source_l = _positive_vector("source_lengths", source_lengths)
    source_m = _positive_vector("source_masses", source_masses)
    target_l = _positive_vector("target_lengths", target_lengths)
    target_m = _positive_vector("target_masses", target_masses)
    if source_l.shape != source_m.shape or target_l.shape != target_m.shape:
        raise ValueError("each morphology must have matching length and mass shapes")
    source_count = int(source_l.size)
    target_count = int(target_l.size)
    if target_count < source_count:
        raise ValueError("split embedding requires target count >= source count")

    source_lf = source_l / float(np.sum(source_l))
    source_mf = source_m / float(np.sum(source_m))
    target_lf = target_l / float(np.sum(target_l))
    target_mf = target_m / float(np.sum(target_m))
    costs = np.full((source_count + 1, target_count + 1), np.inf)
    previous = np.full((source_count + 1, target_count + 1), -1, dtype=np.int64)
    costs[0, 0] = 0.0
    tolerance = 1.0e-14
    for source_index in range(1, source_count + 1):
        minimum_end = source_index
        maximum_end = target_count - (source_count - source_index)
        for end in range(minimum_end, maximum_end + 1):
            maximum_block = end - (source_index - 1)
            for block_size in range(maximum_block, 0, -1):
                start = end - block_size
                prefix_cost = costs[source_index - 1, start]
                if not np.isfinite(prefix_cost):
                    continue
                _, _, block_cost = _split_block(
                    float(source_lf[source_index - 1]),
                    float(source_mf[source_index - 1]),
                    target_lf[start:end],
                    target_mf[start:end],
                )
                candidate = float(prefix_cost + block_cost)
                # Larger terminal blocks are visited first.  Not replacing an
                # equal candidate therefore pushes surplus splits distally.
                if candidate < costs[source_index, end] - tolerance:
                    costs[source_index, end] = candidate
                    previous[source_index, end] = start

    assignments = np.empty(target_count, dtype=np.int64)
    split_counts = np.empty(source_count, dtype=np.int64)
    end = target_count
    for source_index in range(source_count, 0, -1):
        start = int(previous[source_index, end])
        if start < 0:
            raise RuntimeError("failed to construct a monotone split embedding")
        assignments[start:end] = source_index - 1
        split_counts[source_index - 1] = end - start
        end = start

    embedded_lf = np.empty(target_count, dtype=np.float64)
    embedded_mf = np.empty(target_count, dtype=np.float64)
    for source_index in range(source_count):
        indices = np.flatnonzero(assignments == source_index)
        block_l, block_m, _ = _split_block(
            float(source_lf[source_index]),
            float(source_mf[source_index]),
            target_lf[indices],
            target_mf[indices],
        )
        embedded_lf[indices] = block_l
        embedded_mf[indices] = block_m

    locks = np.zeros(target_count, dtype=np.float64)
    locks[1:] = (assignments[1:] == assignments[:-1]).astype(np.float64)
    return SplitEmbedding(
        source_lengths=embedded_lf * float(np.sum(target_l)),
        source_masses=embedded_mf * float(np.sum(target_m)),
        target_lengths=target_l.copy(),
        target_masses=target_m.copy(),
        segment_source_links=assignments,
        source_joint_locks=locks,
        target_joint_locks=np.zeros(target_count, dtype=np.float64),
        split_counts=split_counts,
        morphology_cost=float(costs[source_count, target_count]),
    )


def split_joint_profile(
    source_values: np.ndarray | list[float],
    segment_source_links: np.ndarray | list[int],
    *,
    internal_value: float = 0.0,
) -> np.ndarray:
    """Lift per-joint values, assigning split-internal joints explicitly."""

    values = np.asarray(source_values, dtype=np.float64)
    assignments = np.asarray(segment_source_links, dtype=np.int64)
    if values.ndim != 1 or values.size == 0 or not np.all(np.isfinite(values)):
        raise ValueError("source_values must be a nonempty finite vector")
    if assignments.ndim != 1 or assignments.size < values.size:
        raise ValueError("segment_source_links has an invalid shape")
    if not np.isfinite(internal_value):
        raise ValueError("internal_value must be finite")
    if assignments[0] != 0 or assignments[-1] != values.size - 1:
        raise ValueError("segment assignments must cover every source link in order")
    if np.any(np.diff(assignments) < 0) or np.any(np.diff(assignments) > 1):
        raise ValueError("segment assignments must be contiguous and monotone")
    result = np.full(assignments.size, float(internal_value), dtype=np.float64)
    starts = np.r_[True, assignments[1:] != assignments[:-1]]
    result[starts] = values[assignments[starts]]
    return result


def split_state_lift_matrix(
    source_count: int,
    segment_source_links: np.ndarray | list[int],
    *,
    length_scale: float = 1.0,
) -> np.ndarray:
    """Lift physical states into a split-link coordinate space.

    State order is ``[x, relative angles, xdot, hinge rates]``.  Original joint
    coordinates are copied to the first piece of their source link; inserted
    split joints start at exactly zero.  Global dynamic-similarity scaling is
    applied to cart position and all velocities.
    """

    assignments = np.asarray(segment_source_links, dtype=np.int64)
    if source_count < 1 or assignments.ndim != 1 or assignments.size < source_count:
        raise ValueError("source_count and segment assignments are inconsistent")
    if assignments[0] != 0 or assignments[-1] != source_count - 1:
        raise ValueError("segment assignments must cover every source link")
    if np.any(np.diff(assignments) < 0) or np.any(np.diff(assignments) > 1):
        raise ValueError("segment assignments must be contiguous and monotone")
    if not np.isfinite(length_scale) or length_scale <= 0.0:
        raise ValueError("length_scale must be finite and positive")
    target_count = int(assignments.size)
    source_d = source_count + 1
    target_d = target_count + 1
    matrix = np.zeros((2 * target_d, 2 * source_d), dtype=np.float64)
    matrix[0, 0] = float(length_scale)
    matrix[target_d, source_d] = float(np.sqrt(length_scale))
    rate_scale = float(1.0 / np.sqrt(length_scale))
    starts = np.r_[True, assignments[1:] != assignments[:-1]]
    for segment in np.flatnonzero(starts):
        source_link = int(assignments[segment])
        matrix[1 + segment, 1 + source_link] = 1.0
        matrix[target_d + 1 + segment, source_d + 1 + source_link] = rate_scale
    return matrix


def split_absolute_coordinate_lift_matrix(
    source_count: int,
    segment_source_links: np.ndarray | list[int],
    *,
    length_scale: float = 1.0,
) -> np.ndarray:
    """Lift ``[x, absolute angles, xdot, hinge rates]`` route coordinates."""

    assignments = np.asarray(segment_source_links, dtype=np.int64)
    physical = split_state_lift_matrix(
        source_count,
        assignments,
        length_scale=length_scale,
    )
    target_count = int(assignments.size)
    source_d = source_count + 1
    target_d = target_count + 1
    matrix = physical.copy()
    matrix[1:target_d, 1:source_d] = 0.0
    for segment, source_link in enumerate(assignments):
        matrix[1 + segment, 1 + int(source_link)] = 1.0
    return matrix


def split_state_projection(
    lift_matrix: np.ndarray,
    segment_length_fractions: np.ndarray | list[float],
) -> np.ndarray:
    """Return a length-weighted left inverse for a split-state lift matrix."""

    lift = np.asarray(lift_matrix, dtype=np.float64)
    fractions = _positive_vector("segment_length_fractions", segment_length_fractions)
    if lift.ndim != 2 or lift.shape[0] != 2 * (fractions.size + 1):
        raise ValueError("lift matrix does not match segment length fractions")
    weights = np.ones(lift.shape[0], dtype=np.float64)
    weights[1 : fractions.size + 1] = fractions
    weighted_lift = weights[:, None] * lift
    gram = lift.T @ weighted_lift
    if np.linalg.matrix_rank(gram) != gram.shape[0]:
        raise ValueError("lift matrix must have full column rank")
    return np.linalg.solve(gram, lift.T * weights[None, :])


def embed_morphology(
    lengths: np.ndarray | list[float],
    masses: np.ndarray | list[float],
    target_count: int,
    *,
    ghost_length: float = 0.02,
    ghost_mass: float = 1e-4,
) -> tuple[np.ndarray, np.ndarray]:
    """Embed a chain in a larger coordinate space using distal ghost links.

    Total length and mass are conserved by taking each ghost's small positive
    amount from the last real link.  Adjacent link-count continuation can then
    remain in one fixed-dimensional MuJoCo model until the final projection.
    """

    source_lengths = _positive_vector("lengths", lengths)
    source_masses = _positive_vector("masses", masses)
    if source_lengths.shape != source_masses.shape:
        raise ValueError("lengths and masses must have the same shape")
    if target_count < source_lengths.size:
        raise ValueError("target_count cannot be smaller than the source count")
    extra = int(target_count - source_lengths.size)
    if extra == 0:
        return source_lengths.copy(), source_masses.copy()
    if min(ghost_length, ghost_mass) <= 0.0:
        raise ValueError("ghost dimensions must be positive")
    length_taken = extra * float(ghost_length)
    mass_taken = extra * float(ghost_mass)
    if source_lengths[-1] <= length_taken or source_masses[-1] <= mass_taken:
        raise ValueError("last source link is too small to create requested ghosts")
    embedded_lengths = np.r_[
        source_lengths[:-1], source_lengths[-1] - length_taken, np.full(extra, ghost_length)
    ]
    embedded_masses = np.r_[
        source_masses[:-1], source_masses[-1] - mass_taken, np.full(extra, ghost_mass)
    ]
    return embedded_lengths, embedded_masses


def common_count_morphologies(
    source_lengths: np.ndarray | list[float],
    source_masses: np.ndarray | list[float],
    target_lengths: np.ndarray | list[float],
    target_masses: np.ndarray | list[float],
    *,
    ghost_length: float = 0.02,
    ghost_mass: float = 1e-4,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Embed two morphologies into a common count for smooth homotopy."""

    source_lengths = _positive_vector("source_lengths", source_lengths)
    source_masses = _positive_vector("source_masses", source_masses)
    target_lengths = _positive_vector("target_lengths", target_lengths)
    target_masses = _positive_vector("target_masses", target_masses)
    count = max(source_lengths.size, target_lengths.size)
    source_l, source_m = embed_morphology(
        source_lengths, source_masses, count,
        ghost_length=ghost_length, ghost_mass=ghost_mass,
    )
    target_l, target_m = embed_morphology(
        target_lengths, target_masses, count,
        ghost_length=ghost_length, ghost_mass=ghost_mass,
    )
    if not np.isclose(np.sum(source_l), np.sum(target_l)):
        raise ValueError("source and target total lengths must match")
    if not np.isclose(np.sum(source_m), np.sum(target_m)):
        raise ValueError("source and target total link masses must match")
    return source_l, source_m, target_l, target_m


def homotopy_morphology(
    source_lengths: np.ndarray | list[float],
    source_masses: np.ndarray | list[float],
    target_lengths: np.ndarray | list[float],
    target_masses: np.ndarray | list[float],
    progress: float,
    *,
    ghost_length: float = 0.02,
    ghost_mass: float = 1e-4,
) -> tuple[np.ndarray, np.ndarray]:
    """Interpolate arbitrary source/target chains in a common link space."""

    if not 0.0 <= progress <= 1.0:
        raise ValueError("progress must lie in [0, 1]")
    source_l, source_m, target_l, target_m = common_count_morphologies(
        source_lengths,
        source_masses,
        target_lengths,
        target_masses,
        ghost_length=ghost_length,
        ghost_mass=ghost_mass,
    )
    return (
        (1.0 - progress) * source_l + progress * target_l,
        (1.0 - progress) * source_m + progress * target_m,
    )


@dataclass
class AdaptiveHomotopy:
    """Deterministic accept/grow, reject/bisect continuation schedule.

    A rejected proposal is a known local upper boundary for the current route
    branch.  Intermediate accepts may improve the warm start, but the next
    proposal must revisit that boundary before advancing beyond it.
    """

    progress: float = 0.0
    step: float = 0.001
    minimum_step: float = 1e-5
    maximum_step: float = 0.10
    growth: float = 1.6
    failed_upper_bound: float | None = None
    failed_upper_bounds: tuple[float, ...] = ()

    def __post_init__(self) -> None:
        if not 0.0 <= self.progress <= 1.0:
            raise ValueError("progress must lie in [0, 1]")
        if not 0.0 < self.minimum_step <= self.step <= self.maximum_step:
            raise ValueError("step bounds must be positive and ordered")
        if self.growth <= 1.0:
            raise ValueError("growth must exceed one")
        bounds = list(self.failed_upper_bounds)
        if self.failed_upper_bound is not None:
            bounds.append(float(self.failed_upper_bound))
        if any(not self.progress < bound <= 1.0 for bound in bounds):
            raise ValueError("failed upper bounds must lie ahead of progress")
        self._set_failed_upper_bounds(bounds)

    def _set_failed_upper_bounds(self, bounds: list[float]) -> None:
        unique: list[float] = []
        for bound in sorted(float(value) for value in bounds):
            if not unique or not np.isclose(bound, unique[-1]):
                unique.append(bound)
        self.failed_upper_bounds = tuple(unique)
        self.failed_upper_bound = unique[0] if unique else None

    def proposal(self) -> float:
        upper = 1.0 if self.failed_upper_bound is None else self.failed_upper_bound
        return float(min(upper, self.progress + self.step))

    def accept(self, proposed: float) -> None:
        if proposed <= self.progress or proposed > 1.0:
            raise ValueError("accepted progress must advance within [0, 1]")
        if (
            self.failed_upper_bound is not None
            and proposed > self.failed_upper_bound
            and not np.isclose(proposed, self.failed_upper_bound)
        ):
            raise ValueError("accepted progress cannot cross a failed upper bound")
        self.progress = float(proposed)
        self._set_failed_upper_bounds(
            [
                bound
                for bound in self.failed_upper_bounds
                if bound > proposed and not np.isclose(bound, proposed)
            ]
        )
        next_step = min(self.maximum_step, self.step * self.growth)
        if self.failed_upper_bound is not None:
            next_step = min(next_step, self.failed_upper_bound - self.progress)
        self.step = float(next_step)

    def reject(self, proposed: float | None = None) -> None:
        rejected = self.proposal() if proposed is None else float(proposed)
        if rejected <= self.progress or rejected > 1.0:
            raise ValueError("rejected progress must lie ahead within [0, 1]")
        self._set_failed_upper_bounds([*self.failed_upper_bounds, rejected])
        next_step = (rejected - self.progress) / 2.0
        if next_step < self.minimum_step:
            raise RuntimeError("homotopy step fell below minimum_step")
        self.step = float(next_step)


def recover_homotopy_failed_upper_bounds(
    trials: list[dict[str, Any]],
    *,
    proposal_key: str = "proposed_progress",
) -> tuple[float, ...]:
    """Reconstruct nested failed boundaries from an older continuation ledger."""

    bounds: list[float] = []
    for trial in trials:
        if proposal_key not in trial:
            continue
        proposed = float(trial[proposal_key])
        if trial.get("accepted"):
            bounds = [
                bound
                for bound in bounds
                if bound > proposed and not np.isclose(bound, proposed)
            ]
        elif not any(np.isclose(proposed, bound) for bound in bounds):
            bounds.append(proposed)
            bounds.sort()
    return tuple(bounds)
