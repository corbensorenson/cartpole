from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

import mujoco
import numpy as np

from gcartpole.env import NLinkCartPoleEnv, wrap_angle
from gcartpole.simulation import advance_checked

Array = np.ndarray


@dataclass(frozen=True)
class QuadraticTrajectoryCost:
    stage_state: Array
    terminal_state: Array
    control: float
    rail_soft_limit: float
    rail_limit: float
    rail_weight: float
    wrap_angles: bool = True
    terminal_target: Array | None = None
    stage_target: Array | None = None
    terminal_factor: Array | None = None
    stage_factor: Array | None = None


@dataclass(frozen=True)
class ILQRResult:
    controls: Array
    states: Array
    feedback_gains: Array
    cost: float
    iterations: int
    converged: bool
    active_control_steps: int
    history: list[dict[str, float | int | bool]]


def add_terminal_cart_weights(
    metric: Array,
    n_links: int,
    *,
    cart_weight: float = 0.0,
    cart_velocity_weight: float = 0.0,
) -> Array:
    """Add cart-specific weights in [qpos, qvel] coordinate order."""
    metric = np.asarray(metric, dtype=np.float64)
    expected_size = 2 * (int(n_links) + 1)
    if metric.shape != (expected_size, expected_size):
        raise ValueError("terminal metric shape does not match link count")
    if min(cart_weight, cart_velocity_weight) < 0.0:
        raise ValueError("terminal cart weights must be nonnegative")
    weighted = metric.copy()
    weighted[0, 0] += float(cart_weight)
    cart_velocity_index = int(n_links) + 1
    weighted[cart_velocity_index, cart_velocity_index] += float(cart_velocity_weight)
    return weighted


def stitch_feedback_trajectories(
    first_controls: Array,
    first_states: Array,
    first_feedback_gains: Array,
    second_controls: Array,
    second_states: Array,
    second_feedback_gains: Array,
    *,
    boundary_tolerance: float = 1e-8,
) -> tuple[Array, Array, Array]:
    """Join two feedback trajectories without introducing a state reset."""
    first_controls = np.asarray(first_controls, dtype=np.float64)
    second_controls = np.asarray(second_controls, dtype=np.float64)
    first_states = np.asarray(first_states, dtype=np.float64)
    second_states = np.asarray(second_states, dtype=np.float64)
    first_feedback_gains = np.asarray(first_feedback_gains, dtype=np.float64)
    second_feedback_gains = np.asarray(second_feedback_gains, dtype=np.float64)
    if first_controls.ndim != 1 or second_controls.ndim != 1:
        raise ValueError("controls must be one-dimensional")
    if first_states.ndim != 2 or second_states.ndim != 2:
        raise ValueError("states must be two-dimensional")
    if first_states.shape[0] != first_controls.size + 1:
        raise ValueError("first trajectory must have one more state than control")
    if second_states.shape[0] != second_controls.size + 1:
        raise ValueError("second trajectory must have one more state than control")
    if first_states.shape[1] != second_states.shape[1]:
        raise ValueError("trajectory state dimensions do not match")
    expected_first_gain_shape = (first_controls.size, first_states.shape[1])
    expected_second_gain_shape = (second_controls.size, second_states.shape[1])
    if first_feedback_gains.shape != expected_first_gain_shape:
        raise ValueError("first feedback-gain dimensions do not match its trajectory")
    if second_feedback_gains.shape != expected_second_gain_shape:
        raise ValueError("second feedback-gain dimensions do not match its trajectory")
    boundary_error = float(np.linalg.norm(first_states[-1] - second_states[0]))
    if boundary_error > boundary_tolerance:
        raise ValueError(
            f"trajectory boundary differs by {boundary_error:.3e}, "
            f"above tolerance {boundary_tolerance:.3e}"
        )
    return (
        np.concatenate((first_controls, second_controls)),
        np.vstack((first_states[:-1], second_states)),
        np.vstack((first_feedback_gains, second_feedback_gains)),
    )


def state_difference(first: Array, second: Array, n_links: int) -> Array:
    delta = np.asarray(first, dtype=np.float64) - np.asarray(second, dtype=np.float64)
    delta = delta.copy()
    delta[1 : n_links + 1] = wrap_angle(delta[1 : n_links + 1])
    return delta


def wrapped_state(state: Array, n_links: int) -> Array:
    result = np.asarray(state, dtype=np.float64).copy()
    result[1 : n_links + 1] = wrap_angle(result[1 : n_links + 1])
    return result


def data_state(data: mujoco.MjData) -> Array:
    return np.r_[
        np.asarray(data.qpos, dtype=np.float64),
        np.asarray(data.qvel, dtype=np.float64),
    ]


class MujocoTransition:
    def __init__(
        self,
        env: NLinkCartPoleEnv,
        coordinate_transform: Array | None = None,
        *,
        continuous_angles: bool = False,
    ) -> None:
        self.env = env
        self.continuous_angles = bool(continuous_angles)
        self.evaluations = 0
        self.data = mujoco.MjData(env.model)
        self.nx = int(env.model.nq + env.model.nv)
        self.coordinate_transform = (
            None
            if coordinate_transform is None
            else np.asarray(coordinate_transform, dtype=np.float64)
        )
        if self.coordinate_transform is not None and self.coordinate_transform.shape != (
            self.nx,
            self.nx,
        ):
            raise ValueError("coordinate transform does not match MuJoCo state dimension")
        self.inverse_transform = (
            None
            if self.coordinate_transform is None
            else np.linalg.inv(self.coordinate_transform)
        )

    def to_coordinates(self, physical_state: Array) -> Array:
        physical = (
            np.asarray(physical_state, dtype=np.float64).copy()
            if self.continuous_angles
            else wrapped_state(physical_state, self.env.n)
        )
        if self.coordinate_transform is None:
            return physical
        return self.coordinate_transform @ physical

    def to_physical(self, coordinate_state: Array) -> Array:
        coordinates = np.asarray(coordinate_state, dtype=np.float64)
        if self.inverse_transform is None:
            return coordinates.copy()
        return self.inverse_transform @ coordinates

    def difference(self, first: Array, second: Array) -> Array:
        if self.continuous_angles:
            return np.asarray(first, dtype=np.float64) - np.asarray(second, dtype=np.float64)
        if self.coordinate_transform is None:
            return state_difference(first, second, self.env.n)
        physical_first = self.to_physical(first)
        physical_second = self.to_physical(second)
        physical_delta = state_difference(
            physical_first,
            physical_second,
            self.env.n,
        )
        return self.coordinate_transform @ physical_delta

    def __call__(self, state: Array, action: float) -> Array:
        self.evaluations += 1
        state = self.to_physical(state)
        nq = int(self.env.model.nq)
        policy_action = float(np.clip(np.asarray(action, dtype=np.float32), -1.0, 1.0))
        mujoco.mj_resetData(self.env.model, self.data)
        self.data.qpos[:] = state[:nq]
        self.data.qvel[:] = state[nq:]
        self.data.ctrl[0] = policy_action * self.env.force_limit
        mujoco.mj_forward(self.env.model, self.data)
        advance_checked(self.env.model, self.data, self.env.frame_skip)
        return self.to_coordinates(data_state(self.data))

    def linearize(
        self,
        state: Array,
        action: float,
        *,
        state_epsilon: float,
        action_epsilon: float,
    ) -> tuple[Array, Array]:
        state = np.asarray(state, dtype=np.float64)
        a = np.empty((self.nx, self.nx), dtype=np.float64)
        for column in range(self.nx):
            offset = np.zeros(self.nx, dtype=np.float64)
            offset[column] = state_epsilon
            plus = self(state + offset, action)
            minus = self(state - offset, action)
            a[:, column] = self.difference(plus, minus) / (2.0 * state_epsilon)
        upper = min(1.0, action + action_epsilon)
        lower = max(-1.0, action - action_epsilon)
        plus = self(state, upper)
        minus = self(state, lower)
        # The policy interface applies float32 actions. Measure this secant
        # in the action units actually delivered to the plant, rather than
        # dividing by an ideal increment that may differ after quantization.
        denominator = float(np.float32(upper)) - float(np.float32(lower))
        if denominator <= 0:
            raise ValueError("action difference vanished at the applied action precision")
        b = (self.difference(plus, minus) / denominator)[:, None]
        return a, b


def _rail_cost_derivatives(x: float, cost: QuadraticTrajectoryCost) -> tuple[float, float, float]:
    distance = abs(float(x)) - cost.rail_soft_limit
    if distance <= 0.0:
        return 0.0, 0.0, 0.0
    width = max(1e-9, cost.rail_limit - cost.rail_soft_limit)
    ratio = distance / width
    value = cost.rail_weight * ratio**4
    gradient = 4.0 * cost.rail_weight * ratio**3 / width * np.sign(x)
    hessian = 12.0 * cost.rail_weight * ratio**2 / (width * width)
    return float(value), float(gradient), float(hessian)


def stage_cost(state: Array, action: float, cost: QuadraticTrajectoryCost, n_links: int) -> float:
    state_x = wrapped_state(state, n_links) if cost.wrap_angles else np.asarray(state, dtype=np.float64)
    x = state_x if cost.stage_target is None else state_x - np.asarray(cost.stage_target)
    rail, _, _ = _rail_cost_derivatives(float(state_x[0]), cost)
    state_value = (x @ cost.stage_state @ x if cost.stage_factor is None else
                   np.sum((cost.stage_factor @ x) ** 2))
    return float(
        0.5 * state_value
        + 0.5 * cost.control * float(action) ** 2
        + rail
    )


def terminal_cost(state: Array, cost: QuadraticTrajectoryCost, n_links: int) -> float:
    state_x = wrapped_state(state, n_links) if cost.wrap_angles else np.asarray(state, dtype=np.float64)
    x = state_x
    if cost.terminal_target is not None:
        x = x - np.asarray(cost.terminal_target, dtype=np.float64)
    rail, _, _ = _rail_cost_derivatives(float(state_x[0]), cost)
    if cost.terminal_factor is not None:
        residual = cost.terminal_factor @ x
        return float(0.5 * (residual @ residual) + rail)
    return float(0.5 * x @ cost.terminal_state @ x + rail)


def rollout(
    transition: Callable[[Array, float], Array],
    initial_state: Array,
    controls: Array,
    cost: QuadraticTrajectoryCost,
    n_links: int,
    *,
    running_costs=None,
) -> tuple[Array, float]:
    controls = np.asarray(controls, dtype=np.float64)
    costs = resolve_running_costs(cost, len(controls), running_costs)
    states = np.empty((len(controls) + 1, len(initial_state)), dtype=np.float64)
    states[0] = initial_state
    total = 0.0
    for step, action in enumerate(controls):
        total += stage_cost(states[step], float(action), costs[step], n_links)
        states[step + 1] = transition(states[step], float(action))
        if not np.all(np.isfinite(states[step + 1])):
            return states, 1e30
    total += terminal_cost(states[-1], cost, n_links)
    return states, float(total)


def resolve_running_costs(cost, steps, running_costs=None):
    """Freeze a stage schedule shared by rollout and quadratic refinement."""
    costs = (cost,) * steps if running_costs is None else tuple(running_costs)
    if len(costs) != steps or not all(isinstance(item, QuadraticTrajectoryCost) for item in costs):
        raise ValueError("running cost schedule must contain one trajectory cost per action")
    return costs


def _cost_derivatives(
    state: Array,
    action: float,
    cost: QuadraticTrajectoryCost,
    n_links: int,
) -> tuple[Array, float, Array, float]:
    state_x = wrapped_state(state, n_links) if cost.wrap_angles else np.asarray(state, dtype=np.float64)
    x = state_x if cost.stage_target is None else state_x - np.asarray(cost.stage_target)
    lx = (cost.stage_state @ x if cost.stage_factor is None else
          cost.stage_factor.T @ (cost.stage_factor @ x))
    lxx = cost.stage_state.copy()
    _, rail_gradient, rail_hessian = _rail_cost_derivatives(float(state_x[0]), cost)
    lx[0] += rail_gradient
    lxx[0, 0] += rail_hessian
    return lx, cost.control * float(action), lxx, float(cost.control)


def _terminal_derivatives(
    state: Array,
    cost: QuadraticTrajectoryCost,
    n_links: int,
) -> tuple[Array, Array]:
    state_x = wrapped_state(state, n_links) if cost.wrap_angles else np.asarray(state, dtype=np.float64)
    x = state_x
    if cost.terminal_target is not None:
        x = x - np.asarray(cost.terminal_target, dtype=np.float64)
    vx = (cost.terminal_state @ x if cost.terminal_factor is None else
          cost.terminal_factor.T @ (cost.terminal_factor @ x))
    vxx = cost.terminal_state.copy()
    _, rail_gradient, rail_hessian = _rail_cost_derivatives(float(state_x[0]), cost)
    vx[0] += rail_gradient
    vxx[0, 0] += rail_hessian
    return vx, vxx


def scalar_box_policy(
    qu: float,
    quu: float,
    qux: Array,
    control: float,
) -> tuple[float, Array, bool]:
    if not np.isfinite(quu) or quu <= 0.0:
        raise np.linalg.LinAlgError("non-positive control curvature")
    unconstrained = -float(qu) / float(quu)
    lower = -1.0 - float(control)
    upper = 1.0 - float(control)
    feedforward = float(np.clip(unconstrained, lower, upper))
    active = bool(feedforward != unconstrained)
    feedback = (
        np.zeros_like(np.asarray(qux, dtype=np.float64))
        if active
        else -np.asarray(qux, dtype=np.float64) / float(quu)
    )
    return feedforward, feedback, active


def _backward_pass(
    transition: MujocoTransition,
    states: Array,
    controls: Array,
    cost: QuadraticTrajectoryCost,
    *,
    regularization: float,
    state_epsilon: float,
    action_epsilon: float,
) -> tuple[Array, Array, Array]:
    horizon = len(controls)
    nx = states.shape[1]
    feedforward = np.empty(horizon, dtype=np.float64)
    feedback = np.empty((horizon, nx), dtype=np.float64)
    active_constraints = np.empty(horizon, dtype=np.bool_)
    vx, vxx = _terminal_derivatives(states[-1], cost, transition.env.n)

    for step in range(horizon - 1, -1, -1):
        a, b = transition.linearize(
            states[step],
            float(controls[step]),
            state_epsilon=state_epsilon,
            action_epsilon=action_epsilon,
        )
        lx, lu, lxx, luu = _cost_derivatives(
            states[step], float(controls[step]), cost, transition.env.n
        )
        qx = lx + a.T @ vx
        qu = float(lu + (b.T @ vx).item())
        qxx = lxx + a.T @ vxx @ a
        quu = float(luu + (b.T @ vxx @ b).item() + regularization)
        qux = (b.T @ vxx @ a).reshape(-1)
        k, gain, active = scalar_box_policy(qu, quu, qux, float(controls[step]))
        feedforward[step] = k
        feedback[step] = gain
        active_constraints[step] = active
        vx = qx + gain * (quu * k + qu) + qux * k
        vxx = qxx + quu * np.outer(gain, gain) + np.outer(gain, qux) + np.outer(qux, gain)
        vxx = 0.5 * (vxx + vxx.T)
    return feedforward, feedback, active_constraints


def optimize_ilqr(
    transition: MujocoTransition,
    initial_state: Array,
    initial_controls: Array,
    cost: QuadraticTrajectoryCost,
    *,
    max_iterations: int = 40,
    state_epsilon: float = 1e-5,
    action_epsilon: float = 1e-4,
    tolerance: float = 1e-5,
) -> ILQRResult:
    controls = np.clip(np.asarray(initial_controls, dtype=np.float64), -1.0, 1.0)
    states, current_cost = rollout(transition, initial_state, controls, cost, transition.env.n)
    regularization = 1e-4
    history: list[dict[str, float | int | bool]] = []
    converged = False
    feedback = np.zeros((len(controls), len(initial_state)), dtype=np.float64)
    active_constraints = np.zeros(len(controls), dtype=np.bool_)

    for iteration in range(max_iterations):
        accepted = False
        try:
            feedforward, candidate_feedback, candidate_active_constraints = _backward_pass(
                transition,
                states,
                controls,
                cost,
                regularization=regularization,
                state_epsilon=state_epsilon,
                action_epsilon=action_epsilon,
            )
        except np.linalg.LinAlgError:
            regularization = min(1e12, regularization * 10.0)
            history.append(
                {
                    "iteration": iteration + 1,
                    "cost": float(current_cost),
                    "accepted": False,
                    "regularization": float(regularization),
                }
            )
            continue

        previous_cost = current_cost
        for alpha in (1.0, 0.5, 0.25, 0.1, 0.05, 0.01):
            candidate_controls = np.empty_like(controls)
            candidate_states = np.empty_like(states)
            candidate_states[0] = initial_state
            candidate_cost = 0.0
            for step in range(len(controls)):
                error = transition.difference(candidate_states[step], states[step])
                candidate_controls[step] = np.clip(
                    controls[step] + alpha * feedforward[step] + candidate_feedback[step] @ error,
                    -1.0,
                    1.0,
                )
                candidate_cost += stage_cost(
                    candidate_states[step],
                    float(candidate_controls[step]),
                    cost,
                    transition.env.n,
                )
                candidate_states[step + 1] = transition(
                    candidate_states[step], float(candidate_controls[step])
                )
            candidate_cost += terminal_cost(candidate_states[-1], cost, transition.env.n)
            if np.isfinite(candidate_cost) and candidate_cost < current_cost:
                controls = candidate_controls
                states = candidate_states
                current_cost = float(candidate_cost)
                feedback = candidate_feedback
                active_constraints = candidate_active_constraints
                regularization = max(1e-9, regularization / 3.0)
                accepted = True
                break
        if not accepted:
            regularization = min(1e12, regularization * 10.0)
        relative_improvement = (previous_cost - current_cost) / max(1.0, abs(previous_cost))
        history.append(
            {
                "iteration": iteration + 1,
                "cost": float(current_cost),
                "accepted": bool(accepted),
                "relative_improvement": float(relative_improvement),
                "regularization": float(regularization),
                "active_control_steps": int(np.count_nonzero(candidate_active_constraints)),
            }
        )
        if accepted and relative_improvement < tolerance:
            converged = True
            break

    try:
        _, feedback, active_constraints = _backward_pass(
            transition,
            states,
            controls,
            cost,
            regularization=regularization,
            state_epsilon=state_epsilon,
            action_epsilon=action_epsilon,
        )
    except np.linalg.LinAlgError:
        pass
    return ILQRResult(
        controls=controls,
        states=states,
        feedback_gains=feedback,
        cost=float(current_cost),
        iterations=len(history),
        converged=converged,
        active_control_steps=int(np.count_nonzero(active_constraints)),
        history=history,
    )
